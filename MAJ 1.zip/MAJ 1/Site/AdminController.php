<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests\UserRequest;
use App\Http\Requests;


use App\User;
use App\Agence;
use App\Courtier;
use App\Profile;
use App\Site;
use App\Equipeuser;
use App\Ip;

use Auth;
use DB;

class AdminController extends Controller
{
    
    
    public function editRespSite($id)
    {
        //$adminsite  = User::find($id);

        $adminsite    = Auth::user();

        return view('sitesfiles.admins.editRespSite',['adminsite'=> $adminsite]);

    }

    public function addRespEquipe()
    {
        
        $user          = Auth::user();
        
        $site          = Site::find($user->site->id);
        
        $equipes       = $site->equipes;
    

        return view('sitesfiles.admins.addRespEquipe',['site' => $site, 'equipes' => $equipes]);

    }

    public function storeRespEquipe(Request $request)
    {
        
        $user    = Auth::user();
        
        $site    = Site::find($user->site->id);
        
        $equipes = $site->equipes;
        
        $profile = Profile::whereSlug('equipe')->first();
        
        $equipeResp = new User;
                   
        $equipeResp->nom         = $request->get('nom');
        $equipeResp->prenom      = $request->get('prenom');
        $equipeResp->login       = $request->get('login');
        $equipeResp->email       = $request->get('email');
        $equipeResp->tel         = $request->get('tel');
        $equipeResp->fax         = $request->get('fax');
        $equipeResp->courtier_id = $user->courtier_id;
        $equipeResp->agence_id   = $user->agence_id;
        $equipeResp->site_id     = $user->site_id;
        $equipeResp->profile_id  = $profile->id;
        $equipeResp->active      = 1;

        if($request->has('password')) 
        {    
           $equipeResp->password  = bcrypt($request->get('password'));
        }

        $equipeResp->save();

        $ip = new Ip;
        $ip->ip_internet = $request->ip();

        $equipeResp->ips()->save($ip);

        $equipeIdsResp  = $equipeResp->userEquipe()->where('equipe_user.active', 1)->get()->lists('id')->toArray();

        //$idequipe = $equipeResp->userEquipe()->first()->pivot->equipe_id;

        if($request->has('equipeCheck')){

            $equipesId = $request->get('equipeCheck');

            foreach ($equipesId as $equipe_id) {

                if(!in_array($equipe_id, $equipeIdsResp)){

                    $equipeUser = new Equipeuser;
                        $equipeUser->user_id    = $equipeResp->id;
                        $equipeUser->equipe_id  = $equipe_id;
                        $equipeUser->date_debut = date('Y-m-d');
                        $equipeUser->date_fin   = '0000-00-00';
                        $equipeUser->active     = 1;
                    $equipeUser->save();

                }

            }

            DB::table('equipe_user')
                ->where('user_id', $equipeResp->id)
                ->whereNotIn('equipe_id', $equipesId)
                ->whereActive(1)
                ->update([ 'date_fin' => date('Y-m-d'), 'active' => 0 ]);


        }else{

            DB::table('equipe_user')
                ->where('user_id', $equipeResp->id)
                ->whereActive(1)
                ->update([ 'date_fin' => date('Y-m-d'), 'active' => 0 ]);

        }

        return redirect('site/site/equipe/showResp/'.$equipeResp->id);

    }

    public function editRespEquipe($id)
    {
        
        $user         = Auth::user();
        
        $site         = Site::find($user->site->id);
        
        $equipes      = $site->equipes;
        
        $adminequipe  = User::where('id', $id)
                                ->whereHas('profile', function($q){
                                    $q->whereSlug('equipe');
                                })
                                ->where('site_id', $site->id)
                                ->first();

        $equipeIdsResp  = $adminequipe->userEquipe()->where('equipe_user.active', 1)->get()->lists('id');

        return view('sitesfiles.admins.editRespEquipe',['adminequipe' => $adminequipe, 'site' => $site, 'equipes' => $equipes, 'equipeIdsResp' => $equipeIdsResp]);

    }

    public function updateRespSite(UserRequest $request, $id)
    {

        //$user       = User::find($id);
        $user         = Auth::user();
        $user->nom    = $request->get('nom');
        $user->prenom = $request->get('prenom');
        $user->login  = $request->get('login');
        $user->email  = $request->get('email');
        $user->id_appel  = $request->get('idAppel');


        if($request->has('password')) 
        {    
           $user->password = bcrypt($request->get('password'));
        }

        $user->save();

        return redirect('site/site/showResp/'.$user->site_id);

    }

    public function updateRespEquipe(UserRequest $request,$id)
    {

        // return $request->all();

        $user       = Auth::user();
        
        $site       = Site::find($user->site->id);
        
        $equipes    = $site->equipes;
        
        $equipeResp = User::where('id', $id)
                                ->whereHas('profile', function($q){
                                    $q->whereSlug('equipe');
                                })
                                ->where('site_id', $site->id)
                                ->first();

        $equipeResp->nom      = $request->get('nom');
        $equipeResp->prenom   = $request->get('prenom');
        $equipeResp->login    = $request->get('login');
        $equipeResp->email    = $request->get('email');
        $equipeResp->id_appel = $request->get('idAppel');

        if($request->has('password')) 
        {    
           $equipeResp->password  = bcrypt($request->get('password'));
        }

        $equipeResp->save();

        $equipeIdsResp  = $equipeResp->userEquipe()->where('equipe_user.active', 1)->get()->lists('id')->toArray();

        //$idequipe = $equipeResp->userEquipe()->first()->pivot->equipe_id;

        if($request->has('equipeCheck')){

            $equipesId = $request->get('equipeCheck');

            foreach ($equipesId as $equipe_id) {

                if(!in_array($equipe_id, $equipeIdsResp)){

                    $equipeUser = new Equipeuser;
                        $equipeUser->user_id    = $equipeResp->id;
                        $equipeUser->equipe_id  = $equipe_id;
                        $equipeUser->date_debut = date('Y-m-d');
                        $equipeUser->date_fin   = '0000-00-00';
                        $equipeUser->active     = 1;
                    $equipeUser->save();

                }

            }

            DB::table('equipe_user')
                ->where('user_id', $equipeResp->id)
                ->whereNotIn('equipe_id', $equipesId)
                ->whereActive(1)
                ->update([ 'date_fin' => date('Y-m-d'), 'active' => 0 ]);


        }else{

            DB::table('equipe_user')
                ->where('user_id', $equipeResp->id)
                ->whereActive(1)
                ->update([ 'date_fin' => date('Y-m-d'), 'active' => 0 ]);

        }

        return redirect('site/site/equipe/showResp/'.$equipeResp->id);

    }


    public function activeUser($id)
    {
        //$user  = User::find($id);
        $idsite       = Auth::user()->site->id;
        $user         = User::where('id',$id)
                            ->where('site_id',$idsite)
                            ->first();

        $value        = 0;
        
        if(count($user))
        {
            if($user->active)
            {
                $user->active = 0;
                $value        = 0;
            }
            else
            {
                $user->active = 1;
                $value        = 1;
            }

            $user->save();
            $msg = 'ok';

        }
        else
        {
            $msg = 'notok';
        }

        return ['msg'=>$msg , 'value'=>$value];    


    }
    

}
