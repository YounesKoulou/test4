<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;

use App\Http\Requests\ConseillerRequest;

use App\Http\Requests;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;

use App\Events\EventInitialiserClassementSante; 
use App\Events\EventConfigTauxCommUserSante;

use App\Profile;
use \Carbon;
use App\User;
use App\Ip;

use App\Equipe;

class ConseillerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $idequipe          = Input::get('id');
        $equipe            = Equipe::find($idequipe);
        
        return view('sitesfiles.conseillers.create',['equipe' => $equipe]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ConseillerRequest $request)
    {
        //dd($request);

        $idequipe                      = $request->get('idequipe');
        $idsite                        = Auth::user()->site->id;
        $equipe                        = Equipe::where('id',$idequipe)
                                            ->where('site_id',$idsite)
                                            ->first();
                                           
        if($equipe)
        {    
        //$equipe                        = Equipe::find($idequipe);
        //return $equipe;
        $site                          = $equipe->site;
        //return $site;
        $agence                        = $site->agence;


        $conseiller                    = new User;
        $conseiller->nom               = $request->get('nom');
        $conseiller->prenom            = $request->get('prenom');
        $conseiller->login             = $request->get('login');
        $conseiller->profile_id        = Profile::where('nom','Conseiller')
                                                ->first()->id;
        $conseiller->email             = $request->get('email');
        $conseiller->id_appel          = $request->get('idAppel'); 
        $conseiller->password          = bcrypt($request->get('password'));
        $conseiller->objectif          = $request->get('objectif');
        $conseiller->site_id           = $site->id;
        $conseiller->agence_id         = $site->agence_id;
        $conseiller->courtier_id       = $agence->courtier_id;
        $conseiller->active            = 1;

        if($conseiller->save() and $request->get('check_produit')){

            $idsConseillerProduit      = $request->get('check_produit');
            $conseiller->produits()->attach($idsConseillerProduit, ['active' => 1]);
        }   

        $ip = new Ip;
        $ip->ip_internet = $request->ip();

        $conseiller->ips()->save($ip);

        $todayDate                     = date('Y-m-d');

        //return $equipe->attachConseillers;

        $equipe->equipeConseillers()->attach($conseiller->id,['date_debut' => $todayDate,'active' => 1, 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()]);

        //$conseiller->userEquipe()->attach($idequipe,['date_debut' => $todayDate]);

        //Initialser la ligne de classement du mois en cours santé

        $tabInfosInitClassement = ['conseiller'        => $conseiller];

        event(new EventInitialiserClassementSante($tabInfosInitClassement));

        //Initialser les lignes des taux commissions des gammes santé

        $tabInfosConfigTauxComm = ['conseiller'        => $conseiller];

        event(new EventConfigTauxCommUserSante($tabInfosConfigTauxComm));

        return redirect('site/site/equipe/'.$idequipe);
        }
        else
        {
            echo "error";
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //$conseiller          = User::find($id);
        $conseiller            = User::where('id',$id)
                                       ->where('site_id',Auth::user()->site_id)
                                       ->where('profile_id',7)
                                       ->first();
        return view('sitesfiles.conseillers.show',['conseiller'=> $conseiller]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //$conseiller          = User::find($id);
        $conseiller            = User::where('id',$id)
                                       ->where('site_id',Auth::user()->site_id)
                                       ->where('profile_id',7)
                                       ->first();
        return view('sitesfiles.conseillers.edit',['conseiller'=> $conseiller]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ConseillerRequest $request, $id)
    {
        //$conseiller                    = User::find($id);
        $conseiller            = User::where('id',$id)
                                       ->where('site_id',Auth::user()->site_id)
                                       ->where('profile_id',7)
                                       ->first();
        $conseiller->nom               = $request->get('nom');
        $conseiller->prenom            = $request->get('prenom');
        $conseiller->login             = $request->get('login');
        $conseiller->email             = $request->get('email');
        $conseiller->objectif          = $request->get('objectif');
        $conseiller->id_appel          = $request->get('idAppel'); 


        if($request->has('password'))
        {
            $conseiller->password      = bcrypt($request->get('password'));
        }

        if($conseiller->save()){

            $idsConseillerProduit = ($request->has('check_produit') ?  $request->get('check_produit') : []);            
            $conseiller->produits()->sync($idsConseillerProduit, ['active' => 1]);
            
        } 

        return redirect('site/site/equipe/conseiller/'.$conseiller->id);
    }

    public function activeUser($id)
    {
        //$user  = User::find($id);
        $user                   = User::where('id',$id)
                                       ->where('site_id',Auth::user()->site_id)
                                       ->where('profile_id',7)
                                       ->first();
        
        if(count($user))
        {
            if($user->active)
            {
                $user->active = 0;
                $value        = 0;
            }
            else
            {
                $user->active = 1;
                $value        = 1;
            }

            $user->save();
            $msg = 'ok';

        }
        else
        {
            $msg = 'notok';
        }

        return ['msg'=>$msg , 'value'=>$value];    


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
