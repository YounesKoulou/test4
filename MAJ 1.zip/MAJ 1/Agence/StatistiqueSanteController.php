<?php

namespace App\Http\Controllers\Agence;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;


use DB, Auth, Carbon\carbon;

use App\Groupestatut, App\Messagerie, App\Produit, App\Equipeuser, App\Site, App\User;

class StatistiqueSanteController extends Controller
{
    
    private $dateDebut;
    private $dateFin;
    private $dt;
    private $produit;

    public function __construct() {

        $this->dt               = Carbon::create((int)date('Y'), (int)date('m'), (int)date('d'), 23, 59, 59);  
        $this->dateDebut        = '';
        $this->dateFin          = $this->dt->toDateString().' 23:59:59'; 
        $this->produit          = 'fichesantes';
        $this->idProduit        = Produit::whereSlug('sante')->first()->id;
    }


    public function getstatusContrat() {
        return Groupestatut::where('slug', 'contrats')->first()->getStatus($this->idProduit)->lists('id');
    }

    public function getstatusDevis() {
        return Groupestatut::where('slug', 'devis')->first()->getStatus($this->idProduit)->lists('id');
    }

    public function getstatusLeads() {
        return Groupestatut::where('slug', 'leads')->first()->getStatus($this->idProduit)->lists('id');
    }


     public function filterOptions(Request $request) {

                switch ($request->get('option')) {
                   
                    case "option1":
                        $this->dateDebut = $this->dt->toDateString().' 00:00:00';
                        break;
                    case "option2":
                        $this->dateDebut = $this->dt->subDay()->toDateString().' 00:00:00';
                        break;
                    case "option3":
                        $this->dateDebut = $this->dt->subWeek()->toDateString().' 00:00:00';
                        break;
                    case "option4":
                        $this->dateDebut = $this->dt->subMonth()->toDateString().' 00:00:00';
                        break;
                    case "option5":
                        $this->dateDebut = $this->dt->subYear()->toDateString().' 00:00:00';
                        break;
                    default :
                        $this->dateFin    = $request->get('dateFin').' 23:59:59'; 
                        $this->dateDebut  = $request->get('dateDebut').' 00:00:00';
                        break;
                }


                if(!empty($request->get('dateDebut'))) {
                    $this->dateDebut    = $request->get('dateDebut').' 00:00:00'; 
                }

                 if(!empty($request->get('dateFin'))) {
                    $this->dateFin    = $request->get('dateFin').' 23:59:59'; 
                }

             $this->produit = $request->get('produit');

     }


     public function index(Request $request) {
         $produits = Produit::where('active', 1)->get();
         $sites    = Auth::user()->agence->sites()->where('sites.active', 1)->get();
         $equipes  = Auth::user()->agence->equipes()->where('equipes.active', 1)->get();
         return view('agencesfiles.statistiques.index', ['equipes' => $equipes, 'sites' => $sites, 'produits' => $produits]);
     }


     public function nombreFicheParStatut(Request $request) {
           
        $this->filterOptions($request);

        $user      = Auth::user();
        
        $fiches = DB::table($this->produit)
                                ->join('statuts',"statut_id",'=','statuts.id')
                                ->where(function($queryFiche) use ($request, $user){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);
                                    
                                    if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            (!$request->has('equipe') or $request->get('equipe')==0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qS) use ($request) {
                                            $qS->where('dispatchable_id', $request->get('site'));
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                        $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qE) use ($request) {
                                            $qE->where('dispatchable_id', $request->get('equipe'));
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                    ){

                                        $queryFiche->where(function($qC) use ($request) {
                                            $qC->where('equipe_user_id', $request->get('conseiller'));
                                            $qC->where('dispatchable_type', "equipe");
                                        });

                                    } else {

                                        $siteIds   = $user->agence->sites->lists('id');
            
                                        $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                        $queryFiche->where(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                        $queryFiche->orWhere(function($qS) use ($siteIds) {
                                            $qS->whereIn('dispatchable_id', $siteIds);
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $queryFiche->orWhere(function($qA) use ($user)  {
                                            $qA->where('dispatchable_id', $user->agence->id);
                                            $qA->where('dispatchable_type', "agence");
                                        });

                                    }

                                })
                                ->whereIn('statut_id', $this->getstatusLeads())
                                ->where($this->produit . ".active",1)
                                //->whereIn('equipe_user_id', $equipeUserIds)
                                ->select(DB::raw('count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'), 'libelle')
                                ->groupBy("statut_id")
                                ->get(); 
            
            $data = NULL;
            if($fiches){
                foreach($fiches as $fiche) {
                    $data['ficheParStatut'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
                    $data['chiffreParStatut'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->nbrefiches];
                }
            }

            return json_encode($data);

     }



    public function nombreFicheParRegime(Request $request) {

        $this->filterOptions($request);

        $user      = Auth::user();
        
        $fiches = DB::table($this->produit)
                        ->join('saregimes',"saregime_id",'=','saregimes.id')
                        ->where(function($queryFiche) use ($request, $user){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);
                                    
                                    if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            (!$request->has('equipe') or $request->get('equipe')==0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qS) use ($request) {
                                            $qS->where('dispatchable_id', $request->get('site'));
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                        $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qE) use ($request) {
                                            $qE->where('dispatchable_id', $request->get('equipe'));
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                    ){

                                        $queryFiche->where(function($qC) use ($request) {
                                            $qC->where('equipe_user_id', $request->get('conseiller'));
                                            $qC->where('dispatchable_type', "equipe");
                                        });

                                    } else {

                                        $siteIds   = $user->agence->sites->lists('id');
            
                                        $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                        $queryFiche->where(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                        $queryFiche->orWhere(function($qS) use ($siteIds) {
                                            $qS->whereIn('dispatchable_id', $siteIds);
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $queryFiche->orWhere(function($qA) use ($user)  {
                                            $qA->where('dispatchable_id', $user->agence->id);
                                            $qA->where('dispatchable_type', "agence");
                                        });

                                    }

                                })
                        ->where($this->produit . ".active",1)
                        //->whereIn('equipe_user_id',$equipeUserIds)
                        ->select(DB::raw('count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'), 'saregimes.libelle')
                        ->groupBy("saregime_id")
                        ->get(); 

            
            $data = NULL;
            foreach($fiches as $fiche) {
                $data['ficheParRegime'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
                $data['chiffreParRegime'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->nbrefiches];
            }

            return json_encode($data);

     }


     public function nombreFicheParCompagnie(Request $request) {
          
        $this->filterOptions($request);

        $user      = Auth::user();
        
        $fiches = DB::table($this->produit)
                                ->join('sagammes',"sagamme_id",'=','sagammes.id')
                                ->join('sacompagnies',"sagammes.sacompagnie_id",'=','sacompagnies.id')
                                ->where(function($queryFiche) use ($request, $user){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);
                                    
                                    if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            (!$request->has('equipe') or $request->get('equipe')==0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qS) use ($request) {
                                            $qS->where('dispatchable_id', $request->get('site'));
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                        $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qE) use ($request) {
                                            $qE->where('dispatchable_id', $request->get('equipe'));
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                    ){

                                        $queryFiche->where(function($qC) use ($request) {
                                            $qC->where('equipe_user_id', $request->get('conseiller'));
                                            $qC->where('dispatchable_type', "equipe");
                                        });

                                    } else {

                                        $siteIds   = $user->agence->sites->lists('id');
            
                                        $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                        $queryFiche->where(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                        $queryFiche->orWhere(function($qS) use ($siteIds) {
                                            $qS->whereIn('dispatchable_id', $siteIds);
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $queryFiche->orWhere(function($qA) use ($user)  {
                                            $qA->where('dispatchable_id', $user->agence->id);
                                            $qA->where('dispatchable_type', "agence");
                                        });

                                    }

                                })
                                ->whereIn('statut_id', $this->getstatusContrat())
                                ->where($this->produit . ".active",1)
                                //->whereIn('equipe_user_id', $equipeUserIds)
                                ->select(DB::raw('count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'), 'sacompagnies.libelle')
                                ->groupBy("sacompagnie_id")
                                ->get(); 
            
            $data = NULL;

            if($fiches){
                foreach($fiches as $fiche) {
                    $data['ficheParCompagnie'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
                }
            }

            return json_encode($data);
     }



     public function infoGenerale(Request $request) {

            $this->filterOptions($request);

            $user      = Auth::user();
           
            $fichesLead = DB::table($this->produit)
                                ->where(function($queryFiche) use ($request, $user){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);
                                    
                                    if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            (!$request->has('equipe') or $request->get('equipe')==0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qS) use ($request) {
                                            $qS->where('dispatchable_id', $request->get('site'));
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                        $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qE) use ($request) {
                                            $qE->where('dispatchable_id', $request->get('equipe'));
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                    ){

                                        $queryFiche->where(function($qC) use ($request) {
                                            $qC->where('equipe_user_id', $request->get('conseiller'));
                                            $qC->where('dispatchable_type', "equipe");
                                        });

                                    } else {

                                        $siteIds   = $user->agence->sites->lists('id');
            
                                        $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                        $queryFiche->where(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                        $queryFiche->orWhere(function($qS) use ($siteIds) {
                                            $qS->whereIn('dispatchable_id', $siteIds);
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $queryFiche->orWhere(function($qA) use ($user)  {
                                            $qA->where('dispatchable_id', $user->agence->id);
                                            $qA->where('dispatchable_type', "agence");
                                        });

                                    }

                                })
                                ->whereIn('statut_id', $this->getstatusLeads())
                                ->where($this->produit . ".active",1)
                                //->whereIn('equipe_user_id',  $equipeUserIds)
                                ->select(DB::raw('count(*) as nombreLead, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreLead'))
                                ->first(); 


            $fichesDeclare = DB::table($this->produit)
                                ->where(function($queryFiche) use ($request, $user){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);
                                    
                                    if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            (!$request->has('equipe') or $request->get('equipe')==0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qS) use ($request) {
                                            $qS->where('dispatchable_id', $request->get('site'));
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                        $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qE) use ($request) {
                                            $qE->where('dispatchable_id', $request->get('equipe'));
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                    ){

                                        $queryFiche->where(function($qC) use ($request) {
                                            $qC->where('equipe_user_id', $request->get('conseiller'));
                                            $qC->where('dispatchable_type', "equipe");
                                        });

                                    } else {

                                        $siteIds   = $user->agence->sites->lists('id');
            
                                        $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                        $queryFiche->where(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                        $queryFiche->orWhere(function($qS) use ($siteIds) {
                                            $qS->whereIn('dispatchable_id', $siteIds);
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $queryFiche->orWhere(function($qA) use ($user)  {
                                            $qA->where('dispatchable_id', $user->agence->id);
                                            $qA->where('dispatchable_type', "agence");
                                        });

                                    }

                                })
                                ->whereIn('statut_id', $this->getstatusDevis())
                                ->where($this->produit . ".active",1)
                                //->whereIn('equipe_user_id',  $equipeUserIds)
                                ->select(DB::raw('count(*) as nombreDeclare, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreDeclare'))
                                ->first();

            $fichesReel = DB::table($this->produit)
                                ->where(function($queryFiche) use ($request, $user){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);
                                    
                                    if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            (!$request->has('equipe') or $request->get('equipe')==0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qS) use ($request) {
                                            $qS->where('dispatchable_id', $request->get('site'));
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                        $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qE) use ($request) {
                                            $qE->where('dispatchable_id', $request->get('equipe'));
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                    ){

                                        $queryFiche->where(function($qC) use ($request) {
                                            $qC->where('equipe_user_id', $request->get('conseiller'));
                                            $qC->where('dispatchable_type', "equipe");
                                        });

                                    } else {

                                        $siteIds   = $user->agence->sites->lists('id');
            
                                        $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                        $queryFiche->where(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                        $queryFiche->orWhere(function($qS) use ($siteIds) {
                                            $qS->whereIn('dispatchable_id', $siteIds);
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $queryFiche->orWhere(function($qA) use ($user)  {
                                            $qA->where('dispatchable_id', $user->agence->id);
                                            $qA->where('dispatchable_type', "agence");
                                        });

                                    }

                                })
                                ->whereIn('statut_id', $this->getstatusContrat())
                                ->where($this->produit . ".active",1)
                                //->whereIn('equipe_user_id',  $equipeUserIds)
                                ->select(DB::raw('count(*) as nombreReel, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreReel'))
                                ->first(); 

        $data['lead']    = $fichesLead;
        $data['declare'] = $fichesDeclare;
        $data['reel']    = $fichesReel;
        
        return json_encode($data);

     }



    //Statistique compagnie

    public function leadParCompagnie(Request $request) {
          
        $this->filterOptions($request);

        $user = Auth::user();

        $fiches = DB::table($this->produit)
                            ->join('sagammes',"sagamme_id",'=','sagammes.id')
                            ->join('sacompagnies',"sagammes.sacompagnie_id",'=','sacompagnies.id')
                            ->join('statuts', 'statut_id', '=', 'statuts.id')
                            ->join('groupestatuts', 'statuts.groupestatut_id', '=', 'groupestatuts.id')
                            ->where(function($queryFiche) use ($request, $user){

                                $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                $queryFiche->where("date_situation", '<=', $this->dateFin);
                                
                                if( ($request->has('site') and $request->get('site')!=0 ) 
                                        and
                                        (!$request->has('equipe') or $request->get('equipe')==0 )
                                        and
                                        (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                ){

                                    $queryFiche->where(function($qS) use ($request) {
                                        $qS->where('dispatchable_id', $request->get('site'));
                                        $qS->where('dispatchable_type', "site");
                                    });

                                    $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                    $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                        $qE->whereIn('dispatchable_id', $equipeIds);
                                        $qE->where('dispatchable_type', "equipe");
                                    });

                                }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                        and
                                        ($request->has('equipe') and $request->get('equipe')!=0 )
                                        and
                                        (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                ){

                                    $queryFiche->where(function($qE) use ($request) {
                                        $qE->where('dispatchable_id', $request->get('equipe'));
                                        $qE->where('dispatchable_type', "equipe");
                                    });

                                } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                        and
                                        ($request->has('equipe') and $request->get('equipe')!=0 )
                                        and
                                        ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                ){

                                    $queryFiche->where(function($qC) use ($request) {
                                        $qC->where('equipe_user_id', $request->get('conseiller'));
                                        $qC->where('dispatchable_type', "equipe");
                                    });

                                } else {

                                    $siteIds   = $user->agence->sites->lists('id');
        
                                    $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                    $queryFiche->where(function($qE) use ($equipeIds) {
                                        $qE->whereIn('dispatchable_id', $equipeIds);
                                        $qE->where('dispatchable_type', "equipe");
                                    });

                                    $queryFiche->orWhere(function($qS) use ($siteIds) {
                                        $qS->whereIn('dispatchable_id', $siteIds);
                                        $qS->where('dispatchable_type', "site");
                                    });

                                    $queryFiche->orWhere(function($qA) use ($user)  {
                                        $qA->where('dispatchable_id', $user->agence->id);
                                        $qA->where('dispatchable_type', "agence");
                                    });

                                }

                            })
                            ->whereIn("groupestatuts.slug", ['devis', 'contrats'])
                            ->where($this->produit . ".active",1)
                            //->whereIn('equipe_user_id',  $equipeUserIds)
                            ->select(DB::raw('sacompagnies.libelle as compagnie, sagammes.libelle as gamme, groupestatuts.slug as slug, count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'))
                            ->groupBy('sagammes.id',"groupestatuts.id")
                            ->orderBy("sacompagnies.libelle", "asc")
                            ->get();


        $fichesCompagnie = DB::table($this->produit)
                            ->join('sagammes',"sagamme_id",'=','sagammes.id')
                            ->join('sacompagnies',"sagammes.sacompagnie_id",'=','sacompagnies.id')
                            ->join('statuts', 'statut_id', '=', 'statuts.id')
                            ->join('groupestatuts', 'statuts.groupestatut_id', '=', 'groupestatuts.id')
                            ->where(function($queryFiche) use ($request, $user){

                                $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                $queryFiche->where("date_situation", '<=', $this->dateFin);
                                
                                if( ($request->has('site') and $request->get('site')!=0 ) 
                                        and
                                        (!$request->has('equipe') or $request->get('equipe')==0 )
                                        and
                                        (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                ){

                                    $queryFiche->where(function($qS) use ($request) {
                                        $qS->where('dispatchable_id', $request->get('site'));
                                        $qS->where('dispatchable_type', "site");
                                    });

                                    $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                    $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                        $qE->whereIn('dispatchable_id', $equipeIds);
                                        $qE->where('dispatchable_type', "equipe");
                                    });

                                }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                        and
                                        ($request->has('equipe') and $request->get('equipe')!=0 )
                                        and
                                        (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                ){

                                    $queryFiche->where(function($qE) use ($request) {
                                        $qE->where('dispatchable_id', $request->get('equipe'));
                                        $qE->where('dispatchable_type', "equipe");
                                    });

                                } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                        and
                                        ($request->has('equipe') and $request->get('equipe')!=0 )
                                        and
                                        ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                ){

                                    $queryFiche->where(function($qC) use ($request) {
                                        $qC->where('equipe_user_id', $request->get('conseiller'));
                                        $qC->where('dispatchable_type', "equipe");
                                    });

                                } else {

                                    $siteIds   = $user->agence->sites->lists('id');
        
                                    $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                    $queryFiche->where(function($qE) use ($equipeIds) {
                                        $qE->whereIn('dispatchable_id', $equipeIds);
                                        $qE->where('dispatchable_type', "equipe");
                                    });

                                    $queryFiche->orWhere(function($qS) use ($siteIds) {
                                        $qS->whereIn('dispatchable_id', $siteIds);
                                        $qS->where('dispatchable_type', "site");
                                    });

                                    $queryFiche->orWhere(function($qA) use ($user)  {
                                        $qA->where('dispatchable_id', $user->agence->id);
                                        $qA->where('dispatchable_type', "agence");
                                    });

                                }

                            })
                            ->whereIn("groupestatuts.slug", ['devis', 'contrats'])
                            ->where($this->produit . ".active",1)
                            //->whereIn('equipe_user_id', $equipeUserIds)
                            ->select(DB::raw('sacompagnies.libelle as compagnie, groupestatuts.slug as slug, count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'))
                            ->groupBy('sacompagnies.id',"groupestatuts.id")
                            ->orderBy("sacompagnies.libelle", "asc")
                            ->get(); 

        $data = $data1 = $dataPie = NULL;
        
        if($fiches){
            
            foreach ($fiches as $fiche) {

                    if(!isset($data[$fiche->compagnie . '-' . $fiche->gamme]['devis'])) {
                       $data[$fiche->compagnie . '-' . $fiche->gamme]['devis']    = 0;
                    }

                    if(!isset($data[$fiche->compagnie . '-' . $fiche->gamme]['contrats'])) {
                       $data[$fiche->compagnie . '-' . $fiche->gamme]['contrats'] = 0;
                    } 
                   
                 
                  $data[$fiche->compagnie . '-' . $fiche->gamme][$fiche->slug] = $fiche->nbrefiches;
                
            }

           
            $collection = collect($data);

            $gammes      = $collection->keys()->all();                           
            $devis1      = $collection->pluck('devis')->all();
            $contrats1   = $collection->pluck('contrats')->all();
            
           
        } 
 
        if($fichesCompagnie){
                
            foreach ($fichesCompagnie as $fiche) {

                    if(!isset($data1[$fiche->compagnie]['devis'])) {
                       $data1[$fiche->compagnie]['devis']    = 0;
                    }

                    if(!isset($data1[$fiche->compagnie]['contrats'])) {
                       $data1[$fiche->compagnie]['contrats'] = 0;
                    } 
                   
                   $data1[$fiche->compagnie][$fiche->slug] = $fiche->nbrefiches;
                
            }

            $collection = collect($data1);

            $compagnies     = $collection->keys()->all();                            
            $devis2         = $collection->pluck('devis')->all();
            $contrats2      = $collection->pluck('contrats')->all();
            
            //Traitement pie compagnie
            foreach ($compagnies as $index => $compagnie) {
                $dataPie['dataCompagniePie'][] = ['name' => $compagnie, 'y' => ($devis2[$index] + $contrats2[$index])];
            }

        } 

        return json_encode([
                            'gammes' => $gammes, 'devis1' => $devis1, 'contrats1' => $contrats1, 
                            'compagnies' => $compagnies, 'devis2' => $devis2, 'contrats2' => $contrats2,
                            'dataPie' => $dataPie
                        ]);


    }


    public function ficheParGroupPub(Request $request) {

        $this->filterOptions($request);

        $user = Auth::user();

        $fiches = DB::table($this->produit)
                                ->join('groupepub_provenance',"groupepub_provenance_id",'=','groupepub_provenance.id')
                                ->join('groupepubs',"groupepub_provenance.groupepub_id",'=','groupepubs.id')
                                ->where(function($queryFiche) use ($request, $user){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);
                                    
                                    if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            (!$request->has('equipe') or $request->get('equipe')==0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qS) use ($request) {
                                            $qS->where('dispatchable_id', $request->get('site'));
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                        $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qE) use ($request) {
                                            $qE->where('dispatchable_id', $request->get('equipe'));
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                    ){

                                        $queryFiche->where(function($qC) use ($request) {
                                            $qC->where('equipe_user_id', $request->get('conseiller'));
                                            $qC->where('dispatchable_type', "equipe");
                                        });

                                    } else {

                                        $siteIds   = $user->agence->sites->lists('id');
            
                                        $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                        $queryFiche->where(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                        $queryFiche->orWhere(function($qS) use ($siteIds) {
                                            $qS->whereIn('dispatchable_id', $siteIds);
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $queryFiche->orWhere(function($qA) use ($user)  {
                                            $qA->where('dispatchable_id', $user->agence->id);
                                            $qA->where('dispatchable_type', "agence");
                                        });

                                    }

                                })
                                ->where($this->produit . ".active",1)
                                //->whereIn('equipe_user_id',  $equipeUserIds)
                                ->select(DB::raw('count(*) as nbrefiches, SUM(groupepubs.cout) as chiffre'), 'groupepubs.nom as libelle')
                                ->groupBy("groupepub_id")
                                ->get(); 
            
            $data = NULL;
            if($fiches){
                foreach($fiches as $fiche) {
                    $data['ficheParGroupPub'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
                    $data['ficheParGroupPubPieNombre'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->nbrefiches];
                    $data['ficheParGroupPubPieCout'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->chiffre];

                }
            }

            return json_encode($data);
    }



    public function statistiqueConseillers(Request $request) {
          
       $this->filterOptions($request);

        $user = Auth::user();

        $fichesLead = DB::table($this->produit)
                                ->join('equipe_user',"equipe_user_id",'=','equipe_user.id')
                                ->join('users',"equipe_user.user_id",'=','users.id')
                                ->join('equipes',"equipe_user.equipe_id",'=','equipes.id')
                                ->where(function($queryFiche) use ($request, $user){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);
                                    
                                    if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            (!$request->has('equipe') or $request->get('equipe')==0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qS) use ($request) {
                                            $qS->where('dispatchable_id', $request->get('site'));
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                        $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qE) use ($request) {
                                            $qE->where('dispatchable_id', $request->get('equipe'));
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                    ){

                                        $queryFiche->where(function($qC) use ($request) {
                                            $qC->where('equipe_user_id', $request->get('conseiller'));
                                            $qC->where('dispatchable_type', "equipe");
                                        });

                                    } else {

                                        $siteIds   = $user->agence->sites->lists('id');
            
                                        $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                        $queryFiche->where(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                        $queryFiche->orWhere(function($qS) use ($siteIds) {
                                            $qS->whereIn('dispatchable_id', $siteIds);
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $queryFiche->orWhere(function($qA) use ($user)  {
                                            $qA->where('dispatchable_id', $user->agence->id);
                                            $qA->where('dispatchable_type', "agence");
                                        });

                                    }

                                })
                                ->whereIn('statut_id', $this->getstatusLeads())
                                ->where($this->produit . ".active",1)
                                //->whereIn('equipe_user_id',  $equipeUserIds)
                                ->where('equipe_user.active', 1)
                                ->select(DB::raw('users.nom as nom, users.prenom as prenom, users.photo, equipes.nom as equipe, count(*) as nombreLead, SUM(cout) as chiffreLead'))
                                ->groupBy('users.id')
                                ->orderBy('equipes.nom', 'asc')
                                ->get();

            foreach ($fichesLead as $key => $lead) {
                    
                if(!isset($partialTotal[$lead->equipe]['leads'])) {
                    $partialTotal[$lead->equipe]['leads'] = 0;
                }

                if(!isset($partialTotal[$lead->equipe]['chiffreLead'])) {
                    $partialTotal[$lead->equipe]['chiffreLead'] = 0;
                }

                $partialTotal[$lead->equipe]['leads'] += $lead->nombreLead;

                $partialTotal[$lead->equipe]['chiffreLead'] += round($lead->chiffreLead, 2);

                $data[$lead->prenom.' '.$lead->nom]['equipe']          = $lead->equipe;
                $data[$lead->prenom.' '.$lead->nom]['photo']           = $lead->photo;

                $data[$lead->prenom.' '.$lead->nom]['nbLead']          = $lead->nombreLead; 
                $data[$lead->prenom.' '.$lead->nom]['chiffreLead']     = $lead->chiffreLead; 

                $data[$lead->prenom.' '.$lead->nom]['nbDevis']         = 0;
                $data[$lead->prenom.' '.$lead->nom]['chiffreDevis']    = 0; 

                $data[$lead->prenom.' '.$lead->nom]['nbContrat']       = 0;
                $data[$lead->prenom.' '.$lead->nom]['chiffreContrat']  = 0; 
                                                     
            }


            $fichesDeclare = DB::table($this->produit)
                                ->join('equipe_user',"equipe_user_id",'=','equipe_user.id')
                                ->join('users',"equipe_user.user_id",'=','users.id')
                                ->join('equipes',"equipe_user.equipe_id",'=','equipes.id')
                                ->where(function($queryFiche) use ($request, $user){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);
                                    
                                    if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            (!$request->has('equipe') or $request->get('equipe')==0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qS) use ($request) {
                                            $qS->where('dispatchable_id', $request->get('site'));
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                        $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qE) use ($request) {
                                            $qE->where('dispatchable_id', $request->get('equipe'));
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                    ){

                                        $queryFiche->where(function($qC) use ($request) {
                                            $qC->where('equipe_user_id', $request->get('conseiller'));
                                            $qC->where('dispatchable_type', "equipe");
                                        });

                                    } else {

                                        $siteIds   = $user->agence->sites->lists('id');
            
                                        $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                        $queryFiche->where(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                        $queryFiche->orWhere(function($qS) use ($siteIds) {
                                            $qS->whereIn('dispatchable_id', $siteIds);
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $queryFiche->orWhere(function($qA) use ($user)  {
                                            $qA->where('dispatchable_id', $user->agence->id);
                                            $qA->where('dispatchable_type', "agence");
                                        });

                                    }

                                })
                                ->whereIn('statut_id', $this->getstatusDevis())
                                ->where($this->produit . ".active",1)
                                //->whereIn('equipe_user_id',  $equipeUserIds)
                                ->where('equipe_user.active', 1)
                                ->select(DB::raw('users.nom as nom, users.prenom as prenom, users.photo, equipes.nom as equipe, equipes.nom as equipe, count(*) as nombreDeclare, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreDeclare'))
                                ->groupBy('users.id')
                                ->orderBy('equipes.nom', 'asc')
                                ->get(); 

            foreach ($fichesDeclare as $key => $lead) {

                if(!isset($data[$lead->prenom.' '.$lead->nom]['nbLead'])) {
                    $data[$lead->prenom.' '.$lead->nom]['nbLead']      = 0;
                    $data[$lead->prenom.' '.$lead->nom]['chiffreLead'] = 0; 
                }

                if(!isset($partialTotal[$lead->equipe]['devis'])) {
                    $partialTotal[$lead->equipe]['devis'] = 0;
                }

                $partialTotal[$lead->equipe]['devis'] += $lead->nombreDeclare;

                if(!isset($partialTotal[$lead->equipe]['chiffreDevis'])) {
                    $partialTotal[$lead->equipe]['chiffreDevis'] = 0;
                }

                $partialTotal[$lead->equipe]['chiffreDevis'] += round($lead->chiffreDeclare, 2);

                $data[$lead->prenom.' '.$lead->nom]['equipe']          = $lead->equipe;
                $data[$lead->prenom.' '.$lead->nom]['photo']           = $lead->photo;
                
                $data[$lead->prenom.' '.$lead->nom]['nbDevis']         = $lead->nombreDeclare;
                $data[$lead->prenom.' '.$lead->nom]['chiffreDevis']    = round($lead->chiffreDeclare, 2); 

                $data[$lead->prenom.' '.$lead->nom]['nbContrat']       = 0;
                $data[$lead->prenom.' '.$lead->nom]['chiffreContrat']  = 0;

            }



            $fichesReel = DB::table($this->produit)
                                ->join('equipe_user',"equipe_user_id",'=','equipe_user.id')
                                ->join('users',"equipe_user.user_id",'=','users.id')
                                ->join('equipes',"equipe_user.equipe_id",'=','equipes.id')
                                ->where(function($queryFiche) use ($request, $user){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);
                                    
                                    if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            (!$request->has('equipe') or $request->get('equipe')==0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qS) use ($request) {
                                            $qS->where('dispatchable_id', $request->get('site'));
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $equipeIds  = Site::find($request->get('site'))->equipes()->where('equipes.active', 1)->lists('id');

                                        $queryFiche->orWhere(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    }else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            (!$request->has('conseiller') or $request->get('conseiller')==0 )
                                    ){

                                        $queryFiche->where(function($qE) use ($request) {
                                            $qE->where('dispatchable_id', $request->get('equipe'));
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                    } else if( ($request->has('site') and $request->get('site')!=0 ) 
                                            and
                                            ($request->has('equipe') and $request->get('equipe')!=0 )
                                            and
                                            ($request->has('conseiller') and $request->get('conseiller')!=0 )
                                    ){

                                        $queryFiche->where(function($qC) use ($request) {
                                            $qC->where('equipe_user_id', $request->get('conseiller'));
                                            $qC->where('dispatchable_type', "equipe");
                                        });

                                    } else {

                                        $siteIds   = $user->agence->sites->lists('id');
            
                                        $equipeIds = $user->agence->equipes()->where('equipes.active', 1)->lists('equipes.id');

                                        $queryFiche->where(function($qE) use ($equipeIds) {
                                            $qE->whereIn('dispatchable_id', $equipeIds);
                                            $qE->where('dispatchable_type', "equipe");
                                        });

                                        $queryFiche->orWhere(function($qS) use ($siteIds) {
                                            $qS->whereIn('dispatchable_id', $siteIds);
                                            $qS->where('dispatchable_type', "site");
                                        });

                                        $queryFiche->orWhere(function($qA) use ($user)  {
                                            $qA->where('dispatchable_id', $user->agence->id);
                                            $qA->where('dispatchable_type', "agence");
                                        });

                                    }

                                })
                                ->whereIn('statut_id', $this->getstatusContrat())
                                ->where($this->produit . ".active",1)
                                //->whereIn('equipe_user_id',  $equipeUserIds)
                                ->where('equipe_user.active', 1)
                                ->select(DB::raw('users.nom as nom, users.prenom as prenom, users.photo, equipes.nom as equipe, equipes.nom as equipe, count(*) as nombreReel, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreReel'))
                                ->groupBy('users.id')
                                ->orderBy('equipes.nom', 'asc')
                                ->get();
            

            foreach ($fichesReel as $key => $lead) {
                
                $data[$lead->prenom.' '.$lead->nom]['equipe']           = $lead->equipe;
                $data[$lead->prenom.' '.$lead->nom]['photo']            = $lead->photo;

                $data[$lead->prenom.' '.$lead->nom]['nbContrat']        = $lead->nombreReel;
                $data[$lead->prenom.' '.$lead->nom]['chiffreContrat']   = round($lead->chiffreReel, 2);

                if(!isset($partialTotal[$lead->equipe]['contrats'])) {
                    $partialTotal[$lead->equipe]['contrats'] = 0;
                }

                $partialTotal[$lead->equipe]['contrats'] += $lead->nombreReel;

                if(!isset($partialTotal[$lead->equipe]['chiffreContrats'])) {
                    $partialTotal[$lead->equipe]['chiffreContrats'] = 0;
                }   

                $partialTotal[$lead->equipe]['chiffreContrats'] += round($lead->chiffreReel, 2);
                
                if(!isset($data[$lead->prenom.' '.$lead->nom]['nbDevis'])) {
                    $data[$lead->prenom.' '.$lead->nom]['nbDevis']         = 0;
                }

                if(!isset($data[$lead->prenom.' '.$lead->nom]['chiffreDevis'])) {
                    $data[$lead->prenom.' '.$lead->nom]['chiffreDevis']    = 0; 
                }

                 if(!isset($data[$lead->prenom.' '.$lead->nom]['nbLead'])) {
                    $data[$lead->prenom.' '.$lead->nom]['nbLead']      = 0;
                    $data[$lead->prenom.' '.$lead->nom]['chiffreLead'] = 0; 
                }
                

            }
        
        return json_encode(['data' => collect($data)->sortBy('equipe'), 'partials' => $partialTotal]);

    }

     
     //Fonction pour récupérer les equipes en ajax
    function getEquipe(Request $request) {
        
         if($request->get('id') > 0){
            
            $equipeUser  = '';
            $listEquipes = [];
            $conseillers = [];
            $listConseillers = [];

            $equipes = Site::find($request->get('id'))->equipes()->where('equipes.active', 1)->lists('id', 'nom');

            $conseillers  = Equipeuser::whereIn('equipe_id', $equipes)->whereActive(1)->get();

            foreach($conseillers as $conseiller) {
                $listConseillers[$conseiller->id] = [$conseiller->equipe->nom, $conseiller->user->prenom . ' ' . $conseiller->user->nom];
            }
            
            return json_encode(['equipes' => $equipes, 'conseillers' => $conseillers]);

         }

         return json_encode(Auth::user()->agence->equipes()->where('equipes.active', 1)->lists('equipes.id', 'equipes.nom'));
           
    }



}
