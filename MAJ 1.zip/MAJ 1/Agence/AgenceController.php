<?php

namespace App\Http\Controllers\Agence;

use App\Http\Controllers\Controller;

use App\Events\EventNotifications;

use App\Events\EventTracesSante;
use App\Events\EventStatutSante;
use App\Events\EventDevisValideSante;
use App\Events\EventValidationContratSante;
use App\Events\EventRejetDevisSante;
use App\Events\EventRejetContratSante;

use App\Events\EventTracesObseque;
use App\Events\EventStatutObseque;
use App\Events\EventDevisValideObseque;
use App\Events\EventValidationContratObseque;
use App\Events\EventRejetDevisObseque;
use App\Events\EventRejetContratObseque;

use Illuminate\Http\Request;
use App\Http\Requests\StoreAgenceRequest;
use App\Http\Requests\EditAgenceRequest;
use App\Http\Requests;
use App\Agence;
use App\User;
use App\Courtier;
use Auth;
use App\Produit;
use Session;
use App\Fichesante;
use App\Ficheobseque;
use App\Saregime;
use App\Groupeproduit;
use App\Documentfiche;
use App\Client;
use App\ClientProduit;
use App\Statutaction;
use Image;
use App\Site;
use App\Equipe;
use App\Equipeuser; 
use App\Statut;
use App\Action;
use App\Tracessante;
use App\Notification;
use DB;

use Carbon\Carbon;

class AgenceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreAgenceRequest $request)
    {


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $agence       = Auth::user()->agence;
        $produits     = Produit::all();
        return view('agencesfiles.agences.show',['agence' => $agence, 'produits' => $produits]);
    }


    

    public function showResp($id)
    {
        
        $agence            = Auth::user()->agence;
        $agenceAdmin       = Auth::user();

        return view('agencesfiles.agences.showResp',[
                                                       'agenceAdmin' => $agenceAdmin , 
                                                       'agence'       => $agence 
                                                    ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        //$agence             = Agence::find($id);
        $agence            = Auth::user()->agence;
        $produits           = Produit::all();
        return view('agencesfiles.agences.edit',['agence' => $agence, 'produits' => $produits]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(EditAgenceRequest $request, $id)
    {
        //$agence                = Agence::find($id);
        $agence                  = Auth::user()->agence;
        $agence->nom             = $request->get('nom');
        $agence->adresse         = $request->get('adresse');
        $agence->code_postal     = $request->get('codepostal');
        $agence->ville           = $request->get('ville');
        $agence->tel             = $request->get('tel');
        $agence->fax             = $request->get('fax');
        $agence->email           = $request->get('email');
        $agence->site_web        = $request->get('siteweb');
        

        
        //$photo                   = $request->file('photo');

        if($request->file('photo_agence')){
                
                $img = $request->file('photo');
                $mime = Image::make($img)->mime();
                if( $mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif')
                {
                    $imgName       = $agence->nom.'.'.$img->getClientOriginalExtension();
                    $agence->photo = $imgName;
                    $image         = Image::make($img)->resize(100, 100)->save('upload/avatars/agence/'.$imgName);
                }
                else
                {
                    return redirect('agence/agence/'.$agence->id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
                }

        }
        

        if($agence->save()){

            $idsAgenceProduit = ($request->has('check_produit') ?  $request->get('check_produit') : []);
            $agence->produits()->sync($idsAgenceProduit, ['active' => 1]);
        }

        $user                       = Auth::user();
        $user->nom                  = $request->get('nomUser');
        $user->prenom               = $request->get('prenomUser');
        $user->login                = $request->get('loginUser');
        $user->email                = $request->get('emailUser');
        $user->tel                  = $request->get('telUser');
        $user->fax                  = $request->get('faxUser');
        $user->id_appel             = $request->get('idAppel');
        if($request->file('photo')){
                
                $img                = $request->file('photo');
                $mime               = Image::make($img)->mime();
                if( $mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif')
                {
                    $imgName        = $user->nom.'.'.$img->getClientOriginalExtension();
                    $user->photo    = $imgName;
                    $image          = Image::make($img)->resize(100, 100)->save('upload/avatars/'.$imgName);
                }
                else
                {
                    return redirect('site/site/'.$site->id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
                }

        }

        $user->save();

        return redirect('agence/agence/'.$agence->id);
    }

    

    public function changeProduit(Request $request, $id){

        if($request->has('statusId')){
            $statusId = $request->get('statusId');
        }else{
            $statusId = 1;
        }

        if(!$id){
            Session::put('produit_id', 1);
        }else{
            Session::put('produit_id', $id);
        }

        return $statusId;

    }


    public function changeSite(Request $request, $id){

        if($request->has('statusId')){
            $statusId = $request->get('statusId');
        }else{
            $statusId = 1;
        }

        if(!$id){
            Session::forget('site_id');
        }else{
            if($id==0){
                Session::forget('site_id');
            }else{
                Session::put('site_id', $id);
            }
        }

        return $statusId;

    }

    public function changeEquipe(Request $request, $id){

        if($request->has('statusId')){
            $statusId = $request->get('statusId');
        }else{
            $statusId = 1;
        }

        if(!$id){
            Session::forget('equipe_id');
        }else{
            if($id==0){
                Session::forget('equipe_id');
            }else{
                Session::put('equipe_id', $id);
            }
        }

        return $statusId;

    }

    public function groupeProduitsClient($client_id){

        $client = Client::find($client_id);
        //$client->getGroupesProduit();

        $produitIds     = ClientProduit::where('client_id',$client_id)
                                        ->groupBy('produit_id')
                                        ->lists('produit_id');
                
        $gpIds          = Produit::whereIn('id',$produitIds)
                                    ->groupBy('groupeproduit_id')
                                    ->lists('groupeproduit_id');
                
        return $groupeProduits = Groupeproduit::whereIn('id',$gpIds)->get();

    }

    /**
     * change le statut d'une ou plusieurs fiches
     */
    public function changeStatusLeads(Request $request)
    {
        $userInfo      = $this->userInfo();
        
        $statutId      = $request->get('statut');
        $produitId     = $request->get('produit');
        $arrayIdFiches = $request->get('arrayIdLeads');

        $produit       = Produit::find($produitId);
        $produitSlug   = $produit->slug;

        $statut = Statut::find($statutId);

        $newStatut = $statut->libelle;

        $idAction      = Action::whereSlug('CS')->value('id');

        $className = "App\Fiche".$produitSlug;
        //                       ->whereIn('id', $arrayIdFiches)
        //                       ->update(['statut_id' => $statutId]);

        foreach ($arrayIdFiches as $Idfiche) {
            
            $fiche    = $className::find($Idfiche);

            $oldStatut = $fiche->statut->libelle;

            $fiche->statut_id      = $statut->id;
            $fiche->date_situation = Carbon::now();

            if($fiche->save()){
                
                $observation  = "<i class='uk-text-danger material-icons'>&#xE14C;</i> ".$oldStatut."<br><i class='uk-text-success material-icons'>&#xE876;</i> ".$newStatut;
                
                $motif        = $request->has('modalMotifId') ? $request->get('modalMotifId') : null;
                
                $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
                
                $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
                event(new $event($tabInfoTrace));

            }

        }

        return [
                    "success"   => true,
                    "message"   => "Statut Changé",
                    "statutLib" => $newStatut
                ];

    }


    public function dispatchLeads(Request $request)
    {

        $userInfo = $this->userInfo();

        $siteId        = $request->get('site');
        $equipeId      = $request->get('equipe');
        $conseillerId  = $request->get('conseiller');
        $produitId     = $request->get('produit');
        $arrayIdFiches = $request->get('arrayIdLeads');

        $produit       = Produit::find($produitId);
        $produitSlug   = $produit->slug;

        $equipeUser  = null;
        $observation = null;
        $actionSlug  = 'AFC';

        $userList    = [];

        if($conseillerId)
        {
            $actionSlug  = 'AFC';
            $equipeUser   = Equipeuser::where('user_id',$conseillerId)
                                        ->where('equipe_id',$equipeId)
                                        ->first();
            $user       = $equipeUser->user;
            $observation = "<i class='uk-icon-map-marker'></i> ".$equipeUser->equipe->site->nom."<br><i class='uk-icon-group'></i> ".$equipeUser->equipe->nom."<br><i class='uk-icon-user'></i> ". strtoupper($user->nom)." ".ucfirst($user->prenom)." (".$user->login.")";      

            array_push($userList, $equipeUser->user);
            if($equipeUser->equipe->responsable()){
                array_push($userList, $equipeUser->equipe->responsable());
            }  

        }
        else if($equipeId)
        {
            $actionSlug  = 'AFRE';
            $equipe      = Equipe::find($equipeId);
            $observation = "<i class='uk-icon-map-marker'></i> ".$equipe->site->nom."<br><i class='uk-icon-group'></i> ".$equipe->nom;

            if($equipe->responsable()){
                array_push($userList, $equipe->responsable());
            }
        }
        else
        {
            $actionSlug  = 'AFRS';
            $site        = Site::find($siteId);
            $observation = "<i class='uk-icon-map-marker'></i> ".$site->nom;

            if($site->responsable()){
                array_push($userList, $site->responsable());
            }
        }

        $idAction = Action::whereSlug($actionSlug)->value('id');
        $idStatut = Statut::whereSlug($produitSlug.'Appel')->value('id');

        foreach ($arrayIdFiches as $Idfiche) {

            $className = "App\Fiche".$produitSlug;

            $fiche    = $className::find($Idfiche);

            if($conseillerId)
            {
                $fiche->equipe_user_id    = $equipeUser->id;
                $fiche->dispatchable_id   = $equipeUser->equipe_id;
                $fiche->dispatchable_type = 'equipe';
            }
            else if($equipeId)
            {
                $fiche->dispatchable_id   = $equipeId;
                $fiche->dispatchable_type = 'equipe';
            }
            else 
            {
                $fiche->dispatchable_id   = $siteId;
                $fiche->dispatchable_type = 'site'; 
            }

            if($fiche->save()){

                $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
                $event = 'App\Events\EventTraces'.ucfirst($produitSlug);
                event(new $event($tabInfoTrace));

            }

        }

        $notif        = Notification::whereSlug('LEADDISPATCH')->first();
        
        $description  = "Vous avez reçu ".(count($arrayIdFiches) > 1 ? count($arrayIdFiches)." fiches" : "une fiche")." ".$produit->libelle;
        
        $notification = [
            'user_id'         => null,
            'notification_id' => $notif->id,
            'notifiable_id'   => $arrayIdFiches[0],
            'notifiable_type' => $produit->table_produit,
            'rappel_time'     => null,
            'link'            => null,
            'type'            => 'dispatch',
            'description'     => $description
        ];
        
        foreach ($userList as $usr) {

            $notification['user_id'] = $usr->id;
            $notification['link']    = url($usr->profile->slug.'/leads/'.$idStatut);

            event(new EventNotifications($notification));

        }


    }


    public function redirectLead($grPrd, $client_id){

        $prd     = Groupeproduit::find($grPrd)->produits()->lists('id');
        
        $cltPrd  = ClientProduit::where('client_id', $client_id)->whereIn('produit_id',$prd)->orderBy('nombre', 'desc')->first();
        
        if(!$cltPrd){
            return redirect('agence/leads/1');
        }

        $produitSlug = Produit::find($cltPrd->produit_id)->slug;

        

        switch($produitSlug) {

            // produit Santé
            case "sante":

                $fiche = Fichesante::where('client_id', $client_id)->whereActive(1)->orderBy('date_insertion', 'desc')->first();

                break;

            case "obseque":

                $fiche = Ficheobseque::where('client_id', $client_id)->whereActive(1)->orderBy('date_insertion', 'desc')->first();

                break;

            case "auto":

                break;

            default :

                return redirect('agence/leads/1');

                break;
        }

        return redirect('agence/leads/'.$produitSlug.'/'.$fiche->id);
    }


    public function DispatchAuto($id)
    {
        $agence  = Agence::find($id);

        if($agence->disp_auto)
        {
            $agence->disp_auto = 0;
            $active = 0;
        }
        else
        {
            $agence->disp_auto = 1;
            $active = 1;
        }

        $agence->save();


        return $active;

    }


    public function ActiveMatiere($id)
    {
        $agence  = Agence::find($id);

        if($agence->active_matiere)
        {
            $agence->active_matiere = 0;
            $active = 0;
        }
        else
        {
            $agence->active_matiere = 1;
            $active = 1;
        }

        $agence->save();


        return $active;

    }



    public function validationDevisAgence(Request $request){

        $userInfo = $this->userInfo();

        //$equipe                         = Equipe::find($id);
        $idFiche         = $request->get('ficheId'); 
        $observation     = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet      = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
        $statusId        = ($request->get('statusId')) ? $request->get('statusId') : null ; 
        $resultat        = 'ko';

        $slug        = $request->get('slug');
        $nameClass   = "App\Fiche".$slug;
        $eventTrace  = 'App\Events\EventTraces'.ucfirst($slug);
        $eventStatut = 'App\Events\EventStatut'.ucfirst($slug);

        if($idFiche){

            $fiche       = $nameClass::find($idFiche);
            $statutActu  = Statut::find($statusId);

            switch ($statutActu->slug) {

                case 'devis':
                    $slugNouvStatut   = 'devisComplet';
                    $action           = 'VDC';
                    break;

                case 'devisComplet':
                    $slugNouvStatut   = 'devisValide';
                    $action           = 'VDA';
                    break;

                case 'devisRejete':
                    $slugNouvStatut   = 'devisValide';
                    $action           = 'VDA';
                    break;

                case 'devisValide':
                    $slugNouvStatut   = 'nnSigne';
                    $action           = 'VDG';
                    break;
                
                case 'nnSigne':
                    $slugNouvStatut   = 'signe';
                    $action           = 'VCNSG';
                    break;

                case 'signe':
                    $slugNouvStatut   = 'client';
                    $action           = 'VCSG';
                    break;

                default:
                    $resultat         = 'NA';
                    break;
            }
                        
            //return $fiche->id;

            if($fiche and $resultat != 'NA'){

                $statut   = Statut::where('slug', $slugNouvStatut)->first();

                if($statut->groupeStatus->slug=='leads'){
                    $fiche->date_situation = $fiche->date_insertion;
                }elseif($statut->groupeStatus->slug=='devis'){
                    $fiche->date_situation = Carbon::now();
                }elseif($statut->groupeStatus->slug=='contrats'){
                    $fiche->date_situation = Carbon::now();
                }

                $fiche->statut_id = $statut->id;

                if($fiche->save()){

                    $idAction     = Action::where('slug',$action)->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $idFiche, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => $motifRejet, 'idStatut' => $statut->id];
                    event(new $eventTrace($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut = ['idAction' => $idAction, 'idFiche' => $idFiche, 'observation' => $observation, 'motif' => $motifRejet, 'slugProduit' => $slugProduit, 'idStatut' => $statut->id];
                    event(new $eventStatut($tabInfoTraceStatut));

                    //event modification classement dans le cas d'un devis ou contrat validé
                    if($slugNouvStatut == 'devisValide')
                    {
                        $tabInfosDevisValide = ['idFiche' => $idFiche];
                        event(new EventDevisValideSante($tabInfosDevisValide));
                    }
                    elseif ($slugNouvStatut == 'nnSigne') {
                        $tabInfosValidationContrat = ['idFiche' => $idFiche];
                        event(new EventValidationContratSante($tabInfosValidationContrat));
                    }

                    $resultat     = 'ok';
                    
                }
            }
        }

        return $resultat;        
    }


    public function rejetDevisAgence(Request $request){

        $userInfo = $this->userInfo();

        //$equipe                         = Equipe::find($id);
        $idFiche         = $request->get('ficheId'); 
        $observation     = ($request->get('observation')) ? $request->get('observation') : "" ;
        $motifRejet      = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ; 
        $statusId        = ($request->get('statusId')) ? $request->get('statusId') : null ; 
        $resultat        = 'ko';

        $slug        = $request->get('slug');
        $nameClass   = "App\Fiche".$slug;
        $eventTrace  = 'App\Events\EventTraces'.ucfirst($slug);
        $eventStatut = 'App\Events\EventStatut'.ucfirst($slug);

        if($idFiche){

            $fiche       = $nameClass::find($idFiche);
            $statutActu  = Statut::find($statusId);

            switch ($statutActu->slug) {

                case 'devisValide':
                    $slugNouvStatut   = 'devisRejete';
                    $action           = 'RDG';  
                    break;

                case 'nnSigne':
                    $slugNouvStatut   = 'devisRejete';
                    $action           = 'RDG';  
                    break;
                
                case 'signe':
                    $slugNouvStatut   = 'devisRejete';
                    $action           = 'RDG';  
                    break;

                case 'client':
                    $slugNouvStatut   = 'devisRejete';
                    $action           = 'RDG';  
                    break;

                default:
                    $resultat         = 'NA';
                    break;
            }
          
                        
            //return $fiche->id;

            if($fiche and $resultat != 'NA'){

                $statut   = Statut::where('slug', $slugNouvStatut)->first();

                if($statut->groupeStatus->slug=='leads'){
                    $fiche->date_situation = $fiche->date_insertion;
                }elseif($statut->groupeStatus->slug=='devis'){
                    $fiche->date_situation = Carbon::now();
                }elseif($statut->groupeStatus->slug=='contrats'){
                    $fiche->date_situation = Carbon::now();
                }

                $fiche->statut_id = $statut->id;

                if($fiche->save()){

                    $idAction     = Action::where('slug',$action)->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $idFiche, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => $motifRejet, 'idStatut' => $statut->id];
                    event(new $eventTrace($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut = ['idAction' => $idAction, 'idFiche' => $idFiche, 'observation' => $observation, 'motif' => $motifRejet, 'slugProduit' => $slugProduit, 'idStatut' => $statut->id];
                    event(new $eventStatut($tabInfoTraceStatut));

                    //event modification classement dans le cas d'un devis ou contrat rejeté
                    if($statutActu->slug == 'devisValide')
                    {
                        $tabInfosRejetDevis = ['idFiche' => $idFiche];
                        event(new EventRejetDevisSante($tabInfosRejetDevis));
                    }
                    elseif ($statutActu->slug == 'nnSigne' or $statutActu->slug == 'signe') {
                        $tabInfosRejetContrat = ['idFiche' => $idFiche];
                        event(new EventRejetContratSante($tabInfosRejetContrat));
                    }
                                        
                    $resultat     = 'ok';
                    
                }
            }
        }

        return $resultat;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function validateDevisSante(Request $request){

        $statut = [];
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
    
        if($idFiche){

            $fiche  = Fichesante::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="santeDevisNonSigne" or $fiche->statut->slug=="santeDevisSigne"){

                $statut = Statut::where('slug', 'santeContratDepot')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'VDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => null, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesSante($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => null, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutSante($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('DEVISSANTEVAL')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosDevisValide = ['idFiche' => $idFiche];
                    //event(new EventDevisValideSante($tabInfosDevisValide));
                    

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." validé",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function rejectDevisSante(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
    
        if($idFiche){

            $fiche = Fichesante::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="santeDevisNonSigne" or $fiche->statut->slug=="santeDevisSigne"){

                $statut                = Statut::where('slug', 'santeDevisRejete')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'RDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => $motifRejet, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesSante($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => $motifRejet, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutSante($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('DEVISSANTEREJ')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosRejetDevis = ['idFiche' => $idFiche];
                    //event(new EventRejetDevisSante($tabInfosRejetDevis));

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." rejeté",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    
    public function validateContratSante(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
    
        if($idFiche){

            $fiche = Fichesante::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="santeContratDepot") {

                $statut                = Statut::where('slug', 'santeContratEnAttente')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'VCSG')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => null, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesSante($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => null, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutSante($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('CONTRATSANTEVAL')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosValidationContrat = ['idFiche' => $idFiche];
                    //event(new EventValidationContratSante($tabInfosValidationContrat));
                    
                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Contrat numéro : ".$fiche->id." validé",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function rejectContratSante(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
    
        if($idFiche){

            $fiche = Fichesante::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="santeContratDepot" or $fiche->statut->slug=="santeContratEnAttente" or $fiche->statut->slug=="santeClient"){

                if($fiche->statut->slug=="santeContratDepot"){
                    $statut = Statut::where('slug', 'santeAdhesionRejete')->first();
                }else{
                    $statut = Statut::where('slug', 'santeContratRejete')->first();
                }   
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'RDG')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => $motifRejet, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesSante($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => $motifRejet, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutSante($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('CONTRATSANTEREJ')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosRejetContrat = ['idFiche' => $idFiche];
                    //event(new EventRejetContratSante($tabInfosRejetContrat));

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Contrat numéro : ".$fiche->id." rejeté",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function validateDevisObseque(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
    
        if($idFiche){

            $fiche = Ficheobseque::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="obsequeDevisNonSigne" or $fiche->statut->slug=="obsequeDevisSigne"){

                $statut                = Statut::where('slug', 'obsequeContratDepot')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'VDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => null, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesObseque($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => null, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutObseque($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('DEVISOBSEQUEVAL')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosDevisValide = ['idFiche' => $idFiche];
                    //event(new EventDevisValideSante($tabInfosDevisValide));

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." validé",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function rejectDevisObseque(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
    
        if($idFiche){

            $fiche = Ficheobseque::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="obsequeDevisNonSigne" or $fiche->statut->slug=="obsequeDevisSigne"){

                $statut                = Statut::where('slug', 'obsequeDevisRejete')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'RDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => $motifRejet, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesObseque($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => $motifRejet, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutObseque($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('DEVISOBSEQUEREJ')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." rejeté",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function validateContratObseque(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
    
        if($idFiche){

            $fiche = Ficheobseque::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="obsequeContratDepot") {

                $statut                = Statut::where('slug', 'obsequeContratEnAttente')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'VCSG')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => null, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesObseque($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => null, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutObseque($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('CONTRATOBSEQUEVAL')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosValidationContrat = ['idFiche' => $idFiche];
                    //event(new EventValidationContratSante($tabInfosValidationContrat));
                    
                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Contrat numéro : ".$fiche->id." validé",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function rejectContratObseque(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
    
        if($idFiche){

            $fiche = Ficheobseque::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="obsequeContratDepot" or $fiche->statut->slug=="obsequeContratEnAttente" or $fiche->statut->slug=="obsequeClient"){

                if($fiche->statut->slug=="obsequeContratDepot"){
                    $statut = Statut::where('slug', 'obsequeAdhesionRejete')->first();
                }else{
                    $statut = Statut::where('slug', 'obsequeContratRejete')->first();
                }   
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'RDG')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => $motifRejet, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesObseque($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => $motifRejet, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutObseque($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('CONTRATOBSEQUEREJ')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosRejetContrat = ['idFiche' => $idFiche];
                    //event(new EventRejetContratSante($tabInfosRejetContrat));

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Contrat numéro : ".$fiche->id." rejeté",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function userInfo(){

        $user = Auth::user();

        return $userInfo = ['equipe_user_id' => null, 'tracable_id' => $user->agence_id, 'tracable_type' => 'agence'];

    }


}
