<?php

namespace App\Http\Controllers\Agence;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Requests\UserRequest;
use App\Http\Requests;

use App\User;
use App\Agence;
use App\Courtier;
use App\Profile;
use App\Site;
use App\Ip;

use Auth;

class AdminController extends Controller
{
    
    

    

    public function createRespSite($id)
    {

        //echo "id agence :".$id ;
        //$profilesite = Profile::where('nom','Resp Site')
                                    //->first();

        return view('agencesfiles.admins.createRespSite',['idsite' => $id ]);

    }

    

    public function storeRespSite(UserRequest $request)
    {
        
        $idsiterequest          = $request->get('idsite');
        $site                   = Site::where('id',$idsiterequest)
                                        ->where('agence_id',Auth::user()->agence_id)
                                        ->first();
        if($site)
        {
            $agence                 = $site->agence;                                

            $user = new User;
                $user->nom          = $request->get('nom');
                $user->prenom       = $request->get('prenom');
                $user->login        = $request->get('login');
                $user->profile_id   = Profile::where('nom','Resp Site')->first()->id;
                $user->email        = $request->get('email');
                $user->password     = bcrypt($request->get('password'));
                $user->id_appel     = $request->get('idAppel');
                $user->site_id      = $site->id;
                $user->agence_id    = $site->agence_id;
                $user->courtier_id  = $agence->courtier_id;
                $user->active       = 1;
                //$user->responsable  = 1;
            $user->save();

            $ip = new Ip;
            $ip->ip_internet = $request->ip();

            $user->ips()->save($ip);       

            return redirect('agence/agence/site/showResp/'.$site->id);
        }
        else
        {
            //error
        }


    }

    

    public function editRespAgence($id)
    {
        //$adminagence  = User::find($id);
        $adminagence    = Auth::user();

        return view('agencesfiles.admins.editRespAgence',['adminagence'=> $adminagence]);


    }

    public function editRespSite($id)
    {
        $adminsite  = User::where('id',$id)
                          ->where('agence_id',Auth::user()->agence_id)
                          ->where('profile_id',5)
                          ->first();

        return view('agencesfiles.admins.editRespSite',['adminsite'=> $adminsite]);


    }

    public function editRespEquipe($id)
    {
        $adminequipe  = User::where('id',$id)
                            ->where('agence_id',Auth::user()->agence_id)
                            ->where('profile_id',6)
                            ->first();

        return view('agencesfiles.admins.editRespEquipe',['adminequipe'=> $adminequipe]);


    }


    public function updateRespAgence(UserRequest $request,$id)
    {

        //$user               = User::find($id);
        $user               = Auth::user();
        $user->nom          = $request->get('nom');
        $user->prenom       = $request->get('prenom');
        $user->login        = $request->get('login');
        $user->email        = $request->get('email');
        $user->id_appel        = $request->get('idAppel');


        if($request->has('password')) 
        {    
           $user->password = bcrypt($request->get('password'));
        }

        $user->save();
        return redirect('agence/agence/showResp/'.$user->agence_id);
    }

    public function updateRespSite(UserRequest $request,$id)
    {

        $user               = User::where('id',$id)
                                  ->where('agence_id',Auth::user()->agence_id)
                                  ->where('profile_id',5)
                                  ->first();
        if($user)
        {    
            $user->nom          = $request->get('nom');
            $user->prenom       = $request->get('prenom');
            $user->login        = $request->get('login');
            $user->email        = $request->get('email');
            $user->id_appel     = $request->get('idAppel');


            if($request->has('password')) 
            {    
               $user->password = bcrypt($request->get('password'));
            }

            $user->save();
            return redirect('agence/agence/site/showResp/'.$user->site_id);
        }
        else
        {
            //error
        }
    }

    public function updateRespEquipe(UserRequest $request,$id)
    {

        $user               = User::where('id',$id)
                                    ->where('agence_id',Auth::user()->agence_id)
                                    ->where('profile_id',6)
                                    ->first();
        if($user)
        {
            $user->nom          = $request->get('nom');
            $user->prenom       = $request->get('prenom');
            $user->login        = $request->get('login');
            $user->email        = $request->get('email');
            $user->id_appel     = $request->get('idAppel');


            if($request->has('password')) 
            {    
               $user->password  = bcrypt($request->get('password'));
            }

            $user->save();


            $idequipe           = $user->userEquipe()->first()->pivot->equipe_id;


            return redirect('agence/agence/site/equipe/showResp/'.$idequipe);
        }
        else
        {
            //error
        }
    }

    public function activeUser($id)
    {
        //$user  = User::find($id);
        $user        = User::where('id',$id)
                            ->where('agence_id',Auth::user()->agence_id)
                            //->where('responsable',1)
                            ->first();
        
        if(count($user))
        {
            if($user->active)
            {
                $user->active = 0;
                $value        = 0;
            }
            else
            {
                $user->active = 1;
                $value        = 1;
            }

            $user->save();
            $msg = 'ok';

        }
        else
        {
            $msg = 'notok';
        }

        return ['msg'=>$msg , 'value'=>$value];    


    }
    

}
