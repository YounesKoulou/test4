<?php

namespace App\Http\Controllers\Agence;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;

use Auth;

use App\User;
use Hash;
use App\Messagerie;
use App\Fichesante;
use App\Equipe;
use App\Equipeuser;
use Image;
use File;
use App\Tracessante;

class SettingController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function myProfile()
    {

    	$user = Auth::user();

        //$equipeUserId   =  $user->userEquipe->first()->pivot->id;

        $nombreMessageNonLu = Messagerie::where('vu', 0)->whereActive(1)->where('to_id', $user->id)->orderBy('created_at', 'desc')->get();

        // $nbrAppels = Fichesante::whereHas('statut', function ($query) {
        //     $query->where('slug', '=', 'appel');
        // })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();
        // $statutId = Fichesante::whereHas('statut', function ($query) {
        //     $query->where('slug', '=', 'appel');
        // })->whereActive(1)->where('equipe_user_id', $equipeUserId)->first();

        // $nbrDevis = Fichesante::whereHas('statut', function ($query) {
        //     $query->where('slug', '=', 'devis');
        // })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();
        // $statutIdDevis = Fichesante::whereHas('statut', function ($query) {
        //     $query->where('slug', '=', 'devis');
        // })->whereActive(1)->where('equipe_user_id', $equipeUserId)->first();   

        // $nbrContrat = Fichesante::whereHas('statut', function ($query) {
        //     $query->orWhere('slug', '=', 'signe')->orWhere('slug', '=', 'nonSigne');
        // })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();
        // $statutIdContrat = Fichesante::whereHas('statut', function ($query) {
        //     $query->where('slug', '=', 'signe');
        // })->whereActive(1)->where('equipe_user_id', $equipeUserId)->first();

        // $respSite = User::where('site_id', $user->site->id)->where('profile_id', 5)->first();

        // $equipeId     =  $user->userEquipe->first()->pivot->equipe_id;
        //  $equipe = Equipe::find($equipeId);

        //  $userEquipe = Equipeuser::where('equipe_id', $equipe->id)->lists('user_id');



        // $respEquipe = User::whereIn('id', $userEquipe)->where('profile_id', 6)->first();
        // $nbrConseillerEquipe = User::whereIn('id', $userEquipe)->where('profile_id', 7)->get();
        $traces = Tracessante::where('user_id', $user->id)->orderBy('created_at', 'desc')->take(10)->get();

        $agence            = Auth::user()->agence;

    	//return $user;
        return view('agencesfiles.agences.profile', compact('agence', 'traces', 'user', 'nombreMessageNonLu', 'nbrAppels', 'statutId', 'nbrDevis', 'statutIdDevis', 'nbrContrat', 'statutIdContrat', 'respSite', 'equipe', 'respEquipe', 'nbrConseillerEquipe'));

    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function settings()
    {

		return "Settings";

    }

   public function generate(Request $request){

        
        $iduser                 = $request->get("iduser");
        $user                   = User::find($iduser);
        $user->password           = Hash::make($request->get("password"));
        return $user->save() ? 1 : 0;

        }

         public function modifImage(Request $request){

                $image                      = $request->file('logo');
                $filename                   = time() . '.' . $image->getClientOriginalExtension();
                $dossier_libelle            = str_replace(' ', '_', $request->input('libelle'));
                $path                       = 'upload/avatars/' . $filename;
                Image::make($image->getRealPath())->resize(200, 200)->save($path);
                $iduser                 = $request->get("iduser");
                $user                   = User::find($iduser);
                $user->photo           = $filename;
                return $user->save() ? 1 : 0;

        }

        public function couleur(Request $request){

        
        $iduser                 = $request->get("iduser");
        $user                   = User::find($iduser);
        $user->couleur           = $request->get("couleur");
        return $user->save() ? 1 : 0;

        }


    

}
