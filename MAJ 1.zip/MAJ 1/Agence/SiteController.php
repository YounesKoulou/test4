<?php

namespace App\Http\Controllers\Agence;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests\StoreSiteRequest;

use App\Http\Requests;

use App\Site;
use App\Agence;

use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Input;

use Image;

class SiteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        $idAgence     = Auth::user()->agence_id;
        $agence       = Agence::find($idAgence);
        return view('agencesfiles.sites.create',['agence'=> $agence]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSiteRequest $request)
    {
        
        

        $site                  = new Site();
        $site->nom             = $request->get('nom');
        $site->adresse         = $request->get('adresse');
        $site->code_postal     = $request->get('codepostal');
        $site->ville           = $request->get('ville');
        $site->tel             = $request->get('tel');
        $site->fax             = $request->get('fax');
        $site->email           = $request->get('email');
        $site->site_web        = $request->get('siteweb');
        $site->agence_id       = Auth::user()->agence_id;
        $site->active          = 1;

        if($site->save() and $request->get('check_produit')){

            $idsSiteProduit = $request->get('check_produit');
            $site->produits()->attach($idsSiteProduit, ['active' => 1]);
        }  

        return redirect('agence/agence/site/'.$site->id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //$site         = Site::find($id);
        $idAgence     = Auth::user()->agence_id;
        $site         = Site::where('id',$id)
                            ->where('agence_id',$idAgence)
                            ->first();


        return view('agencesfiles.sites.show',['site'=> $site]);
    }

    public function showResp($id)
    {
        //$site             = Site::find($id);
        $idAgence     = Auth::user()->agence_id;
        $site         = Site::where('id',$id)
                            ->where('agence_id',$idAgence)
                            ->first();
        $siteAdmins       = $site->adminsSite;

        return view('agencesfiles.sites.showResp',[
                                                       'siteAdmins' => $siteAdmins , 
                                                       'site'       => $site 
                                                      ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //$site  = Site::find($id);
        $idAgence     = Auth::user()->agence_id;
        $site         = Site::where('id',$id)
                            ->where('agence_id',$idAgence)
                            ->first();

        return view('agencesfiles.sites.edit',['site'=>$site]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(StoreSiteRequest $request, $id)
    {
        //$site                  = Site::find($id);
        $idAgence              = Auth::user()->agence_id;
        $site                  = Site::where('id',$id)
                                     ->where('agence_id',$idAgence)
                                     ->first();
        $site->nom             = $request->get('nom');
        $site->adresse         = $request->get('adresse');
        $site->code_postal     = $request->get('codepostal');
        $site->ville           = $request->get('ville');
        $site->tel             = $request->get('tel');
        $site->fax             = $request->get('fax');
        $site->email           = $request->get('email');
        $site->site_web        = $request->get('siteweb');

        if($request->file('photo')){
                
                $img = $request->file('photo');
                $mime = Image::make($img)->mime();
                if( $mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif')
                {
                    $imgName       = $site->nom.'.'.$img->getClientOriginalExtension();
                    $site->photo = $imgName;
                    $image         = Image::make($img)->resize(100, 100)->save('upload/avatars/site/'.$imgName);
                }
                else
                {
                    return redirect('agence/agence/site/'.$site->id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
                }

        }

        if($site->save()){

            $idsSiteProduit = ($request->has('check_produit') ?  $request->get('check_produit') : []);
            $site->produits()->sync($idsSiteProduit, ['active' => 1]);
        }   

        return redirect('agence/agence/site/'.$site->id);
    }


    public function activeSite($id)
    {
        //$site  = Site::find($id);
        $idAgence     = Auth::user()->agence_id;
        $site         = Site::where('id',$id)
                            ->where('agence_id',$idAgence)
                            ->first();
        
        if(count($site))
        {
            if($site->active)
            {
                $site->active = 0;
                $value          = 0;
            }
            else
            {
                $site->active = 1;
                $value          = 1;
            }

            $site->save();
            $msg = 'ok';

        }
        else
        {
            $msg = 'notok';
        }

        return ['msg'=>$msg , 'value'=>$value];    


    }

    public function DispatchAuto($id)
    {
        $site  = Site::find($id);
        $msg     = "";

        if($site->disp_auto)
        {
            $site->disp_auto = 0;
            $msg = "Dispatching automatique désactivé.";
        }
        else
        {
            $site->disp_auto = 1;
            $msg = "Dispatching automatique activé.";
        }

        if($site->save()){

            return $data = ["resultat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];
        }else{

            return $data = ["resultat" => "error", "msg" => $msg, "titre" => "opération échouée !"];
        }

    }


    public function ActiveMatiere($id)
    {
        $site  = Site::find($id);
        $msg     = "";

        if($site->active_matiere)
        {
            $site->active_matiere = 0;
            $msg = "Matière désactivée.";
        }
        else
        {
            $site->active_matiere = 1;
            $msg = "Matière activée.";
        }

        if($site->save()){

            return $data = ["resultat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];
        }else{

            return $data = ["resultat" => "error", "msg" => $msg, "titre" => "opération échouée !"];
        }

    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
