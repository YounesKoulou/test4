<?php

namespace App\Http\Controllers\Equipe;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Http\Requests\StoreEquipeRequest;

use App\Http\Requests\EditEquipeRequest;

use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\Publique\FicheController;
use App\Events\EventNotifications;

use App\Events\EventTracesSante;
use App\Events\EventStatutSante;
use App\Events\EventDevisValideSante;

use App\Events\EventTracesObseque;
use App\Events\EventStatutObseque;
use App\Events\EventDevisValideObseque;

use App\Categoryequipe;

use App\Equipe;

use App\Profile;

use App\Site;

use App\User;
use App\Produit;
use App\Fichesante;
use App\Ficheobseque;
use App\Saregime;
use App\Groupeproduit;
use App\Documentfiche;
use App\Client;
use App\ClientProduit;
use App\Statutaction;
use App\Equipeuser;
use App\Statut;
use App\Tracessante;
use App\Action;

use App\Informationbancaire;
use App\Modepaiement;
use App\Typepaiement;
use App\Prelevement;
use App\Groupemotif;
use App\Notification;


use Carbon\Carbon;
use Session;
use Image;




class EquipeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $equipeIds = Auth::user()->userEquipe()->get()->lists('pivot.equipe_id');
        
        $equipes   = Equipe::whereActive(1)->whereIn('id', $equipeIds)->get();

        return view('equipesfiles.equipes.index',['equipes' => $equipes]);

    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
        $equipeIds = Auth::user()->userEquipe()->get()->lists('pivot.equipe_id');

        if($equipeIds->contains($id)){

            $equipe = Equipe::find($id);

            return view('equipesfiles.equipes.show',['equipe'=> $equipe]);

        }else{

            return abort(404);

        }

    }

    public function showResp($id)
    {
        //$equipe                = Equipe::find($id);
        $equipe                  = Auth::user()->userEquipe->first();
        
        return view('equipesfiles.equipes.showResp',[
                                                        'equipe'=> $equipe 
                                                      ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {


        $equipeIds = Auth::user()->userEquipe()->get()->lists('pivot.equipe_id');

        if($equipeIds->contains($id)){

            $equipe = Equipe::find($id);

            return view('equipesfiles.equipes.edit',['equipe'=> $equipe]);

        }else{

            return abort(404);

        }


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $equipe    = [];

        $equipeIds = Auth::user()->userEquipe()->get()->lists('pivot.equipe_id');

        if($equipeIds->contains($id)){

            $equipe      = Equipe::find($id);
            
            $equipe->nom = $request->get('nom');  

            if($request->file('photo')){
                    
                    $img  = $request->file('photo');
                    $mime = Image::make($img)->mime();
                    if( $mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif')
                    {
                        $imgName       = $equipe->nom.'.'.$img->getClientOriginalExtension();
                        $equipe->photo = $imgName;
                        $image         = Image::make($img)->resize(100, 100)->save('upload/avatars/equipe/'.$imgName);
                    }
                    else
                    {
                        return redirect('equipe/equipe/'.$equipe->id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
                    }

            }     

            if($equipe->save()){

                $idsEquipeProduit = ($request->has('check_produit') ?  $request->get('check_produit') : []);            
                $equipe->produits()->sync($idsEquipeProduit, ['active' => 1]);
                
            } 

            return redirect('equipe/equipe/'.$equipe->id);

        }else{

            return abort(404);

        }

    }


    public function activeEquipe($id)
    {
        //$equipe  = Equipe::find($id);
        $equipe                      = Auth::user()->userEquipe->first();
        
        if(count($equipe))
        {
            if($equipe->active)
            {
                $equipe->active = 0;
                $value          = 0;
            }
            else
            {
                $equipe->active = 1;
                $value          = 1;
            }

            $equipe->save();
            $msg = 'ok';

        }
        else
        {
            $msg = 'notok';
        }

        return ['msg'=>$msg , 'value'=>$value];    


    }


    public function validationAnimateur(Request $request){

        $userInfo = $this->userInfo();

        //$equipe                         = Equipe::find($id);
        $idFiche         = $request->get('ficheId'); 
        $observation     = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet      = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
        $statusId        = ($request->get('statusId')) ? $request->get('statusId') : null ; 
        $resultat        = 'ko';

        $slug        = $request->get('slug');
        $nameClass   = "App\Fiche".$slug;
        $eventTrace  = 'App\Events\EventTraces'.ucfirst($slug);
        $eventStatut = 'App\Events\EventStatut'.ucfirst($slug);

        if($idFiche){

            $fiche       = $nameClass::find($idFiche);
            $statutActu  = Statut::find($statusId);

            switch ($statutActu->slug) {

                case 'devis':
                    $slugNouvStatut   = 'devisComplet';
                    $action           = 'VDC';
                    break;

                case 'devisComplet':
                    $slugNouvStatut   = 'devisValide';
                    $action           = 'VDA';
                    break;

                case 'devisRejete':
                    $slugNouvStatut   = 'devisValide';
                    $action           = 'VDA';
                    break;

                default:
                    $resultat         = 'NA';
                    break;
            }            
                        
            //return $fiche->id;

            if($fiche and $resultat != 'NA'){

                $statut   = Statut::where('slug', $slugNouvStatut)->first();

                if($statut->groupeStatus->slug=='leads'){
                    $fiche->date_situation = $fiche->date_insertion;
                }elseif($statut->groupeStatus->slug=='devis'){
                    $fiche->date_situation = Carbon::now();
                }elseif($statut->groupeStatus->slug=='contrats'){
                    $fiche->date_situation = Carbon::now();
                }

                $fiche->statut_id = $statut->id;

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug',$action)->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $idFiche, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => $motifRejet, 'idStatut' => $statut->id];
                    event(new $eventTrace($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut = ['idAction' => $idAction, 'idFiche' => $idFiche, 'observation' => $observation, 'motif' => $motifRejet, 'slugProduit' => $slugProduit, 'idStatut' => $statut->id];
                    event(new $eventStatut($tabInfoTraceStatut));

                    //event modification classement dans le cas d'un devis ou contrat validé
                    if($slugNouvStatut == 'devisValide')
                    {
                        $tabInfosDevisValide = ['idFiche' => $idFiche];
                        event(new EventDevisValideSante($tabInfosDevisValide));
                    }

                    $resultat     = 'ok';
                    
                }
            }
        }

        return $resultat;        
    }




    public function changeProduit(Request $request, $id){

        if($request->has('statusId')){
            $statusId = $request->get('statusId');
        }else{
            $statusId = 1;
        }

        if(!$id){
            Session::put('produit_id', 1);
        }else{
            Session::put('produit_id', $id);
        }

        return $statusId;

    }

    public function changeEquipe(Request $request, $id){

        if($request->has('statusId')){
            $statusId = $request->get('statusId');
        }else{

            $statusId = Statut::whereSlug('Appel')->first()->id;
        }

        if(!$id){
            Session::forget('equipe_id');
        }else{
            if($id==0){
                Session::forget('equipe_id');
            }else{
                Session::put('equipe_id', $id);
            }
        }

        return $statusId;

    }


    public function leadsPerTeam($slug,$id){

        $statusId = Statut::whereSlug($slug)->first()->id;

        if(!$id){
            Session::forget('equipe_id');
        }else{
            if($id==0){
                Session::forget('equipe_id');
            }else{
                Session::put('equipe_id', $id);
            }
        }

        return redirect('equipe/leads/'.$statusId);

    }

    public function groupeProduitsClient($client_id){

        $client = Client::find($client_id);
        //$client->getGroupesProduit();

        $produitIds     = ClientProduit::where('client_id',$client_id)
                                        ->groupBy('produit_id')
                                        ->lists('produit_id');
                
        $gpIds          = Produit::whereIn('id',$produitIds)
                                    ->groupBy('groupeproduit_id')
                                    ->lists('groupeproduit_id');
                
        return $groupeProduits = Groupeproduit::whereIn('id',$gpIds)->get();

    }


    /**
     * Dispatcher une plusieurs fiche à un conseiller
     */
    public function dispatchLeadsOld(Request $request)
    {
        $userInfo = $this->userInfo();

        $conseillerId  = $request->get('conseiller');
        $produitId     = $request->get('produit');
        $arrayIdFiches = $request->get('arrayIdLeads');

        $produit       = Produit::find($produitId);
        $produitSlug   = $produit->slug;

        $idStatut      = Statut::whereSlug($produitSlug.'Appel')->value('id');
        $idAction      = Action::whereSlug('AFC')->value('id');

        $conseiller    = User::find($conseillerId);

        foreach ($arrayIdFiches as $Idfiche) {

            $className = "App\Fiche".$produitSlug;

            $fiche    = $className::find($Idfiche);
            $equipeId = $fiche->dispatchable_id; 

            //Chercher le id equipe_user
            $equipeUser   = Equipeuser::where('user_id',$conseiller->id)
                                        ->where('equipe_id',$equipeId)
                                        ->first();

            $user = $equipeUser->user;

            $fiche->equipe_user_id    = $equipeUser->id;
            //$fiche->user_id         = $conseillerId;
            $fiche->dispatchable_id   = $equipeUser->equipe_id;
            $fiche->dispatchable_type = 'equipe';

            if($fiche->save()){
                
                $observation  = "<i class='uk-icon-group'></i> ".$equipeUser->equipe->nom."<br><i class='uk-icon-user'></i> ". strtoupper($user->nom)." ".ucfirst($user->prenom)." (".$user->login.")";
                $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
                $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
                event(new $event($tabInfoTrace));

            }

        }

        $userList     = [];
        
        $notif        = Notification::whereSlug('LEADDISPATCH')->first();
        
        $description  = "Vous avez reçu ".(count($arrayIdFiches) > 1 ? count($arrayIdFiches)." fiches" : "une fiche")." ".$produit->libelle;
        
        $notification = [
            'user_id'         => $conseiller->id,
            'notification_id' => $notif->id,
            'notifiable_id'   => $arrayIdFiches[0],
            'notifiable_type' => $produit->table_produit,
            'rappel_time'     => null,
            'link'            => url($conseiller->profile->slug.'/leads/'.$idStatut),
            'type'            => 'dispatch',
            'description'     => $description
        ];
       
        event(new EventNotifications($notification));

    }

    public function dispatchLeads(Request $request)
    {

        //return $request->all();
        $userInfo           = $this->userInfo();

        //$conseillerId  = $request->get('conseiller');
        $produitId          = $request->get('produit');
        $arrayIdFiches      = $request->get('arrayIdLeads');

        $produit            = Produit::find($produitId);
        $produitSlug        = $produit->slug;

        $idStatut           = Statut::whereSlug($produitSlug.'Appel')->value('id');
        $idAction           = Action::whereSlug('AFC')->value('id');

        //$conseiller = User::find($conseillerId);

        foreach ($arrayIdFiches as $arrayIdFiche) {

            $idFiche        = $arrayIdFiche['idFiche'];
            $idConseiller   = $arrayIdFiche['idConseiller']; 
            //Verifier si le conseiller a été choisi pour cette fiche
            if($idConseiller)
            {
                $conseiller     = User::find($idConseiller);

                $className      = "App\Fiche".$produitSlug;

                $fiche          = $className::find($idFiche);
                $equipeId       = $fiche->dispatchable_id; 

                //Chercher le id equipe_user
                $equipeUser     = Equipeuser::where('user_id',$conseiller->id)
                                            ->where('equipe_id',$equipeId)
                                            ->first();

                $user = $equipeUser->user;

                $fiche->equipe_user_id    = $equipeUser->id;
                //$fiche->user_id         = $conseillerId;
                $fiche->dispatchable_id   = $equipeUser->equipe_id;
                $fiche->dispatchable_type = 'equipe';

                if($fiche->save()){
                    
                    $observation  = "<i class='uk-icon-group'></i> ".$equipeUser->equipe->nom."<br><i class='uk-icon-user'></i> ". strtoupper($user->nom)." ".ucfirst($user->prenom)." (".$user->login.")";
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $equipeUser->id, 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null,'idGrouprPub' => $fiche->getGroupePubProv()->first()->groupepub_id];
                    $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
                    event(new $event($tabInfoTrace));

                }
               
                $userList     = [];
        
                $notif        = Notification::whereSlug('LEADDISPATCH')->first();
                
                $description  = "Vous avez reçu une fiche ".$produit->libelle." numéro : ".$fiche->num_fiche;
                
                $notification = [
                    'user_id'         => $conseiller->id,
                    'notification_id' => $notif->id,
                    'notifiable_id'   => $fiche->id,
                    'notifiable_type' => $produit->table_produit,
                    'rappel_time'     => null,
                    'link'            => url($conseiller->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug),
                    'type'            => 'dispatch',
                    'description'     => $description
                ];
               
                event(new EventNotifications($notification)); 

            }  

        }

        

    }


    public function redirectLead($grPrd, $client_id){

        $prd     = Groupeproduit::find($grPrd)->produits()->lists('id');
        
        $cltPrd  = ClientProduit::where('client_id', $client_id)->whereIn('produit_id',$prd)->orderBy('nombre', 'desc')->first();
        
        if(!$cltPrd){
            return redirect('equipe/leads/1');
        }

        $produitSlug = Produit::find($cltPrd->produit_id)->slug;

        

        switch($produitSlug) {

            // produit Santé
            case "sante":

                $fiche = Fichesante::where('client_id', $client_id)->whereActive(1)->orderBy('date_insertion', 'desc')->first();

                break;

            case "obseque":

                $fiche = Ficheobseque::where('client_id', $client_id)->whereActive(1)->orderBy('date_insertion', 'desc')->first();

                break;

            case "auto":

                break;

            default :

                return redirect('equipe/leads/1');

                break;
        }

        return redirect('equipe/leads/'.$produitSlug.'/'.$fiche->id);
    }


    public function DispatchAuto(Request $request){
        
        $equipe  = Equipe::find($request->get('idEquipe'));

        if($equipe->disp_auto){

            $equipe->disp_auto          = 0;

            if($equipe->save()) 
                $resultat = ["code" => 1, "etat" => "success", "msg" => "Dispatching automatique désactivé", "titre" => "opération éfectuée", "dispAuto" => $equipe->disp_auto];
            else    
                $resultat = ["code" => 3, "etat" => "error", "msg" => "", "titre" => "opération échouée !", "dispAuto" => $equipe->disp_auto];
            
        }else{

            if($equipe->active_matiere){

                $equipe->disp_auto      = 1;

                if($equipe->save()){

                    $FicheController    = new FicheController();
                    $resultatDisp       = $FicheController->dispatchingConseiller($equipe->id);
                    $resultat           = $resultat = ["code" => 4, "etat" => "success", "dispAuto" => $equipe->disp_auto, "resultatDisp" => $resultatDisp];
                    
                }else{

                    $resultat = ["code" => 3, "etat" => "error", "msg" => "", "titre" => "opération échouée !", "dispAuto" => $equipe->disp_auto];
                }
            }else{

                $resultat = ["code" => 2, "etat" => "warning", "msg" => "Vous devez activer la matière ", "titre" => "Attention !", "dispAuto" => $equipe->disp_auto];

            }
            
        }

        return $resultat;

    }

    /**
     * change le statut d'une ou plusieurs fiches
     */
    public function changeStatusLeads(Request $request)
    {
        $userInfo      = $this->userInfo();
        
        $statutId      = $request->get('statut');
        $produitId     = $request->get('produit');
        $arrayIdFiches = $request->get('arrayIdLeads');
        
        $produit       = Produit::find($produitId);
        $produitSlug   = $produit->slug;
        
        $statut        = Statut::find($statutId);
        
        $newStatut     = $statut->libelle;
        
        $idAction      = Action::whereSlug('CS')->value('id');
        
        $className     = "App\Fiche".$produitSlug;
        //                       ->whereIn('id', $arrayIdFiches)
        //                       ->update(['statut_id' => $statutId]);

        foreach ($arrayIdFiches as $Idfiche) {
            
            $fiche    = $className::find($Idfiche);

            $oldStatut = $fiche->statut->libelle;

            $fiche->statut_id      = $statut->id;
            $fiche->date_situation = Carbon::now();

            if($fiche->save()){

                $userInfo['tracable_id'] = $fiche->dispatchable_id;
                
                $observation  = "<i class='uk-text-danger material-icons'>&#xE14C;</i> ".$oldStatut."<br><i class='uk-text-success material-icons'>&#xE876;</i> ".$newStatut;
                
                $motif        = $request->has('modalMotifId') ? $request->get('modalMotifId') : null;
                
                $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
                
                $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
                event(new $event($tabInfoTrace));

            }

        }

        return [
                    "success"   => true,
                    "message"   => "Statut Changé",
                    "statutLib" => $newStatut
                ];

    }

    public function ActiveMatiere(Request $request)
    {
        $equipe  = Equipe::find($request->get('idEquipe'));
        $msg     = "";

        if($equipe->active_matiere)
        {
            $equipe->active_matiere = 0;
            $msg = "Matière désactivée.";
        }
        else
        {
            $equipe->active_matiere = 1;
            $msg = "Matière activée.";
        }

        if($equipe->save()){

            return $data = ["etat" => "success", "msg" => $msg, "titre" => "opération éfectuée", "matiere" => $equipe->active_matiere];
        }else{

            return $data = ["etat" => "error", "msg" => "", "titre" => "opération échouée !", "matiere" => $equipe->active_matiere];
        }

    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    
    public function validateDevisSante(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
    
        if($idFiche){

            $fiche = Fichesante::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="santeDevisNonSigne" or $fiche->statut->slug="santeDevisSigne"){

                $statut                = Statut::where('slug', 'santeContratDepot')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'VDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => null, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesSante($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => null, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutSante($tabInfoTraceStatut));


                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        array_push( $userList, $fiche->dispatchable->responsable() );

                    }else{

                        array_push( $userList, $fiche->dispatchable->responsable() );

                    }

                    $notif = Notification::whereSlug('DEVISSANTEVAL')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosDevisValide = ['idFiche' => $idFiche];
                    // event(new EventDevisValideSante($tabInfosDevisValide));

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." validé",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }


    public function rejectDevisSante(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
    
        if($idFiche){

            $fiche = Fichesante::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="santeDevisNonSigne" or $fiche->statut->slug="santeDevisSigne"){

                $statut                = Statut::where('slug', 'santeDevisRejete')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'RDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => $motifRejet, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesSante($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => $motifRejet, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutSante($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        array_push( $userList, $fiche->dispatchable->responsable() );

                    }else{

                        array_push( $userList, $fiche->dispatchable->responsable() );

                    }

                    $notif = Notification::whereSlug('DEVISSANTEREJ')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." rejeté",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    
    public function validateDevisObseque(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
    
        if($idFiche){

            $fiche = Ficheobseque::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="obsequeDevisNonSigne" or $fiche->statut->slug="obsequeDevisSigne"){

                $statut                = Statut::where('slug', 'obsequeContratDepot')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'VDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => null, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesObseque($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => null, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutObseque($tabInfoTraceStatut));


                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        array_push( $userList, $fiche->dispatchable->responsable() );

                    }else{

                        array_push( $userList, $fiche->dispatchable->responsable() );

                    }

                    $notif = Notification::whereSlug('DEVISOBSEQUEVAL')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosDevisValide = ['idFiche' => $idFiche];
                    // event(new EventDevisValideSante($tabInfosDevisValide));

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." validé",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }


    public function rejectDevisObseque(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
    
        if($idFiche){

            $fiche = Ficheobseque::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="obsequeDevisNonSigne" or $fiche->statut->slug="obsequeDevisSigne"){

                $statut                = Statut::where('slug', 'obsequeDevisRejete')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'RDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => $motifRejet, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesObseque($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => $motifRejet, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutObseque($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        array_push( $userList, $fiche->dispatchable->responsable() );

                    }else{

                        array_push( $userList, $fiche->dispatchable->responsable() );

                    }

                    $notif = Notification::whereSlug('DEVISOBSEQUEREJ')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." rejeté",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }
    public function userInfo(){

        $user = Auth::user();

        $userEquipe = $user->userEquipe()->first()->pivot;

        return $userInfo = ['equipe_user_id' => null, 'tracable_id' => $userEquipe->equipe_id, 'tracable_type' => 'equipe'];

    }


}
