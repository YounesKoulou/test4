<?php

namespace App\Http\Controllers\Equipe;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth, Session;

use App\Produit, App\Groupestatut, App\Sacompagnie, App\Sagamme, App\Agence, App\Site, App\Equipe, App\Fichesante, App\User, App\Prestataire, App\Groupepub, App\Tracessante;

class TracesDispatchController extends Controller
{
    
    public function index() {

    	$produits    = Produit::where('active', 1)->get();
        $idProduit   = Session::get('produit_id');

        //liste des prestataires qui traitent un produit choisie
        $prestataires= Prestataire::whereHas('groupepubs', function($q) use ($idProduit) {
                                    $q->where('produit_id', $idProduit);
                                })->orderBy('nom', 'asc')->get();
     

    	return view('equipesfiles.traceDispatch.index', ['produits' => $produits, 'prestataires' => $prestataires]);
    }


    public function selectPrestataire(Request $request){

        $idPrestataire  = $request->get('idPrestataire');
        $idProduit      = $request->get('idProduit');
        return $groupePubs     = Prestataire::find($idPrestataire)->groupepubs()->where('produit_id', $idProduit)->lists('id', 'nom');
    }

    public function selectAgence(Request $request){

        $idAgence  = $request->get('idAgence');
        //$idProduit      = $request->get('idProduit');
        return $groupePubs     = Agence::find($idAgence)->sites()->orderBy('nom')->lists('id', 'nom');
    }


    public function recherche(Request $request) {
        
        $idProduit          = $request->get('produit');
        $user               = Auth::user();		
        $lignes             = "";
        $colones            = "";
        $tabResult          = array();

        //return $request->get('groupePub');
        if($request->has('groupePub') && $request->get('groupePub') != 0){

            $idGroupPub     = $request->get('groupePub');
            //$lignes         = Groupepub::find($idGroupPub)->get();
            $lignes         = Groupepub::whereId($idGroupPub)->get();

        }else if($request->has('prestataire') && $request->get('prestataire') != 0){

            $idPrestataire  = $request->get('prestataire');
            $lignes         = Prestataire::find($idPrestataire)->groupepubs()->where('produit_id', $idProduit)->get(); 

        }else{

            $lignes         = Groupepub::where('produit_id', $idProduit)->get();

        }

        $colones            = $user->userEquipe()->where('equipe_user.active',1)->get();//retourner la liste des equipes de cet animateur
        $niveau             = 'equipe';


        

        foreach($lignes as $ligne){
            
            foreach($colones as $colone){

                $tabResult[$ligne->id][$colone->id] = Tracessante::where('tracable_type', $niveau)

                                                        ->where('tracable_id', $colone->id)
                                                        
                                                        ->where('groupepub_id', $ligne->id)

                                                        ->where(function($query) use ($request){

                                                            if($request->get('dateDebut') and $request->get('dateFin')){

                                                                $query->whereBetween('updated_at', [$request->get('dateDebut')." 00:00:00", $request->get('dateFin')." 23:59:59"]);

                                                            }else if($request->get('dateDebut')){

                                                                $query->where('updated_at', '>=', $request->get('dateDebut')." 00:00:00");

                                                            }else if($request->get('dateFin')){

                                                                $query->where('updated_at', '<=', $request->get('dateFin')." 23:59:59");
                                                            } 
                                                        }) 
                                                        ->count();

            }

        }

        return json_encode(['lignes' => $lignes, 'colones' => $colones, 'tabResult' => $tabResult, 'niveau' => $niveau]);


    }
}
