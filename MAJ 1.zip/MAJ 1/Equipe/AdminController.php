<?php

namespace App\Http\Controllers\Equipe;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests\UserRequest;
use App\Http\Requests;

//use Illuminate\Support\Facades\Auth;

use App\User;
use App\Agence;
use App\Courtier;
use App\Profile;
use App\Site;


use Auth;

class AdminController extends Controller
{
    
    public function editRespEquipe($id)
    {
        $adminequipe  = Auth::user();

        return view('equipesfiles.admins.editRespEquipe',['adminequipe'=> $adminequipe]);


    }


    public function updateRespEquipe(UserRequest $request,$id)
    {

        $user               = Auth::user();
        $user->nom          = $request->get('nom');
        $user->prenom       = $request->get('prenom');
        $user->login        = $request->get('login');
        $user->email        = $request->get('email');


        if($request->has('password')) 
        {    
           $user->password  = bcrypt($request->get('password'));
        }

        $user->save();


        $idequipe           = $user->userEquipe()->first()->pivot->equipe_id;


        return redirect('equipe/equipe/showResp/'.$idequipe);
    }

    public function activeUser($id)
    {
        //$user  = User::find($id);
        $user = Auth::user();
        
        if(count($user))
        {
            if($user->active)
            {
                $user->active = 0;
                $value        = 0;
            }
            else
            {
                $user->active = 1;
                $value        = 1;
            }

            $user->save();
            $msg = 'ok';

        }
        else
        {
            $msg = 'notok';
        }

        return ['msg'=>$msg , 'value'=>$value];    


    }
    

}
