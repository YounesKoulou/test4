<?php

namespace App\Http\Controllers\Equipe;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class ProfileController extends Controller
{
    public function index() {
       
        $idcourtier = Auth::user()->courtier_id;
        $agences    = Courtier::find($idcourtier)->agences()->paginate(5);
        $user = Auth::user();
        $nombreMessageNonLu = Messagerie::where('vu', 0)->whereActive(1)->where('to_id', $user->id)->orderBy('created_at', 'desc')->get();
        $oriasCourtier = Courtier::first()->orias;

        $traces = Tracessante::where('user_id', $user->id)->orderBy('created_at', 'desc')->take(10)->get();
       return view('equipesfiles.equipes.profile', ['agences' => $agences, 'user' => $user, 'nombreMessageNonLu' => $nombreMessageNonLu, 'traces' => $traces, 'oriasCourtier' => $oriasCourtier]);
    }
}