<?php

namespace App\Http\Controllers\Equipe;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Events\EventTracesSante;            
use App\Events\EventTracesObseque;     
use App\Events\EventNotifications;

use App\Agence;
use App\Site;
use App\Equipe;
use App\Groupepub; 
use App\Equipeusergroupepub;
use App\Origine;
use App\Produit;
use App\Typefiche;
use App\Objectifuser;
use App\ObjectifuserTypefiche;
use App\Tracessante;
use App\Tracesauto;
use App\Tracesobseque;
use App\Fichesante;
use App\Ficheauto;
use App\Ficheobseque;
use App\Action;
use App\Statut;
use App\UserTypefiche;
use App\Equipeuser;
use App\Notification;

use Crypt;
use Auth;
use \Carbon\Carbon;



class ObjectifController extends Controller
{

    public function ObjectifUsers($idProduit, $idEquipe){

        $idProd             = Crypt::decrypt($idProduit);      
        $idEqu              = Crypt::decrypt($idEquipe);
        $equipe             = Equipe::find($idEqu);
        
        return view('equipesfiles.affectationObjectif.objectifConseillers', ['produitActif' => $idProd, 'equipe' => $equipe]);
    }

    public function listProduits(Request $request){

        $idEquipe           = $request->get('idEquipeActif');
        $equipe             = Equipe::find($idEquipe);
        $produits           = $equipe->produits;
        // $produits           = $equipe->produitsActifs;

        return response()->json($produits);
    }

    public function listGroupePubs(Request $request){

        $idEquipe           = $request->get('idEquipeActif');
        $idProduit          = $request->get('idProduitActif');
        $equipe             = Equipe::find($idEquipe);
        $groupePubs         = $equipe->groupepubs()->where('produit_id', $idProduit)->with('prestataire')->get();
        //$groupePubs         = $equipe->groupepubs()->wherePivot('active', 1)->where('produit_id', $idProduit)->with('prestataire')->get();

        return response()->json($groupePubs);
    }

    public function ObjectifUsersMois(Request $request){

        $idProduitActif     = $request->get('idProduitActif');
        $idEquipeActif      = $request->get('idEquipeActif');
        $annee              = $request->get('annee');
        $mois               = $request->get('mois');                

        //$equipe             = Equipe::find($idEquipeActif);
        // les conseillers d un produit
        $idsProduitUsers    = Produit::find($idProduitActif)->users()->where('users.active', 1)->lists('users.id');
        $users              = Equipe::find($idEquipeActif)
                                ->getUserEquipe()->wherePivot('active', 1)
                                ->where('users.active', 1)->where('users.profile_id',7)
                                ->whereIn('users.id', $idsProduitUsers)->get();

        $typeFichesProduit  = Typefiche::where('produit_id', $idProduitActif)->where('active', 1)->select('libelle', 'id')->get(); 
        //$priorites          = range(0, $users->count());
        
        $listObjUser        = array();
        $i                  = $users->count();

        foreach($users as $user){
          
            $userEquipe     = $user->getUserEquipeObj()->where('equipe_id', $idEquipeActif)->where('active', 1)->first();
            $userObj        = $userEquipe->objectifuser($idProduitActif)
                                ->where('annee', $annee)
                                ->where('mois', $mois)
                                ->select('objectifusers.id', 'objectifusers.obj_fiche_mois', 'objectifusers.annee', 'objectifusers.mois', 'objectifusers.active')
                                ->first();

            if($typeFichesProduit && $userObj){

                $listObjTypeFicheUser      = array();

                foreach($typeFichesProduit as $typeFicheProduit){

                    $objTypeFicheUser      = ObjectifuserTypefiche::where('typefiche_id', $typeFicheProduit->id)->where('objectifuser_id', $userObj->id)->first();

                    if($objTypeFicheUser){

                        $listObjTypeFicheUser[$typeFicheProduit->id] = $objTypeFicheUser;

                    }else{

                        $listObjTypeFicheUser[$typeFicheProduit->id] = ['objectifuser_id'=> $userObj->id, 'typefiche_id' => $typeFicheProduit->id, 'obj_fiche_mois' => 0];
                    }
                }

                $userObj->objectifuserTypefiche = $listObjTypeFicheUser;
            }                    
            

            $infosUser      = collect(['nomUser'=> $user->nom, 'idUserEquipe'=> $userEquipe->id]);
            
            if($userObj){

                //$listObjUser[($userGrpPub->pivot->priorite ? $userGrpPub->pivot->priorite : $i)] = $infosUser->merge($userGrpPub->toArray());
                //$listObjUser[]     = $infoUserGrpPub->merge(['priorite' => ($userGrpPub->priorite ? $userGrpPub->priorite : $i)]);
                $listObjUser[]       = $infosUser->merge($userObj);
                                
            }else{

                $listObjTypeFicheUser      = array();

                foreach($typeFichesProduit as $typeFicheProduit){

                    $listObjTypeFicheUser[$typeFicheProduit->id] = ['typefiche_id' => $typeFicheProduit->id, 'obj_fiche_mois' => 0];

                }
                
                // $infosUser->combine(objectifuserTypefiche)   = $listObjTypeFicheUser;
                $infosUser->prepend($listObjTypeFicheUser, 'objectifuserTypefiche');
                $listObjUser[]                      = $infosUser->all();
                // $i++;
                // $listObjUser[]       = $infosUser->merge(['priorite' => $i]);                
            }
         
        }

        return ['listObjUser' => $listObjUser, 'typeFichesProduit' => $typeFichesProduit];

        // $listObjUserTri              = collect($listObjUser)->sortBy('priorite');
        // //$listObjUserTri->pull('pivot');
        // return $listObjUserTri->values()->all();

    }


    public function ObjectifUsersUpdate(Request $request){

        $idObjectifUser = $request->get('idObjectifUser');
        $active         = $request->get('active');
        $objectif       = (int)$request->get('objectif');
        $idUserEquipe   = $request->get('idUserEquipe');
        $idProduit      = $request->get('idProduit'); 
        $annee          = $request->get('annee'); 
        $mois           = $request->get('mois');        

        // si la ligne existe deja
        if($idObjectifUser){

            $objectifUser                 = Objectifuser::find($idObjectifUser);

        }else{

            $objectifUser                 = new Objectifuser;
            $objectifUser->equipe_user_id = $idUserEquipe;
            $objectifUser->produit_id     = $idProduit; 
            $objectifUser->annee          = $annee; 
            $objectifUser->mois           = $mois; 
        }

        $objectifUser->active             = $active;
        $objectifUser->obj_fiche_mois     = $objectif;

        if($objectifUser->save()){

            $resultat = $objectifUser;

        }else{

            $resultat = false;
        } 

        return ['objectifUser' => $resultat];        

    }


    public function ObjectifParTypeFicheUpdate(Request $request){

        $idObjectifUser = $request->get('idObjectifUser');
        $idTypeFiche    = $request->get('idTypeFiche');
        $idObjectifType = $request->get('idObjectifType'); 
        $active         = $request->get('active');
        $objectif       = (int)$request->get('objectif');   

        // si la ligne existe deja
        if($idObjectifType){

            $objectifType                   = ObjectifuserTypefiche::find($idObjectifType);

        }else{

            $objectifType                   = new ObjectifuserTypefiche;
            $objectifType->objectifuser_id  = $idObjectifUser;
            $objectifType->typefiche_id     = $idTypeFiche; 
        }

        $objectifType->active             = $active;
        $objectifType->obj_fiche_mois     = $objectif;

        if($objectifType->save()){

            $resultat = $objectifType;

        }else{

            $resultat = false;
        } 

        return ['objectifType' => $resultat];     

    }


    public function syntheseAffectation(){
        
        $equipes        = Auth::user()->userEquipe()->where('equipes.active', 1)->get();
        $listProduits   = collect();
        
        foreach($equipes as $equipe){

            $produitsEquipe = $equipe->produits;
            $listProduits   = $listProduits->merge($produitsEquipe);
        }
        
        $produits = $listProduits->unique('libelle')->values()->toJson();

        return view('equipesfiles.affectationObjectif.syntheseAffectation',['equipes' => $equipes, 'produits' => $produits]);        
    }


    public function changerEtatUserTypefiche(Request $request){

        $idUser             = $request->get('idUser');
        $idTypefiche        = $request->get('idTypefiche');

        $userTypefiche      = UserTypefiche::where('user_id', $idUser)
                                ->where('typefiche_id', $idTypefiche)
                                ->first();
        
        if($userTypefiche){

            $userTypefiche->etat         = ($userTypefiche->etat ? 0 : 1);

        }else{

            $userTypefiche               = new UserTypefiche;
            $userTypefiche->user_id      = $idUser;
            $userTypefiche->typefiche_id = $idTypefiche;
            $userTypefiche->etat         = 0;
            $userTypefiche->active       = 1;            
        }

        if($userTypefiche->save()){

            return ['etat'=>'OK', 'etatTypefiche'=>$userTypefiche->etat];

        }else{

            return ['etat'=>'KO'];
        }       

    }


    public function syntheseAffectationfUsers(Request $request){

        $idProduitActif     = $request->get('idProduitActif');
        $idEquipeActif      = $request->get('idEquipeActif');
        $annee              = $request->get('annee');
        $mois               = $request->get('mois');        

        $produit            = Produit::find($idProduitActif);
        $statut             = Statut::whereSlug($produit->slug."Appel")->first();

        $tableTrace         = 'App\Traces'.$produit->slug;
        $tableFiche         = 'App\Fiche'.$produit->slug;
        $queryOrder         = 'equipe_user_id';
        $ordre              = 'asc';
        $dateFilter         = 'created_at' ;   

        //liste de fiches non affectées 
        $fiches             = array();
        $listFiches = $tableFiche::whereActive(1)
                                ->where('dispatchable_id', $idEquipeActif)
                                ->where('dispatchable_type', 'equipe')
                                ->where('produit_id', $idProduitActif)
                                ->where('statut_id', $statut->id)
                                ->whereNull('equipe_user_id')
                                ->orderBy( $dateFilter, $ordre )
                                ->with('statut')
                                ->with('produit')
                                ->with('societe')
                                ->with(['client' => function($q1){
                                    $q1->with('regime');
                                }])
                                ->with('equipeAffect')
                                ->with('enfants')
                                ->with(['conjoint' => function($q){
                                    $q->with('regime');
                                }])
                                ->get();  

        foreach($listFiches as $listFiche){

            $fiches[] = collect($listFiche)->put('details', false)->put('cocher', false);
            
        }

        // liste des conseillers
        $conseillers    = Equipe::find($idEquipeActif)
                            ->getUserEquipe()
                            ->where('users.connected', 1)
                            ->where('equipe_user.active',1)
                            ->whereHas('produits', function ($query) use ($idProduitActif) {
                                $query->where('produit_id', $idProduitActif);
                            })
                            ->get();

        $tabSlugActAffect   = ['AFC', 'DAC'];
        $idsActionsAffect   = Action::whereIn('slug', $tabSlugActAffect)->lists('id');

        $dateDebut          = $annee.'-'.str_pad($mois, 2, "0", STR_PAD_LEFT).'-01';
        $dateFin            = $annee.'-'.str_pad($mois, 2, "0", STR_PAD_LEFT).'-31';

        $dateDebutJour      = date('Y-m-d').' 00:00:00';
        $dateFinJour        = date('Y-m-d').' 23:59:59';

        $idsProduitUsers    = Produit::find($idProduitActif)->users()->where('users.active', 1)->lists('users.id');
        
        $users              = Equipe::find($idEquipeActif)
                                ->getUserEquipe()
                                ->wherePivot('active', 1)
                                ->where('users.active', 1)
                                ->where('users.profile_id',7)
                                ->whereIn('users.id', $idsProduitUsers)
                                ->get();

        $typesFichesProduit = Typefiche::where('produit_id', $idProduitActif)->where('active', 1)->select('libelle', 'id', 'slug')->get(); 
        //$priorites          = range(0, $users->count());
        
        $listObjUser        = array();
        $i                  = $users->count();

        foreach($users as $user){

            $listFicheAffMoisType   = array();
            $listFicheAffJourType   = array();
            $listEtatUserTypefiche  = array();

            $userEquipe     = $user->getUserEquipeObj()->where('equipe_id', $idEquipeActif)->where('active', 1)->first();

            $userObj        = $userEquipe->objectifuser($idProduitActif)
                                ->where('annee', $annee)
                                ->where('mois', $mois)
                                ->select('objectifusers.id', 'objectifusers.obj_fiche_mois', 'objectifusers.annee', 'objectifusers.mois', 'objectifusers.active')
                                ->first();

            
            $listFicheAffMois = $tableTrace::whereIn('action_id', $idsActionsAffect)
                                    ->where('equipe_user_id', $userEquipe->id)
                                    ->whereBetween('created_at', [$dateDebut, $dateFin])
                                    ->get();

            if($listFicheAffMois){

                $nbrFicheAffMois    = $listFicheAffMois->count();

                $listFicheAffJour   = $tableTrace::whereIn('action_id', $idsActionsAffect)
                                        ->where('equipe_user_id', $userEquipe->id)
                                        ->whereBetween('created_at', [$dateDebutJour, $dateFinJour])
                                        ->get();

                $nbrFicheAffJour    =  $listFicheAffJour->count();                    

                foreach($typesFichesProduit as $typeFichesProduit){

                    $idsGrpPubType  = Groupepub::where('typefiche_id', $typeFichesProduit->id)->where('produit_id', $idProduitActif)->lists('id');

                    if($idsGrpPubType){

                        $listFicheAffMoisType[$typeFichesProduit->slug]     = $listFicheAffMois->whereIn('groupepub_id', $idsGrpPubType->toArray())->count();

                        if($listFicheAffMoisType[$typeFichesProduit->slug]){

                            $listFicheAffJourType[$typeFichesProduit->slug] = $listFicheAffJour->whereIn('groupepub_id', $idsGrpPubType->toArray())->count();

                        }else{

                            $listFicheAffJourType[$typeFichesProduit->slug] = 0;
                        }

                    }else{

                        $listFicheAffMoisType[$typeFichesProduit->slug]     = 0;
                        $listFicheAffJourType[$typeFichesProduit->slug]     = 0;
                    }

                    // $listFicheAffMois->filter(function ($value, $key) {
                    //     return $value > 2;
                    // });  
                }

               
                // $listFicheAffJour = $listFicheAffMois->filter(function ($value, $key) {
                //     return $value > 2;
                // });                                     

            }else{

                $nbrFicheAffMois  = 0;
                $nbrFicheAffJour  = 0;

                foreach($typesFichesProduit as $typeFichesProduit){
                    
                    $listFicheAffMoisType[$typeFichesProduit->slug]     = 0;
                    $listFicheAffJourType[$typeFichesProduit->slug]     = 0;
                }                    
            } 

            // liste des fiches non lu

            $nbrNnlu            = $tableFiche::where('equipe_user_id', $userEquipe->id)
                                    ->where('lu', 0)
                                    ->whereBetween('created_at', [$dateDebut, $dateFin])
                                    ->count();
            
            // liste des fausses fiches

            $slugStatutFF       = $produit->slug."FausseFiche";
            $idStatutFF         = Statut::where('slug', $slugStatutFF)->first()->id;

            if($idStatutFF){

                $nbrFausseFiche     = $tableFiche::where('equipe_user_id', $userEquipe->id)
                                        ->where('statut_id', $idStatutFF)
                                        ->whereBetween('created_at', [$dateDebut, $dateFin])
                                        ->count();
            }

            // list des etats user typefiche

            foreach($typesFichesProduit as $typeFichesProduit){

                $userTypefiche      = UserTypefiche::where('user_id', $user->id)
                                        ->where('typefiche_id', $typeFichesProduit->id)
                                        ->first();
                
                if($userTypefiche){

                    $listEtatUserTypefiche[$typeFichesProduit->slug]    = $userTypefiche->etat;

                }else{
                
                    $listEtatUserTypefiche[$typeFichesProduit->slug]    = 1;
                }
            }


            //return $listFicheAffMoisType['ANI'];
            $infosUser      =  collect(['idUser'               => $user->id, 
                                        'logoUser'             => $user->photo, 
                                        'nomUser'              => $user->nom, 
                                        'idUserEquipe'         => $userEquipe->id, 
                                        'nbrFicheAffMois'      => $nbrFicheAffMois, 
                                        'listFicheAffMoisType' => $listFicheAffMoisType, 
                                        'nbrFicheAffJour'      => $nbrFicheAffJour, 
                                        'listFicheAffJourType' => $listFicheAffJourType,
                                        'listEtatUserTypefiche'=> $listEtatUserTypefiche,
                                        'nbrNnlu'              => $nbrNnlu,
                                        'nbrFausseFiche'       => $nbrFausseFiche
                                      ]);
            
            if($userObj){

                //$listObjUser[($userGrpPub->pivot->priorite ? $userGrpPub->pivot->priorite : $i)] = $infosUser->merge($userGrpPub->toArray());
                //$listObjUser[]     = $infoUserGrpPub->merge(['priorite' => ($userGrpPub->priorite ? $userGrpPub->priorite : $i)]);
                $listObjUser[]       = $infosUser->merge($userObj);
                                
            }else{

                $listObjUser[]       = $infosUser;
                // $i++;
                // $listObjUser[]       = $infosUser->merge(['priorite' => $i]);                
            }
         
        }


        return ['listObjUser' => $listObjUser, 'typesFichesProduit' => $typesFichesProduit, 'fiches' => $fiches, 'conseillers' => $conseillers];        
    }


    public function listConseillersActif(Request $request){

        $idProduitActif     = $request->get('idProduitActif');
        $idEquipeActif      = $request->get('idEquipeActif');

        $conseillers    = Equipe::find($idEquipeActif)
                            ->getUserEquipe()
                            ->where('users.connected', 1)
                            ->where('equipe_user.active',1)
                            ->whereHas('produits', function ($query) use ($idProduitActif) {
                                $query->where('produit_id', $idProduitActif);
                            })
                            ->get();
        
        return ['conseillers' => $conseillers];

    }



    public function AffcterFicheConseiller(Request $request){

        $idProduitActif         = $request->get('idProduitActif');
        $idEquipeActif          = $request->get('idEquipeActif');  
        $idFiche                = $request->get('idFiche');
        $idUser                 = $request->get('idUser'); 
        $etat                   = 'OK';  

        if($idUser){

            $produit                = Produit::find($idProduitActif);
            $tableFiche             = 'App\Fiche'.$produit->slug;  

            $equipeUser             = Equipeuser::where('user_id', $idUser)->where('equipe_id', $idEquipeActif)->whereActive(1)->first(); 
            $user                   = $equipeUser->user;
            $observation            = "<i class='uk-icon-institution'></i> ".$equipeUser->equipe->site->agence->nom."<br><i class='uk-icon-map-marker'></i> ".$equipeUser->equipe->site->nom."<br><i class='uk-icon-group'></i> ".$equipeUser->equipe->nom."<br><i class='uk-icon-user'></i> ". strtoupper($user->nom)." ".ucfirst($user->prenom)." (".$user->login.")";
            $actionSlug             = 'AFC';
            $idAction               = Action::whereSlug($actionSlug)->value('id');
            // $idStatut               = Statut::whereSlug($produit->slug.'Appel')->value('id');

            $fiche                  = $tableFiche::find($idFiche);
            $fiche->equipe_user_id  = $equipeUser->id;

            if($fiche->save()){

                $observation        = "<i class='uk-icon-group'></i> ".$equipeUser->equipe->nom."<br><i class='uk-icon-user'></i> ". strtoupper($user->nom)." ".ucfirst($user->prenom)." (".$user->login.")";

                $tabInfoTrace       = ['idAction'       => $idAction, 
                                       'idFiche'        => $fiche->id, 
                                       'idStatut'       => $fiche->statut_id, 
                                       'equipe_user_id' => $equipeUser->id, 
                                       'tracable_id'    => $idEquipeActif, 
                                       'tracable_type'  => 'equipe', 
                                       'observation'    => $observation, 
                                       'motif'          => null
                                      ];
                $event              = 'App\Events\EventTraces'.ucfirst($produit->slug);
                event(new $event($tabInfoTrace));

            }else{

                $etat = 'KO';
            }
    
            $notif        = Notification::whereSlug('LEADDISPATCH')->first();
            
            $description  = "Vous avez reçu une fiche ".$produit->libelle." numéro : ".$fiche->num_fiche;
            
            $notification = [
                'user_id'         => $user->id,
                'notification_id' => $notif->id,
                'notifiable_id'   => $fiche->id,
                'notifiable_type' => $produit->table_produit,
                'rappel_time'     => null,
                'link'            => url($user->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug),
                'type'            => 'dispatch',
                'description'     => $description
            ];
            
            event(new EventNotifications($notification));  

                  
        }

        return ['etat' => $etat];
    }

}
