<?php

namespace App\Http\Controllers\Equipe;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Agence;
use App\Site;
use App\Equipe;
use App\Groupepub; 
use App\Equipeusergroupepub;
use App\Origine;
use App\Produit;

use Crypt;


class DispatchController extends Controller
{

    public function DispatchUsers($idProduit, $idEquipe){

        $idProd             = Crypt::decrypt($idProduit);      
        $idEqu              = Crypt::decrypt($idEquipe);
        $equipe             = Equipe::find($idEqu);
        
        return view('equipesfiles.dispatching.dispConseillers', ['produitActif' => $idProd, 'equipe' => $equipe]);
    }

    public function listProduits(Request $request){

        $idEquipe           = $request->get('idEquipeActif');
        $equipe             = Equipe::find($idEquipe);
        $listProduits       = $equipe->produits;
        $produits           = array();
        // $produits           = $equipe->produitsActifs;
        foreach($listProduits as $produit){

            $produits[]     = collect($produit)->put('etatGroupPubProduit', true);
            
        }

        return response()->json($produits);
    }

    public function listGroupePubs(Request $request){

        $idEquipe           = $request->get('idEquipeActif');
        $idProduit          = $request->get('idProduitActif');
        $equipe             = Equipe::find($idEquipe);
        $groupePubs         = $equipe->groupepubs()->where('produit_id', $idProduit)->with('prestataire')->get();
        //$groupePubs         = $equipe->groupepubs()->wherePivot('active', 1)->where('produit_id', $idProduit)->with('prestataire')->get();

        return ['listGrpPubs' => $groupePubs];
    }

    public function DispatchUsersGroupPub(Request $request){

        $idProduitActif     = $request->get('idProduitActif');
        $idGroupPubActif    = $request->get('idGroupPubActif');
        $idEquipeActif      = $request->get('idEquipeActif');

        //$equipe             = Equipe::find($idEquipeActif);
        // les conseillers d un produit
        $idsProduitUsers    = Produit::find($idProduitActif)->users()->where('users.active', 1)->lists('users.id');
        $users              = Equipe::find($idEquipeActif)
                                ->getUserEquipe()->wherePivot('active', 1)
                                ->where('users.active', 1)->where('users.profile_id',7)
                                ->whereIn('users.id', $idsProduitUsers)->get();

        // $idsUsers           = Equipe::whereId($idEquipeActif)->first()->conseillersActifEquipeProduit($idProduitActif)->lists('equipe_user.id');
        //$priorites          = range(0, $users->count());
        
        $listUserGrpPub     = array();
        $i                  = $users->count();

        foreach($users as $user){
          
            $userEquipe     = $user->getUserEquipeObj()->where('equipe_id', $idEquipeActif)->where('active', 1)->first();
            $userGrpPub     = $userEquipe->groupepubs()->where('groupepub_id',$idGroupPubActif)
                            ->select('equipe_user_groupepub.id', 'equipe_user_groupepub.quota', 'equipe_user_groupepub.max_fiche', 'equipe_user_groupepub.priorite', 'equipe_user_groupepub.nbr_fiche_dispatch', 'equipe_user_groupepub.quota_recu', 'equipe_user_groupepub.nbr_fiche', 'equipe_user_groupepub.nbr_fiche_jour', 'equipe_user_groupepub.active')
                            ->first();

            $infosUser      = collect(['nomUser'=> $user->nom, 'iduserEqu'=> $userEquipe->id]);
            
            if($userGrpPub){

                //$listUserGrpPub[($userGrpPub->pivot->priorite ? $userGrpPub->pivot->priorite : $i)] = $infosUser->merge($userGrpPub->toArray());
                //$listUserGrpPub[]     = $infoUserGrpPub->merge(['priorite' => ($userGrpPub->priorite ? $userGrpPub->priorite : $i)]);
                $listUserGrpPub[]       = $infosUser->merge($userGrpPub);
                                
            }else{

                //$listUserGrpPub[$i]     = $infosUser;
                $i++;
                $listUserGrpPub[]       = $infosUser->merge(['priorite' => $i]);                
            }
         
        }

        $listUserGrpPubTri              = collect($listUserGrpPub)->sortBy('priorite');
        //$listUserGrpPubTri->pull('pivot');
        return $listUserGrpPubTri->values()->all();

    }

    public function initialiserDispatching(Request $request){

        $idProduitActif     = $request->get('idProduitActif');
        $idEquipeActif      = $request->get('idEquipeActif');

        // liste des groupes pubs d'un produit
        $idsGroupePubs      = Equipe::find($idEquipeActif)->groupepubs()->where('produit_id', $idProduitActif)->lists('groupepubs.id');

        // les conseillers d un produit
        $idsUsers           = Equipe::whereId($idEquipeActif)->first()->conseillersActifEquipeProduit($idProduitActif)->lists('equipe_user.id');
                                
        $resultat = Equipeusergroupepub::whereIn('equipe_user_id', $idsUsers)->whereIn('groupepub_id', $idsGroupePubs)->delete();

        return ['nbrLignes' => $resultat];

        // }else{

        //     return 'KO';
        // }
    }

    public function DispatchUsersUpdate(Request $request){

        $idDispatchUser         = $request->get('idDispatchUser');
        $active                 = $request->get('active');
        $quota                  = (int)$request->get('quota');
        $maxFiche               = (int)$request->get('maxFiche');
        $priorite               = $request->get('priorite');
        $idUserEquipe           = $request->get('idUserEquipe');
        $idGroupePub            = $request->get('idGroupePub');   
        $etatGroupPubProduit    = $request->get('etatGroupPubProduit');   
        $idProduit              = $request->get('idProduit');  
        $idEquipe               = $request->get('idEquipe');  

        if($etatGroupPubProduit){

            // si la ligne existe deja
            if($idDispatchUser){

                $equipeusergroupepub                 = Equipeusergroupepub::find($idDispatchUser);

            }else{

                $equipeusergroupepub                 = new Equipeusergroupepub;
                $equipeusergroupepub->equipe_user_id = $idUserEquipe;
                $equipeusergroupepub->groupepub_id   = $idGroupePub; 
                
                // $maxPriorite    = Equipeusergroupepub::where('equipe_user_id', $idUserEquipe)
                //                                         ->where('groupepub_id', $idGroupePub)
                //                                         ->max('priorite');
                // $priorite       = $priorite + 1;            
            }

            $equipeusergroupepub->active             = $active;
            $equipeusergroupepub->quota              = $quota;
            $equipeusergroupepub->max_fiche          = $maxFiche;                
            $equipeusergroupepub->priorite           = $priorite;

            if($equipeusergroupepub->save()){

                $resultat = $equipeusergroupepub;

            }else{

                $resultat = false;
            }

        }else{

            $groupePubs         = Equipe::whereId($idEquipe)->first()->groupepubs()->where('produit_id', $idProduit)->get();
            $resultat           = array();

            foreach($groupePubs as $groupePub){

                // si la ligne existe deja
                if($idDispatchUser){

                    $equipeusergroupepub                 = Equipeusergroupepub::where('groupepub_id', $groupePub->id)->where('equipe_user_id', $idUserEquipe)->first();

                }else{

                    $equipeusergroupepub                 = new Equipeusergroupepub;
                    $equipeusergroupepub->equipe_user_id = $idUserEquipe;
                    $equipeusergroupepub->groupepub_id   = $groupePub->id; 
                    
                    // $maxPriorite    = Equipeusergroupepub::where('equipe_user_id', $idUserEquipe)
                    //                                         ->where('groupepub_id', $idGroupePub)
                    //                                         ->max('priorite');
                    // $priorite       = $priorite + 1;            
                }

                $equipeusergroupepub->active             = $active;
                $equipeusergroupepub->quota              = $quota;
                $equipeusergroupepub->max_fiche          = $maxFiche;                
                $equipeusergroupepub->priorite           = $priorite;

                if($equipeusergroupepub->save()){

                    $resultat = $equipeusergroupepub;

                }else{

                    $resultat = false;
                } 
            }            
        }

        return ['equipeusergroupepub' => $resultat];
    }

     public function DispatchUsersUpdateOrder(Request $request){

    	$dispatchUsers      = $request->get('dispatchUsers');
    	$count              = 1;

    	foreach ($dispatchUsers as $dispatchUser){

            if(isset($dispatchUser['id'])){

                $equipeusergroupepub            = Equipeusergroupepub::find($dispatchUser['id']);
                $equipeusergroupepub->priorite  = $count;
                $equipeusergroupepub->save();
                $count++;
            }
    	}
    }
}
