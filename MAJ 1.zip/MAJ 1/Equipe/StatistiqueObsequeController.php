<?php

namespace App\Http\Controllers\Equipe;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;


use DB, Auth, Carbon\carbon;

use App\Groupestatut, App\Messagerie, App\Produit, App\Equipeuser;

class StatistiqueObsequeController extends Controller
{
    
    private $dateDebut;
    private $dateFin;
    private $dt;
    private $produit;

    public function __construct() {

        $this->dt               = Carbon::create((int)date('Y'), (int)date('m'), (int)date('d'), 23, 59, 59);  
        $this->dateDebut        = '';
        $this->dateFin          = $this->dt->toDateString().' 23:59:59'; 
        $this->produit          = 'ficheobseques';
        $this->idProduit        = Produit::whereSlug('obseque')->first()->id;
    }


    public function getstatusContrat() {
        return Groupestatut::where('slug', 'contrats')->first()->getStatus($this->idProduit)->lists('id');
    }

    public function getstatusDevis() {
        return Groupestatut::where('slug', 'devis')->first()->getStatus($this->idProduit)->lists('id');
    }

    public function getstatusLeads() {
         return Groupestatut::where('slug', 'leads')->first()->getStatus($this->idProduit)->lists('id');
    }


     public function filterOptions(Request $request) {

                switch ($request->get('option')) {
                   
                    case "option1":
                        $this->dateDebut = $this->dt->toDateString().' 00:00:00';
                        break;
                    case "option2":
                        $this->dateDebut = $this->dt->subDay()->toDateString().' 00:00:00';
                        break;
                    case "option3":
                        $this->dateDebut = $this->dt->subWeek()->toDateString().' 00:00:00';
                        break;
                    case "option4":
                        $this->dateDebut = $this->dt->subMonth()->toDateString().' 00:00:00';
                        break;
                    case "option5":
                        $this->dateDebut = $this->dt->subYear()->toDateString().' 00:00:00';
                        break;
                    default :
                        $this->dateFin    = $request->get('dateFin').' 23:59:59'; 
                        $this->dateDebut  = $request->get('dateDebut').' 00:00:00';
                        break;
                }


                if(!empty($request->get('dateDebut'))) {
                    $this->dateDebut    = $request->get('dateDebut').' 00:00:00'; 
                }

                 if(!empty($request->get('dateFin'))) {
                    $this->dateFin    = $request->get('dateFin').' 23:59:59'; 
                }
            
            $this->produit  =  $request->get('produit');

     }


     public function index(Request $request) {
        $produits      = Produit::where('active', 1)->get();
     	$user          = Auth::user();
        $equipes       = $user->userEquipe()->where('equipe_user.active', 1)->get();

     	 return view('equipesfiles.statistiques.index', ['equipes' => $equipes, 'produits' => $produits]);
     }


     public function nombreFicheParStatut(Request $request) {
           
            $this->filterOptions($request);

            $user          = Auth::user();
            $equipes       = $user->userEquipe()->where('equipe_user.active', 1)->get();

            $equipeIds     = $equipes->lists('pivot.equipe_id');
            $conseillers   = Equipeuser::whereIn('equipe_id', $equipeIds)->whereActive(1)->lists('id');
            $equipeUserIds = (((int)$request->get('conseiller') > 0) ? [(int)$request->get('conseiller')] : $conseillers);

         	$fiches = DB::table($this->produit)
    							->join('statuts',"statut_id",'=','statuts.id')
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

                    	          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
                                ->whereIn('statut_id', $this->getstatusLeads())
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id', $equipeUserIds)
    							->select(DB::raw('count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'), 'libelle')
    							->groupBy("statut_id")
    							->get(); 
            
            $data = NULL;
            if($fiches){
	            foreach($fiches as $fiche) {
	                $data['ficheParStatut'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
	                $data['chiffreParStatut'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->nbrefiches];
	            }
	        }

    		return json_encode($data);

     }



    public function nombreFicheParRegime(Request $request) {

     	    $this->filterOptions($request);
            
            $user          = Auth::user();
            $equipes       = $user->userEquipe()->where('equipe_user.active', 1)->get();

            $equipeIds     = $equipes->lists('pivot.equipe_id');
            $conseillers   = Equipeuser::whereIn('equipe_id', $equipeIds)->whereActive(1)->lists('id');
            $equipeUserIds = (((int)$request->get('conseiller') > 0) ? [(int)$request->get('conseiller')] : $conseillers);
                

         	    $fiches = DB::table($this->produit)
    							->join('saregimes',"saregime_id",'=','saregimes.id')
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id',$equipeUserIds)
    							->select(DB::raw('count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'), 'saregimes.libelle')
    							->groupBy("saregime_id")
    							->get(); 

            
            $data = NULL;
            foreach($fiches as $fiche) {
                $data['ficheParRegime'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
                $data['chiffreParRegime'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->nbrefiches];
            }

    		return json_encode($data);

     }


     public function nombreFicheParCompagnie(Request $request) {
          
          $this->filterOptions($request);

            $user          = Auth::user();
            $equipes       = $user->userEquipe()->where('equipe_user.active', 1)->get();

            $equipeIds     = $equipes->lists('pivot.equipe_id');
            $conseillers   = Equipeuser::whereIn('equipe_id', $equipeIds)->whereActive(1)->lists('id');
            $equipeUserIds = (((int)$request->get('conseiller') > 0) ? [(int)$request->get('conseiller')] : $conseillers);

          $fiches = DB::table($this->produit)
                                ->join('obgammes',"obgamme_id",'=','obgammes.id')
    							->join('sacompagnies',"obgammes.sacompagnie_id",'=','sacompagnies.id')
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
    							->whereIn('statut_id', $this->getstatusContrat())
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id', $equipeUserIds)
    							->select(DB::raw('count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'), 'sacompagnies.libelle')
    							->groupBy("sacompagnie_id")
    							->get(); 

            
            $data = NULL;

            if($fiches){
	            foreach($fiches as $fiche) {
	                $data['ficheParCompagnie'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
	            }
	        }

    		return json_encode($data);
     }



     public function infoGenerale(Request $request) {

            $this->filterOptions($request);

            $user          = Auth::user();
            $equipes       = $user->userEquipe()->where('equipe_user.active', 1)->get();

            $equipeIds     = $equipes->lists('pivot.equipe_id');
            $conseillers   = Equipeuser::whereIn('equipe_id', $equipeIds)->whereActive(1)->lists('id');
            $equipeUserIds = (((int)$request->get('conseiller') > 0) ? [(int)$request->get('conseiller')] : $conseillers);

            $fichesLead = DB::table($this->produit)
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
    							->whereIn('statut_id', $this->getstatusLeads())
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id',  $equipeUserIds)
    							->select(DB::raw('count(*) as nombreLead, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreLead'))
    							->first(); 


     	    $fichesDeclare = DB::table($this->produit)
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
    							->whereIn('statut_id', $this->getstatusDevis())
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id',  $equipeUserIds)
    							->select(DB::raw('count(*) as nombreDeclare, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreDeclare'))
    							->first(); 


            $fichesReel = DB::table($this->produit)
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
    							->whereIn('statut_id', $this->getstatusContrat())
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id',  $equipeUserIds)
    							->select(DB::raw('count(*) as nombreReel, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreReel'))
    							->first(); 

        
        $data['lead']    = $fichesLead;
        $data['declare'] = $fichesDeclare;
        $data['reel']    = $fichesReel;
      
        return json_encode($data);

     }



    //Statistique compagnie

    public function leadParCompagnie(Request $request) {
          
			$this->filterOptions($request);

			$user          = Auth::user();
			$equipes       = $user->userEquipe()->where('equipe_user.active', 1)->get();

			$equipeIds     = $equipes->lists('pivot.equipe_id');
			$conseillers   = Equipeuser::whereIn('equipe_id', $equipeIds)->whereActive(1)->lists('id');
			$equipeUserIds = (((int)$request->get('conseiller') > 0) ? [(int)$request->get('conseiller')] : $conseillers);
          
          	$fiches = DB::table($this->produit) 
                                ->join('obgammes',"obgamme_id",'=','obgammes.id')
    							->join('sacompagnies',"obgammes.sacompagnie_id",'=','sacompagnies.id')
    							->join('statuts', 'statut_id', '=', 'statuts.id')
    							->join('groupestatuts', 'statuts.groupestatut_id', '=', 'groupestatuts.id')
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
    							->whereIn("groupestatuts.slug", ['devis', 'contrats'])
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id',  $equipeUserIds)
    							->select(DB::raw('sacompagnies.libelle as compagnie, obgammes.libelle as gamme, groupestatuts.slug as slug, count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'))
    							->groupBy('obgammes.id',"groupestatuts.id")
    							->orderBy("sacompagnies.libelle", "asc")
    							->get();


            $fichesCompagnie = DB::table($this->produit)
                                ->join('obgammes',"obgamme_id",'=','obgammes.id')
    							->join('sacompagnies',"obgammes.sacompagnie_id",'=','sacompagnies.id')
    							->join('statuts', 'statut_id', '=', 'statuts.id')
    							->join('groupestatuts', 'statuts.groupestatut_id', '=', 'groupestatuts.id')
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
    							->whereIn("groupestatuts.slug", ['devis', 'contrats'])
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id', $equipeUserIds)
    							->select(DB::raw('sacompagnies.libelle as compagnie, groupestatuts.slug as slug, count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'))
    							->groupBy('sacompagnies.id',"groupestatuts.id")
    							->orderBy("sacompagnies.libelle", "asc")
    							->get(); 

            
            $data = $data1 = $dataPie = NULL;
            

           
            if($fiches){
	            
	            foreach ($fiches as $fiche) {

	                   if(!isset($data[$fiche->compagnie . '-' . $fiche->gamme]['devis'])) {
	                	  $data[$fiche->compagnie . '-' . $fiche->gamme]['devis']    = 0;
	                   }

	                   if(!isset($data[$fiche->compagnie . '-' . $fiche->gamme]['contrats'])) {
	                	  $data[$fiche->compagnie . '-' . $fiche->gamme]['contrats'] = 0;
	                   } 
                       
	            	 
	            	  $data[$fiche->compagnie . '-' . $fiche->gamme][$fiche->slug] = $fiche->nbrefiches;
	            	
	            }

               
	             $collection = collect($data);

				$gammes      = $collection->keys()->all();               			 
				$devis1      = $collection->pluck('devis')->all();
				$contrats1   = $collection->pluck('contrats')->all();
				
	           
	        } 
 
    		if($fichesCompagnie){
	            
	            foreach ($fichesCompagnie as $fiche) {

	                   if(!isset($data1[$fiche->compagnie]['devis'])) {
	                	  $data1[$fiche->compagnie]['devis']    = 0;
	                   }

	                   if(!isset($data1[$fiche->compagnie]['contrats'])) {
	                	  $data1[$fiche->compagnie]['contrats'] = 0;
	                   } 
                       
	            	 
	            	  $data1[$fiche->compagnie][$fiche->slug] = $fiche->nbrefiches;
	            	
	            }

               
	             $collection = collect($data1);

				$compagnies     = $collection->keys()->all();               			 
				$devis2         = $collection->pluck('devis')->all();
				$contrats2      = $collection->pluck('contrats')->all();
				

				//Traitement pie compagnie
				foreach ($compagnies as $index => $compagnie) {
					$dataPie['dataCompagniePie'][] = ['name' => $compagnie, 'y' => ($devis2[$index] + $contrats2[$index])];
				}

	           
	        } 

    		return json_encode([
    			                  'gammes' => $gammes, 'devis1' => $devis1, 'contrats1' => $contrats1, 
    			                  'compagnies' => $compagnies, 'devis2' => $devis2, 'contrats2' => $contrats2,
    			                  'dataPie' => $dataPie
    			              ]);
     }

  

    public function ficheParGroupPub(Request $request) {
         
         	$this->filterOptions($request);
         
            $user          = Auth::user();
            $equipes       = $user->userEquipe()->where('equipe_user.active', 1)->get();

            $equipeIds     = $equipes->lists('pivot.equipe_id');
            $conseillers   = Equipeuser::whereIn('equipe_id', $equipeIds)->whereActive(1)->lists('id');
            $equipeUserIds = (((int)$request->get('conseiller') > 0) ? [(int)$request->get('conseiller')] : $conseillers);

            $fiches = DB::table($this->produit)
                                ->join('groupepub_provenance',"groupepub_provenance_id",'=','groupepub_provenance.id')
                                ->join('groupepubs',"groupepub_provenance.groupepub_id",'=','groupepubs.id')
                                ->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

                                })
                                ->where($this->produit . ".active",1)
                                //->whereIn('equipe_user_id',  $equipeUserIds)
                                ->select(DB::raw('count(*) as nbrefiches, SUM(groupepubs.cout) as chiffre'), 'groupepubs.nom as libelle')
                                ->groupBy("groupepub_id")
                                ->get(); 
            
            $data = NULL;
            if($fiches){
                foreach($fiches as $fiche) {
                    $data['ficheParGroupPub'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
                    $data['ficheParGroupPubPieNombre'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->nbrefiches];
                    $data['ficheParGroupPubPieCout'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->chiffre];

                }
            }

            return json_encode($data);
    }



    public function statistiqueConseillers(Request $request) {
          
          $this->filterOptions($request);

            $user          = Auth::user();
            $equipes       = $user->userEquipe()->where('equipe_user.active', 1)->get();

            $equipeIds     = $equipes->lists('pivot.equipe_id');
            $equipeUserIds = Equipeuser::whereIn('equipe_id', $equipeIds)->whereActive(1)->lists('id');
            
            $data = $info = null;

             $fichesLead = DB::table($this->produit)
                                ->join('equipe_user',"equipe_user_id",'=','equipe_user.id')
    							->join('users',"equipe_user.user_id",'=','users.id')
    							->join('equipes',"equipe_user.equipe_id",'=','equipes.id')
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
    							->whereIn('statut_id', $this->getstatusLeads())
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id',  $equipeUserIds)
    							->where('equipe_user.active', 1)
    							->select(DB::raw('users.nom as nom, users.prenom as prenom, users.photo, equipes.nom as equipe, count(*) as nombreLead'))
    							->groupBy('users.id')
                                ->orderBy('equipes.nom', 'asc')
    							->get();

    		foreach ($fichesLead as $key => $lead) {
                    
                    $data[$lead->prenom.' '.$lead->nom]['equipe']          = $lead->equipe;
                    $data[$lead->prenom.' '.$lead->nom]['photo']           = $lead->photo;

	    			$data[$lead->prenom.' '.$lead->nom]['nbLead']          = $lead->nombreLead; 

	    			$data[$lead->prenom.' '.$lead->nom]['nbDevis']         = 0;
	    		    $data[$lead->prenom.' '.$lead->nom]['chiffreDevis']    = 0; 

	    		    $data[$lead->prenom.' '.$lead->nom]['nbContrat']       = 0;
	    		    $data[$lead->prenom.' '.$lead->nom]['chiffreContrat']  = 0; 
     			                                     
    		}


     	    $fichesDeclare = DB::table($this->produit)
     	                        ->join('equipe_user',"equipe_user_id",'=','equipe_user.id')
    							->join('users',"equipe_user.user_id",'=','users.id')
    							->join('equipes',"equipe_user.equipe_id",'=','equipes.id')
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
    							->whereIn('statut_id', $this->getstatusDevis())
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id',  $equipeUserIds)
    							->where('equipe_user.active', 1)
    							->select(DB::raw('users.nom as nom, users.prenom as prenom, users.photo, equipes.nom as equipe, equipes.nom as equipe, count(*) as nombreDeclare, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreDeclare'))
    							->groupBy('users.id')
                                ->orderBy('equipes.nom', 'asc')
    							->get(); 

    	    foreach ($fichesDeclare as $key => $lead) {

    	    	$data[$lead->prenom.' '.$lead->nom]['equipe']          = $lead->equipe;
                $data[$lead->prenom.' '.$lead->nom]['photo']           = $lead->photo;
    			
    			$data[$lead->prenom.' '.$lead->nom]['nbDevis']         = $lead->nombreDeclare;
	    		$data[$lead->prenom.' '.$lead->nom]['chiffreDevis']    = round($lead->chiffreDeclare, 2); 

     			$data[$lead->prenom.' '.$lead->nom]['nbContrat']       = 0;
	    		$data[$lead->prenom.' '.$lead->nom]['chiffreContrat']  = 0;
    		}



            $fichesReel = DB::table($this->produit)
                                ->join('equipe_user',"equipe_user_id",'=','equipe_user.id')
    							->join('users',"equipe_user.user_id",'=','users.id')
    							->join('equipes',"equipe_user.equipe_id",'=','equipes.id')
    							->where(function($queryFiche) use($request, $equipeIds, $equipeUserIds){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

                                    if((int)$request->get('conseiller') == 0){
                                        $queryFiche->whereIn('dispatchable_id',  $equipeIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }else{
                                        $queryFiche->whereIn('equipe_user_id',  $equipeUserIds);
                                        $queryFiche->where('dispatchable_type',  'equipe');
                                    }

    							})
    							->whereIn('statut_id', $this->getstatusContrat())
    							->where($this->produit . ".active",1)
    							//->whereIn('equipe_user_id',  $equipeUserIds)
    							->where('equipe_user.active', 1)
    							->select(DB::raw('users.nom as nom, users.prenom as prenom, users.photo, equipes.nom as equipe, equipes.nom as equipe, count(*) as nombreReel, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreReel'))
    							->groupBy('users.id')
                                ->orderBy('equipes.nom', 'asc')
    							->get();

    		foreach ($fichesReel as $key => $lead) {
    			
    			$data[$lead->prenom.' '.$lead->nom]['equipe']           = $lead->equipe;
                $data[$lead->prenom.' '.$lead->nom]['photo']            = $lead->photo;

    			$data[$lead->prenom.' '.$lead->nom]['nbContrat']        = $lead->nombreReel;
    			$data[$lead->prenom.' '.$lead->nom]['chiffreContrat']   = round($lead->chiffreReel, 2);

    		}


    	return json_encode($data);

     }

   

}
