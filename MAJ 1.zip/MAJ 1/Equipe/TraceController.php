<?php

namespace App\Http\Controllers\Equipe;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;


use App\Groupestatut, App\Statut, App\Produit, App\Agence, App\Site, App\Equipe, App\Equipeuser, App\Fichesante, App\User, App\Tracessantes;


class TraceController extends Controller
{
    
    public function index() {
        
        $produits     = Produit::whereActive(1)->get();
        
        $user         = Auth::user();
        
        $equipes      = $user->userEquipe()->where('equipe_user.active',1)->get();//retourner la liste des equipes de cet animateur
        $equipeIds    = $equipes->lists('pivot.equipe_id');
        
        //$groupeStatus = Groupestatut::whereActive(1)->get();
        
        $status       = Statut::whereActive(1)->get();
        
        $prefixe      = $this->getProfile();

        $conseillers  = collect(DB::table('equipe_user')
                            ->leftjoin('users','equipe_user.user_id','=','users.id')
                            ->where('users.active',1)
                            ->where('equipe_user.active',1)
                            //->where('users.profile_id',7)
                            ->whereIn('equipe_user.equipe_id', $equipeIds)
                            ->select('users.id','users.login','equipe_user.equipe_id', 'equipe_user.id as equipeUserId')
                            ->get());

    	return view('equipesfiles.traces', [
                                    //'groupeStatus' => $groupeStatus,
                                    'status'      => $status,
                                    'produits'    => $produits,
                                    'equipes'     => $equipes,
                                    'conseillers' => $conseillers,
                                    'prefixe'     => $prefixe
                                ]);

    }

	public function traces(Request $request) {
        
        $className = "App\Traces".$request->get('produit');

        $columnSlug = "fiche".$request->get('produit')."_id";
        
        $user      = Auth::user();
        
        $equipes      = $user->userEquipe()->where('equipe_user.active',1)->get();//retourner la liste des equipes de cet animateur
        $equipeIds    = $equipes->lists('pivot.equipe_id');
        
        $fiches    = $className::whereActive(1)

                        ->where(function($query) use ($request, $columnSlug){

                            if($request->has('dateDebut') and $request->has('dateFin')){

                                $query->whereBetween('created_at', [$request->get('dateDebut')." 00:00:00", $request->get('dateFin')." 23:59:59"]);

                            }else if($request->has('dateDebut')){

                                $query->where('created_at', '>=', $request->get('dateDebut')." 00:00:00");

                            }else if($request->has('dateFin')){

                                $query->where('created_at', '<=', $request->get('dateFin')." 23:59:59");
                            }

                            if($request->has('statutId')){
                                $query->where('statut_id', $request->get('statutId'));
                            }

                            if($request->has('ficheNum')){
                                $query->where($columnSlug, $request->get('ficheNum'));
                            }

                            if($request->has('txt_num_fiche')){
                                $query->whereHas('fiche', function($q) use ($request) {
                                    $q->where('num_fiche', trim($request->get('txt_num_fiche')));
                                });
                            }

                            $query->whereHas('statut', function($q) use ($request) {
                                if($request->has('groupestatus') and !$request->has('status')){
                                    $q->where('groupestatut_id', $request->get('groupestatus'));
                                }else if($request->has('groupestatus') and $request->has('groupestatus')){
                                    $q->whereId($request->get('status'));
                                }
                            });


                        })

                        ->where(function($q) use ($request, $equipeIds){

                            $q->whereIn('tracable_id', $equipeIds);
                            $q->where('tracable_type', 'equipe');
                     
                        })

                        ->where(function($q) use ($request) {

                            if($request->has('equipe') and $request->has('conseiller')){
                                
                                $q->where('user_id', $request->get('conseiller'));
                                $q->where('tracable_id', $request->get('equipe'));
                                $q->where('tracable_type', 'equipe');

                            }else if(!$request->has('equipe') and $request->has('conseiller')){
                                
                                $q->where('user_id', $request->get('conseiller'));

                            }
                            
                        })

                        ->orderBy('created_at', 'desc')
                        ->orderBy('id', 'asc')
                        ->has("fiche")
                        ->with("fiche", "statut", "user", "action", "motif", "userable")
                        ->paginate(50);

        return json_encode($fiches);  

    }





}
