<?php

namespace App\Http\Controllers\Equipe;

use Illuminate\Http\Request;

use App\Http\Requests\ConseillerRequest;

use App\Http\Requests;


use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\Auth;

use App\Events\EventInitialiserClassementSante; 
use App\Events\EventConfigTauxCommUserSante;

use App\Profile;
use App\User;
use App\Fichesante;
use App\Ficheobseque;
use App\Equipe;
use App\Commentaire;
use App\Equipeuser;
use App\Ip;

use Carbon\Carbon;

class ConseillerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $equipeIds = Auth::user()->userEquipe()->get()->lists('pivot.equipe_id');
        
        $equipes   = Equipe::whereActive(1)->whereIn('id', $equipeIds)->get();

        $site                        = Auth::user()->site;

        return view('equipesfiles.conseillers.create', ['equipes' => $equipes, 'site' => $site]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ConseillerRequest $request)
    {

        $equipeId = $request->get('idequipe');
        
        $equipe   = Equipe::find($equipeId);
        
        $site     = $equipe->site;
        
        $agence   = $site->agence;

        $conseiller = new User;

        $conseiller->nom               = $request->get('nom');
        $conseiller->prenom            = $request->get('prenom');
        $conseiller->login             = $request->get('login');
        $conseiller->profile_id        = Profile::where('nom','Conseiller')->first()->id;
        $conseiller->email             = $request->get('email');
        $conseiller->password          = bcrypt($request->get('password'));
        $conseiller->objectif          = $request->get('objectif');
        $conseiller->id_appel          = $request->get('idAppel'); 
        $conseiller->site_id           = $site->id;
        $conseiller->agence_id         = $site->agence_id;
        $conseiller->courtier_id       = $agence->courtier_id;
        $conseiller->active            = 1;

        if($conseiller->save() and $request->get('check_produit')){

            $idsConseillerProduit      = $request->get('check_produit');
            $conseiller->produits()->attach($idsConseillerProduit, ['active' => 1]);
        }  

        $ip = new Ip;
        $ip->ip_internet = $request->ip();

        $conseiller->ips()->save($ip);


        $todayDate = date('Y-m-d');

        //return $equipe->attachConseillers;

        $equipe->equipeConseillers()->attach($conseiller->id,['date_debut' => $todayDate, 'active' => 1, 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()]);

        //$conseiller->userEquipe()->attach($idequipe,['date_debut' => $todayDate]);

        //Initialser la ligne de classement du mois en cours santé

        $tabInfosInitClassement = ['conseiller'        => $conseiller];

        event(new EventInitialiserClassementSante($tabInfosInitClassement));

        //Initialser les lignes des taux commissions des gammes santé

        $tabInfosConfigTauxComm = ['conseiller'        => $conseiller];

        event(new EventConfigTauxCommUserSante($tabInfosConfigTauxComm));

        return redirect('equipe/equipe/'.$equipeId);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $equipeIds = Auth::user()->userEquipe()->get()->lists('pivot.equipe_id');

        $conseillerIds = Equipeuser::whereIn('equipe_id', $equipeIds)->whereActive(1)->lists('user_id');

        if($conseillerIds->contains($id)){

            $conseiller = User::find($id);

            return view('equipesfiles.conseillers.show',['conseiller' => $conseiller]);

        }else{

            return abort(404);

        }

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $equipeIds = Auth::user()->userEquipe()->get()->lists('pivot.equipe_id');

        $conseillerIds = Equipeuser::whereIn('equipe_id', $equipeIds)->whereActive(1)->lists('user_id');

        if($conseillerIds->contains($id)){

            $equipes = Equipe::whereIn('id', $equipeIds)->get();

            $conseiller = User::find($id);

            return view('equipesfiles.conseillers.edit',['equipes' => $equipes, 'conseiller' => $conseiller]);

        }else{

            return abort(404);

        }

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ConseillerRequest $request, $id)
    {
        
        $equipeId = $request->get('equipe_id');
        
        $equipe   = Equipe::find($equipeId);

        $conseiller = User::find($id);

        $conseiller->nom      = $request->get('nom');
        $conseiller->prenom   = $request->get('prenom');
        $conseiller->login    = $request->get('login');
        $conseiller->email    = $request->get('email');
        $conseiller->objectif = $request->get('objectif');
        $conseiller->id_appel = $request->get('idAppel'); 

        if($request->has('password'))
        {
            $conseiller->password = bcrypt($request->get('password'));
        }

        if($conseiller->save()){

            $idsConseillerProduit = ($request->has('check_produit') ?  $request->get('check_produit') : []);            
            $conseiller->produits()->sync($idsConseillerProduit, ['active' => 1]);
            
        } 

        $equipeuser = Equipeuser::where('user_id', $conseiller->id)->whereActive(1)->first();

        $todayDate = date('Y-m-d');

        if($equipeuser->equipe_id != $equipeId){

            $equipeuser->date_fin = $todayDate;
            $equipeuser->active   = 0;
            $equipeuser->save();

            $equipe->equipeConseillers()->attach($conseiller->id,['date_debut' => $todayDate, 'active' => 1, 'created_at' => Carbon::now() , 'updated_at' => Carbon::now()]);

        }


        return redirect('equipe/equipe/conseiller/'.$conseiller->id);

    }



    public function activeUser($id)
    {
        //$user  = User::find($id);
        $equipe                  = Auth::user()->userEquipe->first();
        $user                    = $equipe->equipeConseillers()
                                          ->where('users.id',$id)
                                          ->first();
        
        if(count($user))
        {
            if($user->active)
            {
                $user->active = 0;
                $value        = 0;
            }
            else
            {
                $user->active = 1;
                $value        = 1;
            }

            $user->save();
            $msg = 'ok';

        }
        else
        {
            $msg = 'notok';
        }

        return ['msg'=>$msg , 'value'=>$value];    


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


}
