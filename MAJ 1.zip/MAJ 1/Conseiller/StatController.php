<?php

namespace App\Http\Controllers\Conseiller;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Produit;
use App\Sacompagnie;
use Auth;
use DB;

class StatController extends Controller
{
    public function getStat()
    {
    	$produits   		= Produit::where('active',1)->select('id','libelle')->get();

    	return view('conseillersfiles.statistiques.showStats', ['produits' => $produits]);

    }


    public function postFichesParEtat(Request $request)
    {
    	$user       		= Auth::user();
    	$idproduit          = $request->get('produit');
    	$produit 			= Produit::find($idproduit);
    	$dateDebut 			= $request->get('dateDebut');
    	$dateFin 			= $request->get('dateFin');
    	$libelleProduit 	= $produit->slug.'s';
    	//$className 			= "App\Fiche".$produit->slug;
    	$tableName    		= 'fiche'.$produit->slug.'s';
    	//return $tableName;

    	//return $fiches 		= $className::where('active',1)
    						  // ->groupBy('statut_id')->get()
    						   
    	$fiches 			= DB::table($tableName)
    							->join('statuts',"$tableName.statut_id",'=','statuts.id')
    							->where(function($queryFiche) use($request,$tableName){

    								 if($request->has('dateDebut') and $request->has('dateFin')) 
							         {
							          	$queryFiche->whereBetween("$tableName.date_insertion", [$request->get('dateDebut'), $request->get('dateFin')]);

							          	//$queryFiche->whereRaw("DATE_FORMAT('$tableName.date_insertion', '%Y-%m-%d') between $request->get('dateDebut') and $request->get('dateFin')");
							         }

    							})
    							->where("$tableName.active",1)
    							->where('user_id',$user->id)
    							->select(DB::raw('count(*) as nbrefiches'), 'libelle')
    							->groupBy("$tableName.statut_id")
    							->lists('nbrefiches','libelle');
    							//->toSql();
    							
    	
    	$arrayChart         = [];						

    	foreach ($fiches as $key => $value) {

    		$arrayCouple 		= [$key,$value];
    		//array_push($arrayCouple,$key);
    		//array_push($arrayCouple,$value);
    		array_push($arrayChart,$arrayCouple);

    		
    	}

    	if($arrayChart)
    	{
    		$success = 'ok';
    	}
    	else
    	{
    		$success = 'not ok';
    	}

    	sleep(1);

    	return ['success' => $success, 'libelleProduit' => $libelleProduit, 'content' => $arrayChart];



    }

    public function postFichesParRegime(Request $request)
    {
    	$user       		= Auth::user();
    	$idproduit          = $request->get('produit');
    	$produit 			= Produit::find($idproduit);
    	$dateDebut 			= $request->get('dateDebut');
    	$dateFin 			= $request->get('dateFin');
    	$libelleProduit 	= $produit->slug.'s';
    	//$className 			= "App\Fiche".$produit->slug;
    	$tableName    		= 'fiche'.$produit->slug.'s';
    	//return $tableName;

    	//return $fiches 		= $className::where('active',1)
    						  // ->groupBy('statut_id')->get()
    						   
    	$fiches 			= DB::table($tableName)
    							->join('saregimes',"$tableName.saregime_id",'=','saregimes.id')
    							->where(function($queryFiche) use($request,$tableName){

    								 if($request->has('dateDebut') and $request->has('dateFin')) 
							         {
							          	$queryFiche->whereBetween("$tableName.date_insertion", [$request->get('dateDebut'), $request->get('dateFin')]);

							          	//$queryFiche->whereRaw("DATE_FORMAT('$tableName.date_insertion', '%Y-%m-%d') between $request->get('dateDebut') and $request->get('dateFin')");
							         }

    							})
    							->where("$tableName.active",1)
    							->where('user_id',$user->id)
    							->select(DB::raw('count(*) as nbrefiches'), 'libelle')
    							->groupBy("$tableName.saregime_id")
    							->lists('nbrefiches','libelle');
    							//->toSql();
    							
    	
    	$arrayChart         = [];						

    	foreach ($fiches as $key => $value) {

    		$arrayCouple 		= [$key,$value];
    		//array_push($arrayCouple,$key);
    		//array_push($arrayCouple,$value);
    		array_push($arrayChart,$arrayCouple);

    		
    	}

    	if($arrayChart)
    	{
    		$success = 'ok';
    	}
    	else
    	{
    		$success = 'not ok';
    	}

    	sleep(1);

    	return ['success' => $success, 'libelleProduit' => $libelleProduit, 'content' => $arrayChart];



    }


    public function postAffairesParCie(Request $request)
    {
    	$user       		= Auth::user();
    	$idproduit          = $request->get('produit');
    	$produit 			= Produit::find($idproduit);
    	$dateDebut 			= $request->get('dateDebut');
    	$dateFin 			= $request->get('dateFin');
    	$libelleProduit 	= $produit->slug.'s';
    	//$className 			= "App\Fiche".$produit->slug;
    	$tableName    		= 'fiche'.$produit->slug.'s';
    	//return $tableName;

    	//return $fiches 		= $className::where('active',1)
    						  // ->groupBy('statut_id')->get()


    	$compagnies 		= collect(DB::table($tableName)
    							->join('sacompagnies',"$tableName.num_compagnie",'=','sacompagnies.code') 
    							->join('statuts',"$tableName.statut_id",'=','statuts.id')
    							->join('groupestatuts',"statuts.groupestatut_id",'=','groupestatuts.id')
    							->where(function($queryFiche) use($request,$tableName){

    								 if($request->has('dateDebut') and $request->has('dateFin')) 
							         {
							          	$queryFiche->whereBetween("$tableName.date_insertion", [$request->get('dateDebut'), $request->get('dateFin')]);
							         }

    							})
    							->where("$tableName.active",1)
    							->where('groupestatuts.libelle','Contrats')
    							->where('user_id',$user->id)
    							->select(DB::raw('count(*) as nbrefiches'), 'statuts.libelle', 'sacompagnies.code')
    							->groupBy('sacompagnies.code')
    							//->get());
    							->lists('sacompagnies.code'));
    						   
    	$fiches 			= collect(DB::table($tableName)
    							->join('sacompagnies',"$tableName.num_compagnie",'=','sacompagnies.code')
    							->join('statuts',"$tableName.statut_id",'=','statuts.id')
    							->join('groupestatuts',"statuts.groupestatut_id",'=','groupestatuts.id')
    							->where(function($queryFiche) use($request,$tableName){

    								 if($request->has('dateDebut') and $request->has('dateFin')) 
							         {
							          	$queryFiche->whereBetween("$tableName.date_insertion", [$request->get('dateDebut'), $request->get('dateFin')]);

							          	//$queryFiche->whereRaw("DATE_FORMAT('$tableName.date_insertion', '%Y-%m-%d') between $request->get('dateDebut') and $request->get('dateFin')");
							         }

    							})
    							->where("$tableName.active",1)
    							->where('groupestatuts.libelle','Contrats')
    							->where('user_id',$user->id)
    							->select(DB::raw('count(*) as nbrefiches'), 'statuts.libelle','sacompagnies.code')
    							->groupBy('sacompagnies.code','statuts.libelle')
    							//->lists('nbrefiches','statuts.libelle'))->keyBy('code');
    							->get());
    	
    	//dd($fiches);
    	$series = [];

		//$listCie  = $fiches->pluck('code');

		//dd($compagnies);

		foreach ($fiches as $key => $value) {
			//*********************************
			$arrayCie   = collect($value);
			//dd($arrayCie);
			$code       = $arrayCie['code'];
			$statut     = $arrayCie['libelle'];
			$nbrFiche   = $arrayCie['nbrefiches'];
			$arrayTmp   = $arrayCie->flip()->keys();
			$arrayTmp->pop();
			//dd($arrayTmp);
			//array_push($series,[$code => $arrayTmp->toJson()]);
			array_push($series,$value);


		}

		//dd($series);
		$seriesGroupBy = collect($series)->groupBy('libelle');
		//$seriesJson = collect($series)->toJson();
		//dd($seriesGroupBy);

		$arrayStatuts = [];

		foreach ($seriesGroupBy as $keySeries => $valueSeries) {

			$arrayCode = $valueSeries;

			foreach ($arrayCode as $keyCode => $valueCode) {

				$arrayStatuts[$keySeries][$valueCode->code] = $valueCode->nbrefiches;

				//dd($valueCode->code);
			}

			
		} 

		
		$arrayStatutsCollect = collect($arrayStatuts);
		//dd($arrayStatutsCollect);
		

		//Construire un tableau des cies comme clé avec valeur 0

		$arrayCieZero = $compagnies->flip();

		$arrayCieZero = $arrayCieZero->map(function ($item, $key) {
		    return $item * 0;
		});

		//dd($arrayCieZero);

		//Parcourir le tableau des statuts pour ajouter tous les compagnies a chaque statut

		foreach ($arrayStatutsCollect as $keyStatut => $valueStatut) {

			$arrayCode  = collect($valueStatut);

			$diffCodes = $arrayCieZero->diffKeys($arrayCode);

			//dd($diffCodes);

			$arrayCodeAll = $arrayCode->merge($diffCodes)->toArray();

			ksort($arrayCodeAll);



			//dd($ArrayCodeAll);

			$arrayStatutsCollect[$keyStatut] = $arrayCodeAll;


			//Insérer les codes des cies qui ne figure pas ds ce tableau 
		}

		//dd($arrayStatutsCollect);

		//Tableau des libelles cies 

		$compagnies = $compagnies->map(function ($item, $key) {
		    return $this->getLibelleCie($item);
		});



		if($seriesGroupBy)
    	{
    		$success = 'ok';
    	}
    	else
    	{
    		$success = 'not ok';
    	}


    	sleep(1);

    	return ['success' => $success, 'libelleProduit' => $libelleProduit, 'content' => $arrayStatutsCollect , 'compagnies' => $compagnies];



    }

    public function getLibelleCie($codeCie)
    {
    	$libCie = Sacompagnie::where('code',$codeCie)
    				->select('libelle')
    				->lists('libelle');
    	return $libCie;

    }


    public function postAffairesParRegime(Request $request)
    {
    	$user       		= Auth::user();
    	$idproduit          = $request->get('produit');
    	$produit 			= Produit::find($idproduit);
    	$dateDebut 			= $request->get('dateDebut');
    	$dateFin 			= $request->get('dateFin');
    	$libelleProduit 	= $produit->slug.'s';
    	//$className 			= "App\Fiche".$produit->slug;
    	$tableName    		= 'fiche'.$produit->slug.'s';
    	//return $tableName;

    	//return $fiches 		= $className::where('active',1)
    						  // ->groupBy('statut_id')->get()


    	$regimes 			= collect(DB::table($tableName)
    							->join('saregimes',"$tableName.saregime_id",'=','saregimes.id') 
    							->join('statuts',"$tableName.statut_id",'=','statuts.id')
    							->join('groupestatuts',"statuts.groupestatut_id",'=','groupestatuts.id')
    							->where(function($queryFiche) use($request,$tableName){

    								 if($request->has('dateDebut') and $request->has('dateFin')) 
							         {
							          	$queryFiche->whereBetween("$tableName.date_insertion", [$request->get('dateDebut'), $request->get('dateFin')]);

							         }

    							})
    							->where("$tableName.active",1)
    							->where('groupestatuts.libelle','Contrats')
    							->where('user_id',$user->id)
    							->select(DB::raw('count(*) as nbrefiches'), 'statuts.libelle', 'saregimes.code')
    							->groupBy('saregimes.code')
    							//->get());
    							->lists('saregimes.code'));
    						   
    	$fiches 			= collect(DB::table($tableName)
    							->join('saregimes',"$tableName.saregime_id",'=','saregimes.id')
    							->join('statuts',"$tableName.statut_id",'=','statuts.id')
    							->join('groupestatuts',"statuts.groupestatut_id",'=','groupestatuts.id')
    							->where(function($queryFiche) use($request,$tableName){

    								 if($request->has('dateDebut') and $request->has('dateFin')) 
							         {
							          	$queryFiche->whereBetween("$tableName.date_insertion", [$request->get('dateDebut'), $request->get('dateFin')]);

							          	//$queryFiche->whereRaw("DATE_FORMAT('$tableName.date_insertion', '%Y-%m-%d') between $request->get('dateDebut') and $request->get('dateFin')");
							         }

    							})
    							->where("$tableName.active",1)
    							->where('groupestatuts.libelle','Contrats')
    							->where('user_id',$user->id)
    							->select(DB::raw('count(*) as nbrefiches'), 'statuts.libelle','saregimes.code')
    							->groupBy('saregimes.code','statuts.libelle')
    							//->lists('nbrefiches','statuts.libelle'))->keyBy('code');
    							->get());
    	
    	//dd($fiches);
    	$series = [];

		//$listCie  = $fiches->pluck('code');

		//dd($compagnies);

		foreach ($fiches as $key => $value) {
			//*********************************
			$arrayCie   = collect($value);
			//dd($arrayCie);
			$code       = $arrayCie['code'];
			$statut     = $arrayCie['libelle'];
			$nbrFiche   = $arrayCie['nbrefiches'];
			$arrayTmp   = $arrayCie->flip()->keys();
			$arrayTmp->pop();
			//dd($arrayTmp);
			//array_push($series,[$code => $arrayTmp->toJson()]);
			array_push($series,$value);


		}

		//dd($series);
		$seriesGroupBy = collect($series)->groupBy('libelle');
		//$seriesJson = collect($series)->toJson();
		//dd($seriesGroupBy);

		$arrayStatuts = [];

		foreach ($seriesGroupBy as $keySeries => $valueSeries) {

			$arrayCode = $valueSeries;

			foreach ($arrayCode as $keyCode => $valueCode) {

				$arrayStatuts[$keySeries][$valueCode->code] = $valueCode->nbrefiches;

				//dd($valueCode->code);
			}

			
		} 

		
		$arrayStatutsCollect = collect($arrayStatuts);
		//dd($arrayStatutsCollect);
		

		//Construire un tableau des cies comme clé avec valeur 0

		$arrayCieZero = $regimes->flip();

		$arrayCieZero = $arrayCieZero->map(function ($item, $key) {
		    return $item * 0;
		});

		//dd($arrayCieZero);

		//Parcourir le tableau des statuts pour ajouter tous les compagnies a chaque statut

		foreach ($arrayStatutsCollect as $keyStatut => $valueStatut) {

			$arrayCode  = collect($valueStatut);

			$diffCodes = $arrayCieZero->diffKeys($arrayCode);

			//dd($diffCodes);

			$arrayCodeAll = $arrayCode->merge($diffCodes)->toArray();

			ksort($arrayCodeAll);



			//dd($ArrayCodeAll);

			$arrayStatutsCollect[$keyStatut] = $arrayCodeAll;


			//Insérer les codes des cies qui ne figure pas ds ce tableau 
		}

		//dd($arrayStatutsCollect);

		//Tableau des libelles cies 

		//$regimes = $regimes->map(function ($item, $key) {
		  //  return $this->getLibelleCie($item);
		//});



		if($seriesGroupBy)
    	{
    		$success = 'ok';
    	}
    	else
    	{
    		$success = 'not ok';
    	}


    	sleep(1);

    	return ['success' => $success, 'libelleProduit' => $libelleProduit, 'content' => $arrayStatutsCollect , 'regimes' => $regimes];



    }


}
