<?php

namespace App\Http\Controllers\Conseiller;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Http\Requests;

use Auth;

use App\User;
use Hash;
use App\Messagerie;
use App\Statut;
use App\Fichesante;
use App\Ficheobseque;
use App\Ficheauto;
use App\Equipe;
use App\Equipeuser;
use Image;
use File;
use App\Tracessante;

class SettingController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function myProfile()
    {

        $user = Auth::user();

        $equipeUserId   =  $user->userEquipe->first()->pivot->id;

        $nombreMessageNonLu = Messagerie::where('vu', 0)->whereActive(1)->where('to_id', $user->id)->orderBy('created_at', 'desc')->whereNull('to_del')->get();
// sante
        $nbrAppels = Fichesante::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'santeAppel');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();

        $statutAppel = Statut::where('slug', '=', 'santeAppel')->first()->id;

        $nbrDevis = Fichesante::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'santeDevisEnCours');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();

        $statutDevis = Statut::where('slug', '=', 'santeDevisEnCours')->first()->id;   

        $nbrContrat = Fichesante::whereHas('statut', function ($query) {
            $query->orWhere('slug', '=', 'santeClient');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();

        $statutContrat = Statut::where('slug', '=', 'santeClient')->first()->id;

        $nbrRappels = Fichesante::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'santeRappel');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();
        $statutRappel = Statut::whereSlug('santeRappel')->first()->id;


        $nbrRejets = Fichesante::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'santeContratRejet');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();
        // $statutRejet = Fichesante::whereHas('statut', function ($query) {
        //     $query->where('slug', '=', 'rejet');
        // })->whereActive(1)->where('equipe_user_id', $equipeUserId)->first()->statut_id;

// obseque
        $nbrAppelsObseque = Ficheobseque::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'obsequeAppel');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();

        $statutAppelObseque = Statut::where('slug', '=', 'obsequeAppel')->first()->id;

        $nbrDevisObseque = Ficheobseque::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'obsequeDevisEnCours');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();

        $statutDevisObseque = Statut::where('slug', '=', 'obsequeDevisEnCours')->first()->id;   

        $nbrContratObseque = Ficheobseque::whereHas('statut', function ($query) {
            $query->orWhere('slug', '=', 'obsequeClient');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();

        $statutContratObseque = Statut::where('slug', '=', 'obsequeClient')->first()->id;

        $nbrRappelsObseque = Ficheobseque::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'obsequeRappel');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();
        $statutRappelObseque = Statut::whereSlug('obsequeRappel')->first()->id;


        $nbrRejetsObseque = Ficheobseque::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'obsequeContratRejet');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();

// auto
        $nbrAppelsAuto = Ficheauto::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'autoAppel');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();

        $statutAppelAuto = Statut::where('slug', '=', 'autoAppel')->first()->id;

        $nbrDevisAuto = Ficheauto::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'autoDevisEnCours');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();

        $statutDevisAuto = Statut::where('slug', '=', 'autoDevisEnCours')->first()->id;   

        $nbrContratAuto = Ficheauto::whereHas('statut', function ($query) {
            $query->orWhere('slug', '=', 'autoClient');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();

        $statutContratAuto = Statut::where('slug', '=', 'autoClient')->first()->id;

        $nbrRappelsAuto = Ficheauto::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'autoRappel');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();
        $statutRappelAuto = Statut::whereSlug('autoRappel')->first()->id;


        $nbrRejetsAuto = Ficheauto::whereHas('statut', function ($query) {
            $query->where('slug', '=', 'autoContratRejet');
        })->whereActive(1)->where('equipe_user_id', $equipeUserId)->count();
        // $statutRejet = Fichesante::whereHas('statut', function ($query) {
        //     $query->where('slug', '=', 'rejet');
        // })->whereActive(1)->where('equipe_user_id', $equipeUserId)->first()->statut_id;

        $respSite = User::where('site_id', $user->site->id)->where('profile_id', 5)->first();

        $equipeId     =  $user->userEquipe->first()->pivot->equipe_id;
        $equipe = Equipe::find($equipeId);

        $userEquipe = Equipeuser::where('equipe_id', $equipe->id)->lists('user_id');



        $respEquipe = User::whereIn('id', $userEquipe)->where('profile_id', 6)->first();


        $traces = Tracessante::where('user_id', $user->id)->orderBy('created_at', 'desc')->take(10)->get();




        //return $user;
        return view('conseillers.profile', compact('user', 'nombreMessageNonLu', 'nbrAppels', 'nbrDevis', 'nbrRappels', 'nbrRejets', 'statutDevis', 'nbrContrat', 'statutContrat', 'statutRappel', 'statutRejet', 'respSite', 'equipe', 'respEquipe', 'traces', 'statutAppel', 'nbrAppelsObseque', 'nbrDevisObseque', 'nbrRappelsObseque', 'nbrRejetsObseque', 'statutDevisObseque', 'nbrContratObseque', 'statutContratObseque', 'statutRappelObseque', 'statutAppelObseque', 'nbrAppelsAuto', 'nbrDevisAuto', 'nbrRappelsAuto', 'nbrRejetsAuto', 'statutDevisAuto', 'nbrContratAuto', 'statutContratAuto', 'statutRappelAuto', 'statutAppelAuto'));

    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function settings()
    {

		return "Settings";

    }

   public function generate(Request $request){

        
        $iduser                 = $request->get("iduser");
        $user                   = User::find($iduser);
        $user->password           = Hash::make($request->get("password"));
        return $user->save() ? 1 : 0;

        }

         public function modifImage(Request $request){

                $image                      = $request->file('logo');
                $filename                   = time() . '.' . $image->getClientOriginalExtension();
                $dossier_libelle            = str_replace(' ', '_', $request->input('libelle'));
                $path                       = 'upload/avatars/' . $filename;
                Image::make($image->getRealPath())->resize(200, 200)->save($path);
                $iduser                 = $request->get("iduser");
                $user                   = User::find($iduser);
                $user->photo           = $filename;
                return $user->save() ? 1 : 0;

        }

         public function couleur(Request $request){

        
        $iduser                 = $request->get("iduser");
        $user                   = User::find($iduser);
        $user->couleur           = $request->get("couleur");
        return $user->save() ? 1 : 0;

        }

    

}
