<?php

namespace App\Http\Controllers\Conseiller;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;
use Carbon\Carbon;

use App\Produit, App\Classementsante;

class ClassementController extends Controller
{

    public function index() {

    	$produits     = Produit::where('active', 1)->get();

        $user         = Auth::user();
        $site         = $user->site;
        // $sites        = $agence->sites()
        //                        ->where('active',1)
        //                        ->get();
        //$equipes    = Equipe::where('active', 1)->get();

        $date 		  = Carbon::now();
        $dateFirstDay = Carbon::create($date->year, $date->month, 01,00,00,00);
        $year 		  = $date->year;
        $month 		  = $date->month - 1;

    	return view('conseillersfiles.classement.index', ['produits' => $produits,'site' => $site, 'year' => $year, 'month' => $month, 'date' => $dateFirstDay, 'activeOnglet' => 1]);

    	//return view('courtiersfiles.classement.test');
    }

    public function indexId($id) {

        $produits     = Produit::where('active', 1)->get();

        $user         = Auth::user();
        $site         = $user->site;
        // $sites        = $agence->sites()
        //                        ->where('active',1)
        //                        ->get();
        //$equipes    = Equipe::where('active', 1)->get();

        $date         = Carbon::now();
        $dateFirstDay = Carbon::create($date->year, $date->month, 01,00,00,00);
        $year         = $date->year;
        $month        = $date->month - 1;

        return view('conseillersfiles.classement.index', ['produits' => $produits,'site' => $site, 'year' => $year, 'month' => $month, 'date' => $dateFirstDay, 'activeOnglet' => $id]);

        //return view('courtiersfiles.classement.test');
    }

    public function getClassement(Request $request) {
        
        //return $request->all();	
        $tableName            = $request->get('produit');
    	$idSite               = "";
    	$idEquipes            = [];
    	$idConseillers        = [];
    	$dateProduction       = "";

    	
    	if($request->has('dateProdHidden')){

            $dateProduction        = $request->get('dateProdHidden');
            $dateProductionCarbon  = new Carbon($dateProduction);
            $annee                 = $dateProductionCarbon->year;
            $mois                  = $dateProductionCarbon->month;
        
        }


        // return $classements     = ClassementSante::whereHas('userEquipe', function ($query)  {
        //                                $query->where('equipe_id', 1);
        //                            })->get();

        $classements        = Classementsante::where('classementsantes.active',1)
        					->where(function($query) use ($request,$mois,$annee){

        					if($request->has('dateProdHidden'))
        					{
        						$query->where('classementsantes.mois',$mois);
        						$query->where('classementsantes.annee',$annee);
        					}


					        if($request->has('site') and !$request->has('equipes') and !$request->has('conseillers')){

					           $idSite        = $request->get('site');
					           $query->where('classementsantes.site_id', $idSite);
					        }
					        
					        if($request->has('equipes') and !$request->has('conseillers')){
						        $query->whereHas('userEquipe', function ($q)  use ($request){

								           $idEquipes      = $request->get('equipes');
								           $q->whereIn('equipe_user.equipe_id', $idEquipes);
								        
		                         });
						    }
					        

        					if($request->has('conseillers'))
        					{
        						$idConseillers  = $request->get('conseillers');
        						$query->whereIn('classementsantes.equipe_user_id', $idConseillers);
        					}

        						

        					})
							//->select('users.nom', 'users.prenom')
							->orderBy('classementsantes.CACommissionable','desc')
							->with('userEquipe','site','agence','fichesantesActive')
       						->get();

        					//return json_encode($classements);
        					return ['classement' => $classements , 'mois' => $mois , 'annee' => $annee];



    }

    public function getDetailContratsClassement($id)
    {
    	//return $id;

    	// return $classement = ClassementSante::find($id)->fichesantesActive()
     //                         ->with('statut','garantie')
     //                         ->orderBy("fichesantes.date_situation")
     //                         ->get();

        return $classement = DB::table('classementsante_fichesante')
                                 ->join('fichesantes','classementsante_fichesante.fichesante_id','=','fichesantes.id')
                                 ->join('statuts','classementsante_fichesante.statut_id','=','statuts.id')
                                 ->join('sagaranties','classementsante_fichesante.sagarantie_id','=','sagaranties.id')
                                 ->where('classementsante_fichesante.classementsante_id',$id)
                                 ->where('classementsante_fichesante.active',1)
                                 ->select('fichesantes.num_fiche','statuts.libelle as libelleStatut','classementsante_fichesante.date_effet','classementsante_fichesante.date_situation','sagaranties.libelle as libelleGarantie','classementsante_fichesante.cotisationAnnuelle','classementsante_fichesante.statut_id')
                                 ->orderBy('classementsante_fichesante.date_situation')
                                 ->get();

    }

    


}
