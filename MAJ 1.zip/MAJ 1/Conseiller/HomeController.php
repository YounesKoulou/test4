<?php

namespace App\Http\Controllers\Conseiller;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use Auth;
use App\User;

class HomeController extends Controller
{
    public function index() {

    	$user = Auth::user();
    	$respSite = User::where('site_id', $user->site->id)->where('profile_id', 5)->first();
    	return view('conseillers.home', ['user' => $user, 'respSite' => $respSite]);
    }
}
