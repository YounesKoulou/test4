<?php

namespace App\Http\Controllers\Conseiller;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Input;
use App\Http\Requests;

use App\Events\EventTracesSante;
use App\Events\EventStatutSante;

use App\User;
use App\Fichesante;
use App\Ficheobseque;
use App\ClientProduit;
use App\Statut;
use App\Action;
use App\Produit;
use Carbon\Carbon;
use Auth;


class ConseillerController extends Controller
{


    /**
     * change le statut d'une ou plusieurs fiches
     */
    public function changeStatusLeads(Request $request)
    {
        $userInfo      = $this->userInfo();
        
        $statutId      = $request->get('statut');
        $produitId     = $request->get('produit');
        $arrayIdFiches = $request->get('arrayIdLeads');

        $produit       = Produit::find($produitId);
        $produitSlug   = $produit->slug;

        $statut = Statut::find($statutId);

        $newStatut = $statut->libelle;

        $idAction      = Action::whereSlug('CS')->value('id');

        $className = "App\Fiche".$produitSlug;
        //                       ->whereIn('id', $arrayIdFiches)
        //                       ->update(['statut_id' => $statutId]);

        foreach ($arrayIdFiches as $Idfiche) {
            
            $fiche    = $className::find($Idfiche);

            $oldStatut = $fiche->statut->libelle;

            $fiche->statut_id      = $statut->id;
            $fiche->date_situation = Carbon::now();

            if($fiche->save()){
                
                $observation  = "<i class='uk-text-danger material-icons'>&#xE14C;</i> ".$oldStatut."<br><i class='uk-text-success material-icons'>&#xE876;</i> ".$newStatut;
                
                $motif        = $request->has('modalMotifId') ? $request->get('modalMotifId') : null;
                
                $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
                
                $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
                event(new $event($tabInfoTrace));

            }

        }

        return [
                    "success"   => true,
                    "message"   => "Statut Changé",
                    "statutLib" => $newStatut
                ];

    }



    public function deleteFicheObseque(Request $request){

        $fiche = Ficheobseque::find($request->get('id'));
        $fiche->active = 0;

        if($fiche->save()){

            $cltPrd = ClientProduit::firstOrCreate(['client_id' => $fiche->client_id, 'produit_id' => $fiche->produit_id]);
            $cltPrd->decrement('nombre');

            $url = url("conseiller/leads/groupeproduit/".$fiche->produit->groupeProduit->id."/".$fiche->client_id);

            return ['success' => 'true' , 'message' => 'la fiche est supprimé', 'url' => $url];

        }else{

            return ['success' => 'false' , 'message' => 'impossible de supprimer la fiche'];

        }

    }

    public function deleteFicheSante(Request $request){
        
        $fiche = Fichesante::find($request->get('id'));
        $fiche->active = 0;

        if($fiche->save()){

            $cltPrd = ClientProduit::firstOrCreate(['client_id' => $fiche->client_id, 'produit_id' => $fiche->produit_id]);
            $cltPrd->decrement('nombre');

            $url = url("conseiller/leads/groupeproduit/".$fiche->produit->groupeProduit->idacefiche->client_id);

            return ['success' => 'true' , 'message' => 'la fiche est supprimé', 'url' => $url];

        }else{

            return ['success' => 'false' , 'message' => 'impossible de supprimer la fiche'];

        }

    }


    public function validationConseiller(Request $request){

        $userInfo = $this->userInfo();

        //$equipe                         = Equipe::find($id);
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
        $statusId    = ($request->get('statusId')) ? $request->get('statusId') : null ; 
        $resultat        = 'ko';

        $slug        = $request->get('slug');
        $nameClass   = "App\Fiche".$slug;
        $eventTrace  = 'App\Events\EventTraces'.ucfirst($slug);
        $eventStatut = 'App\Events\EventStatut'.ucfirst($slug);

        if($idFiche){

            $fiche       = $nameClass::find($idFiche);
            $statutActu  = Statut::find($statusId);

            switch ($statutActu->slug) {

                case 'devis':
                    $slugNouvStatut   = 'devisComplet';
                    $action           = 'VDC';
                    break;

                case 'devisRejete':
                    $slugNouvStatut   = 'devisComplet';
                    $action           = 'VDC';
                    break;

                default:
                    $resultat         = 'NA';
                    break;
            }            
                        
            //return $fiche->id;

            if($fiche and $resultat != 'NA'){

                $statut   = Statut::where('slug', $slugNouvStatut)->first();

                if($statut->groupeStatus->slug=='leads'){
                    $fiche->date_situation = $fiche->date_insertion;
                }elseif($statut->groupeStatus->slug=='devis'){
                    $fiche->date_situation = Carbon::now();
                }elseif($statut->groupeStatus->slug=='contrats'){
                    $fiche->date_situation = Carbon::now();
                }

                $fiche->statut_id = $statut->id;

                if($fiche->save()){

                    $idAction           = Action::where('slug',$action)->value('id');
                    $tabInfoTrace       = ['idAction' => $idAction, 'idFiche' => $idFiche, 'observation' => $observation, 'motif' => $motifRejet, 'idStatut' => $statut->id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type']];
                    event(new $eventTrace($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut = ['idAction' => $idAction, 'idFiche' => $idFiche, 'observation' => $observation, 'motif' => $motifRejet, 'slugProduit' => $slugProduit, 'idStatut' => $statut->id];
                    event(new $eventStatut($tabInfoTraceStatut));

                    $resultat     = 'ok';
                    
                }
            }
        }

        return $resultat;        
    }




    public function userInfo(){

        $user = Auth::user();

        $userEquipe = $user->userEquipe()->first()->pivot;

        return $userInfo = ['equipe_user_id' => $userEquipe->id, 'tracable_id' => $userEquipe->equipe_id, 'tracable_type' => 'equipe'];

    }




}
