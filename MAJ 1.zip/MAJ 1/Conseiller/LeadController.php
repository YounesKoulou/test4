<?php

namespace App\Http\Controllers\Conseiller;
use App\Http\Controllers\Controller;


use Illuminate\Http\Request;


use App\Http\Requests;

use App\Http\Controllers\Client\SouscriptionController;
use App\Http\Controllers\Client\SouscriptionObsequeController;
use App\Http\Controllers\Client\SouscriptionAutoController;
use App\Http\Controllers\SettingController;

use App\Events\EventTracesSante;
use App\Events\EventTracesObseque;
use App\Events\EventTracesGav;
use App\Events\EventTracesAuto;

use App\Events\EventStatutSante;
use App\Events\EventStatutObseque;
use App\Events\EventStatutGav;

use App\Events\EventNotifications;
use App\Events\EventCreateProcessesLead;
use App\Events\EventChangeStateProcessLead;

use App\Http\Requests\EditLeadSanteRequest;
use App\Http\Requests\EditLeadObsequeRequest;
use App\Http\Requests\EditLeadGavRequest;
use App\Http\Requests\EditLeadAutoRequest;

use App\Http\Requests\DuplicateLeadSanteRequest;
use App\Http\Requests\DuplicateLeadObsequeRequest;
use App\Http\Requests\DuplicateLeadGavRequest;

use App\Http\Requests\GetHistoryFicheRequest;
use App\Http\Requests\GetCommentaireFicheRequest;
use App\Http\Requests\AddCommentaireFicheRequest;
use App\Http\Requests\SaveInfoClientRequest;
use App\Http\Requests\DocumentRequest;
use Illuminate\Support\Facades\Input;


use App\User;
use App\Fichesante;
use App\Ficheobseque;
use App\Fichegav;
use App\Ficheauto;
use App\Vehicule;
use App\Sinistre;
use App\Infraction;
use App\Produit;
use App\Groupeproduit;
use App\Groupestatut;
use App\Statut;
use App\Client;
use App\Enfant;
use App\GavEnfant;
use App\Conjoint;
use App\GavConjoint;
use App\Saregime;
use App\Statutaction;
use App\Documentfiche;
use App\ClientProduit;
use App\Commentaire;
use App\Proposition;
use App\Informationbancaire;
use App\Modepaiement;
use App\Typepaiement;
use App\Prelevement;
use App\Parametre;
use App\Modelemail;
use App\Action;
use App\Sagarantie;
use App\Sacompagnie;
use App\Sagamme;
use App\Obgamme;
use App\Obgarantie;
use App\Notification;
use App\Cdr;
use App\Profession;
use App\Carmarque;
use App\Carburant;
use App\AutoEnfant;
use App\AutoConjoint;
use App\Conductsecond;
use App\Groupequestionnaire;
use App\Questionnaire;
use App\Reponsequestionnaire;
use App\Fichequestionnaire;
use App\Fichegroupequestionnaire;

use Crypt;
use Auth;
use DB;
use File;
use Session;
use Carbon\Carbon;
use Mail;
use mikehaertl\pdftk\Pdf;



class LeadController extends Controller
{

    /**
     * save les modifications sur la fiche sante
     */
    public function editClientSante(EditLeadSanteRequest $request) {

        //return $request->all();

        $userInfo = $this->userInfo();

        $conjointId   = 0;
        $enfantIds    = [];
        $ficheId      = $request->get("ficheId");

        $fiche = Fichesante::find($ficheId);
            $date_effet         = $this->dateCarbon($request->get('date_effet'));
            $date_naissance     = $this->dateCarbon($request->get('date_naissance'));
            $fiche->date_effet  = $request->get('date_effet');
            $fiche->saregime_id = $request->get('saregime_id');
            $fiche->ani         = ($date_effet->diffInYears($date_naissance) >= 55 or $request->get('saregime_id') == 3 ) ? 0 : 1;

        if($fiche->save()){

            $observation  = '' ;
            $actionSlug   = 'GF';

            if($request->get('etatSave')){
                $observation  = 'Type: '.$fiche->statut->groupeStatus->libelle ;
                $actionSlug   = 'MI';
            }else{
                $observation  = null ;
                $actionSlug   = 'GF';
            }
            
            $idAction     = Action::whereSlug($actionSlug)->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'idStatut' => $fiche->statut_id, 'observation' => $observation, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));
        }

        $clientId = $request->get('clientId');
        
        $client = Client::find($clientId);
            $client->nom            = $request->get('nom');
            $client->prenom         = $request->get('prenom');
            $client->civilite       = $request->get('civilite');
            $client->sexe           = $request->get('sexe');
            $client->sit_familiale  = $request->get('sit_familiale');
            $client->date_naissance = $request->get('date_naissance');
            $client->email          = $request->get('email');
            $client->email_pro      = $request->get('email_pro');
            $client->profession_id     = $request->get('profession');
            $client->ville          = $request->get('ville');
            $client->adresse        = $request->get('adresse');
            $client->tel_mobile     = $request->get('tel_mobile');
            $client->code_postal    = $request->get('code_postal');
            //$client->saregime_id    = $request->get('saregime_id');
        $client->save();

        if($request->has('has_conjoint')){

            $conjoint_id = $request->get('conjoint_id');

            if($conjoint_id == 0){
                $conjoint = new Conjoint;
                    $conjoint->nom            = $request->get('conjoint_nom');
                    $conjoint->prenom         = $request->get('conjoint_prenom');
                    $conjoint->civilite       = $request->get('conjoint_civilite');
                    $conjoint->sexe           = $request->get('conjoint_sexe');
                    $conjoint->date_naissance = $request->get('conjoint_date_naissance');
                    $conjoint->sit_familiale  = $request->get('conjoint_sit_familiale');
                    $conjoint->saregime_id    = $request->get('conjoint_saregime_id');
                    $conjoint->fichesante_id  = $ficheId;
                
                if($conjoint->save()){
                    $idAction     = Action::whereSlug('AC')->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'],  'observation' => 'ID conjoint: '.$conjoint->id, 'motif' => null];
                    event(new EventTracesSante($tabInfoTrace));
                }

            }else{
                $conjoint = Conjoint::find($conjoint_id);
                    $conjoint->nom            = $request->get('conjoint_nom');
                    $conjoint->prenom         = $request->get('conjoint_prenom');
                    $conjoint->civilite       = $request->get('conjoint_civilite');
                    $conjoint->sexe           = $request->get('conjoint_sexe');
                    $conjoint->date_naissance = $request->get('conjoint_date_naissance');
                    $conjoint->sit_familiale  = $request->get('conjoint_sit_familiale');
                    $conjoint->fichesante_id  = $ficheId;
                    $conjoint->saregime_id    = $request->get('conjoint_saregime_id');
                $conjoint->save();
            }

            $conjointId = $conjoint->id;

         }

        if($request->has('enfant')){

            $enfants = $request->get('enfant');
            
            $nbrEnfants = 0;

            foreach ($enfants as $enfant) {

                $enfant_id            = $enfant['id'];
                $enfant_sexe          = $enfant['sexe'];
                $enfant_nom           = $enfant['nom'];
                $enfant_prenom        = $enfant['prenom'];
                $enfant_dateNaissance = $enfant['date_naissance'];
                $enfant_ayantDroit    = $enfant['ayant_droit'];

                if($enfant_id == 0){
                    $enfant = new Enfant;
                        $enfant->sexe           = $enfant_sexe;
                        $enfant->nom            = $enfant_nom;
                        $enfant->prenom         = $enfant_prenom;
                        $enfant->date_naissance = Carbon::createFromFormat('d/m/Y', $enfant_dateNaissance)->format('Y-m-d');
                        $enfant->ayant_droit    = $enfant_ayantDroit;
                        $enfant->fichesante_id  = $ficheId;
                    $enfant->save();

                    $nbrEnfants++;
                
                }else{
                    $enfant = Enfant::find($enfant_id);
                        $enfant->sexe           = $enfant_sexe;
                        $enfant->nom            = $enfant_nom;
                        $enfant->prenom         = $enfant_prenom;
                        $enfant->date_naissance = Carbon::createFromFormat('d/m/Y', $enfant_dateNaissance)->format('Y-m-d');
                        $enfant->ayant_droit    = $enfant_ayantDroit;
                        $enfant->ayant_droit    = $enfant_ayantDroit;
                        $enfant->fichesante_id  = $ficheId;
                    $enfant->save();
                }


                array_push($enfantIds, $enfant->id);

            }

            if($nbrEnfants>0){
                $idAction     = Action::whereSlug('AE')->value('id');
                $tabInfoTrace = [
                                    'idAction'       => $idAction, 
                                    'idFiche'        => $fiche->id, 
                                    'idStatut'       => $fiche->statut_id, 
                                    'equipe_user_id' => $userInfo['equipe_user_id'], 
                                    'tracable_id'    => $userInfo['tracable_id'], 
                                    'tracable_type'  => $userInfo['tracable_type'], 
                                    'observation'    => $nbrEnfants." ".str_plural('enfant', $nbrEnfants)." ".str_plural('ajouté',$nbrEnfants), 
                                    'motif'          => null
                                ];
                event(new EventTracesSante($tabInfoTrace));
            }

        }

        //Insertion des réponses du questionnaire

        if($request->has('radioGrpQst'))//Si le radio est coché
        {
            $radioGrpQst  = $request->get('radioGrpQst');
            $groupeQst    = $request->get('groupeQst');

            if($radioGrpQst == 1)// Radio = 'Oui'
            {
                if($request->has('reponseQuestionOui'))//Les questions si 'oui'
                {

                    //Supprimer les reponses des qst du choix 'non'

                    $deletedRows = Fichequestionnaire::where('ficheable_id', $ficheId)
                                                      ->where('ficheable_type','fichesantes')  
                                                      ->whereHas('questionnaire', function($q) {
                                                            $q->where('valGrpQuest',0);
                                                        })
                                                      ->delete();


                    $reponsesQstOui   = $request->get('reponseQuestionOui');
                    $totalPointOui  = 0;

                    foreach ($reponsesQstOui as $qstId => $reponseQstOui) {
                        if($reponseQstOui['reponse'] != "")
                        {
                            $ficheQuestionnaire = Fichequestionnaire::firstOrNew(['ficheable_id' => $ficheId, 'ficheable_type' => 'fichesantes','questionnaire_id' => $qstId, 'produit_id' => $fiche->produit_id]);

                            $ficheQuestionnaire->reponsequestionnaire_id = $reponseQstOui['reponse'];
                            $ficheQuestionnaire->active                 = 1;
                            $ficheQuestionnaire->save();

                            //point de la réponse
                           $pointReponse = $ficheQuestionnaire->reponseQuestionnaire()->first()->point;

                           $totalPointOui = $totalPointOui + $pointReponse;
                          

                            // $ficheQuestionnaire = new Fichequestionnaire;
                            // $ficheQuestionnaire->ficheable_id           = $ficheId;
                            // $ficheQuestionnaire->ficheable_type         = 'fichesantes';
                            // $ficheQuestionnaire->questionnaire_id       = $qstId;
                            // $ficheQuestionnaire->reponsequestionnaire_id = $reponseQstOui['reponse'];
                            // $ficheQuestionnaire->produit_id             = $fiche->produit_id;
                            // $ficheQuestionnaire->active                 = 1;
                            // $ficheQuestionnaire->save();

                        }
                    }

                    //Stocker le total des points dans la fiche
                    $fiche->total_points = $totalPointOui;
                    $fiche->choixGrpQst  = 1;
                    $fiche->save();

                    //Enregistrer la valeur du choix du grp qst dans la table 'fichegroupequestionnaires'

                    $fichegroupequestionnaire = Fichegroupequestionnaire::firstOrNew(['ficheable_id' => $ficheId, 'ficheable_type' => 'fichesantes','groupequestionnaire_id' => $groupeQst]);
                    $fichegroupequestionnaire->valeur = $radioGrpQst;
                    $fichegroupequestionnaire->active = 1;
                    $fichegroupequestionnaire->save();
                }
            }
            else // Radio = 'Non'
            {
                if($request->has('reponseQuestionNon'))//Les questions si 'non'
                {

                    //Supprimer les reponses des qst du choix 'oui'

                    $deletedRows = Fichequestionnaire::where('ficheable_id', $ficheId)
                                                      ->where('ficheable_type','fichesantes')  
                                                      ->whereHas('questionnaire', function($q) {
                                                            $q->where('valGrpQuest',1);
                                                        })
                                                      ->delete();

                    $reponsesQstNon   = $request->get('reponseQuestionNon');
                    $totalPointNon  = 0;

                    foreach ($reponsesQstNon as $qstId => $reponseQstNon) {
                        if($reponseQstNon['reponse'] != "")
                        {
                            $ficheQuestionnaire = Fichequestionnaire::firstOrNew(['ficheable_id' => $ficheId, 'ficheable_type' => 'fichesantes','questionnaire_id' => $qstId, 'produit_id' => $fiche->produit_id]);

                            $ficheQuestionnaire->reponsequestionnaire_id = $reponseQstNon['reponse'];
                            $ficheQuestionnaire->active                 = 1;
                            $ficheQuestionnaire->save();

                            //point de la réponse
                           $pointReponse = $ficheQuestionnaire->reponseQuestionnaire()->first()->point;

                           $totalPointNon = $totalPointNon + $pointReponse;

                            // $ficheQuestionnaire = new Fichequestionnaire;
                            // $ficheQuestionnaire->ficheable_id           = $ficheId;
                            // $ficheQuestionnaire->ficheable_type         = 'fichesantes';
                            // $ficheQuestionnaire->questionnaire_id       = $qstId;
                            // $ficheQuestionnaire->reponsequestionnaire_id = $reponseQstOui['reponse'];
                            // $ficheQuestionnaire->produit_id             = $fiche->produit_id;
                            // $ficheQuestionnaire->active                 = 1;
                            // $ficheQuestionnaire->save();

                        }
                    }

                    //Stocker le total des points dans la fiche
                    $fiche->total_points = $totalPointNon;
                    $fiche->choixGrpQst  = 0;
                    $fiche->save();


                    //Enregistrer la valeur du choix du grp qst dans la table 'fichegroupequestionnaires'

                    $fichegroupequestionnaire = Fichegroupequestionnaire::firstOrNew(['ficheable_id' => $ficheId, 'ficheable_type' => 'fichesantes','groupequestionnaire_id' => $groupeQst]);
                    $fichegroupequestionnaire->valeur = $radioGrpQst;
                    $fichegroupequestionnaire->active = 1;
                    $fichegroupequestionnaire->save();
                }
            }
            
        }
        

        

        return [
            'success'      => true,
            'message'      => 'info validé',
            'conjointId'   => $conjointId,
            //'enfantIds'    => $enfantIds,
            'enfants'      => $fiche->enfants,
            'fichePoints'  => $fiche->total_points
        ];

    }


    /**
     * save les modifications sur la fiche obseque
     */
    public function editClientObseque(EditLeadObsequeRequest $request) {

        $userInfo = $this->userInfo();

        $ficheId = $request->get("ficheId");

        $clientId = $request->get('clientId');

        $client = Client::find($clientId);
            $client->nom            = $request->get('nom');
            $client->prenom         = $request->get('prenom');
            $client->civilite       = $request->get('civilite');
            $client->sexe           = $request->get('sexe');
            $client->sit_familiale  = $request->get('sit_familiale');
            $client->date_naissance = $request->get('date_naissance');
            $client->email          = $request->get('email');
            $client->email_pro      = $request->get('email_pro');
            $client->profession_id     = $request->get('profession');
            $client->ville          = $request->get('ville');
            $client->adresse        = $request->get('adresse');
            $client->tel_mobile     = $request->get('tel_mobile');
            $client->code_postal    = $request->get('code_postal');
            //$client->saregime_id    = $request->get('saregime_id');
        $client->save();

        $fiche = Ficheobseque::find($ficheId);
            $date_effet         = $this->dateCarbon($request->get('date_effet'));
            $date_naissance     = $this->dateCarbon($request->get('date_naissance'));
            $fiche->date_effet  = $request->get('date_effet');
            $fiche->saregime_id = $request->get('saregime_id');
            $fiche->capital     = $request->get('capital');
            $fiche->ani         = ($date_effet->diffInYears($date_naissance) >= 55 or $request->get('saregime_id') == 3 ) ? 0 : 1;

        if($fiche->save()){

            $observation  = '' ;
            $actionSlug   = 'GF';

            if($request->get('etatSave')){
                $observation  = 'Type: '.$fiche->statut->groupeStatus->libelle ;
                $actionSlug   = 'MI';
            }else{
                $observation  = null ;
                $actionSlug   = 'GF';
            }
            
            $idAction     = Action::whereSlug($actionSlug)->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'idStatut' => $fiche->statut_id, 'observation' => $observation, 'motif' => null];
            event(new EventTracesObseque($tabInfoTrace));
        }

        return [
            'success'    => true,
            'message'    => 'info validé',
        ];

    }

    /**
     * save les modifications sur la fiche sante
     */
    public function editClientGav(EditLeadGavRequest $request) {

        $userInfo = $this->userInfo();

        $conjointId   = 0;
        $enfantIds    = [];
        $ficheId      = $request->get("ficheId");

        $fiche = Fichegav::find($ficheId);
            $date_effet         = $this->dateCarbon($request->get('date_effet'));
            $date_naissance     = $this->dateCarbon($request->get('date_naissance'));
            $fiche->date_effet  = $request->get('date_effet');
            $fiche->regime_id   = $request->get('saregime_id');
            $fiche->ani         = ($date_effet->diffInYears($date_naissance) >= 55 or $request->get('saregime_id') == 3 ) ? 0 : 1;

        if($fiche->save()){

            $observation  = '' ;
            $actionSlug   = 'GF';

            if($request->get('etatSave')){
                $observation  = 'Type: '.$fiche->statut->groupeStatus->libelle ;
                $actionSlug   = 'MI';
            }else{
                $observation  = null ;
                $actionSlug   = 'GF';
            }
            
            $idAction     = Action::whereSlug($actionSlug)->value('id');
            $tabInfoTrace = [
                                'idAction'       => $idAction, 
                                'idFiche'        => $fiche->id, 
                                'equipe_user_id' => $userInfo['equipe_user_id'], 
                                'tracable_id'    => $userInfo['tracable_id'], 
                                'tracable_type'  => $userInfo['tracable_type'], 
                                'idStatut'       => $fiche->statut_id, 
                                'observation'    => $observation, 
                                'motif'          => null
                            ];
            event(new EventTracesGav($tabInfoTrace));
        }

        $clientId = $request->get('clientId');
        
        $client = Client::find($clientId);
            $client->nom            = $request->get('nom');
            $client->prenom         = $request->get('prenom');
            $client->civilite       = $request->get('civilite');
            $client->sexe           = $request->get('sexe');
            $client->sit_familiale  = $request->get('sit_familiale');
            $client->date_naissance = $request->get('date_naissance');
            $client->email          = $request->get('email');
            $client->email_pro      = $request->get('email_pro');
            $client->profession_id     = $request->get('profession');
            $client->ville          = $request->get('ville');
            $client->adresse        = $request->get('adresse');
            $client->tel_mobile     = $request->get('tel_mobile');
            $client->code_postal    = $request->get('code_postal');
            //$client->saregime_id    = $request->get('saregime_id');
        $client->save();

        if($request->has('has_conjoint')){

            $conjoint_id = $request->get('conjoint_id');

            if($conjoint_id == 0){
                $conjoint = new GavConjoint;
                    $conjoint->nom            = $request->get('conjoint_nom');
                    $conjoint->prenom         = $request->get('conjoint_prenom');
                    $conjoint->civilite       = $request->get('conjoint_civilite');
                    $conjoint->sexe           = $request->get('conjoint_sexe');
                    $conjoint->date_naissance = $request->get('conjoint_date_naissance');
                    $conjoint->sit_familiale  = $request->get('conjoint_sit_familiale');
                    $conjoint->regime_id      = $request->get('conjoint_saregime_id');
                    $conjoint->fichegav_id    = $ficheId;
                
                if($conjoint->save()){
                    $idAction     = Action::whereSlug('AC')->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'],  'observation' => 'ID conjoint: '.$conjoint->id, 'motif' => null];
                    event(new EventTracesGav($tabInfoTrace));
                }

            }else{
                $conjoint = GavConjoint::find($conjoint_id);
                    $conjoint->nom            = $request->get('conjoint_nom');
                    $conjoint->prenom         = $request->get('conjoint_prenom');
                    $conjoint->civilite       = $request->get('conjoint_civilite');
                    $conjoint->sexe           = $request->get('conjoint_sexe');
                    $conjoint->date_naissance = $request->get('conjoint_date_naissance');
                    $conjoint->sit_familiale  = $request->get('conjoint_sit_familiale');
                    $conjoint->fichegav_id    = $ficheId;
                    $conjoint->regime_id      = $request->get('conjoint_saregime_id');
                $conjoint->save();
            }

            $conjointId = $conjoint->id;

         }

        if($request->has('enfant')){

            $enfants = $request->get('enfant');
            
            $nbrEnfants = 0;

            foreach ($enfants as $enfant) {

                $enfant_id            = $enfant['id'];
                $enfant_sexe          = $enfant['sexe'];
                $enfant_nom           =  $enfant['nom'];
                $enfant_prenom        = $enfant['prenom'];
                $enfant_dateNaissance = $enfant['date_naissance'];
                $enfant_ayantDroit    = $enfant['ayant_droit'];

                if($enfant_id == 0){
                    $enfant = new GavEnfant;
                        $enfant->sexe           = $enfant_sexe;
                        $enfant->nom            = $enfant_nom;
                        $enfant->prenom         = $enfant_prenom;
                        $enfant->date_naissance = Carbon::createFromFormat('d/m/Y', $enfant_dateNaissance)->format('Y-m-d');
                        $enfant->ayant_droit    = $enfant_ayantDroit;
                        $enfant->fichegav_id    = $ficheId;
                    $enfant->save();

                    $nbrEnfants++;
                
                }else{
                    $enfant = GavEnfant::find($enfant_id);
                        $enfant->sexe           = $enfant_sexe;
                        $enfant->nom            = $enfant_nom;
                        $enfant->prenom         = $enfant_prenom;
                        $enfant->date_naissance = Carbon::createFromFormat('d/m/Y', $enfant_dateNaissance)->format('Y-m-d');
                        $enfant->ayant_droit    = $enfant_ayantDroit;
                        $enfant->ayant_droit    = $enfant_ayantDroit;
                        $enfant->fichegav_id    = $ficheId;
                    $enfant->save();
                }


                array_push($enfantIds, $enfant->id);

            }

            if($nbrEnfants>0){
                $idAction     = Action::whereSlug('AE')->value('id');
                $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $nbrEnfants." ".str_plural('enfant', $nbrEnfants)." ".str_plural('ajouté',$nbrEnfants), 'motif' => null];
                event(new EventTracesGav($tabInfoTrace));
            }

        }

        return [
            'success'      => true,
            'message'      => 'info validé',
            'conjointId'   => $conjointId,
            //'enfantIds'    => $enfantIds,
            'enfants'      => $fiche->enfants,
        ];

    }


    /**
     * save les modifications sur la fiche auto  a ajouter dans request EditLeadAutoRequest
     */
    public function editClientAuto(Request $request) {

        // $userInfo               = $this->userInfo();
        // $newSinistresIds        = [];
        // $newInfractionsIds      = [];
        // $vehiculeReq            = collect((array) $request->get('vehicule'));
        // $ficheReq               = collect((array) $request->get('fiche'));
        // $clientReq              = collect((array) $request->get('client'));
        // $conjointReq            = collect((array) $request->get('conjoint'));
        // $conductSecondReq       = collect((array) $request->get('conductSecond'));
        // $produitReq             = (array) $ficheReq['produit'];
        // $sinistresReq           = collect((array) $request->get('sinistres'));
        // //$infractionsReq         = collect((array) $request->get('infractions'));
        // $enfantsReq             = collect((array) $request->get('enfants'));
        // $etatSinistre           = $request->get('etatSinistre');
        // //$etatInfraction         = $request->get('etatInfraction');
        // $etatEnfant             = $request->get('etatEnfant');
        // // $vehicule               = (object) $request->get('vehicule');

        // $ficheReqSs             =  $ficheReq->diffKeys([
        //                             'produit' => 2,
        //                             'client' => 2,
        //                             'statut' => 2,
        //                             'get_groupe_pub_prov' => 2
        //                         ]);      



        // // Modification table client
        // $client                 = Client::find($clientReq['id']);

        // foreach ($clientReq as $key => $value) {

        //     // if($client->has($key)){

        //         $client->{$key}   = $value;
        //     // }
        // }

        // $client->save();              


        // // Modification table ficheauto
        // $fiche                  = Ficheauto::find($ficheReqSs['id']);
        
        // foreach ($ficheReqSs as $key => $value) {

        //     // if($fiche->has($key)){

        //         $fiche->{$key}   = $value;
        //     // }
        // }
        
        // if($fiche->save()){

        //     $observation        = '' ;
        //     $actionSlug         = 'GF';

        //     if($request->get('etatSave')){

        //         $observation    = 'Type: '.$fiche->statut->groupeStatus->libelle ;
        //         $actionSlug     = 'MI';
        //     }else{
        //         $observation    = null ;
        //         $actionSlug     = 'GF';
        //     }
            
        //     $idAction     = Action::whereSlug($actionSlug)->value('id');
        //     $tabInfoTrace = ['idAction'         => $idAction, 
        //                      'idFiche'          => $fiche->id, 
        //                      'equipe_user_id'   => $userInfo['equipe_user_id'], 
        //                      'tracable_id'      => $userInfo['tracable_id'], 
        //                      'tracable_type'    => $userInfo['tracable_type'], 
        //                      'idStatut'         => $fiche->statut_id, 
        //                      'observation'      => $observation, 
        //                      'motif'            => null
        //                     ];
        //     event(new EventTracesAuto($tabInfoTrace));
        // }        



        // // Modification table vehicule
        // if($vehiculeReq->has('id')){

        //     $vehicule               = Vehicule::find($vehiculeReq['id']);

        // }else{

        //     $vehicule               = new Vehicule;
        // }

        // foreach ($vehiculeReq as $key => $value) {

        //     $vehicule->{$key}   = $value;
        // }

        // $vehicule->save();


        // // Modification table conjoint
        // if($conjointReq->has('id')){

        //     $conjoint               = AutoConjoint::find($conjointReq['id']);

        // }else{

        //     $conjoint               = new AutoConjoint;
        //     $conjoint->ficheauto_id = $fiche->id;
        // }

        // foreach ($conjointReq as $key => $value) {

        //     $conjoint->{$key}   = $value;
        // }

        // $conjoint->save();     


        // // Modification table conductSecond
        // // Modification table vehicule
        // if($conductSecondReq->has('id')){

        //     $conductSecond               = Conductsecond::find($conductSecondReq['id']);

        // }else{

        //     $conductSecond               = new Conductsecond;
        //     $conductSecond->ficheauto_id = $fiche->id;
        // }        

        // foreach ($conductSecondReq as $key => $value) {

        //     $conductSecond->{$key}   = $value;
        // }

        // $conductSecond->save();            


        // // Modification table sinistre
        // if($etatSinistre == 'O'){

        //     $nbrNewSinistres        = 0;
        //     $tabIdsSinistresExist   = $sinistresReq->pluck('id')->filter()->all();
        //     Sinistre::where('ficheauto_id', $fiche->id)->whereNotIn('id', $tabIdsSinistresExist)->delete();            

        //     foreach ($sinistresReq as $key => $sinistreReq) {

        //         $sinistreReq  = collect((array) $sinistreReq);

        //         if($sinistreReq->has('id')){

        //             $sinistre = Sinistre::find($sinistreReq['id']);  

        //         }else{

        //             $sinistre               = new Sinistre;
        //             $sinistre->ficheauto_id = $fiche->id;
        //             $nbrNewSinistres ++;                    
        //         }

        //         foreach ($sinistreReq as $cle => $valeur) {

        //             $sinistre->{$cle}   = $valeur;
        //         }

        //         $sinistre->save();

        //         //array_push($newSinistresIds, $sinistre->id);
             
        //     } // foreach


        //     if($nbrNewSinistres > 0){

        //         // Enregistrer les traces
        //         $idAction     = Action::whereSlug('AS')->value('id');
        //         $tabInfoTrace = [
        //                             'idAction'       => $idAction, 
        //                             'idFiche'        => $fiche->id, 
        //                             'idStatut'       => $fiche->statut_id, 
        //                             'equipe_user_id' => $userInfo['equipe_user_id'], 
        //                             'tracable_id'    => $userInfo['tracable_id'], 
        //                             'tracable_type'  => $userInfo['tracable_type'], 
        //                             'observation'    => $nbrNewSinistres." ".str_plural('sinistre', $nbrNewSinistres)." ".str_plural('ajouté',$nbrNewSinistres), 
        //                             'motif'          => null
        //                         ];
        //         event(new EventTracesAuto($tabInfoTrace));  
        //     }                         

        // }else{

        //     Sinistre::where('ficheauto_id', $fiche->id)->delete();
        // }


        // // // Modification table fraction
        // // if($etatInfraction == 'O'){

        // //     $nbrNewInfractions        = 0;
        // //     $tabIdsInfractionsExist   = $infractionsReq->pluck('id')->filter()->all();
        // //     Infraction::where('ficheauto_id', $fiche->id)->whereNotIn('id', $tabIdsInfractionsExist)->delete();

        // //     foreach ($infractionsReq as $key => $infractionReq) {

        // //         $infractionReq  = collect((array) $infractionReq);

        // //         if($infractionReq->has('id')){

        // //             $infraction = Infraction::find($infractionReq['id']);  

        // //         }else{

        // //             $infraction               = new Infraction;
        // //             $infraction->ficheauto_id = $fiche->id;
        // //             $nbrNewInfractions++;
        // //         }

        // //         foreach ($infractionReq as $cle => $valeur) {

        // //             $infraction->{$cle}   = $valeur;
        // //         }

        // //         $infraction->save();
        // //     }// foreach


        // //     if($nbrNewInfractions > 0){

        // //         // Enregistrer les traces
        // //         $idAction     = Action::whereSlug('AI')->value('id');
        // //         $tabInfoTrace = [
        // //                             'idAction'       => $idAction, 
        // //                             'idFiche'        => $fiche->id, 
        // //                             'idStatut'       => $fiche->statut_id, 
        // //                             'equipe_user_id' => $userInfo['equipe_user_id'], 
        // //                             'tracable_id'    => $userInfo['tracable_id'], 
        // //                             'tracable_type'  => $userInfo['tracable_type'], 
        // //                             'observation'    => $nbrNewInfractions." ".str_plural('infraction', $nbrNewInfractions)." ".str_plural('ajouté',$nbrNewInfractions), 
        // //                             'motif'          => null
        // //                         ];
        // //         event(new EventTracesAuto($tabInfoTrace));  
        // //     }                

        // // }else{

        // //     Infraction::where('ficheauto_id', $fiche->id)->delete();
        // // }

        // // Modification table enfants
        // if($etatEnfant){

        //     $nbrNewEnfants        = 0;
        //     $tabIdsEnfantsExist   = $enfantsReq->pluck('id')->filter()->all();
        //     AutoEnfant::where('ficheauto_id', $fiche->id)->whereNotIn('id', $tabIdsEnfantsExist)->delete();

        //     foreach ($enfantsReq as $key => $enfantReq) {

        //         $enfantReq  = collect((array) $enfantReq);

        //         if($enfantReq->has('id')){

        //             $enfant = AutoEnfant::find($enfantReq['id']);  

        //         }else{

        //             $enfant                 = new AutoEnfant;
        //             $enfant->ficheauto_id   = $fiche->id;
        //             $nbrNewEnfants++;
        //         }

        //         foreach ($enfantReq as $cle => $valeur) {

        //             $enfant->{$cle}   = $valeur;
        //         }

        //         $enfant->save();
        //     }// foreach


        //     if($nbrNewEnfants > 0){

        //         // Enregistrer les traces
        //         $idAction     = Action::whereSlug('AE')->value('id');
        //         $tabInfoTrace = [
        //                             'idAction'       => $idAction, 
        //                             'idFiche'        => $fiche->id, 
        //                             'idStatut'       => $fiche->statut_id, 
        //                             'equipe_user_id' => $userInfo['equipe_user_id'], 
        //                             'tracable_id'    => $userInfo['tracable_id'], 
        //                             'tracable_type'  => $userInfo['tracable_type'], 
        //                             'observation'    => $nbrNewEnfants." ".str_plural('enfant', $nbrNewEnfants)." ".str_plural('ajouté',$nbrNewEnfants), 
        //                             'motif'          => null
        //                         ];
        //         event(new EventTracesAuto($tabInfoTrace));  
        //     }                

        // }else{

        //     AutoEnfant::where('ficheauto_id', $fiche->id)->delete();
        // }

        // $sinistres      = Sinistre::where('ficheauto_id', $fiche->id)->get();
        // //$infractions    = Infraction::where('ficheauto_id', $fiche->id)->get();
        // $enfants        = AutoEnfant::where('ficheauto_id', $fiche->id)->get();


        // return [
        //     'success'      => true,
        //     'message'      => 'info validé',
        //     'sinistres'    => $sinistres,
        //     //'infractions'  => $infractions,
        //     'enfants'      => $enfants,
        // ];

        return 1;

    }
    
    /**
     * supprimer l'enfant
     */
    public function deleteChildGav(Request $request) {

        $id = $request->get("id");

        $enfant = GavEnfant::find($id);

        $fiche = $enfant->fichegav;

        $userInfo = $this->userInfo();

        if($enfant->delete()){
            $idAction     = Action::whereSlug('SE')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => ' ID enfant: '.$id, 'motif' => null];
            event(new EventTracesGav($tabInfoTrace));

            return "l'enfant a été supprimé";
        }

    }


    /**
     * supprimer le conjoint
     */
    public function deleteConjointGav(Request $request) {

        $id = $request->get("id");

        $conjoint = GavConjoint::find($id);

        $fiche = $conjoint->fichegav;

        $userInfo = $this->userInfo();

        if($conjoint->delete()){
            $idAction     = Action::whereSlug('SC')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => ' ID conjoint: '.$id, 'motif' => null];
            event(new EventTracesGav($tabInfoTrace));

            return "le conjoint a été supprimé";
        }

        

    }

    /**
     * supprimer l'enfant
     */
    public function deleteChild(Request $request) {

        $id = $request->get("id");

        $enfant = Enfant::find($id);

        $fiche = $enfant->fichesante;

        $userInfo = $this->userInfo();

        if($enfant->delete()){
            $idAction     = Action::whereSlug('SE')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => ' ID enfant: '.$id, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));

            return "l'enfant a été supprimé";
        }

    }


    /**
     * supprimer le conjoint
     */
    public function deleteConjoint(Request $request) {

        $id = $request->get("id");

        $conjoint = Conjoint::find($id);

        $fiche = $conjoint->fichesante;

        $userInfo = $this->userInfo();

        if($conjoint->delete()){
            $idAction     = Action::whereSlug('SC')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => ' ID conjoint: '.$id, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));

            return "le conjoint a été supprimé";
        }

        

    }


    /**
     * Recevoir le status de la fiche
     */
    public function getStatut(Request $request){

        $statut_id = $request->get('statutId');
        $fiche_id  = $request->get('ficheId');
        $prd_id    = $request->get('prdId');

        $statut = Statut::find($statut_id);

        $slug = $statut->slug;

        $rappel = [];
    
        if($statut->slug==$statut->slug_produit.'Rappel'){
            $rappel = $this->lastRappel($fiche_id, $statut_id, $prd_id);
        }

        return [
            'statutId'     => $statut->id,
            'statutLib'    => $statut->libelle,
            'motifs'       => $statut->motifs,
            'rappelActive' => ($statut->slug==$statut->slug_produit.'Rappel') ? 1 : 0 ,
            'rappel'       => $rappel,
        ];

    }

    
    /**
     * Recevoir le dernier rappel
     */
    public function lastRappel($fiche_id, $statut_id, $prd_id){

        $produit = Produit::find($prd_id);

        $rappel = Statutaction::where('actionable_id', $fiche_id)
                                ->where('actionable_type', "fiche".$produit->slug."s")
                                ->where('statut_id', $statut_id)
                                ->orderBy('created_at', 'desc')
                                ->first();

        return $rappel;

    }


    /**
     * changer le statut de la fiche
     */
    public function changeStatut(Request $request){

        $user                          = Auth::user();
        
        //$produit_id                  = Session::get('produit_id');
        $produit_id                    = $request->get('prdId');
        $produit                       = Produit::find($produit_id);

        $slugPrd = $produit->slug;
        
        $fiche_id                      = $request->get('modalFicheId');
        $statut_id                     = $request->get('modalStatutId');
        
        $statutAction                  = new Statutaction;
        
        $className                     = "App\Fiche".$produit->slug;
        
        $fiche                         = $className::find($fiche_id);

        $oldStatut = $fiche->statut->libelle;

        $statutAction->actionable_type = "fiche".$produit->slug."s";
        
        $statut = Statut::find($statut_id);

        // if($statut->groupeStatus->slug=='leads'){
        //     $fiche->date_situation = $fiche->date_insertion;
        // }elseif($statut->groupeStatus->slug=='devis'){
        //     $fiche->date_situation = Carbon::now();
        // }elseif($statut->groupeStatus->slug=='contrats'){
        //     $fiche->date_situation = Carbon::now();
        // }

        $fiche->date_situation = Carbon::now();

        $fiche->statut_id = $statut->id;
        
        $statutAction->complement      = $request->get('action_complement');
        $statutAction->user_id         = $user->id;
        $statutAction->statut_id       = $statut_id;
        $statutAction->actionable_id   = $fiche_id;
        
        if($request->has('modalMotifId')){
            $statutAction->motif_id = $request->get('modalMotifId');
            $fiche->motif_id        = $request->get('modalMotifId');
        }

        $timeRappel  = '';

        if($request->has('rappel_date')){
            $statutAction->date_rappel     = $request->get('rappel_date');
            $timeRappel .= " <i class='uk-icon-calendar'></i> ".$request->get('rappel_date');
        }

        if($request->has('rappel_heure')){
            $statutAction->heure_rappel    = $request->get('rappel_heure');
            $timeRappel .= " <i class='uk-icon-clock-o'></i> ".$request->get('rappel_heure');
        }

        // $fiche->save();

        // $statutAction->save();

        if($fiche->save() and $statutAction->save()){

            $userInfo = $this->userInfo();

            $idAction     = Action::whereSlug('CS')->value('id');
            $observation  = "<i class='uk-text-danger material-icons'>&#xE14C;</i> ".$oldStatut."<br><i class='uk-text-success material-icons'>&#xE876;</i> ".$statutAction->statut->libelle."<br>".$timeRappel;
            $motif        = $request->has('modalMotifId') ? $request->get('modalMotifId') : null;
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => $motif];
            $event        = 'App\Events\EventTraces'.ucfirst($produit->slug);
            event(new $event($tabInfoTrace));

            if($statut->slug==$slugPrd."Rappel"){

                $userList = [];

                if($fiche->equipe_user_id){

                    array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                    array_push( $userList, $fiche->dispatchable->responsable() );

                }else{

                    array_push( $userList, $fiche->dispatchable->responsable() );

                }

                $notif = Notification::whereSlug('LEADRAPPEL')->first();
                
                $notification = [
                    'user_id'         => null,
                    'notification_id' => $notif->id,
                    'notifiable_id'   => $fiche->id,
                    'notifiable_type' => $fiche->produit->table_produit,
                    'rappel_time'     => $request->get('rappel_date') .' '. $request->get('rappel_heure'),
                    'link'            => null,
                    'type'            => 'rappel',
                    'description'     => $request->get('action_complement')
                ];

                foreach ($userList as $usr) {

                    $notification['user_id'] = $usr->id;
                    $notification['link']    = url($usr->profile->slug.'/leads/'.$produit->slug.'/'.$fiche->slug);
                   
                    event(new EventNotifications($notification));

                }

            }

            $info_fiche = [
                            'fiche_id'     => $fiche->id,
                            'prd_slug'     => $fiche->produit->slug
                        ];

            $collection = collect(event(new EventCreateProcessesLead($info_fiche)));
            $processes  = $collection->flatten(1);
            $processes->values()->all();

            return [
                    "success"   => true,
                    "message"   => "Bien ajouté",
                    "statutLib" => $request->get("statutLib"),
                    "processes" => $processes,
                    "statut"    => $statut
                ];

        }

    }


    /**
     * Ajouter un document à une fiche
     */
    public function addDoc(DocumentRequest $request){

        //$produit_id   = Session::get('produit_id');
        $produit_id   = $request->get('prdId');
        $produit      = Produit::find($produit_id);

        $doc_id   = $request->get('docId');
        $fiche_id = $request->get('ficheId');
        $doc_file = $request->file('document');
        
        $user      = Auth::user();

        $className = "App\Fiche".$produit->slug;
        
        $fiche    = $className::find($fiche_id);
        $document = Documentfiche::find($doc_id);

        $dir = "upload/documents/".$produit->slug;

        if (!file_exists($dir)) {
            File::makeDirectory($dir, 0777, true);
        }
        
        $directory = $dir."/$fiche_id";

        if (!file_exists($directory)) {
            File::makeDirectory($directory, 0777, true);
        }

        $doc_ext  = $doc_file->getClientOriginalExtension();
        $doc_name = str_slug($document->nom).'-'.date('Y-m-d h:i:s').'.'.$doc_ext;

        $fichier = $doc_file->move($directory,$doc_name);

        $fiche->documentFiche()->detach($doc_id);

        $fiche->documentFiche()->attach($doc_id, ['active' => 1, 'path' => $fichier, 'user_id' => $user->id]);

        $userInfo = $this->userInfo();

        $idAction     = Action::whereSlug('AD')->value('id');
        $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => "<a href='".asset($fichier)."' target='_blank'>".$document->nom."</a>", 'motif' => null];
        $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
        event(new $event($tabInfoTrace));

        $docFile = $fiche->documentFiche()->where('documentfiche_id', $doc_id)->first();

        if($doc_ext =='pdf'){
            $icon = 'pdf';
        }elseif($doc_ext =='doc' or $doc_ext =='docx'){
            $icon = 'word';
        }else{
            $icon = 'image';
        }

        return [ 
                    "success" => true,
                    "message" => "le document a été ajouté.",
                    "path"    => url($fichier),
                    "user"    => "$user->login ($user->nom $user->prenom)",
                    "date"    => Carbon::parse($docFile->pivot->created_at)->format('d/m/Y H:i:s'),
                    "icon"    => $icon
                ];

    }

    /**
     * Dupliquer une fiche santé
     */
    public function duplicateSante(Request $request, $client_id, $fiche_id, $produit_id){
        
        $conjoint     = [];
        $enfants      = [];
        
        $user         = Auth::user();
        $equipeUserId =  $user->userEquipe->first()->pivot->id;

        $access = 0;
        
        $produitSlug        = $request->segment(5);
        $currentProduit     = Produit::whereSlug($produitSlug)->first();
        
        $client             = Client::find($client_id);
        
        if($currentProduit->id == $produit_id){

            $fiche    = Fichesante::find($fiche_id);
            $conjoint = $fiche->conjoint;
            $enfants  = $fiche->enfants;

            if($fiche->statut->slug=='santeAppel'){
                return redirect('conseiller/leads/sante/'.$fiche->slug)->with('duplicate_message', 'Le statut de la fiche ne permet pas de la dupliquer!!!');
            }

            if($fiche->equipe_user_id == $equipeUserId){
                $access = 1;
            }

        }else{
            
            $prd = Produit::find($produit_id);
            $className = "App\Fiche".$prd->slug;
            $fiche1 = $className::find($fiche_id);

            // if($fiche1->statut->slug=='appel'){
            //     return redirect('conseiller/leads/'.$prd->slug.'/'.$fiche1->slug)->with('duplicate_message', 'Le statut de la fiche ne permet pas de la dupliquer!!!');
            // }

            if($fiche1->equipe_user_id == $equipeUserId){
                $access = 1;
            }

        }

        $produit            = Produit::find($currentProduit->id);
        
        $produitIds         = Fichesante::where('client_id',$client->id)
                                            ->groupBy('produit_id')
                                            ->lists('produit_id');
        
        $gpIds              = Produit::whereIn('id',$produitIds)
                                        ->groupBy('groupeproduit_id')
                                        ->lists('groupeproduit_id');
        
        $groupeProduits     = Groupeproduit::whereIn('id',$gpIds)->get();
        
        $regimes            = Saregime::whereActive(1)->get();

        $regimePardefaut    = Saregime::where('code', 'SES')->first();
        
        $groupePrd          = $produit->groupeProduit;
        
        $groupeProduitsList = Groupeproduit::whereActive(1)->with('produits')->get();
        
        $contrats           = Fichesante::getContrats($client->id, $groupePrd->id);
        
        $documents          = Documentfiche::where('produit_id', $produit_id)->get();

        $professions = Profession::whereActive(1)->orderBy('libelle', 'asc')->get();

        return view('shared.produits.duplicate_sante', [
                                    'user'               => $user,
                                    'client'             => $client,
                                    'groupeProduits'     => $groupeProduits,
                                    'regimes'            => $regimes,
                                    'regimePardefaut'    => $regimePardefaut,
                                    'groupeProduitsList' => $groupeProduitsList,
                                    'contrats'           => $contrats,
                                    'documents'          => $documents,
                                    'conjoint'           => $conjoint,
                                    'enfants'            => $enfants,
                                    'currentProduit'     => $currentProduit,
                                    'access'             => $access,
                                    'professions'        => $professions,
                                ]
            );

    }

    /**
     * Dupliquer une fiche santé
     */
    public function duplicateGav(Request $request, $client_id, $fiche_id, $produit_id){
        
        $conjoint     = [];
        $enfants      = [];
        
        $user         = Auth::user();
        $equipeUserId =  $user->userEquipe->first()->pivot->id;

        $access = 0;
        
        $produitSlug        = $request->segment(5);
        $currentProduit     = Produit::whereSlug($produitSlug)->first();
        
        $client             = Client::find($client_id);
        
        if($currentProduit->id == $produit_id){

            $fiche    = Fichegav::find($fiche_id);
            $conjoint = $fiche->conjoint;
            $enfants  = $fiche->enfants;

            if($fiche->statut->slug=='gavAppel'){
                return redirect('conseiller/leads/gav/'.$fiche->slug)->with('duplicate_message', 'Le statut de la fiche ne permet pas de la dupliquer!!!');
            }

            if($fiche->equipe_user_id == $equipeUserId){
                $access = 1;
            }

        }else{
            
            $prd = Produit::find($produit_id);
            $className = "App\Fiche".$prd->slug;
            $fiche1 = $className::find($fiche_id);

            // if($fiche1->statut->slug=='appel'){
            //     return redirect('conseiller/leads/'.$prd->slug.'/'.$fiche1->slug)->with('duplicate_message', 'Le statut de la fiche ne permet pas de la dupliquer!!!');
            // }

            if($fiche1->equipe_user_id == $equipeUserId){
                $access = 1;
            }

        }

        $produit            = Produit::find($currentProduit->id);
        
        $produitIds         = Fichegav::where('client_id',$client->id)
                                            ->groupBy('produit_id')
                                            ->lists('produit_id');
        
        $gpIds              = Produit::whereIn('id',$produitIds)
                                        ->groupBy('groupeproduit_id')
                                        ->lists('groupeproduit_id');
        
        $groupeProduits     = Groupeproduit::whereIn('id',$gpIds)->get();
        
        $regimes            = Saregime::whereActive(1)->get();

        $regimePardefaut    = Saregime::where('code', 'SES')->first();
        
        $groupePrd          = $produit->groupeProduit;
        
        $groupeProduitsList = Groupeproduit::whereActive(1)->with('produits')->get();
        
        $contrats           = Fichegav::getContrats($client->id, $groupePrd->id);
        
        $documents          = Documentfiche::where('produit_id', $produit_id)->get();

        $professions = Profession::whereActive(1)->orderBy('libelle', 'asc')->get();

        return view('shared.produits.duplicate_gav', [
                                    'user'               => $user,
                                    'client'             => $client,
                                    'groupeProduits'     => $groupeProduits,
                                    'regimes'            => $regimes,
                                    'regimePardefaut'    => $regimePardefaut,
                                    'groupeProduitsList' => $groupeProduitsList,
                                    'contrats'           => $contrats,
                                    'documents'          => $documents,
                                    'conjoint'           => $conjoint,
                                    'enfants'            => $enfants,
                                    'currentProduit'     => $currentProduit,
                                    'access'             => $access,
                                    'professions'        => $professions,
                                ]
            );

    }
    
    /**
     * Dupliquer une fiche obseque
     */
    public function duplicateObseque(Request $request, $client_id, $fiche_id, $produit_id){

        $capital            = 0;

        $user               = Auth::user();
        $equipeUserId =  $user->userEquipe->first()->pivot->id;

        $access = 0;
        
        $produitSlug        = $request->segment(5);
        $currentProduit     = Produit::whereSlug($produitSlug)->first();
        
        $client             = Client::find($client_id);

        
        if($currentProduit->id == $produit_id){

            $fiche    = Ficheobseque::find($fiche_id);
            $capital  = $fiche->capital;

            if($fiche->statut->slug=='obsequeAppel'){
                return redirect('conseiller/leads/obseque/'.$fiche->slug)->with('duplicate_message', 'Le statut de la fiche ne permet pas de la dupliquer!!!');
            }

            if($fiche->equipe_user_id == $equipeUserId){
                $access = 1;
            }

        }else{
            
            $prd       = Produit::find($produit_id);
            $className = "App\Fiche".$prd->slug;
            $fiche1    = $className::find($fiche_id);

            // if($fiche1->statut->slug=='appel'){
            //     return redirect('conseiller/leads/'.$prd->slug.'/'.$fiche1->slug)->with('duplicate_message', 'Le statut de la fiche ne permet pas de la dupliquer!!!');
            // }

            if($fiche1->equipe_user_id == $equipeUserId){
                $access = 1;
            }

        }


        $produit            = Produit::find($currentProduit->id);
        
        $produitIds         = Fichesante::where('client_id',$client->id)
                                            ->groupBy('produit_id')
                                            ->lists('produit_id');
        
        $gpIds              = Produit::whereIn('id',$produitIds)
                                        ->groupBy('groupeproduit_id')
                                        ->lists('groupeproduit_id');
        
        $groupeProduits     = Groupeproduit::whereIn('id',$gpIds)->get();
        
        $regimes            = Saregime::whereActive(1)->get();

        $regimePardefaut    = Saregime::where('code', 'SES')->first();
        
        $groupePrd          = $produit->groupeProduit;
        
        $groupeProduitsList = Groupeproduit::whereActive(1)->with('produits')->get();
        
        $contrats           = Ficheobseque::getContrats($client->id, $groupePrd->id);
        
        $documents          = Documentfiche::where('produit_id', $produit_id)->get();
        
        $professions = Profession::whereActive(1)->orderBy('libelle', 'asc')->get();

        return  view('shared.produits.duplicate_obseque', [
                                    'user'               => $user,
                                    'client'             => $client,
                                    'groupeProduits'     => $groupeProduits,
                                    'capital'            => $capital,
                                    'regimes'            => $regimes,
                                    'regimePardefaut'    => $regimePardefaut,
                                    'groupeProduitsList' => $groupeProduitsList,
                                    'contrats'           => $contrats,
                                    'documents'          => $documents,
                                    'currentProduit'     => $currentProduit,
                                    'access'             => $access,
                                    'professions'        => $professions,
                                ]
                );

    }


    /**
     * Créer une fiche santé
     */
    public function newSante(DuplicateLeadSanteRequest $request){

        $userInfo = $this->userInfo();

        $user         = Auth::user();
        $equipeId     =  $user->userEquipe->first()->pivot->equipe_id;
        $equipeUserId =  $user->userEquipe->first()->pivot->id;
        
        $conjointId   = 0;
        
        $enfantIds    = [];
        
        $produit      = Produit::whereSlug($request->get('produitSlug'))->first();
        
        $clientId     = $request->get('clientId');
        
        $client = Client::find($clientId);
            $client->nom            = $request->get('nom');
            $client->prenom         = $request->get('prenom');
            $client->civilite       = $request->get('civilite');
            $client->sexe           = $request->get('sexe');
            $client->sit_familiale  = $request->get('sit_familiale');
            $client->date_naissance = $request->get('date_naissance');
            $client->email          = $request->get('email');
            $client->email_pro      = $request->get('email_pro');
            $client->profession_id     = $request->get('profession');
            $client->ville          = $request->get('ville');
            $client->adresse        = $request->get('adresse');
            $client->tel_mobile     = $request->get('tel_mobile');
            $client->code_postal    = $request->get('code_postal');
            $client->saregime_id    = $request->get('saregime_id');
        $client->save();

        $date_effet     = $this->dateCarbon($request->get('date_effet'));
        $date_naissance = $this->dateCarbon($client->date_naissance);

        $fiche = new Fichesante;
            $fiche->client_id               = $client->id;
            $fiche->slug                    = uniqid();
            $fiche->produit_id              = $produit->id;
            $fiche->equipe_user_id          = $equipeUserId;
            $fiche->dispatchable_id         = $equipeId;
            $fiche->dispatchable_type       = 'equipe';
            $fiche->statut_id               = Statut::whereSlug('santeAppel')->first()->id;
            $fiche->groupepub_provenance_id = 1;
            $fiche->groupepub_societe_id    = 1;
            $fiche->active                  = 1;
            $fiche->date_insertion          = Carbon::now()->format('Y-m-d H:i:s');
            $fiche->date_situation          = $fiche->date_insertion;
            $fiche->date_effet              = $request->get('date_effet');
            $fiche->saregime_id             = $request->get('saregime_id');
            $fiche->ani                     = ($date_effet->diffInYears($date_naissance) >= 55 or $request->get('saregime_id') == 3 ) ? 0 : 1;
        
        if($fiche->save()){
            $srcPrd       = Produit::find($request->get('srcPrd'));
            $srcClass     = "App\Fiche".$srcPrd->slug;
            $srcFiche     = $srcClass::find($request->get('srcFiche'));
            $observation  = "<i class='material-icons'>".$srcPrd->icon."</i> ".$srcPrd->libelle."<br>source: <span class='uk-text-bold'>#".$srcFiche->num_fiche."</span>";
            $idAction     = Action::whereSlug('DF')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));
        }

        $cltPrd = ClientProduit::firstOrCreate(['client_id' => $client->id, 'produit_id' => $produit->id]);
        $cltPrd->increment('nombre');

        $fiche->num_fiche = $this->mask(2,$fiche->produit_id).$this->mask(7,$fiche->id);
        $fiche->save();

        $ficheId = $fiche->id;

        $info_fiche = [
                        'fiche_id' => $ficheId,
                        'prd_slug' => $produit->slug,
                    ];

        event(new EventCreateProcessesLead($info_fiche));

        if($request->has('has_conjoint')){

            $conjoint = new Conjoint;
                $conjoint->nom            = $request->get('conjoint_nom');
                $conjoint->prenom         = $request->get('conjoint_prenom');
                $conjoint->civilite       = $request->get('conjoint_civilite');
                $conjoint->sexe           = $request->get('conjoint_sexe');
                $conjoint->date_naissance = $request->get('conjoint_date_naissance');
                $conjoint->sit_familiale  = $request->get('conjoint_sit_familiale');
                $conjoint->fichesante_id  = $ficheId;
                $conjoint->saregime_id    = $request->get('conjoint_saregime_id');
            $conjoint->save();

            $conjointId = $conjoint->id;

         }

        if($request->has('enfant')){

            $enfants = $request->get('enfant');

            foreach ($enfants as $enfant) {

                $enfant_sexe          = $enfant['sexe'];
                $enfant_nom           =  $enfant['nom'];
                $enfant_prenom        = $enfant['prenom'];
                $enfant_dateNaissance = $enfant['date_naissance'];
                $enfant_ayantDroit    = $enfant['ayant_droit'];

                $enfant = new Enfant;
                    $enfant->sexe           = $enfant_sexe;
                    $enfant->nom            = $enfant_nom;
                    $enfant->prenom         = $enfant_prenom;
                    $enfant->date_naissance = Carbon::createFromFormat('d/m/Y', $enfant_dateNaissance)->format('Y-m-d');
                    $enfant->ayant_droit    = $enfant_ayantDroit;
                    $enfant->fichesante_id  = $ficheId;
                $enfant->save();

            }

        }

        $url = url('conseiller/leads/sante/'.$fiche->slug);

        return [
            'success' => true,
            'message' => 'La fiche a été dupliquée',
            'url'     => $url

        ];

    }


    /**
     * Créer une fiche santé
     */
    public function newGav(DuplicateLeadGavRequest $request){

        $userInfo = $this->userInfo();

        $user         = Auth::user();
        $equipeId     =  $user->userEquipe->first()->pivot->equipe_id;
        $equipeUserId =  $user->userEquipe->first()->pivot->id;
        
        $conjointId   = 0;
        
        $enfantIds    = [];
        
        $produit      = Produit::whereSlug($request->get('produitSlug'))->first();
        
        $clientId     = $request->get('clientId');
        
        $client = Client::find($clientId);
            $client->nom            = $request->get('nom');
            $client->prenom         = $request->get('prenom');
            $client->civilite       = $request->get('civilite');
            $client->sexe           = $request->get('sexe');
            $client->sit_familiale  = $request->get('sit_familiale');
            $client->date_naissance = $request->get('date_naissance');
            $client->email          = $request->get('email');
            $client->email_pro      = $request->get('email_pro');
            $client->profession_id     = $request->get('profession');
            $client->ville          = $request->get('ville');
            $client->adresse        = $request->get('adresse');
            $client->tel_mobile     = $request->get('tel_mobile');
            $client->code_postal    = $request->get('code_postal');
            $client->saregime_id    = $request->get('saregime_id');
        $client->save();

        $date_effet     = $this->dateCarbon($request->get('date_effet'));
        $date_naissance = $this->dateCarbon($client->date_naissance);

        $fiche = new Fichegav;
            $fiche->client_id               = $client->id;
            $fiche->slug                    = uniqid();
            $fiche->produit_id              = $produit->id;
            $fiche->equipe_user_id          = $equipeUserId;
            $fiche->dispatchable_id         = $equipeId;
            $fiche->dispatchable_type       = 'equipe';
            $fiche->statut_id               = Statut::whereSlug('gavAppel')->first()->id;
            $fiche->groupepub_provenance_id = 1;
            $fiche->groupepub_societe_id    = 1;
            $fiche->active                  = 1;
            $fiche->date_insertion          = Carbon::now()->format('Y-m-d H:i:s');
            $fiche->date_situation          = $fiche->date_insertion;
            $fiche->date_effet              = $request->get('date_effet');
            $fiche->regime_id               = $request->get('saregime_id');
            $fiche->ani                     = ($date_effet->diffInYears($date_naissance) >= 55 or $request->get('saregime_id') == 3 ) ? 0 : 1;
        
        if($fiche->save()){
            $srcPrd       = Produit::find($request->get('srcPrd'));
            $srcClass     = "App\Fiche".$srcPrd->slug;
            $srcFiche     = $srcClass::find($request->get('srcFiche'));
            $observation  = "<i class='material-icons'>".$srcPrd->icon."</i> ".$srcPrd->libelle."<br>source: <span class='uk-text-bold'>#".$srcFiche->num_fiche."</span>";
            $idAction     = Action::whereSlug('DF')->value('id');
            $tabInfoTrace = [
                                'idAction'       => $idAction, 
                                'idFiche'        => $fiche->id, 
                                'idStatut'       => $fiche->statut_id, 
                                'equipe_user_id' => $userInfo['equipe_user_id'], 
                                'tracable_id'    => $userInfo['tracable_id'], 
                                'tracable_type'  => $userInfo['tracable_type'], 
                                'observation'    => $observation, 
                                'motif'          => null
                            ];
            event(new EventTracesGav($tabInfoTrace));
        }

        $cltPrd = ClientProduit::firstOrCreate(['client_id' => $client->id, 'produit_id' => $produit->id]);
        $cltPrd->increment('nombre');

        $fiche->num_fiche = $this->mask(2,$fiche->produit_id).$this->mask(7,$fiche->id);
        $fiche->save();

        $ficheId = $fiche->id;

        $info_fiche = [
                        'fiche_id' => $ficheId,
                        'prd_slug' => $produit->slug,
                    ];

        event(new EventCreateProcessesLead($info_fiche));

        if($request->has('has_conjoint')){

            $conjoint = new GavConjoint;
                $conjoint->nom            = $request->get('conjoint_nom');
                $conjoint->prenom         = $request->get('conjoint_prenom');
                $conjoint->civilite       = $request->get('conjoint_civilite');
                $conjoint->sexe           = $request->get('conjoint_sexe');
                $conjoint->date_naissance = $request->get('conjoint_date_naissance');
                $conjoint->sit_familiale  = $request->get('conjoint_sit_familiale');
                $conjoint->fichegav_id    = $ficheId;
                $conjoint->regime_id      = $request->get('conjoint_saregime_id');
            $conjoint->save();

            $conjointId = $conjoint->id;

         }

        if($request->has('enfant')){

            $enfants = $request->get('enfant');

            foreach ($enfants as $enfant) {

                $enfant_sexe          = $enfant['sexe'];
                $enfant_nom           =  $enfant['nom'];
                $enfant_prenom        = $enfant['prenom'];
                $enfant_dateNaissance = $enfant['date_naissance'];
                $enfant_ayantDroit    = $enfant['ayant_droit'];

                $enfant = new GavEnfant;
                    $enfant->sexe           = $enfant_sexe;
                    $enfant->nom            = $enfant_nom;
                    $enfant->prenom         = $enfant_prenom;
                    $enfant->date_naissance = Carbon::createFromFormat('d/m/Y', $enfant_dateNaissance)->format('Y-m-d');;
                    $enfant->ayant_droit    = $enfant_ayantDroit;
                    $enfant->fichegav_id    = $ficheId;
                $enfant->save();

            }

        }

        $url = url('conseiller/leads/gav/'.$fiche->slug);

        return [
            'success' => true,
            'message' => 'La fiche a été dupliquée',
            'url'     => $url

        ];

    }

    /**
     * Créer une fiche obseque
     */
    public function newObseque(DuplicateLeadObsequeRequest $request){

        $userInfo = $this->userInfo();

        $user         = Auth::user();
        $equipeId     =  $user->userEquipe->first()->pivot->equipe_id;
        $equipeUserId =  $user->userEquipe->first()->pivot->id;
        
        $capital      = 0;
        
        $produit      = Produit::whereSlug($request->get('produitSlug'))->first();
        
        $clientId     = $request->get('clientId');
        
        $client = Client::find($clientId);
            $client->nom            = $request->get('nom');
            $client->prenom         = $request->get('prenom');
            $client->civilite       = $request->get('civilite');
            $client->sexe           = $request->get('sexe');
            $client->sit_familiale  = $request->get('sit_familiale');
            $client->date_naissance = $request->get('date_naissance');
            $client->email          = $request->get('email');
            $client->email_pro      = $request->get('email_pro');
            $client->profession_id     = $request->get('profession');
            $client->ville          = $request->get('ville');
            $client->adresse        = $request->get('adresse');
            $client->tel_mobile     = $request->get('tel_mobile');
            $client->code_postal    = $request->get('code_postal');
            $client->saregime_id    = $request->get('saregime_id');
        $client->save();

        $date_effet     = $this->dateCarbon($request->get('date_effet'));
        $date_naissance = $this->dateCarbon($client->date_naissance);

        $fiche = new Ficheobseque;
            $fiche->client_id               = $client->id;
            $fiche->slug                    = uniqid();
            $fiche->produit_id              = $produit->id;
            $fiche->equipe_user_id          = $equipeUserId;
            $fiche->dispatchable_id         = $equipeId;
            $fiche->dispatchable_type       = 'equipe';
            $fiche->statut_id               = Statut::whereSlug('obsequeAppel')->first()->id;
            $fiche->groupepub_provenance_id = 1;
            $fiche->groupepub_societe_id    = 1;
            $fiche->active                  = 1;
            $fiche->date_insertion          = Carbon::now()->format('Y-m-d H:i:s');
            $fiche->date_situation          = $fiche->date_insertion;
            $fiche->date_effet              = $request->get('date_effet');
            $fiche->capital                 = $request->get('capital');
            //$fiche->saregime_id             = $request->get('saregime_id');
            $fiche->ani                     = ($date_effet->diffInYears($date_naissance) >= 55 or $request->get('saregime_id') == 3 ) ? 0 : 1;
        
        if($fiche->save()){
            $srcPrd       = Produit::find($request->get('srcPrd'));
            $srcClass     = "App\Fiche".$srcPrd->slug;
            $srcFiche     = $srcClass::find($request->get('srcFiche'));
            $observation  = "<i class='material-icons'>".$srcPrd->icon."</i> ".$srcPrd->libelle."<br>source: <span class='uk-text-bold'>#".$srcFiche->num_fiche."</span>";
            $idAction     = Action::whereSlug('DF')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
            event(new EventTracesObseque($tabInfoTrace));
        }

        $cltPrd = ClientProduit::firstOrCreate(['client_id' => $client->id, 'produit_id' => $produit->id]);
        $cltPrd->increment('nombre');

        $fiche->num_fiche = $this->mask(2,$fiche->produit_id).$this->mask(7,$fiche->id);
        $fiche->save();

        $info_fiche = [
                'fiche_id' => $fiche->id,
                'prd_slug' => $produit->slug,
            ];

        event(new EventCreateProcessesLead($info_fiche));

        $ficheSlug = $fiche->slug;

        $url = url('conseiller/leads/obseque/'.$ficheSlug);

        return [
            'success' => true,
            'message' => 'La fiche a été dupliquée',
            'url'     => $url

        ];

    }

    /**
     * Ajouter un commentaire
     */
    public function addComment(AddCommentaireFicheRequest $request){

        $slug        = $request->get("slugPrd");
        $ficheId     = $request->get("ficheId");

        $className = "App\Fiche".$slug;

        $fiche = $className::find($ficheId);

        $commentaire = $request->get("commentaire");

        $commentable = "fiche".$slug."s";

        $user       = Auth::user();

        $comment = new Commentaire;
            $comment->commentable_id    = $ficheId;
            $comment->commentable_type  = $commentable;
            $comment->message           = $commentaire;
            $comment->user_id           = $user->id;
        
        if($comment->save()){

            $userInfo = $this->userInfo();
            $idAction     = Action::whereSlug('EC')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' =>  $commentaire, 'motif' => null];
            $event = 'App\Events\EventTraces'.ucfirst($slug);
            event(new $event($tabInfoTrace));
        }

        return [ 'success' => true, 'message' => 'Le commentaire a été ajouté.'];

    }


    /**
     * Recevoir les commentaires de la fiche 
     */
    public function getComments(GetCommentaireFicheRequest $request){
        
        $slug       = $request->get("slugPrd");
        $ficheId    = $request->get("ficheId");

        $className  = "App\Fiche".$slug;

        $fiche      = $className::find($ficheId);
        
        $comments   = $fiche->comments;

        return $comments;

    }


    /**
     * Recevoir l'historique de la fiche
     */
    public function getHistory(GetHistoryFicheRequest $request){
        
        $slug      = $request->get("slugPrd");
        $ficheId   = $request->get("ficheId");
        
        $className = "App\Fiche".$slug;
        
        $fiche     = $className::find($ficheId);

        return $fiche->getHistory();

    }


    /**
     * Recevoir les propoitions envoyées au client
     */
    public function getProposition(Request $request){

        $user = Auth::user();

        if($request->has('propositionId')){

            $propositionId = $request->get('propositionId');
            
            $proposition   = Proposition::find($propositionId);
            
            $propositionId = base64_encode($proposition->id);

            $ficheNum      = base64_encode($proposition->num_fiche);
            
            $fiche         = $proposition->getFiche();

            $client        = $proposition->client;

            $ficheCrypter  = rawurlencode(base64_encode($fiche->slug));
            
            return view('emails.read_proposition', [
                                                        'societe'    => $fiche->societe->societe, 
                                                        'client'        => $client, 
                                                        'produit'       => $fiche->produit->slug,
                                                        'user'          => $user, 
                                                        'ficheCrypter'  => $ficheCrypter, 
                                                        'client'        => $proposition->client, 
                                                        'proposition'   => $proposition, 
                                                        'propositionId' => $propositionId, 
                                                        'ficheNum'      => $ficheNum
                                                    ]
                        );

        }else{

            return "Pas de proposition";

        }

    }


    /**
     * Renvoyer les propoitions envoyées au client
     */
    public function resendProposition(Request $request){

        if($request->has('propositionId')){

            $user          = Auth::user();
            
            $proposition   = Proposition::find($request->get('propositionId'));
            
            $client        = $proposition->client;
            
            $fiche         = $proposition->getFiche();
            
            $propositionId = base64_encode($proposition->id);

            $ficheNum      = base64_encode($proposition->num_fiche);

            $ficheCrypter  = rawurlencode(base64_encode($fiche->slug));

            $formules = collect($proposition->formules);

            $garanties           = [];
            $garantiesCodes      = [];
            $tarifsGarantie      = [];

            foreach($formules as $index => $item){

                $formule = collect(json_decode($item))->first();
                
                array_push($garanties, $formule->id);
                array_push($garantiesCodes, $formule->code_garantie);
                array_push($tarifsGarantie, $formule->tarif);

            }

            $dataGarantie = [

                'garantie'          => $garanties,
                'codeGarantie'      => $garantiesCodes,
                'tarif'             => $tarifsGarantie,
                'objetProposition'  => $proposition->id,
                'Border'            => ''

            ];

            $data            = serialize($dataGarantie);
            $dataCrypter     = base64_encode($data);
            $tableauGarantie = url('propositionLien?q='.$dataCrypter);
            
            $urlshort = new SettingController();
            $key      = 'AIzaSyBHxOoC-ICQGKDUAHfzOqAZLeGF-HVyUWU';
            $shorURL  = $urlshort->shorten($tableauGarantie, $key, "https://www.googleapis.com/urlshortener/v1/url");
            // traitement tableau garantie fin              

            $propositionId  = base64_encode($proposition->id);
            $ficheNum       = base64_encode($proposition->num_fiche);
            $ficheCrypter   = rawurlencode(base64_encode($fiche->slug));

            try{

                $societe = $fiche->societe->societe;

                $tabEmailUser    = explode("@", $user->email);
                $debutEmailUser  = $tabEmailUser[0];

                $tabEmailProv    = explode("@", $societe->email);
                $debutEmailProv  = $tabEmailProv[1];    

                $emailUser       = $debutEmailUser.'@'.$debutEmailProv;                     

                Mail::send('emails.proposition_tarifs', [
                                                            'societe'       => $societe, 
                                                            'client'        => $client, 
                                                            'produit'       => $fiche->produit->slug, 
                                                            'user'          => $user, 
                                                            'ficheCrypter'  => $ficheCrypter, 
                                                            'proposition'   => $proposition, 
                                                            'propositionId' => $propositionId, 
                                                            'ficheNum'      => $ficheNum,
                                                            'shorURL'       => $shorURL
                                                        ], function ($m) use ($client, $user, $societe, $emailUser)  {
                                                        
                    $m->from($emailUser, $societe->nom);

                    $m->to($client->email, $client->nom)->subject('Votre proposition de tarif');

                });

                $userInfo = $this->userInfo();
                
                $idAction = Action::whereSlug('RP')->value('id');

                $tabInfoTrace = [
                                    'idAction'       => $idAction, 
                                    'idFiche'        => $fiche->id, 
                                    'idStatut'       => $fiche->statut_id, 
                                    'equipe_user_id' => $userInfo['equipe_user_id'], 
                                    'tracable_id'    => $userInfo['tracable_id'], 
                                    'tracable_type'  => $userInfo['tracable_type'], 
                                    'observation'    => "Source: ".$proposition->id, 
                                    'motif'          => null
                                ];

                $event = 'App\Events\EventTraces'.ucfirst($fiche->produit->slug);
                event(new $event($tabInfoTrace));

                return ['success' => true, 'message' => 'La proposition a été renvoyée.'];

            }catch(\Exception $e){

               return ['success' => false, 'message' => 'problème en renvoi de proposition.'];

            } 

        }else{

            return ['success' => false, 'message' => 'problème en renvoi de proposition.'];

        }

    }


    /**
     * Proposer une ou plusieurs formules à un prospect
     */
    public function proposeSanteFormules(Request $request){

        $user  = Auth::user();

        $ficheNum = $request->get('ficheNum');
        $fiche    = Fichesante::where('num_fiche', $ficheNum)->first();

        $clientId = $request->get('clientId');
        $client   = Client::find($clientId);

        $formules = $request->get('formules');

        $garanties           = [];
        $garantiesCodes      = [];
        $tarifsGarantie      = [];

        foreach($formules as $index => $formule){

            $produit            = $request->get('produit');
            $dossierCompagnie   = 'compagnie';
            $verifydirectory    = 'upload/proposition/BA/'.$produit;
            //$linkPdf            = Parametre::whereKey('dossier_pdf')->first()->value;
        
            if (!file_exists($verifydirectory)) 
            {
                $result = File::makeDirectory('upload/proposition/BA/'.$produit, 0777, true);
            }

            $dossierCompagnie   = str_replace(' ', '_', $dossierCompagnie);
            $verify             = 'upload/proposition/BA/'.$produit.'/'.$dossierCompagnie;
        
            if (!file_exists($verify)) 
            { 
                $result = File::makeDirectory('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie, 0777, true);
            }

            $fileName               = uniqid();
            $libelleGamme           = $formules[$index]['gamme'];
            $idGarantie             = $formules[$index]['id'];
            $codeGarantie           = $formules[$index]['code_garantie'];
            $tarifGarantie          = $formules[$index]['tarif'];
            array_push($garanties, $idGarantie);
            array_push($garantiesCodes, $codeGarantie);
            //array_push($tarifsGarantie, $tarifGarantie);
            $tarifsGarantie[$codeGarantie] = $tarifGarantie;

            $formules[$index]['options'] = collect($request->get('options'))->where('code', $codeGarantie)->all();
            $formule['options']          = collect($request->get('options'))->where('code', $codeGarantie)->all();

            $formules[$index]['prestations'] = $request->get('prestations');
            
            //$formules[$index]['tarif']   +=  collect($request->get('options'))->where('code', $codeGarantie)->first()->tarif;

            //$ba                     = Sagamme::where('libelle', $libelleGamme)->first()->code;
            $ba                     = Sagarantie::whereCode($codeGarantie)->first()->gamme->code;
            $ba                     = strtoupper(str_replace(' ', '', $ba));
            $tg                     = $ba;
            $souscription           = new SouscriptionController();            
            $verifierSouscription   = 0;
            $tableau                = $souscription->{$ba}($user, $client, $fiche->enfants, $fiche->conjoint, $fiche, $verifierSouscription, $formule);

            //return $tableau;
            
            //Importer le fichier BA depuis le tarificateur
            $resultatImport         = $souscription->ImportFichierBA($ba);
            // return $resultatImport;
            
            if($resultatImport ){

            $pdf                = new Pdf('upload/'.$ba.'.pdf');
                //$pdf              = new Pdf($directory . $fileName);
                //$pdf              = new Pdf($fileContents);
            $pdf->allow('Printing')
                ->fillForm($tableau)
                ->needAppearances()
                ->saveAs('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

                // $fiche           = Fichesante::where('num_fiche', $contratId)->first(); 
                // $fiche->lien_pdf = asset('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
                // $fiche->save();
                $lienPdf                     = asset('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
                $formules[$index]['lienPdf'] = $lienPdf;                               
            }

        //return $tarifsGarantie;

        $tarifLink = Parametre::whereKey('tarif_link')->first()->value;
        $tarifKey  = Parametre::whereKey('tarif_key')->first()->value;

        $dateEffet =  $request->get('dateEffet');

        $children  = $request->get('dateE');

        $data = [
                'codepostale'    => $request->get('codepostale'),
                'dateA'          => $request->get('dateA'),
                'regimeA'        => $request->get('regimeA'),
                'dateC'          => $request->has('dateC') ? $request->get('dateC') : '',
                'regimeC'        => $request->has('regimeC') ? $request->get('regimeC') : '',
                'dateE'          => $children,
                'exercice'       => Carbon::parse($dateEffet)->year,
                'key'            => $tarifKey,
                'prestation'     => $request->get('prestation'),
                'dateEffet'      => $dateEffet,
                'sansPrestation' => 1,
            ];

        $params = http_build_query($data);

        $tarif = file_get_contents($tarifLink.'dataTableauGaranties?'.$params);

        //return json_decode($tarif);

            $tableaugarantie        = $souscription->{'tg'.$ba}($tarifsGarantie, json_decode($tarif));
            //return $tableaugarantie;
            //Importer le fichier TG depuis le tarificateur
            $resultatImportTG         = $souscription->ImportFichierTG($tg);
            //return $resultatImport;
            
            if($resultatImportTG ){

            $pdf                = new Pdf('upload/TG_'.$tg.'.pdf');
            $pdf->allow('Printing')
                ->fillForm($tableaugarantie)
                ->needAppearances()
                ->saveAs('upload/proposition/TG/'.$tg.'_'.$ficheNum.'.pdf');

                $lienPdfTG                     = asset('upload/proposition/TG/'.$tg.'_'.$ficheNum.'.pdf');
                $formules[$index]['lienPdfTG'] = $lienPdfTG;                               
            }

        //return $tarifsGarantie;

        }

        $proposition            = new Proposition;
        $proposition->num_fiche = $ficheNum;
        $proposition->user_id   = $user->id;
        $proposition->client_id = $clientId;
        $proposition->formules  = json_encode($formules);
        $proposition->active    = 1;
        
        if($proposition->save()){

            $userInfo     = $this->userInfo();
            $idAction     = Action::whereSlug('EP')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => null, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));
            // traitement tableau garantie debut
            $dataGarantie = [

                'garantie'          => $garanties,
                'codeGarantie'      => $garantiesCodes,
                'tarif'             => $tarifsGarantie,
                'objetProposition'  => $proposition->id,
                'Border'            => ''

            ];

            $data            = serialize($dataGarantie);
            $dataCrypter     = base64_encode($data);
            $tableauGarantie = url('propositionLien?q='.$dataCrypter);
            

            $urlshort = new SettingController();
            $key      = 'AIzaSyBHxOoC-ICQGKDUAHfzOqAZLeGF-HVyUWU';
            $shorURL  = $urlshort->shorten($tableauGarantie, $key, "https://www.googleapis.com/urlshortener/v1/url");
            // traitement tableau garantie fin              

        }


        $propositionId  = base64_encode($proposition->id);
        $ficheNum       = base64_encode($proposition->num_fiche);
        $ficheCrypter   = rawurlencode(base64_encode($fiche->slug));

        try{

            $societe = $fiche->societe->societe;
            $tabEmailUser    = explode("@", $user->email);
            $debutEmailUser  = $tabEmailUser[0];

            $tabEmailProv    = explode("@", $societe->email);
            $debutEmailProv  = $tabEmailProv[1];    

            $emailUser       = $debutEmailUser.'@'.$debutEmailProv;

            Mail::send('emails.proposition_tarifs', [
                                                        'societe'       => $societe,
                                                        'client'        => $client, 
                                                        'produit'       => $fiche->produit->slug, 
                                                        'user'          => $user, 
                                                        'ficheCrypter'  => $ficheCrypter, 
                                                        'client'        => $client, 
                                                        'proposition'   => $proposition, 
                                                        'propositionId' => $propositionId, 
                                                        'ficheNum'      => $ficheNum, 
                                                        'shorURL'       => $shorURL
                                                    ]
                                                , function ($m) use ($client, $user, $societe, $emailUser)  {

                $m->from($emailUser, $societe->nom);

                $m->to($client->email, $client->nom)->subject('Votre proposition de tarif');

            });

            $info_fiche = [
                            'fiche_id'     => $fiche->id,
                            'prd_slug'     => $fiche->produit->slug,
                            'process_slug' => 'proposition',
                        ];
            event(new EventChangeStateProcessLead($info_fiche));

            return ['success' => true, 'message' => 'La proposition a été enregistrée.'];

        }catch(\Exception $e){

            dd($e);
            return ['success' => false, 'message' => 'problème en envoi de mail'];
        } 
     

    }

    /**
     * Proposer une ou plusieurs formules à un prospect
     */
    public function proposeObsequeFormules(Request $request){

        $user  = Auth::user();

        $ficheNum = $request->get('ficheNum');
        $fiche    = Ficheobseque::where('num_fiche', $ficheNum)->first();

        $clientId = $request->get('clientId');
        $client   = Client::find($clientId);

        $formules = $request->get('formules');

        $garanties      = [];
        $tarifsGarantie = [];

        foreach($formules as $index => $formule){

            $produit            = $request->get('produit');
            $dossierCompagnie   = 'compagnie';
            $verifydirectory    = 'upload/proposition/BA/'.$produit;
            //$linkPdf          = Parametre::whereKey('dossier_pdf')->first()->value;
        
            if (!file_exists($verifydirectory)){
                $result = File::makeDirectory('upload/proposition/BA/'.$produit, 0777, true);
            }

            $dossierCompagnie   = str_replace(' ', '_', $dossierCompagnie);
            $verify             = 'upload/proposition/BA/'.$produit.'/'.$dossierCompagnie;
        
            if (!file_exists($verify)){
                $result = File::makeDirectory('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie, 0777, true);
            }

            $fileName               = uniqid();
            $libelleGamme           = $formules[$index]['gamme'];
            $idGarantie             = $formules[$index]['id'];
            $codeGarantie           = $formules[$index]['code_garantie'];
            $tarifGarantie          = $formules[$index]['tarif'];
            array_push($garanties, $idGarantie);
            //array_push($tarifsGarantie, $tarifGarantie);
            $tarifsGarantie[$codeGarantie] = $tarifGarantie;

            $ba                     = Obgarantie::whereCode($codeGarantie)->first()->gamme->code;
            $ba                     = strtoupper(str_replace(' ', '', $ba));
            $souscription           = new SouscriptionObsequeController();            
            $verifierSouscription   = 0;
            //$tableau                = $souscription->{$ba}($user, $client, $fiche, $verifierSouscription, $formule);
            
            //Importer le fichier BA depuis le tarificateur
            //$resultatImport         = $souscription->ImportFichierBA($ba);
            
            // if($resultatImport ){

            //     $pdf = new Pdf('upload/'.$ba.'.pdf');
            //     $pdf->fillForm($tableau)
            //         ->needAppearances()
            //         ->saveAs('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

            //     $lienPdf                     = asset('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
            //     $formules[$index]['lienPdf'] = $lienPdf;

            // }

        }

        $proposition            = new Proposition;
        $proposition->num_fiche = $ficheNum;
        $proposition->user_id   = $user->id;
        $proposition->client_id = $clientId;
        $proposition->formules  = json_encode($formules);
        $proposition->active    = 1;
        
        if($proposition->save()){
            $userInfo     = $this->userInfo();
            $idAction     = Action::whereSlug('EP')->value('id');
            $tabInfoTrace = [
                                'idAction'       => $idAction, 
                                'idFiche'        => $fiche->id, 
                                'idStatut'       => $fiche->statut_id, 
                                'equipe_user_id' => $userInfo['equipe_user_id'], 
                                'tracable_id'    => $userInfo['tracable_id'], 
                                'tracable_type'  => $userInfo['tracable_type'], 
                                'observation'    => null, 
                                'motif'          => null
                            ];
            event(new EventTracesObseque($tabInfoTrace));

            // traitement tableau garantie debut
            $dataGarantie = [

                'garantie'          => $garanties,
                'tarif'             => $tarifsGarantie,
                'objetProposition'  => $proposition->id,
                'Border'            => ''

            ];

            $data            = serialize($dataGarantie);
            $dataCrypter     = base64_encode($data);
            $tableauGarantie = url('propositionLien'.$request->get('produit').'?q='.$dataCrypter);

            $urlshort = new SettingController();
            $key      = 'AIzaSyBHxOoC-ICQGKDUAHfzOqAZLeGF-HVyUWU';
            $shorURL  = $urlshort->shorten($tableauGarantie, $key, "https://www.googleapis.com/urlshortener/v1/url");
            // traitement tableau garantie fin  

        }

        $propositionId  = base64_encode($proposition->id);
        $ficheNum       = base64_encode($proposition->num_fiche);
        $ficheCrypter   = rawurlencode(base64_encode($fiche->slug));

        try{

            $societe = $fiche->societe->societe;

            $tabEmailUser    = explode("@", $user->email);
            $debutEmailUser  = $tabEmailUser[0];

            $tabEmailProv    = explode("@", $societe->email);
            $debutEmailProv  = $tabEmailProv[1];    

            $emailUser       = $debutEmailUser.'@'.$debutEmailProv; 

            Mail::send('emails.proposition_tarifs', [
                                                        'societe'       => $societe,
                                                        'client'        => $client, 
                                                        'produit'       => $fiche->produit->slug, 
                                                        'user'          => $user, 
                                                        'ficheCrypter'  => $ficheCrypter, 
                                                        'proposition'   => $proposition, 
                                                        'propositionId' => $propositionId, 
                                                        'ficheNum'      => $ficheNum,
                                                        'shorURL'       => $shorURL
                                                    ], function ($m) use ($client, $user, $societe, $emailUser)  {

                $m->from($emailUser, $societe->nom);

                $m->to($client->email, $client->nom)->subject('Votre proposition de tarif');

            });

            $info_fiche = [
                            'fiche_id'     => $fiche->id,
                            'prd_slug'     => $fiche->produit->slug,
                            'process_slug' => 'proposition',
                        ];
            event(new EventChangeStateProcessLead($info_fiche));

            return ['success' => true, 'message' => 'La proposition a été enregistrée.'];

        }catch(\Exception $e){

            return $e;

            return ['success' => false, 'message' => 'problème en envoi de mail'];
        }
     
    }


    /**
     * Proposer une ou plusieurs formules à un prospect
     */
    public function proposeAutoFormules(Request $request){

        $user  = Auth::user();

        $ficheNum = $request->get('ficheNum');
        $fiche    = Ficheauto::where('num_fiche', $ficheNum)->first();

        $clientId = $request->get('clientId');
        $client   = Client::find($clientId);

        $formules = $request->get('formules');

        $garanties      = [];
        $tarifsGarantie = [];

        foreach($formules as $index => $formule){

            $produit            = $request->get('produit');
            $dossierCompagnie   = 'compagnie';
            $verifydirectory    = 'upload/proposition/BA/'.$produit;
            //$linkPdf          = Parametre::whereKey('dossier_pdf')->first()->value;
        
            if (!file_exists($verifydirectory)){
                $result = File::makeDirectory('upload/proposition/BA/'.$produit, 0777, true);
            }

            $dossierCompagnie   = str_replace(' ', '_', $dossierCompagnie);
            $verify             = 'upload/proposition/BA/'.$produit.'/'.$dossierCompagnie;
        
            if (!file_exists($verify)){
                $result = File::makeDirectory('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie, 0777, true);
            }

            $fileName               = uniqid();
            $libelleGamme           = $formules[$index]['gamme'];
            $idGarantie             = $formules[$index]['id'];
            $codeGarantie           = $formules[$index]['code_garantie'];
            $tarifGarantie          = $formules[$index]['tarif'];
            array_push($garanties, $idGarantie);
            //array_push($tarifsGarantie, $tarifGarantie);
            $tarifsGarantie[$codeGarantie] = $tarifGarantie;

            //$ba                     = Obgarantie::whereCode($codeGarantie)->first()->gamme->code;
            //$ba                     = strtoupper(str_replace(' ', '', $ba));
            $souscription           = new SouscriptionAutoController();            
            $verifierSouscription   = 0;
            $tableau                = $souscription->devis($user, $client, $client, $client, $fiche, $verifierSouscription, $formule);
            
            //Importer le fichier BA depuis le tarificateur
            //$resultatImport         = $souscription->ImportFichierBA($ba);
            
            // if($resultatImport ){

            //     $pdf = new Pdf('upload/'.$ba.'.pdf');
            //     $pdf->fillForm($tableau)
            //         ->needAppearances()
            //         ->saveAs('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

            //     $lienPdf                     = asset('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
            //     $formules[$index]['lienPdf'] = $lienPdf;

            // }

        }

        $proposition            = new Proposition;
        $proposition->num_fiche = $ficheNum;
        $proposition->user_id   = $user->id;
        $proposition->client_id = $clientId;
        $proposition->formules  = json_encode($formules);
        $proposition->active    = 1;
        
        if($proposition->save()){
            $userInfo     = $this->userInfo();
            $idAction     = Action::whereSlug('EP')->value('id');
            $tabInfoTrace = [
                                'idAction'       => $idAction, 
                                'idFiche'        => $fiche->id, 
                                'idStatut'       => $fiche->statut_id, 
                                'equipe_user_id' => $userInfo['equipe_user_id'], 
                                'tracable_id'    => $userInfo['tracable_id'], 
                                'tracable_type'  => $userInfo['tracable_type'], 
                                'observation'    => null, 
                                'motif'          => null
                            ];
            //event(new EventTracesObseque($tabInfoTrace));

            // traitement tableau garantie debut
            $dataGarantie = [

                'garantie'          => $garanties,
                'tarif'             => $tarifsGarantie,
                'objetProposition'  => $proposition->id,
                'Border'            => ''

            ];

            $data            = serialize($dataGarantie);
            $dataCrypter     = base64_encode($data);
            $tableauGarantie = url('propositionLien'.$request->get('produit').'?q='.$dataCrypter);

            $urlshort = new SettingController();
            $key      = 'AIzaSyBHxOoC-ICQGKDUAHfzOqAZLeGF-HVyUWU';
            $shorURL  = $urlshort->shorten($tableauGarantie, $key, "https://www.googleapis.com/urlshortener/v1/url");
            // traitement tableau garantie fin  

        }

        $propositionId  = base64_encode($proposition->id);
        $ficheNum       = base64_encode($proposition->num_fiche);
        $ficheCrypter   = rawurlencode(base64_encode($fiche->slug));

        try{

            $societe = $fiche->societe->societe;

            $tabEmailUser    = explode("@", $user->email);
            $debutEmailUser  = $tabEmailUser[0];

            $tabEmailProv    = explode("@", $societe->email);
            $debutEmailProv  = $tabEmailProv[1];    

            $emailUser       = $debutEmailUser.'@'.$debutEmailProv; 

            Mail::send('emails.proposition_tarifs', [
                                                        'societe'       => $societe,
                                                        'client'        => $client, 
                                                        'produit'       => $fiche->produit->slug, 
                                                        'user'          => $user, 
                                                        'ficheCrypter'  => $ficheCrypter, 
                                                        'proposition'   => $proposition, 
                                                        'propositionId' => $propositionId, 
                                                        'ficheNum'      => $ficheNum,
                                                        'shorURL'       => $shorURL
                                                    ], function ($m) use ($client, $user, $societe, $emailUser)  {

                $m->from($emailUser, $societe->nom);

                $m->to($client->email, $client->nom)->subject('Votre proposition de tarif');

            });

            $info_fiche = [
                            'fiche_id'     => $fiche->id,
                            'prd_slug'     => $fiche->produit->slug,
                            'process_slug' => 'proposition',
                        ];
            event(new EventChangeStateProcessLead($info_fiche));

            return ['success' => true, 'message' => 'La proposition a été enregistrée.'];

        }catch(\Exception $e){

            return $e;

            return ['success' => false, 'message' => 'problème en envoi de mail'];
        }
     
    }

    
    // generation pdf proposition 

    public function generationPdfProposition(Request $request){
        //$fiche  = Fichesante::where('num_fiche', $request->get('ficheNum'))->first(); 
        $user  = Auth::user();

        $produit ='SANTE';
        $dossierCompagnie = 'compagnie';
        $verifydirectory    = 'upload/proposition/BA/'.$produit;
        //$linkPdf = Parametre::whereKey('dossier_pdf')->first()->value;
       
        if (!file_exists($verifydirectory)) 
                     {
            $result = File::makeDirectory('upload/proposition/BA/'.$produit, 0777, true);
                    }
                    $dossierCompagnie    = str_replace(' ', '_', $dossierCompagnie);

                    $verify    = 'upload/proposition/BA/'.$produit.'/'.$dossierCompagnie;
       
        if (!file_exists($verify)) 
                     {
            $result = File::makeDirectory('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie, 0777, true);
                    }

        $fileName = time();
        $pdf = new Pdf($linkPdf.'upload/form.pdf');
        $pdf->fillForm(array(
               'Nom'    => 'HAMOUDI',
               'Prénom' => 'AYOUB',
               'Email'  => 'hamoudi.ayoub@gmail.com',
               'Ville'  => 'RABAT',
               'Cotisation totale' => '12 500',
               'Sexe' => 'H',
               'Date deffet souhaitée' => '31/12/2016',
               'No de contrat actuel' => '12343213132',
               'Tél' => '07677889',
                'Date' => date('d/m/Y'), 
                'Sexe_2' => 'H',
                'Sexe_3' => 'F',
                'Sexe_4' => 'H',
                'Sexe_5' => 'F',
                'Nom de naissance' => 'AYOUB',
                'Conseiller' => $user->nom,
                'Née le_1' => '12/01/1986',
                'Née le_2' => '12/01/1986',
                'Née le_3' => '12/01/1986',
                'Née le_4' => '12/01/1986',
                'Née le_5' => '12/01/1986',
                'Organisme de tutelle' => 'compagnie',
                'Adresse_1' => '36 rue adrej hay amal secteur 4 karia',
                'Nom_2' => 'HDIDAN',
                'Nom_3' => 'HDIDAN 2',
                'Nom_3' => 'HDIDAN 3',
                'Nom_4' => 'HDIDAN 4',
                'Nom_5' => 'HDIDAN 5',
                'Intermdiaire' => 'EMMA CRM',
                'Cabinet' => 'Tihad souvyati',
                'RCS' => '123456',
                'No ORIAS' => '1234567878',
                

           ))
           ->needAppearances()
           ->saveAs('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
           // $fiche  = Fichesante::where('num_fiche', $contratId)->first(); 
           // $fiche->lien_pdf = asset('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
           // $fiche->save();
            $lienPdf = asset('upload/propostion/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
            return $lienPdf;

    }


    /**
     * Sauvegarder les info du clients (bancaire ...)
     */
    public function saveInfoClientSante(SaveInfoClientRequest $request){

        $userInfo      = $this->userInfo();

        $garantie_code = $request->get('garantie_code');

        $garantie  = Sagarantie::whereCode($garantie_code)->first();

        $clientId  = $request->get('info_num_client');
        $contratId = $request->get('info_num_contrat');

        $fiche    = Fichesante::where('num_fiche', $contratId)->first(); 
        $client   = $fiche->client;
        $enfants  = Enfant::where('fichesante_id', $fiche->id)->get();
        
        // $fiche->sagamme_id          = $request->get('gamme_id');
        // $fiche->sagarantie_id       = $request->get('garantie_id');
        $fiche->sagamme_id          = $garantie->gamme->id;
        $fiche->sagarantie_id       = $garantie->id;
        
        $fiche->soins_val           = $request->get('soins_val');
        $fiche->optique_val         = $request->get('optique_val');
        $fiche->dentaire_val        = $request->get('dentaire_val');
        $fiche->hospitalisation_val = $request->get('hospitalisation_val');
        
        $fiche->cotisation          = $request->get('info_montant');
        $fiche->num_formule         = $request->get('info_formule');
        //$fiche->num_compagnie     = $request->get('info');
        $fiche->num_affiliate       = $request->get('info_num_aff');
        $fiche->num_security_social = $request->get('info_num_ss');
        
        $fiche->modepaiement_id     = $request->get('mode_paiement');
        $fiche->typepaiement_id     = $request->get('type_paiement');
        $fiche->prelevement_id      = $request->get('prelevement');
        $fiche->nbr_mois_gratuit    = $request->get('nbr_mois_gratuit');
        $fiche->paiement_cb         = $request->get('paiement_cb');
        $fiche->remise              = $request->get('remise');
        //$fiche->frais_dossier_offert = $request->get('frais_dossier_offert');
        $fiche->frais_dossier       = $request->get('frais_dossier') ;


        $fiche->options             = $request->get('options');

        $fiche->date_situation      = Carbon::now();

        $fiche->save();


        $conjoint = $fiche->conjoint;

        if($conjoint){
            $conjoint->cotisation          = $request->get('info_montant');
            $conjoint->num_affiliate       = $request->get('info_num_aff_conj');
            $conjoint->num_security_social = $request->get('info_num_ss_conj');
            $conjoint->save();
        }

        $infoBanque = Informationbancaire::where('client_id', $clientId)->where('contrat_id', $contratId)->first();

        if(!$infoBanque){
            $infoBanque = new Informationbancaire;
        }

        $infoBanque->client_id                  = $clientId;
        $infoBanque->contrat_id                 = $contratId;
        $infoBanque->active                     = 1;
        
        if($request->has("iban_pre") and $request->get("iban_pre")){

            $iban_pre = str_replace('-', '', $request->get("iban_pre"));

            $infoBanque->nom_banque_pre         = $request->get('nom_banque_pre');
            $infoBanque->adresse_banque_pre     = $request->get('adresse_banque_pre');
            $infoBanque->ville_banque_pre       = $request->get('ville_banque_pre');
            $infoBanque->code_pays_pre          = substr($iban_pre, 0, 2);
            $infoBanque->cle_iban_pre           = substr($iban_pre, 2, 2);
            $infoBanque->code_etablissement_pre = substr($iban_pre, 4, 5);
            $infoBanque->code_guichet_pre       = substr($iban_pre, 9, 5);
            $infoBanque->num_compte_pre         = substr($iban_pre, 14, 11);
            $infoBanque->cle_rib_pre            = substr($iban_pre, 25, 2);
            $infoBanque->code_bic_pre           = Crypt::encrypt($request->get('code_bic_pre'));

            $infoBanque->iban_pre               = Crypt::encrypt($iban_pre);

            if($request->has("iban_rem") and $request->get("iban_rem")){

                $iban_rem = str_replace('-', '', $request->get("iban_rem"));
            
                $infoBanque->nom_banque_rem         = $request->get('nom_banque_rem');
                $infoBanque->adresse_banque_rem     = $request->get('adresse_banque_rem');
                $infoBanque->ville_banque_rem       = $request->get('ville_banque_rem');
                $infoBanque->code_pays_rem          = substr($iban_rem, 0, 2);
                $infoBanque->cle_iban_rem           = substr($iban_rem, 2, 2);
                $infoBanque->code_etablissement_rem = substr($iban_rem, 4, 5);
                $infoBanque->code_guichet_rem       = substr($iban_rem, 9, 5);
                $infoBanque->num_compte_rem         = substr($iban_rem, 14, 11);
                $infoBanque->cle_rib_rem            = substr($iban_rem, 25, 2);
                $infoBanque->code_bic_rem           = Crypt::encrypt($request->get('code_bic_rem'));

                $infoBanque->iban_rem               = Crypt::encrypt($iban_rem);

            }

        }


        if($request->has("iban_pre") and $request->get("iban_pre")){

            if($infoBanque->save()){

                $statut                = Statut::whereSlug('santeDevisNonSigne')->first();
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();
                $fiche->save();

                //changer le statut de la fiche => nnsigne
                $idAction              = Action::whereSlug('SCP')->value('id');
                $tabInfoTrace          = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => null, 'motif' => null];
                event(new EventTracesSante($tabInfoTrace));
            }

        }else if( $fiche->statut->groupeStatus->slug == "leads" ) {

            $statut                = Statut::whereSlug('santeDevisEnCours')->first();
            $fiche->statut_id      = $statut->id;
            $fiche->date_situation = Carbon::now();
            $fiche->save();

            $idAction              = Action::whereSlug('SCP')->value('id');
            $tabInfoTrace          = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => null, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));

        }

        $user = [];

        if(is_null($fiche->equipe_user_id)){
            $user = $fiche->dispatchable->responsable();
        }else{
            $user = $fiche->affectedUser($fiche->equipe_user_id);
        }
        
        $nomClient      = $fiche->client->nom;
        $prenomClient   = $fiche->client->prenom;
        $emailClient    = $fiche->client->email;
        $civiliteClient = $fiche->client->sexe;
        //$page = "documents.$formule->compagnie.$formule->gamme.BA" ;

        //return view($page, [ 'proposition' => $proposition, 'formule' => $formule, 'user' => $user, 'fiche' => $fiche ]);
        if($conjoint){

            $data = [ 
                'nomConseiller'               => $user->nom,
                'prenomConseiller'            => $user->prenom,
                'telConseiller'               => $user->tel,
                'emailConseiller'             => $user->email,
                'faxConseiller'               => $user->fax,
                'logo'                        => $request->get('logo'),
                'civiliteClient'              => $fiche->client->sexe,
                'nomClient'                   => $fiche->client->nom,
                'prenomClient'                => $fiche->client->prenom,
                'dateNaissanceClient'         => $fiche->client->date_naissance,
                'adresseClient'               => $fiche->client->adresse,
                'codePostalClient'            => $fiche->client->code_postal,
                'emailClient'                 => $fiche->client->email,
                'telDomicileClient'           => $fiche->client->tel_domicile,
                'telMobileClient'             => $fiche->client->tel_mobile,
                'telBureauClient'             => $fiche->client->tel_bureau,
                'villeClient'                 => $fiche->client->ville,
                'professionClient'            => $fiche->client->profession_id, 
                'sitFamilialeClient'          => $fiche->client->sit_familiale,
                'garantie'                    => $request->get('garantie'), 
                'nomConjoint'                 => $fiche->conjoint->nom,
                'prenomConjoint'              => $fiche->conjoint->prenom,
                'dateNaissanceConjoint'       => $fiche->conjoint->date_naissance,
                'nomCompagnie'                => $request->get('compagnie'),
                'lienCrm'                     => public_path().'/uploads/BA'
                 //'proposition' => json_decode([$proposition]), 
                // 'formule'     => json_decode([$formule]), 
                // 'user'        => json_decode([$user]), 
                // 'client'      => json_decode($fiche->client),
                // 'clientR'     => json_decode($fiche->client->regime),
                // 'fiche'       => json_decode($fiche),
                // 'conjoint'    => ($fiche->conjoint) ? json_decode($fiche->conjoint) : [],
                // 'conjointR'   => ($fiche->conjoint) ? $fiche->conjoint->regime : [],
                // 'enfants'     => json_decode(($fiche->enfants) ? $fiche->enfants : [])
            ];
        }else{
            $data = [ 
                'nomConseiller'               => $user->nom,
                'prenomConseiller'            => $user->prenom,
                'telConseiller'               => $user->tel,
                'emailConseiller'             => $user->email,
                'faxConseiller'               => $user->fax,
                'logo'                        => $request->get('logo'),
                'civiliteClient'              => $fiche->client->sexe,
                'nomClient'                   => $fiche->client->nom,
                'prenomClient'                => $fiche->client->prenom,
                'dateNaissanceClient'         => $fiche->client->date_naissance,
                'adresseClient'               => $fiche->client->adresse,
                'codePostalClient'            => $fiche->client->code_postal,
                'emailClient'                 => $fiche->client->email,
                'telDomicileClient'           => $fiche->client->tel_domicile,
                'telMobileClient'             => $fiche->client->tel_mobile,
                'telBureauClient'             => $fiche->client->tel_bureau,
                'villeClient'                 => $fiche->client->ville,
                'professionClient'            => $fiche->client->profession_id, 
                'sitFamilialeClient'          => $fiche->client->sit_familiale,
                'garantie'                    => $request->get('garantie'), 
                'nomConjoint'                 => '',
                'prenomConjoint'              => '',
                'dateNaissanceConjoint'       => '',
                'nomCompagnie'                => $request->get('compagnie'),
                'lienCrm'                     => public_path().'/uploads/BA'
                 //'proposition' => json_decode([$proposition]), 
                // 'formule'     => json_decode([$formule]), 
                // 'user'        => json_decode([$user]), 
                // 'client'      => json_decode($fiche->client),
                // 'clientR'     => json_decode($fiche->client->regime),
                // 'fiche'       => json_decode($fiche),
                // 'conjoint'    => ($fiche->conjoint) ? json_decode($fiche->conjoint) : [],
                // 'conjointR'   => ($fiche->conjoint) ? $fiche->conjoint->regime : [],
                // 'enfants'     => json_decode(($fiche->enfants) ? $fiche->enfants : [])
            ];
        }
        // lien serveur
        $produit ='SANTE';
        $dossierCompagnie = $request->get('compagnie');
        $verifydirectory    = 'upload/souscription/BA/'.$produit;
        //$linkPdf = Parametre::whereKey('dossier_pdf')->first()->value;

       
        if (!file_exists($verifydirectory)) 
                     {
            $result = File::makeDirectory('upload/souscription/BA/'.$produit, 0777, true);
                    }
                    $dossierCompagnie    = str_replace(' ', '_', $dossierCompagnie);

                    $verify    = 'upload/souscription/BA/'.$produit.'/'.$dossierCompagnie;
       
        if (!file_exists($verify)) 
                     {
            $result = File::makeDirectory('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie, 0777, true);
                    }
       // $fiche  = Fichesante::where('num_fiche', $contratId)->first();           
        $fileName   = uniqid();
        $gamme      = $garantie->gamme;
        $ba         = $gamme->code;
        $ba         = strtoupper(str_replace(' ', '', $ba));
        // $tableau = $this->{$ba}($user, $client, $enfants, $conjoint, $fiche);

        $souscription = new SouscriptionController();

        $verifierSouscription = 1;
        $options=collect(json_decode($request->get('options')));
        $formule = '';
        $formule['options'] = [];
        foreach($options as $option){
            array_push($formule['options'], json_decode(json_encode($option), true));
        }
        //dd($formule);

        $tableau = $souscription->{$ba}($user, $client, $fiche->enfants, $conjoint, $fiche, $verifierSouscription, $formule);

        //Importer le fichier BA depuis le tarificateur
        $resultatImport         = $souscription->ImportFichierBA($ba);
        
        $pdf = new Pdf('upload/'.$ba.'.pdf');
        $pdf->allow('Printing')
            ->fillForm($tableau)
                ->needAppearances()
           ->saveAs('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

        $fiche->lien_pdf = asset('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
        $fiche->save();
        $lienPdf = asset('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

        $info_fiche = [
                        'fiche_id'     => $fiche->id,
                        'prd_slug'     => $fiche->produit->slug
                    ];
                    
        $collection = collect(event(new EventCreateProcessesLead($info_fiche)));
        $processes  = $collection->flatten(1);
        $processes->values()->all();

        $proposition            = new Proposition;
        $proposition->num_fiche = $fiche->num_fiche;
        $proposition->user_id   = $user->id;
        $proposition->client_id = $client->id;
        //$proposition->formules  = json_encode($formules);
        $proposition->active    = 1;
        $proposition->save();
        
        return [
                'garantie'         => $garantie->libelle,
                'lienPdf'          => $lienPdf, 
                'dossierCompagnie' => $dossierCompagnie, 
                'fileName'         => $fileName, 
                'success'          => true, 
                'message'          => 'les informations sont enregistrées.', 
                'logo'             => $request->get('logo'), 
                'nomClient'        => $nomClient, 
                'prenomClient'     => $prenomClient, 
                'emailClient'      => $emailClient, 
                'civiliteClient'   => $civiliteClient, 
                'tarif'            => $request->get('info_montant'), 
                'processes'        => $processes,
                'PropositionId'    => $proposition->id
            ];
    }

    /**
     * Sauvegarder les info du clients (bancaire ...)
     */
    public function saveInfoClientGav(SaveInfoClientRequest $request){

        $userInfo = $this->userInfo();

        $garantie_code = $request->get('garantie_code');

        $garantie  = Gavgarantie::whereCode($garantie_code)->first();
        
        $clientId  = $request->get('info_num_client');
        $contratId = $request->get('info_num_contrat');
        
        $fiche     = Fichegav::where('num_fiche', $contratId)->first(); 
        $client    = $fiche->client;
        $enfants   = GavEnfant::where('fichegav_id', $fiche->id)->get();
        
        // $fiche->sagamme_id          = $request->get('gamme_id');
        // $fiche->sagarantie_id       = $request->get('garantie_id');
        $fiche->gavgamme_id          = $garantie->gamme->id;
        $fiche->gavgarantie_id       = $garantie->id;
        
        $fiche->cotisation          = $request->get('info_montant');
        $fiche->num_formule         = $request->get('info_formule');
        //$fiche->num_compagnie     = $request->get('info');
        $fiche->num_affiliate       = $request->get('info_num_aff');
        $fiche->num_security_social = $request->get('info_num_ss');
        
        $fiche->modepaiement_id     = $request->get('mode_paiement');
        $fiche->typepaiement_id     = $request->get('type_paiement');
        $fiche->prelevement_id      = $request->get('prelevement');
        $fiche->nbr_mois_gratuit    = $request->get('nbr_mois_gratuit');
        $fiche->paiement_cb         = $request->get('paiement_cb');
        $fiche->remise              = $request->get('remise');
        //$fiche->frais_dossier_offert = $request->get('frais_dossier_offert');
        $fiche->frais_dossier       = $request->get('frais_dossier') ;

        $fiche->date_situation      = Carbon::now();

        $fiche->save();


        $conjoint = $fiche->conjoint;

        if($conjoint){
            $conjoint->cotisation          = $request->get('info_montant');
            $conjoint->num_affiliate       = $request->get('info_num_aff_conj');
            $conjoint->num_security_social = $request->get('info_num_ss_conj');
            $conjoint->save();
        }

        $infoBanque = Informationbancaire::where('client_id', $clientId)->where('contrat_id', $contratId)->first();

        if(!$infoBanque){
            $infoBanque = new Informationbancaire;
        }

        $infoBanque->client_id                  = $clientId;
        $infoBanque->contrat_id                 = $contratId;
        $infoBanque->active                     = 1;
        
        if($request->has("iban_pre") and $request->get("iban_pre")){

            $iban_pre = str_replace('-', '', $request->get("iban_pre"));

            $infoBanque->nom_banque_pre         = $request->get('nom_banque_pre');
            $infoBanque->adresse_banque_pre     = $request->get('adresse_banque_pre');
            $infoBanque->ville_banque_pre       = $request->get('ville_banque_pre');
            $infoBanque->code_pays_pre          = Crypt::encrypt(substr($iban_pre, 0, 2));
            $infoBanque->cle_iban_pre           = Crypt::encrypt(substr($iban_pre, 2, 2));
            $infoBanque->code_etablissement_pre = Crypt::encrypt(substr($iban_pre, 4, 5));
            $infoBanque->code_guichet_pre       = Crypt::encrypt(substr($iban_pre, 9, 5));
            $infoBanque->num_compte_pre         = Crypt::encrypt(substr($iban_pre, 14, 11));
            $infoBanque->cle_rib_pre            = Crypt::encrypt(substr($iban_pre, 25, 2));
            $infoBanque->code_bic_pre           = Crypt::encrypt($request->get('code_bic_pre'));

            $infoBanque->iban_pre               = Crypt::encrypt($iban_pre);

            if($request->has("iban_rem") and $request->get("iban_rem")){

                $iban_rem = str_replace('-', '', $request->get("iban_rem"));
            
                $infoBanque->nom_banque_rem         = $request->get('nom_banque_rem');
                $infoBanque->adresse_banque_rem     = $request->get('adresse_banque_rem');
                $infoBanque->ville_banque_rem       = $request->get('ville_banque_rem');
                $infoBanque->code_pays_rem          = Crypt::encrypt(substr($iban_rem, 0, 2));
                $infoBanque->cle_iban_rem           = Crypt::encrypt(substr($iban_rem, 2, 2));
                $infoBanque->code_etablissement_rem = Crypt::encrypt(substr($iban_rem, 4, 5));
                $infoBanque->code_guichet_rem       = Crypt::encrypt(substr($iban_rem, 9, 5));
                $infoBanque->num_compte_rem         = Crypt::encrypt(substr($iban_rem, 14, 11));
                $infoBanque->cle_rib_rem            = Crypt::encrypt(substr($iban_rem, 25, 2));
                $infoBanque->code_bic_rem           = Crypt::encrypt($request->get('code_bic_rem'));

                $infoBanque->iban_rem               = Crypt::encrypt($iban_rem);

            }

        }


        if($request->has("iban_pre") and $request->get("iban_pre")){

            if($infoBanque->save()){

                $statut                = Statut::whereSlug('gavDevisNonSigne')->first();
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();
                $fiche->save();

                //changer le statut de la fiche => nnsigne
                $idAction              = Action::whereSlug('SCP')->value('id');
                $tabInfoTrace          = [
                                            'idAction'       => $idAction, 
                                            'idFiche'        => $fiche->id, 
                                            'idStatut'       => $fiche->statut_id, 
                                            'equipe_user_id' => $userInfo['equipe_user_id'], 
                                            'tracable_id'    => $userInfo['tracable_id'], 
                                            'tracable_type'  => $userInfo['tracable_type'], 
                                            'observation'    => null, 
                                            'motif'          => null
                                        ];
                event(new EventTracesGav($tabInfoTrace));
            }

        }else if( $fiche->statut->groupeStatus->slug == "leads" ) {

            $statut                = Statut::whereSlug('gavDevisEnCours')->first();
            $fiche->statut_id      = $statut->id;
            $fiche->date_situation = Carbon::now();
            $fiche->save();

            $idAction              = Action::whereSlug('SCP')->value('id');
            $tabInfoTrace          = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $fiche->id, 
                                        'idStatut'       => $fiche->statut_id, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => null, 
                                        'motif'          => null
                                    ];
            event(new EventTracesGav($tabInfoTrace));

        }

        $user = [];

        if(is_null($fiche->equipe_user_id)){
            $user = $fiche->dispatchable->responsable();
        }else{
            $user = $fiche->affectedUser($fiche->equipe_user_id);
        }
        
        $nomClient      = $fiche->client->nom;
        $prenomClient   = $fiche->client->prenom;
        $emailClient    = $fiche->client->email;
        $civiliteClient = $fiche->client->sexe;
        //$page = "documents.$formule->compagnie.$formule->gamme.BA" ;

        //return view($page, [ 'proposition' => $proposition, 'formule' => $formule, 'user' => $user, 'fiche' => $fiche ]);
        if($conjoint){

            $data = [ 
                'nomConseiller'               => $user->nom,
                'prenomConseiller'            => $user->prenom,
                'telConseiller'               => $user->tel,
                'emailConseiller'             => $user->email,
                'faxConseiller'               => $user->fax,
                'logo'                        => $request->get('logo'),
                'civiliteClient'              => $fiche->client->sexe,
                'nomClient'                   => $fiche->client->nom,
                'prenomClient'                => $fiche->client->prenom,
                'dateNaissanceClient'         => $fiche->client->date_naissance,
                'adresseClient'               => $fiche->client->adresse,
                'codePostalClient'            => $fiche->client->code_postal,
                'emailClient'                 => $fiche->client->email,
                'telDomicileClient'           => $fiche->client->tel_domicile,
                'telMobileClient'             => $fiche->client->tel_mobile,
                'telBureauClient'             => $fiche->client->tel_bureau,
                'villeClient'                 => $fiche->client->ville,
                'professionClient'            => $fiche->client->profession_id, 
                'sitFamilialeClient'          => $fiche->client->sit_familiale,
                'garantie'                    => $request->get('garantie'), 
                'nomConjoint'                 => $fiche->conjoint->nom,
                'prenomConjoint'              => $fiche->conjoint->prenom,
                'dateNaissanceConjoint'       => $fiche->conjoint->date_naissance,
                'nomCompagnie'                => $request->get('compagnie'),
                'lienCrm'                     => public_path().'/uploads/BA'
                 //'proposition' => json_decode([$proposition]), 
                // 'formule'     => json_decode([$formule]), 
                // 'user'        => json_decode([$user]), 
                // 'client'      => json_decode($fiche->client),
                // 'clientR'     => json_decode($fiche->client->regime),
                // 'fiche'       => json_decode($fiche),
                // 'conjoint'    => ($fiche->conjoint) ? json_decode($fiche->conjoint) : [],
                // 'conjointR'   => ($fiche->conjoint) ? $fiche->conjoint->regime : [],
                // 'enfants'     => json_decode(($fiche->enfants) ? $fiche->enfants : [])
            ];
        }else{
            $data = [ 
                'nomConseiller'               => $user->nom,
                'prenomConseiller'            => $user->prenom,
                'telConseiller'               => $user->tel,
                'emailConseiller'             => $user->email,
                'faxConseiller'               => $user->fax,
                'logo'                        => $request->get('logo'),
                'civiliteClient'              => $fiche->client->sexe,
                'nomClient'                   => $fiche->client->nom,
                'prenomClient'                => $fiche->client->prenom,
                'dateNaissanceClient'         => $fiche->client->date_naissance,
                'adresseClient'               => $fiche->client->adresse,
                'codePostalClient'            => $fiche->client->code_postal,
                'emailClient'                 => $fiche->client->email,
                'telDomicileClient'           => $fiche->client->tel_domicile,
                'telMobileClient'             => $fiche->client->tel_mobile,
                'telBureauClient'             => $fiche->client->tel_bureau,
                'villeClient'                 => $fiche->client->ville,
                'professionClient'            => $fiche->client->profession_id, 
                'sitFamilialeClient'          => $fiche->client->sit_familiale,
                'garantie'                    => $request->get('garantie'), 
                'nomConjoint'                 => '',
                'prenomConjoint'              => '',
                'dateNaissanceConjoint'       => '',
                'nomCompagnie'                => $request->get('compagnie'),
                'lienCrm'                     => public_path().'/uploads/BA'
                 //'proposition' => json_decode([$proposition]), 
                // 'formule'     => json_decode([$formule]), 
                // 'user'        => json_decode([$user]), 
                // 'client'      => json_decode($fiche->client),
                // 'clientR'     => json_decode($fiche->client->regime),
                // 'fiche'       => json_decode($fiche),
                // 'conjoint'    => ($fiche->conjoint) ? json_decode($fiche->conjoint) : [],
                // 'conjointR'   => ($fiche->conjoint) ? $fiche->conjoint->regime : [],
                // 'enfants'     => json_decode(($fiche->enfants) ? $fiche->enfants : [])
            ];
        }
        // lien serveur
        $produit ='GAV';
        $dossierCompagnie = $request->get('compagnie');
        $verifydirectory    = 'upload/souscription/BA/'.$produit;
        //$linkPdf = Parametre::whereKey('dossier_pdf')->first()->value;
       
        if (!file_exists($verifydirectory)) 
                     {
            $result = File::makeDirectory('upload/souscription/BA/'.$produit, 0777, true);
                    }
                    $dossierCompagnie    = str_replace(' ', '_', $dossierCompagnie);

                    $verify    = 'upload/souscription/BA/'.$produit.'/'.$dossierCompagnie;
       
        if (!file_exists($verify)) 
                     {
            $result = File::makeDirectory('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie, 0777, true);
                    }
       // $fiche  = Fichesante::where('num_fiche', $contratId)->first();           
        $fileName   = uniqid();
        $gamme      = $garantie->gamme;
        $ba         = $gamme->code;
        $ba         = strtoupper(str_replace(' ', '', $ba));
        // $tableau = $this->{$ba}($user, $client, $enfants, $conjoint, $fiche);

        $souscription = new SouscriptionGavController();

        $verifierSouscription = 1;
        $formule=''; 
        $tableau = $souscription->{$ba}($user, $client, $fiche->enfants, $conjoint, $fiche, $verifierSouscription, $formule);

        //Importer le fichier BA depuis le tarificateur
        $resultatImport         = $souscription->ImportFichierBA($ba);
        
        $pdf = new Pdf('upload/'.$ba.'.pdf');
        $pdf->allow('Printing')
            ->fillForm($tableau)
                ->needAppearances()
           ->saveAs('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

        $fiche->lien_pdf = asset('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
        $fiche->save();
        $lienPdf = asset('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

        $info_fiche = [
                        'fiche_id'     => $fiche->id,
                        'prd_slug'     => $fiche->produit->slug
                    ];
                    
        $collection = collect(event(new EventCreateProcessesLead($info_fiche)));
        $processes  = $collection->flatten(1);
        $processes->values()->all();

        return [
            'garantie'         => $garantie->libelle,
            'lienPdf'          => $lienPdf, 
            'dossierCompagnie' => $dossierCompagnie, 
            'fileName'         => $fileName, 
            'success'          => true, 
            'message'          => 'les informations sont enregistrées.', 
            'logo'             => $request->get('logo'), 
            'nomClient'        => $nomClient, 
            'prenomClient'     => $prenomClient, 
            'emailClient'      => $emailClient, 
            'civiliteClient'   => $civiliteClient, 
            'tarif'            => $request->get('info_montant'), 
            'processes'        => $processes
        ];

    }

    // recuperation data apres signature 

    public function responseSignature(Request $request){

        
        $ficheSante = ficheSante::find(1);
        $ficheSante->transaction_id = $request->get('transaction_id');
        $ficheSante->signature_time = $request->get('signature_time');
        $ficheSante->url_fichier    = $request->get('url_fichier');
        $ficheSante->save();


    }

    /**
     * Afficher de la fiche
     */
    public function showLead($slug, $id) {

        $userInfo = $this->userInfo();

        $ficheStatus        = [];

        $produit            = Produit::whereSlug($slug)->first();
        
        $produit            = Produit::find($produit->id);
        
        $groupePrd          = $produit->groupeProduit;
        
        $regimes            = Saregime::whereActive(1)->get();

        $regimePardefaut    = Saregime::where('code', 'SES')->first();
        
        $groupeProduitsList = Groupeproduit::whereActive(1)->with('produits')->get();
        
        $documents          = Documentfiche::where('produit_id', $produit->id)->get();

        $className = "App\Fiche".$produit->slug;

        $fiche = $className::whereSlug($id)->first();

        if(!$fiche){

            return abort(404);

        }
        
        $fiche->increment('nbr_vu');
        
        $groupeProduits = $this->groupeProduitsClient($fiche->client_id);
                                    
        $contrats       = $className::getContrats($fiche->client_id, $groupePrd->id);
                                    
        $ficheStatus    = Statutaction::where('actionable_id', $id)
                                    ->where('actionable_type', 'fiche'.$produit->slug.'s')
                                    ->orderBy('created_at', 'desc')
                                    ->get();
                                    
        $modePaiements  = Modepaiement::whereActive(1)->get();
        $typePaiements  = Typepaiement::whereActive(1)->get();
        $prelevements   = Prelevement::whereActive(1)->get();
                                    
        $infoBanque     = Informationbancaire::whereActive(1)->where('contrat_id', $fiche->num_fiche)->where('client_id', $fiche->client_id)->first();

        $user           = Auth::user();
        $equipeUserId   =  $user->userEquipe->first()->pivot->id;

        $access         = 0;

        if($fiche->equipe_user_id == $equipeUserId){
            $access = 1;
            if(!$fiche->lu){
                $fiche->lu = 1;
                if($fiche->save()){

                    $idAction     = Action::whereSlug('FL')->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => Carbon::now()->format('d/m/Y H:i:s'), 'motif' => null];
                    $event        = 'App\Events\EventTraces'.ucfirst($produit->slug);
                    event(new $event($tabInfoTrace));
        
                    
                    $notif        = Notification::whereSlug('LEADOPEN')->first();

                    $responsable  = $fiche->dispatchable->responsable();
                   
                    $notification = [
                        'user_id'         => $responsable->id,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => url($responsable->profile->slug.'/leads/'.$produit->slug.'/'.$fiche->slug),
                        'type'            => 'lead',
                        'description'     => "Par: ".$user->nom." ".$user->prenom
                    ];
                   
                    event(new EventNotifications($notification));
                }
            }
        }

        
        $tarifLink   = Parametre::whereKey('tarif_link')->first()->value;
        $tarifKey    = Parametre::whereKey('tarif_key')->first()->value;
        
        $ibanApiKey  = Parametre::whereKey('iban_api_key')->first()->value;
        $ibanApiLink = Parametre::whereKey('iban_api_link')->first()->value;

        $modelesMailing = Modelemail::where('active',1)
                                    ->where('produit_id',$produit->id)
                                    ->select('id','libelle','produit_id')
                                    ->get();
        
        $compagnies  = [];
        $obgammes    = [];
        $obgaranties = [];

        if($produit->slug == 'obseque'){
            $compagnies  = Sacompagnie::whereActive(1)->get();
            $obgammes    = Obgamme::whereActive(1)->get();
            $obgaranties = Obgarantie::whereActive(1)->get();
        }

        $callHistory = $this->getCallHistory($fiche->produit->id);

        $professions = Profession::whereActive(1)->orderBy('libelle', 'asc')->get();
         
                
        $processes   = [];

        $traitement = collect(json_decode($fiche->traitements))->where('statut', $fiche->statut->slug)->first();
        //dd($traitement);

        if($traitement && $traitement->processes){
            $processes = $traitement->processes ;
        }

        //Gestion des questionnaires

        $groupeQsts = Groupequestionnaire::where('active',1)
                                        ->where('produit_id',$produit->id)
                                        ->get();

        //return $fiche->ficheQuestionnaires()->get();
        //return $fiche->ficheGroupeQuestionnaire()->first()->valeur;
        //return $fiche->ficheQuestionnaire(2)->reponsequestionnaire_id;
        //return $fiche->questionnaireExist(1);
          //return $fiche->ficheGroupeQuestionnaireExist();

        //Retourner les réponses du questionnaire s'ils existent

        // $ficheQsts = Fichequestionnaire::where('active',1)
        //                                 ->where('ficheable_id',$fiche->id)
        //                                 ->where('ficheable_type',$produit->table_produit)
        //                                 ->where('produit_id',$produit->id)
        //                                 ->get();

        //Retourner le choix de la réponse 'oui/non'

        // $ficheGroupeQst = Fichegroupequestionnaire::where('active',1)
        //                                         ->where('ficheable_id',$fiche->id)
        //                                         ->where('ficheable_type',$produit->table_produit)

        //return json_encode($processes);

        return view("conseillers.".$produit->slug, [

                                    'groupeProduits'     => $groupeProduits,
                                    'fiche'              => $fiche,
                                    'regimes'            => $regimes,
                                    'regimePardefaut'    => $regimePardefaut,
                                    'contrats'           => $contrats,
                                    'ficheStatus'        => $ficheStatus,
                                    'groupeProduitsList' => $groupeProduitsList,
                                    'documents'          => $documents,
                                    'modePaiements'      => $modePaiements,
                                    'typePaiements'      => $typePaiements,
                                    'prelevements'       => $prelevements,
                                    'infoBanque'         => $infoBanque,
                                    'access'             => $access,
                                    'tarifLink'          => $tarifLink,
                                    'tarifKey'           => $tarifKey,
                                    'modelesMailing'     => $modelesMailing,
                                    'compagnies'         => $compagnies,
                                    'obgammes'           => $obgammes,
                                    'obgaranties'        => $obgaranties,
                                    'callHistory'        => $callHistory,
                                    'professions'        => $professions,
                                    'ibanApiKey'         => $ibanApiKey,
                                    'ibanApiLink'        => $ibanApiLink,
                                    'processes'          => json_encode($processes),
                                    'groupeQsts'         => $groupeQsts,
                                    // 'ficheQsts'          => $ficheQsts,
                                ]
            );

    }


    /**
     * Recevoir les groupes de produits
     */
    public function groupeProduitsClient($client_id){

        $client = Client::find($client_id);
        //$client->getGroupesProduit();

        $produitIds     = ClientProduit::where('client_id',$client_id)
                                        ->groupBy('produit_id')
                                        ->lists('produit_id');
                
        $gpIds          = Produit::whereIn('id',$produitIds)
                                    ->groupBy('groupeproduit_id')
                                    ->lists('groupeproduit_id');
                
        return $groupeProduits = Groupeproduit::whereIn('id',$gpIds)->get();

    }


    /**
     * Afficher les fiches selon le statut
     */
    public function leads(Request $request, $status=null) {
        
        $user         = Auth::user();

        $equipeUserId = $user->userEquipe->first()->pivot->id;
        
        // display active products
        $produits     = $user->produits;
        //$produits     = Produit::whereActive(1)->get();

        if(!Session::has('produit_id')){
            $prdSession = Produit::whereSlug('sante')->first();
            Session::put('produit_id', $prdSession->id);
        }

        $id        = Session::get('produit_id');
        $produit   = Produit::find($id);

        $slugPrd   = $produit->slug;

        $statut = collect($produit->status)->where('id', (int)$status)->first();

        if(count($statut)==0){ 
            $statut = Statut::whereSlug($slugPrd."Appel")->first();
            return redirect('conseiller/leads/'.$statut->id);
        }

        $groupeStatus = $statut->groupeStatus; 

        if($produit->slug) {

            $className  = "App\Fiche".$produit->slug;

            $query = " 1 = 1 ";

            if(Input::has('dd') and Input::has('df')){
                $dd = Input::get('dd');
                $df = Input::get('df');
                $query = " (created_at between '".$dd." 00:00:00' and '".$df." 23:59:59') ";
            }elseif(Input::has('dd') and !Input::has('df')){
                $dd = Input::get('dd');
                $query = " (created_at >= '".$dd." 00:00:00') ";
            }elseif(!Input::has('dd') and Input::has('df')){
                $df = Input::get('df');
                $query = " (created_at <= '".$df." 23:59:59') ";
            }

            $queryOrder = 'lu';
            $ordre = 'asc';

            if($groupeStatus->slug=='leads' and $statut->slug!=$slugPrd."Appel"){
                $queryOrder = 'created_at';
                $ordre = 'desc';
            }elseif($groupeStatus->slug=='devis'){
                $queryOrder = 'date_situation';
                $ordre = 'desc';
            }elseif($groupeStatus->slug=='contrats'){
                $queryOrder = 'date_situation';
                $ordre = 'desc';
            }

            $dateFilter = 'created_at' ;

            if($groupeStatus->slug == 'leads'){

                $dateFilter = 'created_at' ;

            }elseif($groupeStatus->slug == 'devis' or $groupeStatus->slug == 'contrats'){

                $dateFilter = 'date_situation' ;

            }


            $fiches    = $className::whereActive(1)
                                        ->where('equipe_user_id', $equipeUserId)
                                        ->where('produit_id', $id)
                                        ->where('statut_id', $statut->id)
                                        ->where(function($query) use ($request, $dateFilter) {
                                            if($request->has('dd') and $request->has('df')){
                                                $dd = $request->get('dd');
                                                $df = $request->get('df');
                                                $query->whereBetween($dateFilter, [$dd.' 00:00:00', $df.' 23:59:59']);
                                            }elseif($request->has('dd') and !$request->has('df')){
                                                $dd = $request->get('dd');
                                                $query->where($dateFilter, '>=', $dd.' 00:00:00');
                                            }elseif(!$request->has('dd') and $request->has('df')){
                                                $df = $request->get('df');
                                                $query->where($dateFilter, '<=', $df.' 23:59:59');
                                            }
                                        })
                                        ->orderBy( $queryOrder, $ordre)
                                        ->orderBy('created_at', 'desc')
                                        ->paginate(30);


            $callHistory = $this->getCallHistory($produit->id);

            $dureeImpressionSysteme   = Parametre::whereKey('duree_impression')->first()->value;

            switch($groupeStatus->slug) {

                case 'leads':
                    return view('conseillers.leads_'.$produit->slug, ['produits' => $produits, 'fiches' => $fiches, 'statusId' => $statut->id, 'statut' => $statut, 'callHistory' => $callHistory]);
                    break;

                case 'devis':
                    return view('conseillers.devis_'.$produit->slug, ['produits' => $produits, 'fiches' => $fiches, 'statut' => $statut, 'callHistory' => $callHistory]);
                    break;

                case 'contrats':
                    return view('conseillers.contrats_'.$produit->slug, ['produits' => $produits, 'fiches' => $fiches, 'statut' => $statut, 'callHistory' => $callHistory, 'dureeImpressionSysteme' => $dureeImpressionSysteme]);
                    break;
                
                default:
                    return view('conseillers.leads_'.$produit->slug, ['produits' => $produits, 'fiches' => $fiches, 'statusId' => $statut->id, 'statut' => $statut, 'callHistory' => $callHistory]);
                    break;                
                
            }

        }

    }


    /**
     * Générer le numero du contrat
     */
    public function mask($nbrbits, $valeur){

        $nbrBitsValeur  = $nbrbits - strlen($valeur);
        $resultat       = $valeur;

        if($nbrBitsValeur > 0){

            for($i=0; $i<$nbrBitsValeur; $i++){

                $resultat = '0'.$resultat;

            }
        }

        return $resultat;
    }

    /**
     * Changer le produit
     */
    public function changeProduit(Request $request, $id){

        $user = Auth::user();

        if(!$id){
            Session::put('produit_id', $user->getProducts()->first()->id);
        }else{
            Session::put('produit_id', $id);
        }

        try {

            $produit   = Produit::whereId(Session::get('produit_id'))->first();

            $statusId  = Statut::where('slug_produit', $produit->slug)
                                        ->with(['groupeStatus' => function($q){
                                            $q->whereSlug('leads');
                                        }])
                                        ->orderBy('ordre', 'asc')
                                        ->first()
                                        ->id;

            return ($statusId) ? $statusId : 0 ;

        }catch(\Exception $e){

            return 0;

        }

    }


    public function userInfo(){

        $user = Auth::user();

        $userEquipe = $user->userEquipe()->first()->pivot;

        return $userInfo = ['equipe_user_id' => $userEquipe->id, 'tracable_id' => $userEquipe->equipe_id, 'tracable_type' => 'equipe'];

    }


    /**
     * Sauvegarder les info du clients (bancaire ...)
     */
    public function saveInfoClientObseque(SaveInfoClientRequest $request){

        $userInfo = $this->userInfo();

        $garantie_code = $request->get('garantie_code');

        $garantie = Obgarantie::whereCode($garantie_code)->first();

        $clientId  = $request->get('info_num_client');
        $contratId = $request->get('info_num_contrat');

        $fiche  = Ficheobseque::where('num_fiche', $contratId)->first(); 
        $client = $fiche->client;
        
        // $fiche->sagamme_id          = $request->get('gamme_id');
        // $fiche->sagarantie_id       = $request->get('garantie_id');
        $fiche->obgamme_id          = $garantie->gamme->id;
        $fiche->obgarantie_id       = $garantie->id;
        
        $fiche->cotisation          = $request->get('info_montant');
        $fiche->num_formule         = $request->get('info_formule');
        //$fiche->num_compagnie     = $request->get('info');
        $fiche->num_affiliate       = $request->get('info_num_aff');
        $fiche->num_security_social = $request->get('info_num_ss');
        
        $fiche->modepaiement_id     = $request->get('mode_paiement');
        $fiche->typepaiement_id     = $request->get('type_paiement');
        $fiche->prelevement_id      = $request->get('prelevement');
        $fiche->nbr_mois_gratuit    = $request->get('nbr_mois_gratuit');
        $fiche->paiement_cb         = $request->get('paiement_cb');
        $fiche->remise              = $request->get('remise');
        //$fiche->frais_dossier_offert = $request->get('frais_dossier_offert');
        $fiche->frais_dossier       = $request->get('frais_dossier') ;
        
        $fiche->date_situation      = Carbon::now();
        
        $fiche->capital             = $request->get('montant_capital');

        $fiche->save();


        $infoBanque = Informationbancaire::where('client_id', $clientId)->where('contrat_id', $contratId)->first();

        if(!$infoBanque){
            $infoBanque = new Informationbancaire;
        }

        $infoBanque->client_id                  = $clientId;
        $infoBanque->contrat_id                 = $contratId;
        $infoBanque->active                     = 1;
        
        if($request->has("iban_pre") and $request->get("iban_pre")){

            $iban_pre = str_replace('-', '', $request->get("iban_pre"));

            $infoBanque->nom_banque_pre         = $request->get('nom_banque_pre');
            $infoBanque->adresse_banque_pre     = $request->get('adresse_banque_pre');
            $infoBanque->ville_banque_pre       = $request->get('ville_banque_pre');
            $infoBanque->code_pays_pre          = substr($iban_pre, 0, 2);
            $infoBanque->cle_iban_pre           = substr($iban_pre, 2, 2);
            $infoBanque->code_etablissement_pre = substr($iban_pre, 4, 5);
            $infoBanque->code_guichet_pre       = substr($iban_pre, 9, 5);
            $infoBanque->num_compte_pre         = substr($iban_pre, 14, 11);
            $infoBanque->cle_rib_pre            = substr($iban_pre, 25, 2);
            $infoBanque->code_bic_pre           = Crypt::encrypt($request->get('code_bic_pre'));

            $infoBanque->iban_pre               = Crypt::encrypt($iban_pre);

            if($request->has("iban_rem") and $request->get("iban_rem")){

                $iban_rem = str_replace('-', '', $request->get("iban_rem"));
            
                $infoBanque->nom_banque_rem         = $request->get('nom_banque_rem');
                $infoBanque->adresse_banque_rem     = $request->get('adresse_banque_rem');
                $infoBanque->ville_banque_rem       = $request->get('ville_banque_rem');
                $infoBanque->code_pays_rem          = substr($iban_rem, 0, 2);
                $infoBanque->cle_iban_rem           = substr($iban_rem, 2, 2);
                $infoBanque->code_etablissement_rem = substr($iban_rem, 4, 5);
                $infoBanque->code_guichet_rem       = substr($iban_rem, 9, 5);
                $infoBanque->num_compte_rem         = substr($iban_rem, 14, 11);
                $infoBanque->cle_rib_rem            = substr($iban_rem, 25, 2);
                $infoBanque->code_bic_rem           = Crypt::encrypt($request->get('code_bic_rem'));

                $infoBanque->iban_rem               = Crypt::encrypt($iban_rem);

            }

        }


        if($request->has("iban_pre") and $request->get("iban_pre")){

            if($infoBanque->save()){

                $statut                = Statut::whereSlug('obsequeDevisNonSigne')->first();
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();
                $fiche->save();

                //changer le statut de la fiche => nnsigne
                $idAction              = Action::whereSlug('SCP')->value('id');
                $tabInfoTrace          = [
                                            'idAction'       => $idAction,
                                            'idFiche'        => $fiche->id,
                                            'idStatut'       => $fiche->statut_id,
                                            'equipe_user_id' => $userInfo['equipe_user_id'],
                                            'tracable_id'    => $userInfo['tracable_id'],
                                            'tracable_type'  => $userInfo['tracable_type'],
                                            'observation'    => null,
                                            'motif'          => null
                                        ];
                event(new EventTracesObseque($tabInfoTrace));

            }

        }else if( $fiche->statut->groupeStatus->slug == "leads" ) {

            $statut                = Statut::whereSlug('obsequeDevisEnCours')->first();
            $fiche->statut_id      = $statut->id;
            $fiche->date_situation = Carbon::now();
            $fiche->save();

            //changer le statut de la fiche => nnsigne
            $idAction              = Action::whereSlug('SCP')->value('id');
            $tabInfoTrace          = [
                                        'idAction'       => $idAction,
                                        'idFiche'        => $fiche->id,
                                        'idStatut'       => $fiche->statut_id,
                                        'equipe_user_id' => $userInfo['equipe_user_id'],
                                        'tracable_id'    => $userInfo['tracable_id'],
                                        'tracable_type'  => $userInfo['tracable_type'],
                                        'observation'    => null,
                                        'motif'          => null
                                    ];
            event(new EventTracesObseque($tabInfoTrace));
            
        }
        
        $user = [];

        if(is_null($fiche->equipe_user_id)){
            $user = $fiche->dispatchable->responsable();
        }else{
            $user = $fiche->affectedUser($fiche->equipe_user_id);
        }

        $nomClient      = $fiche->client->nom;
        $prenomClient   = $fiche->client->prenom;
        $emailClient    = $fiche->client->email;
        $civiliteClient = $fiche->client->sexe;

        $data = [ 
                'nomConseiller'         => $user->nom,
                'prenomConseiller'      => $user->prenom,
                'telConseiller'         => $user->tel,
                'emailConseiller'       => $user->email,
                'faxConseiller'         => $user->fax,
                'logo'                  => $request->get('logo'),
                'civiliteClient'        => $fiche->client->sexe,
                'nomClient'             => $fiche->client->nom,
                'prenomClient'          => $fiche->client->prenom,
                'dateNaissanceClient'   => $fiche->client->date_naissance,
                'adresseClient'         => $fiche->client->adresse,
                'codePostalClient'      => $fiche->client->code_postal,
                'emailClient'           => $fiche->client->email,
                'telDomicileClient'     => $fiche->client->tel_domicile,
                'telMobileClient'       => $fiche->client->tel_mobile,
                'telBureauClient'       => $fiche->client->tel_bureau,
                'villeClient'           => $fiche->client->ville,
                'professionClient'      => $fiche->client->profession_id, 
                'sitFamilialeClient'    => $fiche->client->sit_familiale,
                'garantie'              => $request->get('garantie'), 
                'nomConjoint'           => '',
                'prenomConjoint'        => '',
                'dateNaissanceConjoint' => '',
                'nomCompagnie'          => $request->get('compagnie'),
                'lienCrm'               => public_path().'/uploads/BA'
            ];

        // lien serveur
        $produit          ='OBSEQUE';
        $dossierCompagnie = $request->get('compagnie');
        $verifydirectory  = 'upload/souscription/BA/'.$produit;
        //$linkPdf = Parametre::whereKey('dossier_pdf')->first()->value;
       
        if (!file_exists($verifydirectory)){

            $result = File::makeDirectory('upload/souscription/BA/'.$produit, 0777, true);

        }
        
        $dossierCompagnie    = str_replace(' ', '_', $dossierCompagnie);

        $verify    = 'upload/souscription/BA/'.$produit.'/'.$dossierCompagnie;
       
        if (!file_exists($verify)){

            $result = File::makeDirectory('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie, 0777, true);
        
        }

        $fileName   = uniqid();
        $gamme      = $garantie->gamme;
        $ba         = $gamme->code;
        $ba         = strtoupper(str_replace(' ', '', $ba));

        $souscription         = new SouscriptionObsequeController();
        $verifierSouscription = 1;
        $formule              = ''; 
        $tableau              = $souscription->{$ba}($user, $client, $fiche, $verifierSouscription, $formule);

        //Importer le fichier BA depuis le tarificateur
        $resultatImport       = $souscription->ImportFichierBA($ba);
        
        $pdf = new Pdf('upload/'.$ba.'.pdf');
        $pdf->allow('Printing')
            ->fillForm($tableau)
                ->needAppearances()
           ->saveAs('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

        $fiche->lien_pdf = asset('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
        $fiche->save();
        $lienPdf = asset('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

        $info_fiche = [
                        'fiche_id'     => $fiche->id,
                        'prd_slug'     => $fiche->produit->slug
                    ];
                    
        $collection = collect(event(new EventCreateProcessesLead($info_fiche)));
        $processes  = $collection->flatten(1);
        $processes->values()->all();

        return [
                'garantie'         => $garantie->libelle,
                'lienPdf'          => $lienPdf, 
                'dossierCompagnie' => $dossierCompagnie, 
                'fileName'         => $fileName, 
                'success'          => true, 
                'message'          => 'les informations sont enregistrées.', 'logo' => $request->get('logo'), 'nomClient' => $nomClient, 
                'prenomClient'     => $prenomClient, 
                'emailClient'      => $emailClient, 
                'civiliteClient'   => $civiliteClient, 
                'tarif'            => $request->get('info_montant'),
                'processes'        => $processes
            ];

    }


    public function getCallHistory($produit_id){

        try {

            $user       = Auth::user();
        
            $produit    = Produit::find($produit_id);
            $slugPrd    = $produit->slug;
            
            $info_prd   = $user->getInfoPrd($produit->id);
            
            $objectif   = $info_prd->pivot->objectif;
            $seuil_call = $info_prd->pivot->duree_appel;
            $nbr_call   = $info_prd->pivot->nbr_appel;

            $equipeUserId = $user->userEquipe->first()->pivot->id;
            
            $className    = "App\Fiche".$slugPrd;

            // $date = Carbon::parse('2013-09-13 23:26:11.123789');
            // $startMonth = $date->startOfMonth()->toDateTimeString();
            // $endMonth   = $date->endOfMonth()->toDateTimeString();

            $startMonth = Carbon::now()->startOfMonth()->toDateTimeString();
            $endMonth   = Carbon::now()->endOfMonth()->toDateTimeString();

            $callsM     = Cdr::where('src', $user->id_appel)
                                    ->where('calldate', '>=', $startMonth)
                                    ->where('calldate', '<=', $endMonth)
                                    ->get();

            $nbr_contrat = $user->getContratInfo($slugPrd)['nbr_contrat'];
            $chiffre     = $user->getContratInfo($slugPrd)['chiffre'];

            return $history = [
                                'nbr_appel'   => $callsM->count(),
                                'duree_appel' => $this->getHoursFromMinites($callsM->sum('duration')),
                                'nbr_contrat' => $nbr_contrat,
                                'chiffre'     => $chiffre,
                                'objectif'    => ($objectif) ? $objectif : 0,
                                'per'         => ($objectif) ? round( ($chiffre * 100) / $objectif ,2) : 0,
                            ];
            
        } catch (\Exception $e) {
            
            return $history = [
                                'nbr_appel'   => 0,
                                'duree_appel' => 0,
                                'nbr_contrat' => 0,
                                'chiffre'     => 0,
                                'objectif'    => 0,
                                'per'         => 0,
                            ];

        }

        

        /** **/

        // $startDay = Carbon::now()->startOfDay();
        // $endDay   = Carbon::now()->endOfDay();
        //
        // $callsJ   = Cdr::where('calldate', '>=', $startDay)
        //                 ->where('calldate', '<=', $endDay)
        //                 ->where('src', $user->id_appel)
        //                 ->get();


        $startDay = '2013-09-13 00:00:00';
        $endDay   = '2013-09-13 23:59:59';

        $callsJ   = Cdr::where('calldate', '>=', $startDay)
                        ->where('calldate', '<=', $endDay)
                        ->get();


        /** **/

        $objJ = $className::select(DB::raw('SUM(cotisation * (12 - nbr_mois_gratuit) ) as objectif'))
                            ->whereHas('statut', function($q) use ($slugPrd) {
                                $q->whereSlug($slugPrd.'Client');
                            })
                            ->where('equipe_user_id', $equipeUserId)
                            ->where('date_situation', '>=', $startDay)
                            ->where('date_situation', '<=', $endDay)
                            ->first()
                            ->objectif;

        /** **/

        // $startWeek = Carbon::now()->startOfWeek();
        // $endWeek   = Carbon::now()->endOfWeek();
        // $callsH    = Cdr::where('calldate', '>=', $startWeek)
        //                     ->where('calldate', '<=', $endWeek)
        //                     ->where('src', $user->id_appel)
        //                     ->get();

        $date = Carbon::parse('2013-09-13 23:26:11.123789');
        $startWeek  = $date->startOfWeek()->toDateTimeString();
        $endWeek    = $date->endOfWeek()->toDateTimeString();
        $callsH     = Cdr::where('calldate', '>=', $startWeek)
                            ->where('calldate', '<=', $endWeek)
                            ->get();

        /** **/

        //return Cdr::orderBy('calldate', 'desc')->get()->take(100);


        $objH = $className::select(DB::raw('SUM(cotisation * (12 - nbr_mois_gratuit) ) as objectif'))
                    ->whereHas('statut', function($q) use ($slugPrd) {
                        $q->whereSlug($slugPrd.'Client');
                    })
                    ->where('equipe_user_id', $equipeUserId)
                    ->where('date_situation', '>=', $startWeek)
                    ->where('date_situation', '<=', $endWeek)
                    ->first()
                    ->objectif;
        
        /** **/

        // $startMonth = Carbon::now()->startOfMonth();
        // $endMonth   = Carbon::now()->endOfMonth();
        //
        // $callsM     = Cdr::where('calldate', '>=', $startMonth)
        //                     ->where('calldate', '<=', $endMonth)
        //                     ->where('src', $user->id_appel)
        //                     ->get();


        $date = Carbon::parse('2013-09-13 23:26:11.123789');
        $startMonth = $date->startOfMonth()->toDateTimeString();
        $endMonth   = $date->endOfMonth()->toDateTimeString();

        $callsM     = Cdr::where('calldate', '>=', $startMonth)
                            ->where('calldate', '<=', $endMonth)
                            ->get();


        /** **/

        $objM = $className::select(DB::raw('SUM(cotisation * (12 - nbr_mois_gratuit) ) as objectif'))
                    ->whereHas('statut', function($q) use ($slugPrd) {
                        $q->whereSlug($slugPrd.'Client');
                    })
                    ->where('equipe_user_id', $equipeUserId)
                    ->where('date_situation', '>=', $startMonth)
                    ->where('date_situation', '<=', $endMonth)
                    ->first()
                    ->objectif;



        $history = [
                    'J' => [],
                    'H' => [],
                    'M' => []
                    ];


        $history['J'] = [
                            'DA' => [   
                                        'value' => $this->getHoursFromMinites($callsJ->sum('duration')),
                                        'per'   => ($seuil_call) ? round( ($callsJ->sum('duration') * 100) / $seuil_call ,2) : 0 
                                    ],
                            'NA' => [
                                        'value' => $callsJ->count(), 
                                        'per'   => ($nbr_call) ? round( ($callsJ->count() * 100) / $nbr_call ,2) : 0
                                    ],
                            'CA' => [
                                        'value' => $objJ, 
                                        'per'   => ($objectif) ? round( ($objJ * 100) / $objectif ,2) : 0
                                    ]
                        ];

        $history['H'] = [
                            'DA' => [
                                        'value' => $this->getHoursFromMinites($callsH->sum('duration')), 
                                        'per'   => ($seuil_call) ? round( ($callsH->sum('duration') * 100) / ($seuil_call*6) ,2) : 0 
                                    ],
                            'NA' => [
                                        'value' => $callsH->count(), 
                                        'per'   => ($nbr_call) ? round( ($callsH->count() * 100) / ($nbr_call*6) ,2) : 0
                                    ],
                            'CA' => [
                                        'value' => $objH, 
                                        'per'   => ($objectif) ? round( ($objH * 100) / ($objectif/7) ,2) : 0
                                    ]
                        ];

        $history['M'] = [
                            'DA' => [
                                        'value' => $this->getHoursFromMinites($callsM->sum('duration')), 
                                        'per'   => ($seuil_call) ? round( ($callsM->sum('duration') * 100) / ($seuil_call*24) ,2) : 0 
                                    ],
                            'NA' => [
                                        'value' => $callsM->count(), 
                                        'per'   => ($nbr_call) ? round( ($callsM->count() * 100) / ($nbr_call*24) ,2) : 0
                                    ],
                            'CA' => [
                                        'value' => $objM, 
                                        'per'   => ($objectif) ? round( ($objM * 100) / ($objectif/24) ,2) : 0
                                    ]
                        ];

        return $history;

    }

    public function getHoursFromMinites($time, $format = '%02dH%02d'){
        
        if ($time < 1) {
            return;
        }

        $hours   = floor($time / 60);

        $minutes = ($time % 60);

        return sprintf($format, $hours, $minutes);

    }

    public function demandeImpression(Request $request)
    {
        //return $request->all();
                $statut = [];

                $numFiche  = $request->get('ficheNum');
                $prdSlug   = $request->get('prdSlug');

                try{

                    $produit = Produit::whereSlug($prdSlug)->first();

                    $className = "App\Fiche".$produit->slug;

                    try{

                        $userInfo = $this->userInfo();
                        
                        $fiche    = $className::where("num_fiche", $numFiche)->first();

                        //$statut   = $fiche->statut;

                        //$fiche->num_police = $numPolice;

                        //$client      = $fiche->client;
                        
                        //$ficheStatut = $fiche->statut->slug;

                        //$slugPrd = $produit->slug;

                       // if( $ficheStatut == $slugPrd.'ContratDepot' ){

                        // $statutSlug         = $prdSlug.'CentreGestion';

                        // $statut             = Statut::whereSlug($statutSlug)->first();

                        // $fiche->statut_id   = $statut->id;
                        $date_demande       = Carbon::now();

                        $fiche->infos_impression  = collect(['is_printed' => 0, 'date_demande' => $date_demande, 'date_validation' => null, 'date_impression' => null])->toJson();//etat impression demandé

                           // $fiche->date_situation = Carbon::now();

                       //}else if( $ficheStatut == $slugPrd.'Client' ){

                            //$fiche->date_situation = Carbon::now();

                       // }

                        if($fiche->save()){

                            // $user = [];

                            // if($fiche->equipe_user_id){

                            //     $user = $fiche->affectedUser($fiche->equipe_user_id);

                            // }else{

                            //     $user = $fiche->dispatchable->responsable();

                            // }

                            // Mail::send('emails.validation_contrat', ['user' => $user, 'client' => $client, 'fiche' => $fiche], function ($m) use ($client, $user)  {

                            //     $m->from($user->courtier->email, $user->courtier->nom);

                            //     $m->to($client->email, $client->nom)->subject('Validation du contrat');

                            // });

                            $idAction     = Action::whereSlug('DID')->value('id');
                            $observation  = "";

                            $tabInfoTrace = [
                                            'idAction'       => $idAction,
                                            'idFiche'        => $fiche->id,
                                            'idStatut'       => $fiche->statut_id,
                                            'equipe_user_id' => $userInfo['equipe_user_id'],
                                            'tracable_id'    => $userInfo['tracable_id'], 
                                            'tracable_type'  => $userInfo['tracable_type'], 
                                            'observation'    => $observation,
                                            'motif'          => null
                                        ];
                            $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
                            event(new $event($tabInfoTrace));

                            // Debut Notification

                                $userList = [];

                                if($fiche->equipe_user_id){

                                    array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                                    
                                    if($fiche->dispatchable->responsable()){
                                        array_push( $userList, $fiche->dispatchable->responsable() );
                                    }

                                }else{

                                    if($fiche->dispatchable->responsable()){
                                        array_push( $userList, $fiche->dispatchable->responsable() );
                                    }

                                }

                                $notif = Notification::whereSlug('PRINTREQUEST')->first();
                                
                                $notification = [
                                    'user_id'         => null,
                                    'notification_id' => $notif->id,
                                    'notifiable_id'   => $fiche->id,
                                    'notifiable_type' => $fiche->produit->table_produit,
                                    'rappel_time'     => null,
                                    'link'            => null,
                                    'type'            => 'lead',
                                    'description'     => $observation
                                ];

                                foreach ($userList as $usr) {

                                    $notification['user_id'] = $usr->id;
                                    $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                                   
                                    event(new EventNotifications($notification));

                                }
                            // Fin Notification

                        }


                        return [
                            'success' => true,
                            'fiche'   => $fiche->slug,
                            'statut'  => $fiche->statut_id,
                            'message' => 'demande d\'impression envoyée',
                        ];

                    }catch(\Exception $e){

                        return [
                            'success' => false,
                            'message' => 'Problème d\'envoi de demande d\'impression !!!',
                        ];

                    }

                }catch(\Exception $e){

                    return [
                        'success' => false,
                        'message' => 'Problème d\'envoi de demande d\'impression !!!',
                    ];

                }

    }

    public function demandeFax(Request $request)
    {
        $numFiche  = $request->get('ficheNum');
        $prdSlug   = $request->get('prdSlug');

        //return $request->all();

        try{

            $produit = Produit::whereSlug($prdSlug)->first();

            $className = "App\Fiche".$produit->slug;

            try{

                $userInfo = $this->userInfo();
                
                $fiche    = $className::where("num_fiche", $numFiche)->first();

                $date_demande       = Carbon::now();

                $fiche->infos_fax  = collect(['is_faxed' => 0, 'date_demande' => $date_demande, 'date_fax' => null])->toJson();

                if($fiche->save()){

                    $idAction     = Action::whereSlug('DEF')->value('id');
                    $observation  = "";

                    $tabInfoTrace = [
                                    'idAction'       => $idAction,
                                    'idFiche'        => $fiche->id,
                                    'idStatut'       => $fiche->statut_id,
                                    'equipe_user_id' => $userInfo['equipe_user_id'],
                                    'tracable_id'    => $userInfo['tracable_id'], 
                                    'tracable_type'  => $userInfo['tracable_type'], 
                                    'observation'    => $observation,
                                    'motif'          => null
                                ];
                    $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
                    event(new $event($tabInfoTrace));

                    // Debut Notification

                        $userList = [];

                        if($fiche->equipe_user_id){

                            array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                            
                            if($fiche->dispatchable->responsable()){
                                array_push( $userList, $fiche->dispatchable->responsable() );
                            }

                        }else{

                            if($fiche->dispatchable->responsable()){
                                array_push( $userList, $fiche->dispatchable->responsable() );
                            }

                        }

                        $notif = Notification::whereSlug('FAXREQUEST')->first();
                        
                        $notification = [
                            'user_id'         => null,
                            'notification_id' => $notif->id,
                            'notifiable_id'   => $fiche->id,
                            'notifiable_type' => $fiche->produit->table_produit,
                            'rappel_time'     => null,
                            'link'            => null,
                            'type'            => 'lead',
                            'description'     => $observation
                        ];

                        foreach ($userList as $usr) {

                            $notification['user_id'] = $usr->id;
                            $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                           
                            event(new EventNotifications($notification));

                        }
                    // Fin Notification

                }


                return [
                    'success' => true,
                    'fiche'   => $fiche->slug,
                    'statut'  => $fiche->statut_id,
                    'message' => 'demande d\'envoi fax envoyée',
                ];

            }catch(\Exception $e){

                return [
                    'success' => false,
                    'message' => 'Problème d\'envoi de demande de fax !!!',
                ];

            }

        }catch(\Exception $e){

            return [
                'success' => false,
                'message' => 'Problème d\'envoi de demande de fax !!!',
            ];

        }
    }


}   
