<?php

namespace App\Http\Controllers\Conseiller;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB, Auth, Carbon\carbon;

use App\Groupestatut, App\Messagerie, App\Produit;

class StatistiqueSanteController extends Controller
{
    
    private $dateDebut;
    private $dateFin;
    private $dt;
    private $produit;

    public function __construct() {

      $this->dt               = Carbon::create((int)date('Y'), (int)date('m'), (int)date('d'), 23, 59, 59);  
      $this->dateDebut        = '';
      $this->dateFin          = $this->dt->toDateString().' 23:59:59'; 
      $this->produit          = 'fichesantes';
      $this->idProduit        = Produit::whereSlug('sante')->first()->id;
    }


    public function getstatusContrat() {
        return Groupestatut::where('slug', 'contrats')->first()->getStatus($this->idProduit)->lists('id');
    }

    public function getstatusDevis() {
        return Groupestatut::where('slug', 'devis')->first()->getStatus($this->idProduit)->lists('id');
    }

    public function getstatusLeads() {
        return Groupestatut::where('slug', 'leads')->first()->getStatus($this->idProduit)->lists('id');
    }

     
     public function filterOptions(Request $request) {

            switch ($request->get('option')) {
               
                case "option1":
                    $this->dateDebut = $this->dt->toDateString().' 00:00:00';
                    break;
                case "option2":
                    $this->dateDebut = $this->dt->subDay()->toDateString().' 00:00:00';
                    break;
                case "option3":
                    $this->dateDebut = $this->dt->subWeek()->toDateString().' 00:00:00';
                    break;
                case "option4":
                    $this->dateDebut = $this->dt->subMonth()->toDateString().' 00:00:00';
                    break;
                case "option5":
                    $this->dateDebut = $this->dt->subYear()->toDateString().' 00:00:00';
                    break;
                default :
                        $this->dateFin    = $request->get('dateFin').' 23:59:59'; 
                    $this->dateDebut  = $request->get('dateDebut').' 00:00:00';
                  break;
            }


                if(!empty($request->get('dateDebut'))) {
                    $this->dateDebut    = $request->get('dateDebut').' 00:00:00'; 
                }

                 if(!empty($request->get('dateFin'))) {
                    $this->dateFin    = $request->get('dateFin').' 23:59:59'; 
                }
             
            $this->produit = $request->get('produit');

    }


    public function index() {
        $produits = Produit::where('active', 1)->get();
     	  return view('conseillers.statistiques.index', ['produits' => $produits]);
    }


    public function nombreFicheParStatut(Request $request) {
           
          $this->filterOptions($request);

         	$fiches = DB::table($this->produit)
    							->join('statuts',"statut_id",'=','statuts.id')
    							->where(function($queryFiche) use($request){

									// 		if($request->has('dateDebut')) {
									//     		$queryFiche->where("date_situation", '>=', $this->dateDebut);
									//    	}

									//    	if($request->has('dateFin')) {
									//     		$queryFiche->where("date_situation", '<=', $this->dateFin);
									//    	}

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

    							})
                                ->whereIn('statut_id', $this->getstatusLeads())
    							->where($this->produit . ".active",1)
    							->where('equipe_user_id', Auth::user()->userEquipe->first()->pivot->id)
    							->select(DB::raw('count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'), 'libelle')
    							->groupBy("statut_id")
    							->get(); 
            
            $data = NULL;
            if($fiches){
	            foreach($fiches as $fiche) {
	                $data['ficheParStatut'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
	                $data['chiffreParStatut'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->nbrefiches];
	            }
	        }

    		return json_encode($data);

    }



    public function nombreFicheParRegime(Request $request) {

     	    $this->filterOptions($request);
          
          $fiches = DB::table($this->produit)
    							->join('saregimes',"saregime_id",'=','saregimes.id')
    							->where(function($queryFiche) use($request){

									// 		if($request->has('dateDebut')) {
									//     		$queryFiche->where("date_situation", '>=', $this->dateDebut);
									//    	}

									//    	if($request->has('dateFin')) {
									//     		$queryFiche->where("date_situation", '<=', $this->dateFin);
									//    	}

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

    							})
    							->where($this->produit . ".active",1)
    							->where('equipe_user_id',Auth::user()->userEquipe->first()->pivot->id)
    							->select(DB::raw('count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'), 'saregimes.libelle')
    							->groupBy("saregime_id")
    							->get(); 

            
            $data = NULL;
            foreach($fiches as $fiche) {
                $data['ficheParRegime'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
                $data['chiffreParRegime'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->nbrefiches];
            }

    		return json_encode($data);

     }


     public function nombreFicheParCompagnie(Request $request) {
          $this->filterOptions($request);
          $fiches = DB::table($this->produit)
                                ->join('sagammes',"sagamme_id",'=','sagammes.id')
    							->join('sacompagnies',"sagammes.sacompagnie_id",'=','sacompagnies.id')
    							->where(function($queryFiche) use($request){

									// 		if($request->has('dateDebut')) {
									//     		$queryFiche->where("date_situation", '>=', $this->dateDebut);
									//    	}

									//    	if($request->has('dateFin')) {
									//     		$queryFiche->where("date_situation", '<=', $this->dateFin);
									//    	}

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

    							})
    							->whereIn('statut_id', $this->getstatusContrat())
    							->where($this->produit . ".active",1)
    							->where('equipe_user_id',Auth::user()->userEquipe->first()->pivot->id)
    							->select(DB::raw('count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'), 'sacompagnies.libelle')
    							->groupBy("sacompagnie_id")
    							->get(); 

            
            $data = NULL;

            if($fiches){
	            foreach($fiches as $fiche) {
	                $data['ficheParCompagnie'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
	            }
	        }

    		return json_encode($data);
     }



     public function infoGenerale(Request $request) {
            
        $this->filterOptions($request);
     	   
        $fichesLead     = DB::table($this->produit)
    							->where(function($queryFiche) use($request){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

    							})
    							->whereIn('statut_id', $this->getstatusLeads())
    							->where($this->produit . ".active",1)
    							->where('equipe_user_id',Auth::user()->userEquipe->first()->pivot->id)
    							->select(DB::raw('count(*) as nombreLead, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreLead'))
    							->first(); 


        $fichesDeclare  = DB::table($this->produit)
    							->where(function($queryFiche) use($request){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

    							})
    							->whereIn('statut_id', $this->getstatusDevis())
    							->where($this->produit . ".active",1)
    							->where('equipe_user_id',Auth::user()->userEquipe->first()->pivot->id)
    							->select(DB::raw('count(*) as nombreDeclare, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreDeclare'))
    							->first(); 



        $fichesReel     = DB::table($this->produit)
    							->where(function($queryFiche) use($request){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

    							})
    							->whereIn('statut_id', $this->getstatusContrat())
    							->where($this->produit . ".active",1)
    							->where('equipe_user_id',Auth::user()->userEquipe->first()->pivot->id)
    							->select(DB::raw('count(*) as nombreReel, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffreReel'))
    							->first(); 

        $nombreMessage  = Messagerie::where('to_id', Auth::user()->id)->count();
        
        $data['lead']    = $fichesLead;
        $data['declare'] = $fichesDeclare;
        $data['reel']    = $fichesReel;
        $data['message'] = $nombreMessage;

        return json_encode($data);

    }



    //Statistique compagnie

    public function leadParCompagnie(Request $request) {
          
          $this->filterOptions($request);
          
          $fiches = DB::table($this->produit)->join('sagammes',"sagamme_id",'=','sagammes.id')
    							->join('sacompagnies',"sagammes.sacompagnie_id",'=','sacompagnies.id')
    							->join('statuts', 'statut_id', '=', 'statuts.id')
    							->join('groupestatuts', 'statuts.groupestatut_id', '=', 'groupestatuts.id')
    							->where(function($queryFiche) use($request){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

    							})
    							->whereIn("groupestatuts.slug", ['devis', 'contrats'])
    							->where($this->produit . ".active",1)
    							->where('equipe_user_id',Auth::user()->userEquipe->first()->pivot->id)
    							->select(DB::raw('sacompagnies.libelle as compagnie, sagammes.libelle as gamme, groupestatuts.slug as slug, count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'))
    							->groupBy('sagammes.id',"groupestatuts.id")
    							->orderBy("sacompagnies.libelle", "asc")
    							->get();


             $fichesCompagnie = DB::table($this->produit)->join('sagammes',"sagamme_id",'=','sagammes.id')
    							->join('sacompagnies',"sagammes.sacompagnie_id",'=','sacompagnies.id')
    							->join('statuts', 'statut_id', '=', 'statuts.id')
    							->join('groupestatuts', 'statuts.groupestatut_id', '=', 'groupestatuts.id')
    							->where(function($queryFiche) use($request){

						          	$queryFiche->where("date_situation", '>=', $this->dateDebut);
						          	$queryFiche->where("date_situation", '<=', $this->dateFin);

    							})
    							->whereIn("groupestatuts.slug", ['devis', 'contrats'])
    							->where($this->produit.".active",1)
    							->where('equipe_user_id',Auth::user()->userEquipe->first()->pivot->id)
    							->select(DB::raw('sacompagnies.libelle as compagnie, groupestatuts.slug as slug, count(*) as nbrefiches, SUM(cotisation*(12-nbr_mois_gratuit)) as chiffre'))
    							->groupBy('sacompagnies.id',"groupestatuts.id")
    							->orderBy("sacompagnies.libelle", "asc")
    							->get(); 

            
            $data = $data1 = $dataPie = NULL;
            

           
            if($fiches){
	            
	            foreach ($fiches as $fiche) {

	                   if(!isset($data[$fiche->compagnie . '-' . $fiche->gamme]['devis'])) {
	                	  $data[$fiche->compagnie . '-' . $fiche->gamme]['devis']    = 0;
	                   }

	                   if(!isset($data[$fiche->compagnie . '-' . $fiche->gamme]['contrats'])) {
	                	  $data[$fiche->compagnie . '-' . $fiche->gamme]['contrats'] = 0;
	                   } 
                       
	            	 
	            	  $data[$fiche->compagnie . '-' . $fiche->gamme][$fiche->slug] = $fiche->nbrefiches;
	            	
	            }

               
	             $collection = collect($data);

				$gammes     = $collection->keys()->all();               			 
				$devis1      = $collection->pluck('devis')->all();
				$contrats1   = $collection->pluck('contrats')->all();
				
	           
	        } 
 
    if($fichesCompagnie){
	            
	            foreach ($fichesCompagnie as $fiche) {

	                   if(!isset($data1[$fiche->compagnie]['devis'])) {
	                	  $data1[$fiche->compagnie]['devis']    = 0;
	                   }

	                   if(!isset($data1[$fiche->compagnie]['contrats'])) {
	                	  $data1[$fiche->compagnie]['contrats'] = 0;
	                   } 
                       
	            	 
	            	  $data1[$fiche->compagnie][$fiche->slug] = $fiche->nbrefiches;
	            	
	            }

               
	             $collection = collect($data1);

				$compagnies     = $collection->keys()->all();               			 
				$devis2         = $collection->pluck('devis')->all();
				$contrats2      = $collection->pluck('contrats')->all();
				

				//Traitement pie compagnie
				foreach ($compagnies as $index => $compagnie) {
					$dataPie['dataCompagniePie'][] = ['name' => $compagnie, 'y' => ($devis2[$index] + $contrats2[$index])];
				}

	           
	        } 

    		return json_encode([
    			                  'gammes' => $gammes, 'devis1' => $devis1, 'contrats1' => $contrats1, 
    			                  'compagnies' => $compagnies, 'devis2' => $devis2, 'contrats2' => $contrats2,
    			                  'dataPie' => $dataPie
    			              ]);
     }

    public function ficheParGroupPub(Request $request) {
         $this->filterOptions($request);


            $fiches = DB::table($this->produit)
                                ->join('groupepub_provenance',"groupepub_provenance_id",'=','groupepub_provenance.id')
                                ->join('groupepubs',"groupepub_provenance.groupepub_id",'=','groupepubs.id')
                                ->where(function($queryFiche) use($request){

                                    $queryFiche->where("date_situation", '>=', $this->dateDebut);
                                    $queryFiche->where("date_situation", '<=', $this->dateFin);

                                })
                                ->where($this->produit . ".active",1)
                                ->where('equipe_user_id', Auth::user()->userEquipe->first()->pivot->id)
                                ->select(DB::raw('count(*) as nbrefiches, SUM(groupepubs.cout) as chiffre'), 'groupepubs.nom as libelle')
                                ->groupBy("groupepub_id")
                                ->get(); 
            
            $data = NULL;
            if($fiches){
                foreach($fiches as $fiche) {
                    $data['ficheParGroupPub'][] = [$fiche->libelle, $fiche->nbrefiches, (float)$fiche->chiffre];
                    $data['ficheParGroupPubPieNombre'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->nbrefiches];
                    $data['ficheParGroupPubPieCout'][] = ['name' => $fiche->libelle, 'y' => (int)$fiche->chiffre];

                }
            }

            return json_encode($data);
    }

}
