<?php

namespace App\Http\Controllers\Conseiller;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Agence;
use App\Produit;
use App\Sagamme;
use App\User;
use App\Equipeusersagamme;
use App\Commissionfichesante;
use App\Commissionsante;
use Carbon\Carbon;
use DB;
use App\Sacompagnie;
use Auth;

class CommissionController extends Controller
{
    // public function configCommission()
    // {
    // 	$produits    = Produit::where('active', 1)->get();
    //     $agences     = Agence::where('active', 1)->get();
    //     $compagnies  = Sacompagnie::where('active',1)->get();
    //     //$gammes      = Sagamme::where('active',1)->get();


    // 	return view('courtiersfiles.commission.config', ['produits' => $produits,'agences' => $agences,'compagnies' => $compagnies]);
    // }

    public function getCommission()
    {

    	$produits    = Produit::where('active', 1)->get();
        //$sites      = Site::where('active', 1)->get();
        //$equipes    = Equipe::where('active', 1)->get();

        $date 		  = Carbon::now();
        $dateFirstDay = Carbon::create($date->year, $date->month, 01,00,00,00);
        $year 		  = $date->year;
        $month 		  = $date->month - 1;

    	return view('conseillersfiles.commission.index', ['produits' => $produits, 'year' => $year, 'month' => $month, 'date' => $dateFirstDay]);

    }

    public function showCommission(Request $request)
   {
        $tableName            = $request->get('produit');
        $dateProduction       = "";
        $equipeUserId         = Auth::user()->userEquipe()->first()->pivot->id;

        
        if($request->has('dateProdHidden')){

            $dateProduction        = $request->get('dateProdHidden');
            $dateProductionCarbon  = new Carbon($dateProduction);
            $annee                 = $dateProductionCarbon->year;
            $mois                  = $dateProductionCarbon->month;
        
        }


        // return $classements     = ClassementSante::whereHas('userEquipe', function ($query)  {
        //                                $query->where('equipe_id', 1);
        //                            })->get();

        $commissions        = Commissionsante::where('commissionsantes.active',1)
                            ->where('commissionsantes.equipe_user_id',$equipeUserId)
                            ->where(function($query) use ($request,$mois,$annee){

                            if($request->has('dateProdHidden'))
                            {
                                $query->where('commissionsantes.mois',$mois);
                                $query->where('commissionsantes.annee',$annee);
                            }

                            })
                            //->select('users.nom', 'users.prenom')
                            ->orderBy('commissionsantes.CACommissionable','desc')
                            ->with('userEquipe','site','agence')
                            ->get();

                            //return json_encode($classements);
                            return ['commission' => $commissions , 'mois' => $mois , 'annee' => $annee];

   }

   public function getDetailContratsCommission($id)
    {
        //return $id;

        // return $classement = ClassementSante::find($id)->fichesantesActive()
     //                         ->with('statut','garantie')
     //                         ->orderBy("fichesantes.date_situation")
     //                         ->get();

        return $classement = DB::table('commissionfichesantes')
                                 ->join('fichesantes','commissionfichesantes.fichesante_id','=','fichesantes.id')
                                 ->join('sagaranties','commissionfichesantes.sagarantie_id','=','sagaranties.id')
                                 ->join('statuts','commissionfichesantes.statut_id','=','statuts.id')
                                 ->where('commissionfichesantes.commissionsante_id',$id)
                                 ->where('commissionfichesantes.active',1)
                                 ->where('commissionfichesantes.regler',1)
                                 ->select('fichesantes.num_fiche','statuts.libelle as libelleStatut','commissionfichesantes.date_effet','commissionfichesantes.date_situation','sagaranties.libelle as libelleGarantie','commissionfichesantes.tauxcommission','commissionfichesantes.montantCommission','commissionfichesantes.statut_id','statuts.slug as slugStatut')
                                 ->orderBy('commissionfichesantes.date_situation')
                                 ->get();




    }

    public function configUsersGammeCoef(Request $request)
    {
    	//return $request->all();	
        $tableName            = $request->get('produit');
    	$idAgences            = [];
    	$idSites              = [];
    	$idEquipes            = [];
    	$idConseillers        = [];
    	$idCompagnies         = [];
    	$idGammes             = [];

    	$usersGamme        = collect(Equipeusersagamme::where('equipe_user_sagamme.active',1)
        					->where(function($query) use ($request){

        					if($request->has('compagnies') and !$request->has('gammes')){
						        $query->whereHas('gamme', function ($q)  use ($request){

						           $idCompagnies      = $request->get('compagnies');
						           $q->whereIn('sagammes.sacompagnie_id', $idCompagnies);
								        
		                         });
						    }

						    if($request->has('gammes')){

					           $idGammes      = $request->get('gammes');
					           $query->whereIn('equipe_user_sagamme.sagamme_id', $idGammes);
								        
		                         
						    }

        					if($request->has('agences') and !$request->has('sites') and !$request->has('equipes') and !$request->has('conseillers')){

					           // $idAgences      = $request->get('agences');
					           // $query->whereIn('classementsantes.agence_id', $idAgences);

					           $query->whereHas('userEquipe', function ($q)  use ($request){

								           //$idAgences      = $request->get('agences');
								           //$q->whereIn('agence_id', $idAgences);

								           $q->whereHas('user', function ($u)  use ($request){

									           $idAgences      = $request->get('agences');
									           $u->whereIn('agence_id', $idAgences);
										        
				                           });
								        
		                         });

					        }

					        if($request->has('sites') and !$request->has('equipes') and !$request->has('conseillers')){

					           // $idSites        = $request->get('sites');
					           // $query->whereIn('classementsantes.site_id', $idSites);

					           $query->whereHas('userEquipe', function ($q)  use ($request){

								           //$idSites        = $request->get('sites');
								           //$q->whereIn('users.site_id', $idSites);
								           $q->whereHas('user', function ($u)  use ($request){

									           $idSites        = $request->get('sites');
									           $u->whereIn('site_id', $idSites);
										        
				                           });
								        
		                         });
					        }
					        
					        if($request->has('equipes') and !$request->has('conseillers')){
						        $query->whereHas('userEquipe', function ($q)  use ($request){

								           $idEquipes      = $request->get('equipes');
								           $q->whereIn('equipe_user.equipe_id', $idEquipes);
								        
		                         });
						    }
					        

        					if($request->has('conseillers'))
        					{
        						$idConseillers  = $request->get('conseillers');
        						$query->whereIn('equipe_user_sagamme.equipe_user_id', $idConseillers);
        					}

        						

        					})
							//->select('users.nom', 'users.prenom')
							//->orderBy('classementsantes.CACommissionable','desc')
							->with('userEquipe','gamme')
       						->get());
    		$usersGammeCollect = $usersGamme->groupBy('gamme.libelle');

       						return ['usersGamme' => $usersGammeCollect];
    }

    public function updateTauxComm(Request $request)
    {

        //return $request->all();
        $idTaux   = $request->get('idTaux');
        $tauxUser = $request->get('tauxUser');

        

            $userGamme = Equipeusersagamme::where('active',1)
                                ->where('id',$idTaux)
                                ->first();
            $userGamme->tauxcommission   = $tauxUser;

        if($userGamme->save())
            return 'ok';
        else
            return 'notok';

    }

    public function initializeUserGammeRows()
    {
    	$conseillers = User::where('active',1)
                            ->where('profile_id',7)
                            ->has('userEquipe')
                            ->get();

        foreach ($conseillers as $conseiller) 
        {

            $equipeUSerId = $conseiller->userEquipe()->first()->pivot->id;

            $gammes = Sagamme::where('active',1)
            				 ->select('id','libelle','code','sacompagnie_id')
            				 ->orderBy('sacompagnie_id')
            				 ->get();

            foreach ($gammes as $gamme) 
            {
            	$classement     = Equipeusersagamme::firstOrCreate(['equipe_user_id' => $equipeUSerId ,'sagamme_id' => $gamme->id]);
            }
        
           
    	}

    	return 'ok';
   }

   public function calculCommission(Request $request)
   {
   	//return $request->all();
   		$tableName            = $request->get('produit');
    	$idAgences            = [];
    	$idSites              = [];
    	$idEquipes            = [];
    	$idConseillers        = [];
    	$dateProduction       = "";

    	
    	if($request->has('dateProdHidden')){

            $dateProduction        = $request->get('dateProdHidden');
            $dateProductionCarbon  = new Carbon($dateProduction);
            $annee                 = $dateProductionCarbon->year;
            $mois                  = $dateProductionCarbon->month;
        
        }

    	$users        = User::where('users.active',1)
                            ->where('profile_id',7)
                            ->where(function($query) use ($request){

                            if($request->has('agences') and !$request->has('sites') and !$request->has('equipes') and !$request->has('conseillers')){

                               $idAgences      = $request->get('agences');
                               $query->whereIn('users.agence_id', $idAgences);

                            }

                            if($request->has('sites') and !$request->has('equipes') and !$request->has('conseillers')){

                               $idSites        = $request->get('sites');
                               $query->whereIn('users.site_id', $idSites);
                            }
                            
                            if($request->has('equipes') and !$request->has('conseillers')){
                                $query->whereHas('userEquipe', function ($q)  use ($request){

                                           $idEquipes      = $request->get('equipes');
                                           $q->whereIn('equipe_user.equipe_id', $idEquipes);
                                        
                                 });
                            }
                            

                            if($request->has('conseillers'))
                            {

                                $query->whereHas('userEquipe', function ($q)  use ($request){

                                    $idConseillers  = $request->get('conseillers');
                                    $q->whereIn('equipe_user.id', $idConseillers);
                                        
                                 });
                            }

                                

                            })
                            //->select('users.nom', 'users.prenom')
                            //->orderBy('classementsantes.CACommissionable','desc')
                            //->with('userEquipe')
                            ->get();

                            //return json_encode($users);
        foreach ($users as $user) {
        	
        	//Verifier que la ligne de comm n'est pas deja insérée

        	$ligneCommUser                  = Commissionsante::where('equipe_user_id',$user->userEquipe()->first()->pivot->id)
        													 ->where('site_id',$user->site_id)
        													 ->where('agence_id',$user->agence_id)
        													 ->where('mois',$mois)
        													 ->where('annee',$annee)
        													 ->where('active',1)
        													 ->first();

        	if(!$ligneCommUser)
            {
            	$totalCACFiche = 0;
            	$commissionsFicheSante  = collect(Commissionfichesante::where('active',1)
        										  ->where('equipe_user_id',$user->userEquipe()->first()->pivot->id)
        										  ->where('regler',0)
        										  ->get());
            	if(!$commissionsFicheSante->isEmpty())
            	{
            		foreach ($commissionsFicheSante as $commFicheSante) 
            		{        		  	
        		  		$CACFiche = ($commFicheSante['montantCommission']/$commFicheSante['tauxcommission'])*100;
        		  		$totalCACFiche += $CACFiche;
	        		}  

		        	//Insertion de la ligne de commission d'un conseiller dans le mois de production

		        	$commissionUser    				  = new Commissionsante;
		        	$commissionUser->equipe_user_id	  = $user->userEquipe()->first()->pivot->id;
		        	$commissionUser->site_id          = $user->site_id;
		        	$commissionUser->agence_id        = $user->agence_id;
		        	$commissionUser->mois      		  = $mois;
		        	$commissionUser->annee      	  = $annee;
		        	$commissionUser->objectif         = $user->objectif;
		        	$commissionUser->prime            = $commissionsFicheSante->sum('montantCommission');
		        	$commissionUser->CACommissionable = $totalCACFiche;
		        	$commissionUser->active           = 1;
		        	$commissionUser->save();

		        	$idLigneComm = $commissionUser->id;

		        	//changer l'etat des lignes comm des fichiers réglés et ajouter l'id de commission

		        	foreach ($commissionsFicheSante as $commFicheSante) {
	        			$commFicheSante->commissionsante_id = $idLigneComm;
	        			$commFicheSante->regler             = 1;
	        			$commFicheSante->save();  	
	        		  
	        		}
            	}

        		


        	}


        }



   }

   
}
