<?php

namespace App\Http\Controllers\Conseiller;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Messagerie;
use App\Statut;
use App\Statutaction;
use Auth;
use Carbon\Carbon;

class NotificationController extends Controller
{
    public function notification()
    {
       $dt         = Carbon::create((int)date('Y'), (int)date('m'), (int)date('d'));
        $dateDebut    = $dt->toDateString(); 
        $dateFin = $dt->addDays(1)->toDateString();
        $user = Auth::User();     
        $userId = $user->id;
        
        
        $nombreMessageNonLu = Messagerie::where('vu', 0)->where('to_id', $userId)->orderBy('created_at', 'desc')->get();

        $messageNonLu = Messagerie::where('vu', 0)->where('to_id', $userId)->orderBy('created_at', 'desc')->take(5)->get();

        $nombreAlerts = Statutaction::where('statut_id', 2)->where('user_id', $userId)->whereBetween('date_rappel', [$dateDebut, $dateFin])->orderBy('created_at', 'desc')->get();

        $alerts = Statutaction::where('statut_id', 2)->where('user_id', $userId)->whereBetween('date_rappel', [$dateDebut, $dateFin])->orderBy('created_at', 'desc')->take(5)->get();

        $nombreNotif = $nombreAlerts->count() + $nombreMessageNonLu->count();

         $nbrMessage = $nombreMessageNonLu->count();
         $nbrAlert   = $nombreAlerts->count();
         $reponse =["nbrMessage" => $nbrMessage, "nbrAlert" => $nbrAlert, "messageNonLu" => $messageNonLu, "alerts" => $alerts, "notif" => $nombreNotif];

       

        return $reponse;
    }
    // [ 'messageNonLu' => $messageNonLu, 'nombreMessageNonLu' => $nombreMessageNonLu, 'nombreAlerts' => $nombreAlerts, 'alerts' => $alerts, 'nombreNotif' => $nombreNotif]
}
