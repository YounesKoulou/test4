<?php

namespace App\Http\Controllers\Conseiller;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;

use App\Produit, App\Groupestatut, App\Sacompagnie, App\Sagamme, App\Agence, App\Site, App\Fichesante, App\User, App\Prestataire, App\Groupepub;

class SearchController extends Controller
{
    public function index() {

    	$compagnies  = Sacompagnie::where('active', 1)->get();
    	$produits    = Produit::where('active', 1)->get();
    	$groupStatus = Groupestatut::whereIn('slug', ['leads', 'devis', 'contrats'])->orderBy('ordre', 'asc')->get();
        $prestataires= Prestataire::where('active', 1)->orderBy('nom', 'asc')->get();

    	return view('conseillers.search', ['produits' => $produits, 'groupStatus' => $groupStatus, 'compagnies' => $compagnies, 'prestataires' => $prestataires]);
    }

    public function selectGroupeStatut(Request $request){

        $idGrpStatut    = $request->get('idGrpStatut');
        $statuts        = Groupestatut::find($idGrpStatut)->status()->where('statuts.active', 1)->lists('id', 'libelle');

        return json_encode($statuts);

    }

    public function selectPrestataire(Request $request){

        $idPrestataire  = $request->get('idPrestataire');
        return $groupePubs     = Prestataire::find($idPrestataire)->groupepubs()->where('active', 1)->lists('id', 'nom');
    }

    public function selectCompagnie(Request $request){

        $idCie          = $request->get('idCie');
        $gammes         = Sacompagnie::find($idCie)->gammes()->where('sagammes.active', 1)->lists('id', 'libelle');

        return json_encode($gammes);
    }

    public function selectGamme(Request $request){

        $idGamme        = $request->get('idGamme');
        $garanties      = Sagamme::find($idGamme)->garanties()->where('sagaranties.active', 1)->lists('id', 'libelle');

        return json_encode($garanties);
    }


    public function recherche(Request $request) {
        
        $tableName          = $request->get('produit');
        $user               = Auth::user();
        $idsUserEquipe      = $user->allUserEquipe()->lists("equipe_user.id"); 
        $Cies               = "";
        $statuts            = "";

        $idsProvGroupPub    = collect([]);

        if($request->has('groupStatus') and $request->get('groupStatus') != 0 and $request->get('status') == 0){

            $idGrpStatut    = $request->get('groupStatus');
            $statuts        = Groupestatut::find($idGrpStatut)->status()->where('statuts.active', 1)->lists('id');
        }

        
        if($request->has('compagnies') and $request->get('compagnies') != 0 and !$request->get('gammes') and !$request->get('garanties')){

            $idCie          = $request->get('compagnies');
            $Cies           = sacompagnies::find($idCie)->gammes()->where('sagammes.active', 1)->lists('id');
        }

        // if($request->get('conseiller') and !$request->get('equipe')){
        //     //return $request->get('conseiller');
        //     $idUser         = $request->get('conseiller');
        //     $idsUserEquipe  = User::find($idUser)->allUserEquipe()->lists("equipe_user.id"); 

        // }else if($request->get('conseiller') and $request->get('equipe')){
        //     //return $request->get('conseiller');
        //     $idUser         = $request->get('conseiller');
        //     $idEquipe       = $request->get('equipe');
        //     $idsUserEquipe  = User::find($idUser)->allUserEquipe()->where("equipes.id", $idEquipe)->lists("equipe_user.id"); 

        // }

        if($request->get('groupePub')){

            $idGroupPub     = $request->get('groupePub');
            $idsProvGroupPub= Groupepub::find($idGroupPub)->provenances()->lists('groupepub_provenance.id');

        }else if($request->get('prestataire')){

            $idPrestataire  = $request->get('prestataire');
            $ProvGroupPub   = "";

            $groupePubs     = Prestataire::find($idPrestataire)->groupepubs()->where('active', 1)->get();  

            foreach($groupePubs as $groupePub){

                $ProvGroupPub       = Groupepub::find($groupePub->id)->provenances()->lists('groupepub_provenance.id');
                $idsProvGroupPub    = $idsProvGroupPub->merge($ProvGroupPub);

            }

        }


        $fiches = Fichesante::join('clients', 'client_id', '=', 'clients.id')
                       
                       ->where("$tableName.active", 1)

                       ->whereIn("$tableName.equipe_user_id", $idsUserEquipe)

                       ->where(function($query) use ($request, $tableName, $statuts, $idsProvGroupPub, $Cies){
	                       	
	                       	if($request->get('nomClient')) {

	                       	    $query->where('clients.nom', 'like', "%" . $request->get('nomClient') . "%");
	                       	}

	                       	if($request->get('prenomClient')) {

	                       	    $query->where('clients.prenom', 'like', "%" . $request->get('prenomClient') . "%");
	                       	}

                            if($request->get('numComtrat')){

                                $query->where("$tableName.num_fiche", $request->get('numComtrat'));
                            } 


                            if($request->get('dateDebut') and $request->get('dateFin')){

                                $query->whereBetween($tableName.".".$request->get("typeDate"), [$request->get('dateDebut')." 00:00:00", $request->get('dateFin')." 23:59:59"]);

                            }else if($request->get('dateDebut')){

                                $query->where($tableName.".".$request->get("typeDate"), '>=', $request->get('dateDebut')." 00:00:00");

                            }else if($request->get('dateFin')){

                                $query->where($tableName.".".$request->get("typeDate"), '<=', $request->get('dateFin')." 23:59:59");
                            }  


                            if($request->has('status') and $request->get('status') != 0){

                                $query->where("$tableName.statut_id", $request->get('status'));

                            }else if($request->has('groupStatus') and $request->get('groupStatus') != 0){

                                $query->whereIn("$tableName.statut_id", $statuts);

                            }   


                            if($request->get('groupePub') or $request->get('prestataire')){

                                $query->whereIn("$tableName.groupepub_provenance_id", $idsProvGroupPub);

                            }


                            if($request->has('garanties') and $request->get('garanties') != 0){

                                $query->where("$tableName.sagarantie_id", $request->get('garanties'));

                            }else if($request->has('gammes') and $request->get('gammes') != 0){

                                $query->where("$tableName.sagamme_id", $request->get('gammes'));

                            }else if($request->has('compagnies') and $request->get('compagnies') != 0){

                                $query->whereIn("$tableName.sagamme_id", $Cies);

                            }    

                            if($request->has('hospitalisation') and $request->get('hospitalisation') != '0;0'){

                                $hospitalisation = explode(";", $request->get('hospitalisation'));                                
                                $query->whereBetween("$tableName.hospitalisation_val", [$hospitalisation[0], $hospitalisation[1]]);
                            }  

                            if($request->has('dentaire') and $request->get('dentaire') != '0;0'){

                                $dentaire = explode(";", $request->get('dentaire'));
                                $query->whereBetween("$tableName.dentaire_val", [$dentaire[0], $dentaire[1]]);
                            }  

                            if($request->has('optique') and $request->get('optique') != '0;0'){

                                $optique = explode(";", $request->get('optique'));
                                $query->whereBetween("$tableName.optique_val", [$optique[0], $optique[1]]);
                            }  

                            if($request->has('soins') and $request->get('soins') != '0;0'){

                                $soins = explode(";", $request->get('soins'));
                                $query->whereBetween("$tableName.soins_val", [$soins[0], $soins[1]]);
                            }  
                        })


                    //     ->where(function($query) use ($request, $tableName, $user, $idsUserEquipe){
                                
                    //         if($request->get('conseiller')){
                                
                    //             $query->whereIn('equipe_user_id', $idsUserEquipe);

                    //         }else if($request->get('equipe')){

                    //             $query->where('dispatchable_id', $request->get('equipe'));
                    //             $query->where('dispatchable_type', 'equipe');

                    //         }else if(!$request->get('conseiller') and !$request->get('equipe')){

                    //             $equipes     = $user->userEquipe()->where('equipe_user.active',1)->get();//retourner la liste des equipes de cet animateur
                    //             $equipeIds   = $equipes->lists('pivot.equipe_id');                                 

                    //             $query->where(function($qE) use ($equipeIds) {
                    //                 $qE->whereIn('dispatchable_id', $equipeIds);
                    //                 $qE->where('dispatchable_type', 'equipe');
                    //             });

                    //         }   
                                                                                                                        
                    //    })

                       ->with("statut", "client", "dispatchable", "userEquipe", "produit")
                       ->orderBy("$tableName.date_situation")
                       ->paginate(20);
                       //->toSql();
                       //->select('clients.nom', 'clients.prenom', 'clients.email', 'clients.tel_mobile', 'statuts.libelle as statut', "$tableName.num_fiche", "$tableName.slug", "$tableName.date_insertion", "$tableName.equipe_user_id", "$tableName.equipe_user_id", "$tableName.dispatchable_id", "$tableName.dispatchable_type" )
                       //->select('client_id', 'client.nom')
                       //->get();

        return json_encode($fiches);  

    }
}
