<?php

namespace App\Http\Controllers\Conseiller;

use Illuminate\Http\Request;
use mikehaertl\pdftk\Pdf;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class KpdfController extends Controller
{
    public function index() {

    	// Fill form with data array
		$pdf = new Pdf('upload/form.pdf');
		$pdf->fillForm(array(
		        'Nom'=>'IDBRAHIM',
		        'Email' => 'idbrahimdev@gmail.com',
		    ))
		    ->needAppearances()
		    ->saveAs('upload/filled.pdf');
		        return dd($pdf);
		    }

		
}
