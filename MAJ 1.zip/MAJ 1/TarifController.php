<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Http\Requests\TarifSanteRequest;
use App\Http\Requests\TarifObsequeRequest;

use Carbon\Carbon;
use Mail;

use App\Sacompagnie;
use App\Dossier;
use App\Parametre;
use App\Produit;
use App\Obgarantie;
use App\Sagarantie;
use App\Proposition;
use App\Fichesante;
use App\Ficheobseque;
use Crypt;


class TarifController extends Controller
{

    
    public function sante(TarifSanteRequest $request){

        $tarifLink = Parametre::whereKey('tarif_link')->first()->value;
        $tarifKey  = Parametre::whereKey('tarif_key')->first()->value;

        $dateEffet =  $request->get('dateEffet');

        $children  = $request->get('dateE');

        $data = [
                'codepostale'    => $request->get('codepostale'),
                'dateA'          => $request->get('dateA'),
                'regimeA'        => $request->get('regimeA'),
                'dateC'          => $request->has('dateC') ? $request->get('dateC') : '',
                'regimeC'        => $request->has('regimeC') ? $request->get('regimeC') : '',
                'dateE'          => $children,
                'exercice'       => Carbon::parse($dateEffet)->year,
                'key'            => $tarifKey,
                'prestation'     => $request->get('prestation'),
                'dateEffet'      => $dateEffet,
                'sansPrestation' => $request->get('sansPrestation'),
                'fichePoint'     => $request->get('fichePoint')
            ];

        $params = http_build_query($data);

        $tarif = file_get_contents($tarifLink.'webservice?'.$params);

        return json_decode($tarif);

    }


    public function obseque(TarifObsequeRequest $request){

        $tarifLink = Parametre::whereKey('tarif_link')->first()->value;
        $tarifKey  = Parametre::whereKey('tarif_key')->first()->value;

        $data = [
                'nom'                => $request->get('nom'),
                'prenom'             => $request->get('prenom'),
                'dateNaissance'      => $request->get('dateNaissance'),
                'situationFamiliale' => $request->get('situationFamiliale'),
                'codePostale'        => $request->get('codePostale'),
                'key'                => $tarifKey,
                'dateEffet'          => $request->get('dateEffet'),
                'capital'            => $request->get('capital'),
            ];

        $params = http_build_query($data);

        $tarif = file_get_contents($tarifLink.'webserviceObseque?'.$params);

        return json_decode($tarif);

    }

    public function auto(Request $request){

        $tarifLink = Parametre::whereKey('tarif_link')->first()->value;
        $tarifKey  = Parametre::whereKey('tarif_key')->first()->value;

        $data = [
                'nom'                        => $request->get('nom'),
                'prenom'                     => $request->get('prenom'),
                'dateNaissance'              => $request->get('dateNaissance'),
                'situationFamiliale'         => $request->get('situationFamiliale'),
                'profession'                 => $request->get('profession'),
                'key'                        => $tarifKey,
                'dateEffet'                  => $request->get('dateEffet'),
                'prixVehicule'               => $request->get('prixVehicule'),
                'usageVehicule'              => $request->get('usageVehicule'),
                'dateAchat'                  => $request->get('dateAchat'),
                'dateMEC'                    => $request->get('dateMEC'),
                'ModeAcquisition'            => $request->get('ModeAcquisition'),
                'codePostaleDomicile'        => $request->get('codePostaleDomicile'),
                'codePostaleTravail'         => $request->get('codePostaleTravail'),
                'VilleGarage'                => $request->get('VilleGarage'),
                'VilleDomicile'              => $request->get('VilleDomicile'),
                'etatassurancevehicule'      => $request->get('etatassurancevehicule'),
                'titulaireCarteGrise'        => $request->get('titulaireCarteGrise'),
                'conducteurSecondaire'       => $request->get('conducteurSecondaire'),
                'KilometreParcouru'          => $request->get('KilometreParcouru'),
                'PermisEuropeen'             => $request->get('PermisEuropeen'),
                'datePermis'                 => $request->get('datePermis'),
                'assureSsInterruption'       => $request->get('assureSsInterruption'),
                'bonusMalu'                  => $request->get('bonusMalu'),
                'typeGarage'                 => $request->get('typeGarage'),
                'professionConductSecond'    => $request->get('professionConductSecond'),
                'PermisEuropeenConductSecond'=> $request->get('PermisEuropeenConductSecond'),
                'datePermisConductSecond'    => $request->get('datePermisConductSecond'),
                'dateNaissanceConductSecond' => $request->get('dateNaissanceConductSecond'),
                'civilite'                   => $request->get('civilite'),
                'etatVehicule'               => $request->get('etatVehicule')
            ];

        $params = http_build_query($data);

        $tarif = file_get_contents($tarifLink.'webserviceAuto?'.$params);


        return json_decode($tarif);

    }



    // envoi BA au client
    public function emailBA(Request $request){

        $produit = Produit::whereSlug($request->get('prdSlug'))->first();

            
        if($produit){

            $ficheSlug   = $request->get('ficheSlug');
            
            $className   = "App\Fiche".$produit->slug;
            
            $fiche       = $className::whereSlug($ficheSlug)->first();

            $proposition = Proposition::find($request->get('propositionId'));

            if(!$fiche){
                return ['success' => false, 'message' => 'Fiche introuvable!!!'];
            }

            $signatureMerchantId     = Parametre::whereKey('signature_merchant_id')->first()->value;
            $signatureApplicationKey = Parametre::whereKey('signature_application_key')->first()->value;

            $transactionId = $fiche->slug;

            $user = [];

            if($fiche->equipe_user_id){

                $user = $fiche->affectedUser($fiche->equipe_user_id);

            }else{

                $user = $fiche->dispatchable->responsable();

            }

            try{

                $client  = $fiche->client;
                $societe = $fiche->societe->societe;
                
                if( $fiche->statut->slug == $produit->slug."DevisEnCours" ){
                $tabEmailUser    = explode("@", $user->email);
                $debutEmailUser  = $tabEmailUser[0];

                $tabEmailProv    = explode("@", $societe->email);
                $debutEmailProv  = $tabEmailProv[1];    

                $emailUser       = $debutEmailUser.'@'.$debutEmailProv;

                    Mail::send('emails.souscrire_devis', 
                            [

                                'societe'        => $societe, 
                                'user'           => $user,
                                'fiche'          => $fiche,
                                'produit'        => $request->get('produit'),
                                'civilitee'      => $client->civilite,//$request->get('civilitee'), 
                                'civiliteClient' => $client->civilite,//$request->get('civiliteClient'), 
                                'emailClient'    => $client->email,//$request->get('emailClient'),
                                'nomClient'      => $client->nom,//$request->get('nomClient'), 
                                'prenomClient'   => $client->prenom,//$request->get('prenomClient'),
                                'transactionId'  => $transactionId,
                                'logo'           => $user->courtier->photo,
                                'email'          => $user->email,
                                'prdSlug'        => $produit->slug,
                                'proposition'    => $proposition
                            ]
                            , function ($m) use ($request, $user, $produit, $client, $societe, $emailUser)   {

                    
                        $m->from($emailUser, $societe->nom);

                        $m->to($client->email, $client->nom.' '.$client->prenom)->subject("Votre Devis: ".$produit->libelle);

                    });

                }else if( $fiche->statut->slug == $produit->slug."DevisNonSigne" ){
                $tabEmailUser    = explode("@", $user->email);
                $debutEmailUser  = $tabEmailUser[0];

                $tabEmailProv    = explode("@", $societe->email);
                $debutEmailProv  = $tabEmailProv[1];    

                $emailUser       = $debutEmailUser.'@'.$debutEmailProv;

                    Mail::send('emails.proposition_BA', 
                            [

                                'societe'                 => $societe, 
                                'user'                    => $user,
                                'signatureApplicationKey' => $signatureApplicationKey, 
                                'signatureMerchantId'     => $signatureMerchantId, 
                                'lienPdf'                 => $request->get('lienPdf'), 
                                'dossierCompagnie'        => $request->get('dossierCompagnie'), 
                                'produit'                 => $request->get('produit'),
                                'civilitee'               => $client->civilite,//$request->get('civilitee'), 
                                'dateEffet'               => $fiche->date_effet,//$request->get('dateEffet'), 
                                'tarif'                   => $request->get('cotisation'), 
                                'garantie'                => $request->get('garantie'), 
                                'civiliteClient'          => $client->civilite,//$request->get('civiliteClient'), 
                                'emailClient'             => $client->email,//$request->get('emailClient'),
                                'nomClient'               => $client->nom,//$request->get('nomClient'), 
                                'prenomClient'            => $client->prenom,//$request->get('prenomClient'),
                                'transactionId'           => $transactionId,
                                'logo'                    => $user->courtier->photo,
                                'email'                   => $user->email,
                                'fileName'                => $request->get('fileName'),
                                'prdSlug'                 => $produit->slug
                            ]
                            , function ($m) use ($request, $user, $produit, $client, $societe, $emailUser)   {

                    
                        $m->from($emailUser, $societe->nom);

                        $m->to($client->email, $client->nom.' '.$client->prenom)->subject("Votre Devis: ".$produit->libelle);

                    });

                }

                return ['success' => true, 'message' => 'BA a été envoyé.'];

            }catch(\Exception $e){


                
               return ['success' => false, 'message' => 'probleme en envoi de mail.'];

            } 

        }else{

            return ['success' => false, 'message' => 'Produit introuvable !!!'];

        }

    }


   

    public function aprilRenfort(Request $request){

        $april_renfort       = Parametre::whereKey('april_renfort')->first()->value;
        //$april_renfort = "http://tarif.crmecg.com/aprilRenfortTest";

        //data générale
        $dateEffet      = $request->get('dateEffet');
        $codePostal     = $request->get('codepostale');
        
        //data assuré
        $dateAssure     = $request->get('dateA');
        $regimeAssure   = $request->get('regimeA');
        
        //data conjoint
        $dateConjoint   = $request->get('dateC');
        $regimeConjoint = $request->get('regimeC');
        
        //data enfants
        $children       = $request->get('dateE');
        
        $lib_gamme      = $request->get('lib_gamme');
        $lib_garantie   = $request->get('lib_garantie');
        $euro_malin     = $request->get('euro_malin');

        $dateEffet =  $request->get('dateEffet');

        $data      = [
                        'codepostale'  => $codePostal,
                        'dateA'        => $dateAssure,
                        'regimeA'      => $regimeAssure,
                        'dateC'        => $dateConjoint,
                        'regimeC'      => $regimeConjoint,
                        'dateE'        => $children,
                        'dateEffet'    => $dateEffet,
                        'euro_malin'   => $euro_malin,
                        'lib_gamme'    => $lib_gamme,
                        'lib_garantie' => $lib_garantie,
                    ];

        $params  = http_build_query($data);

        $options = file_get_contents($april_renfort.'?'.$params);

        return $options;

    }

    public function propositionLien(Request $request){

        $tableauLink = Parametre::whereKey('tableauGarantie_link')->first()->value;
        // $tarifKey  = Parametre::whereKey('tarif_key')->first()->value;
                try{

        $retour           = $request->get('q');
        $decrypterData    = base64_decode($retour);
        $donnee           = unserialize($decrypterData);


        $garanties = Sagarantie::whereIn('code', $donnee['codeGarantie'])->get();

        $data      = [
                        'garantie'         => $donnee['garantie'],
                        'codeGarantie'     => $donnee['codeGarantie'],
                        'tarif'            => $donnee['tarif'],
                        'objetProposition' => $donnee['objetProposition'],
                        'border'           => $donnee['Border']
                     ];



        $params = http_build_query($data);

        $tarif = file_get_contents($tableauLink.'?'.$params);

        $obj =  json_decode($tarif);

        $produit = '';

        $numFiche = Proposition::where('id', $donnee['objetProposition'])->first()->num_fiche;


        return view('emails.proposition_tableau',compact('obj', 'garanties', 'produit', 'numFiche')) ;

        }catch(\Exception $e){
            dd($e);
            return abort(404);
        }



        

    }

    public function propositionLienOBSEQUE(Request $request){

        $tableauLink = Parametre::whereKey('tableauGarantie_link')->first()->value;

        $tableauLinkComplet = $tableauLink.'OBSEQUE';
        // $tarifKey  = Parametre::whereKey('tarif_key')->first()->value;
                try{

        $retour           = $request->get('q');
        $decrypterData    = base64_decode($retour);
        $donnee           = unserialize($decrypterData);


        $garanties = Obgarantie::whereIn('id', $donnee['garantie'])->get();

        $data      = [
                        'garantie'         => $donnee['garantie'],
                        'tarif'            => $donnee['tarif'],
                        'objetProposition' => $donnee['objetProposition'],
                        'border'           => $donnee['Border']
                     ];

             

        $params = http_build_query($data);


        $tarif = file_get_contents($tableauLinkComplet.'?'.$params);


        $obj =  json_decode($tarif);

        $produit = 'Obseque';


        return view('emails.proposition_tableau',compact('obj', 'garanties', 'produit')) ;

        }catch(\Exception $e){

            return abort(404);
        }



        

    }

    public function retourDonneeSouscription(Request $request){

        $idProposition =  $request->get('Idproposition');
        $codeGarantie  =  $request->get('codeGarantie');

        $proposition = Proposition::find($idProposition);
        $ficheSante  = Fichesante::where('num_fiche', $proposition->num_fiche)->first();
        $produit     = '';

        if($ficheSante->statut->slug != 'santeDevisSigne'){
        
            return view('souscription.sante', compact('idProposition', 'codeGarantie', 'produit'));

        }else{

            return view("client.error");

        }

    }

    public function retourDonneeSouscriptionObseque(Request $request){

        $idProposition =  $request->get('Idproposition');
        $codeGarantie  =  $request->get('codeGarantie');

        $proposition   = Proposition::find($idProposition);
        $ficheObseque  = Ficheobseque::where('num_fiche', $proposition->num_fiche)->first();
        $produit       = 'Obseque';

        if($ficheObseque->statut->slug != 'obsequeDevisSigne'){



        return view('souscription.obseque', compact('idProposition', 'codeGarantie', 'produit'));

        }else{
                return view("client.error");
            }
        }

    public function modalDetail(Request $request){

        $formules = $request->get('formules');
        $tableauLink = Parametre::whereKey('tableauGarantie_link')->first()->value;

        $garanties           = [];
        $garantiesCodes      = [];
        $tarifsGarantie      = [];

                foreach($formules as $index => $formule){

            //$idGarantie             = $formules[$index]['id'];
            $idGarantie             = Sagarantie::where('code', $formules[$index]['code_garantie'])->first()->id;
            $tarifGarantie          = $formules[$index]['tarif'];
            $codeGarantie           = $formules[$index]['code_garantie'];
            array_push($garanties, $idGarantie);
            array_push($garantiesCodes, $codeGarantie);
            //array_push($tarifsGarantie, $tarifGarantie);
            $tarifsGarantie[$codeGarantie] = $tarifGarantie;

        }

        $dataGarantie = [

                'garantie'          => $garanties,
                'codeGarantie'      => $garantiesCodes,
                'tarif'             => $tarifsGarantie,
                'objetProposition'  => 1,
                'Border'            => ''

            ];

            $data            = serialize($dataGarantie);
            $dataCrypter     = base64_encode($data);
            $tableauGarantie = url('propositionLienTableau?q='.$dataCrypter);

        $garanties = Sagarantie::whereIn('code', $garantiesCodes)->get();

        $params = http_build_query($dataGarantie);

        $tarif = $tableauLink.'?'.$params;

        $obj =  json_decode($tarif);
        //return ['obj' => $obj, 'garanties' => $garanties];

        return $tableauGarantie ;


    }

    public function modalDetailOBSEQUE(Request $request){

        $formules = $request->get('formules');
        $tableauLink = Parametre::whereKey('tableauGarantie_link')->first()->value;

        $garanties      = [];
        $tarifsGarantie = [];

                foreach($formules as $index => $formule){


            $idGarantie             = $formules[$index]['id'];
            $tarifGarantie          = $formules[$index]['tarif'];
            $codeGarantie           = $formules[$index]['code_garantie'];
            array_push($garanties, $idGarantie);
            //array_push($tarifsGarantie, $tarifGarantie);
            $tarifsGarantie[$codeGarantie] = $tarifGarantie;

        }

        $dataGarantie = [

                'garantie'          => $garanties,
                'tarif'             => $tarifsGarantie,
                'objetProposition'     => 1,
                'Border'            => ''

            ];

            $data            = serialize($dataGarantie);
            $dataCrypter     = base64_encode($data);
            $tableauGarantie = url('propositionLienTableauOBSEQUE?q='.$dataCrypter);

        $garanties = Obgarantie::whereIn('id', $garanties)->get();

        $params = http_build_query($dataGarantie);

        $tarif = $tableauLink.'?'.$params;

        $obj =  json_decode($tarif);
        //return ['obj' => $obj, 'garanties' => $garanties];

        return $tableauGarantie ;


    }

        public function propositionLienTableau(Request $request){

        $tableauLink = Parametre::whereKey('tableauGarantie_link')->first()->value;
        // $tarifKey  = Parametre::whereKey('tarif_key')->first()->value;
                try{

        $retour           = $request->get('q');
        $decrypterData    = base64_decode($retour);
        $donnee           = unserialize($decrypterData);


        $garanties = Sagarantie::whereIn('code', $donnee['codeGarantie'])->get();

        $data      = [
                        'garantie'         => $donnee['garantie'],
                        'codeGarantie'     => $donnee['codeGarantie'],
                        'tarif'            => $donnee['tarif'],
                        'objetProposition' => $donnee['objetProposition'],
                        'border'           => $donnee['Border']
                     ];

        $params = http_build_query($data);

        $tarif = file_get_contents($tableauLink.'?'.$params);

        $obj =  json_decode($tarif);

        $produit = '';

        return view('partage.tableau_garantie',compact('obj', 'garanties', 'produit')) ;

        }catch(\Exception $e){
            dd($e);

            return abort(404);
        }
    }

    public function propositionLienTableauOBSEQUE(Request $request){

        $tableauLink = Parametre::whereKey('tableauGarantie_link')->first()->value;
        // $tarifKey  = Parametre::whereKey('tarif_key')->first()->value;
        $tableauLinkComplet = $tableauLink.'OBSEQUE';
                try{

        $retour           = $request->get('q');
        $decrypterData    = base64_decode($retour);
        $donnee           = unserialize($decrypterData);


        $garanties = Obgarantie::whereIn('id', $donnee['garantie'])->get();

        $data      = [
                        'garantie'         => $donnee['garantie'],
                        'tarif'            => $donnee['tarif'],
                        'objetProposition' => $donnee['objetProposition'],
                        'border'           => $donnee['Border']
                     ];

        $params = http_build_query($data);

        $tarif = file_get_contents($tableauLinkComplet.'?'.$params);

        $obj =  json_decode($tarif);

        $produit = 'Obseque';

        return view('partage.tableau_garantie',compact('obj', 'garanties', 'produit')) ;

        }catch(\Exception $e){
            dd($e);

            return abort(404);
        }
    }

    public function getFraisDossiers(Request $request){

        $frais = [];

        try{

            $prdSlug = $request->get('prdSlug');

            $produit = Produit::whereSlug($prdSlug)->first();

            $dossiers   = Dossier::where('produit_id', $produit->id)->with('getCompagnies')->get();
            
            foreach ($dossiers as $key => $dossier) {
                $frais[$dossier->getCompagnies->code] = $dossier->montant;
            }

            return $frais;


        }catch(\Exception $e){
            
            return $frais;

        }

    }


}
