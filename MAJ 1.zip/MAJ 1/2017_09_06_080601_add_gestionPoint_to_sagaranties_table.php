<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddGestionPointToSagarantiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('sagaranties', function (Blueprint $table) {
            $table->integer('max_point')->unsigned()->nullable()->after('sagamme_id');
            $table->integer('min_point')->unsigned()->nullable()->after('sagamme_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('sagaranties', function (Blueprint $table) {
            //
        });
    }
}
