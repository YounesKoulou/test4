<?php

namespace App\Http\Controllers\Courtier;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Agence;
use App\Site;
use App\Equipe;
use App\Groupepub; 
use App\AgenceGroupepub;
use App\SiteGroupepub;
use App\EquipeGroupepub;


class DispatchController extends Controller
{
    
    public function DispatchAgences($idGroupePub){
   
        $agences    = Agence::where('active', 1)->get(); 
        $priorites  = range(0, $agences->count());
        $groupePub  = Groupepub::find($idGroupePub);

        return view('courtiersfiles.prestataire.dispatching.dispAgences',['agences'=>$agences, 'groupePub'=>$groupePub, 'priorites'=>$priorites]);

    }

    public function DispatchAgencesUpdate($idInput, $valInput, $idGroupePub, $etatCheckbox){

        $tabIdInput         = explode('_', $idInput);
        $nomInput           = $tabIdInput[0];
        $idAgence           = $tabIdInput[1];
        $agenceGroupePub    = AgenceGroupepub::where('agence_id',$idAgence)->where('groupepub_id',$idGroupePub)->first();
        //return $etatCheckbox;

        switch ($nomInput) {

            case 'etatAgence':{

                if ($etatCheckbox == "true") {

                  if($agenceGroupePub){

                    $agenceGroupePub->active = 1;   
                    //return 1;                                    

                  }else{

                     $agenceGroupePub               = new AgenceGroupepub;
                     $agenceGroupePub->agence_id    = $idAgence;
                     $agenceGroupePub->groupepub_id = $idGroupePub; 
                     $agenceGroupePub->active       = 1;                 
                     //return 2;
                  }

                }else{

                    $agenceGroupePub->active = 0;
                    //return 3;

                }

                break;
            }

            case 'quota':{    

                $agenceGroupePub->quota = $valInput;
                break;
            }

            case 'seuil':{

                $agenceGroupePub->max_fiche = $valInput;
                break;
            }

            case 'priorite':{
                
                $agenceGroupePub->priorite = $valInput;
                break;
            }

            default:
                return 0;
                break;
        }  

        $agenceGroupePub->save();
        //return 1;

    }







    public function DispatchSites($idGroupePub, $idAgence){

        $sites      = Agence::find($idAgence)->sites->where('active',1); 
        $priorites  = range(0, $sites->count());
        $agence     = Agence::find($idAgence);
        $groupePub  = Groupepub::find($idGroupePub);
        //return $Agence;

        return view('courtiersfiles.prestataire.dispatching.dispSites',['sites'=>$sites, 'groupePub'=>$groupePub, 'priorites'=>$priorites, 'agence'=>$agence]);

    }

    public function DispatchSitesUpdate($idInput, $valInput, $idGroupePub, $etatCheckbox){

        $tabIdInput         = explode('_', $idInput);
        $nomInput           = $tabIdInput[0];
        $idSite             = $tabIdInput[1];
        $siteGroupePub      = SiteGroupepub::where('site_id',$idSite)->where('groupepub_id',$idGroupePub)->first();
        //return $siteGroupePub;
        //return $nomInput;

        switch ($nomInput) {

            case 'etatSite':{

                if ($etatCheckbox == "true") {

                  if($siteGroupePub){

                    $siteGroupePub->active = 1;   
                    //return 1;                                    

                  }else{

                     $siteGroupePub               = new SiteGroupepub;
                     $siteGroupePub->site_id      = $idSite;
                     $siteGroupePub->groupepub_id = $idGroupePub; 
                     $siteGroupePub->active       = 1;                 
                     //return 2;
                  }

                }else{

                    $siteGroupePub->active = 0;
                    //return 3;

                }

                break;
            }

            case 'quota':{    

                $siteGroupePub->quota = $valInput;
                break;
            }

            case 'seuil':{

                $siteGroupePub->max_fiche = $valInput;
                break;
            }

            case 'priorite':{
                
                $siteGroupePub->priorite = $valInput;
                break;
            }

            default:
                return 0;
                break;
        }  

        $siteGroupePub->save();
        //return 1;

    }


    public function DispatchEquipes($idGroupePub, $idSite){

        $groupePub  = Groupepub::find($idGroupePub);
        $equipes    = Site::find($idSite)->equipes->where('active',1); 
        $priorites  = range(0, $equipes->count());
        $agence     = Site::find($idSite)->agence;
        $site       = Site::find($idSite);

        return view('courtiersfiles.prestataire.dispatching.dispEquipes',['equipes'=>$equipes, 'groupePub'=>$groupePub, 'priorites'=>$priorites, 'agence'=>$agence, 'site'=>$site]);

    }

    public function DispatchEquipesUpdate($idInput, $valInput, $idGroupePub, $etatCheckbox){

        $tabIdInput         = explode('_', $idInput);
        $nomInput           = $tabIdInput[0];
        $idEquipe           = $tabIdInput[1];
        $equipeGroupePub    = EquipeGroupepub::where('equipe_id',$idEquipe)->where('groupepub_id',$idGroupePub)->first();
        //return $etatCheckbox;

        switch ($nomInput) {

            case 'etatEquipe':{

                if ($etatCheckbox == "true") {

                  if($equipeGroupePub){

                    $equipeGroupePub->active = 1;   
                    //return 1;                                    

                  }else{

                     $equipeGroupePub               = new EquipeGroupepub;
                     $equipeGroupePub->equipe_id    = $idEquipe;
                     $equipeGroupePub->groupepub_id = $idGroupePub; 
                     $equipeGroupePub->active       = 1;                 
                     //return 2;
                  }

                }else{

                    $equipeGroupePub->active = 0;
                    //return 3;

                }

                break;
            }

            case 'quota':{    

                $equipeGroupePub->quota = $valInput;
                break;
            }

            case 'seuil':{

                $equipeGroupePub->max_fiche = $valInput;
                break;
            }

            case 'priorite':{
                
                $equipeGroupePub->priorite = $valInput;
                break;
            }

            default:
                return 0;
                break;
        }  

        $equipeGroupePub->save();
        //return 1;

    }


}
