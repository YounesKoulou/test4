<?php

namespace App\Http\Controllers\Courtier;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Http\Requests\StoreAgenceRequest;
use App\Http\Requests\EditAgenceRequest;
use App\Http\Requests;
use App\Agence;
use App\User;
use App\Courtier;
use App\Produit;
use Illuminate\Support\Facades\Auth;

use Image;

class AgenceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $idcourtier = Auth::user()->courtier_id;
        // $agences    = Courtier::find($idcourtier)->agences()->paginate(5);

        //return $courtier->agences;
        // return view('courtiersfiles.agences.index',['agences' => $agences]);
        return redirect('courtier/profile');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $produits   = Produit::all();
        return view('courtiersfiles.agences.create', ['produits' => $produits]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreAgenceRequest $request)
    {        
        $agence                  = new Agence();
        $agence->nom             = $request->get('nom');
        $agence->adresse         = $request->get('adresse');
        $agence->code_postal     = $request->get('codepostal');
        $agence->ville           = $request->get('ville');
        $agence->tel             = $request->get('tel');
        $agence->fax             = $request->get('fax');
        $agence->email           = $request->get('email');
        $agence->site_web        = $request->get('siteweb');
        $agence->courtier_id     = Auth::user()->courtier_id;
        $agence->active          = 1;

        if($agence->save() and $request->get('check_produit')){

            $idsAgenceProduit = $request->get('check_produit');
            $agence->produits()->attach($idsAgenceProduit, ['active' => 1]);
        }

        return redirect('courtier/agence/'.$agence->id);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $agence       = Agence::find($id);
        $produits     = Produit::all();
        return view('courtiersfiles.agences.show',['agence' => $agence, 'produits' => $produits]);
    }


    

    public function showResp($id)
    {
        $agence             = Agence::find($id);
        $agenceAdmins       = $agence->adminsAgence;

        return view('courtiersfiles.agences.showResp',[
                                                       'agenceAdmins' => $agenceAdmins , 
                                                       'agence'       => $agence 
                                                      ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $agence             = Agence::find($id);
        //return $agence->produits->lists('id')->contains(6);
        $produits           = Produit::all();
        return view('courtiersfiles.agences.edit',['agence' => $agence, 'produits' => $produits]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(EditAgenceRequest $request, $id)
    {

        $agence                 = Agence::find($id);
        $agence->nom             = $request->get('nom');
        $agence->adresse         = $request->get('adresse');
        $agence->code_postal     = $request->get('codepostal');
        $agence->ville           = $request->get('ville');
        $agence->tel             = $request->get('tel');
        $agence->fax             = $request->get('fax');
        $agence->email           = $request->get('email');
        $agence->site_web        = $request->get('siteweb');
        $agence->courtier_id     = Auth::user()->courtier_id;

        
        //$photo                   = $request->file('photo');

        if($request->file('photo')){
                
                $img = $request->file('photo');
                $mime = Image::make($img)->mime();
               
                if( $mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif')
                {
                    $imgName       = $agence->nom.'.'.$img->getClientOriginalExtension();
                    $image         = Image::make($img)->resize(100, 100)->save('upload/avatars/agence/'.$imgName);
                    $agence->photo = $imgName;
        
                }
                else
                {
                    return redirect('courtier/agence/'.$id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
                }

        }


        if($agence->save()){

            $idsAgenceProduit = ($request->has('check_produit') ?  $request->get('check_produit') : []);
            $agence->produits()->sync($idsAgenceProduit, ['active' => 1]);
        }

        return redirect('courtier/agence/'.$agence->id);
    }


    public function activeAgence($id)
    {
        $agence  = Agence::find($id);
        
        if(count($agence))
        {
            if($agence->active)
            {
                $agence->active = 0;
                $value          = 0;
            }
            else
            {
                $agence->active = 1;
                $value          = 1;
            }

            $agence->save();
            $msg = 'ok';

        }
        else
        {
            $msg = 'notok';
        }

        return ['msg'=>$msg , 'value'=>$value];    


    }

    public function DispatchAuto($id)
    {
        $agence  = Agence::find($id);
        $msg     = "";

        if($agence->disp_auto)
        {
            $agence->disp_auto = 0;
            $msg = "Dispatching automatique désactivé.";
        }
        else
        {
            $agence->disp_auto = 1;
            $msg = "Dispatching automatique activé.";
        }

        if($agence->save()){

            return $data = ["resultat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];
        }else{

            return $data = ["resultat" => "error", "msg" => $msg, "titre" => "opération échouée !"];
        }

    }


    public function ActiveMatiere($id)
    {
        $agence  = Agence::find($id);
        $msg     = "";

        if($agence->active_matiere)
        {
            $agence->active_matiere = 0;
            $msg = "Matière désactivée.";
        }
        else
        {
            $agence->active_matiere = 1;
            $msg = "Matière activée.";
        }

        if($agence->save()){

            return $data = ["resultat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];
        }else{

            return $data = ["resultat" => "error", "msg" => $msg, "titre" => "opération échouée !"];
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
