<?php

namespace App\Http\Controllers\Courtier;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
//use App\Http\Controllers\Auth;
use App\Http\Requests;
use Illuminate\Support\Facades\Auth;

use App\Events\EventNotifications;

use App\Events\EventTracesSante;
use App\Events\EventStatutSante;
use App\Events\EventDevisValideSante;
use App\Events\EventValidationContratSante;
use App\Events\EventRejetDevisSante;
use App\Events\EventRejetContratSante;
use App\Events\EventResilContratSante;

use App\Events\EventTracesObseque;
use App\Events\EventStatutObseque;
use App\Events\EventDevisValideObseque;
use App\Events\EventValidationContratObseque;
use App\Events\EventRejetDevisObseque;
use App\Events\EventRejetContratObseque;
use App\Events\EventResilContratObseque;

use App\Courtier;
use App\Agence;
use App\Categoryequipe;
use App\Equipe;
use App\Profile;
use App\Site;
use App\User;
use App\Produit;
use App\Fichesante;
use App\Ficheobseque;
use App\Saregime;
use App\Groupeproduit;
use App\Documentfiche;
use App\Client;
use App\ClientProduit;
use App\Statutaction;
use App\Equipeuser;
use App\Statut;
use App\Action;
use App\Tracessante;
use App\Notification;

use Carbon\Carbon;
use Session;
use Image;


class CourtierController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //$site  = Site::find($id);
        $courtier             = Auth::user()->courtier;

        return view('courtiersfiles.courtiers.edit',['courtier'=>$courtier]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //$site                  = Site::find($id);
        $courtier                   = Auth::user()->courtier;
        $courtier->nom              = $request->get('nom');
        $courtier->adresse          = $request->get('adresse');
        $courtier->code_postal      = $request->get('codepostal');
        $courtier->ville            = $request->get('ville');
        $courtier->tel              = $request->get('tel');
        $courtier->fax              = $request->get('fax');
        $courtier->email            = $request->get('email');
        $courtier->site_web         = $request->get('siteweb');
        $courtier->orias            = $request->get('orias');
        if($request->file('logoApplication')){
                
                $img                = $request->file('logoApplication');
                $mime               = Image::make($img)->mime();
                if( $mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif')
                {
                    $imgName        = time().'.'.$img->getClientOriginalExtension();
                    $courtier->photo= $imgName;
                    $image          = Image::make($img)->resize(240, 47)->save('upload/avatars/courtier/'.$imgName);
                }
                else
                {
                    return redirect('site/site/'.$site->id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
                }

        }

        

        $courtier->save();

        $user                       = Auth::user();
        $user->nom                  = $request->get('nomUser');
        $user->prenom               = $request->get('prenomUser');
        $user->login                = $request->get('loginUser');
        $user->email                = $request->get('emailUser');
        $user->tel                  = $request->get('telUser');
        $user->fax                  = $request->get('faxUser');
        $user->id_appel             = $request->get('idAppel');
        if($request->file('photo')){
                
                $img                = $request->file('photo');
                $mime               = Image::make($img)->mime();
                if( $mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif')
                {
                    $imgName        = $user->nom.'.'.$img->getClientOriginalExtension();
                    $user->photo    = $imgName;
                    $image          = Image::make($img)->resize(100, 100)->save('upload/avatars/'.$imgName);
                }
                else
                {
                    return redirect('site/site/'.$site->id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
                }

        }

        $user->save();

        return redirect('courtier/profile');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


       //liste des fiches a valider par l'animateur
    public function leads($status=null) {       

        
        if(!Session::has('produit_id')){
            
            $productsession = Produit::whereSlug("sante")->first();
            Session::put('produit_id', $productsession->id);
        }

        if(!$status){

            $status     = Statut::find(1);
        }

        $id             = Session::get('produit_id');// id produit
        $produit        = Produit::find($id); //retourner le produit 
        $produits       = Produit::whereActive(1)->get(); // retourner la liste des produits  
        $conseillers    = User::where('profile_id',7)->get();
        $equipes        = Equipe::where('active',1)->get();
        $groupeStatus   = Statut::find($status)->groupeStatus;   

        if($produit->slug) {

            $classFicheProduit   = 'App\Fiche'.$produit->slug; 

            $fiches = $classFicheProduit::whereActive(1)
                                        ->where('produit_id', $id)
                                        ->where('statut_id', $status)
                                        ->orderBy('updated_at', 'desc')
                                        ->get();
                                        
            switch($groupeStatus->slug) {

                case 'leads':
                    return view('equipesfiles.equipes.leads_'.$produit->slug, ['produits' => $produits, 'equipes' => $equipes, 'fiches' => $fiches, 'statusId' => $status, 'conseillers' => $conseillers]);
                    break;

                case 'devis':
                    return view('equipesfiles.equipes.devis_'.$produit->slug, ['produits' => $produits, 'equipes' => $equipes, 'fiches' => $fiches, 'statusId' => $status, 'conseillers' => $conseillers]);
                    break;

                case 'contrats':
                    return view('equipesfiles.equipes.contrats_'.$produit->slug, ['produits' => $produits, 'equipes' => $equipes, 'fiches' => $fiches, 'statusId' => $status, 'conseillers' => $conseillers]);
                    break;
                
                default:
                    return view('equipesfiles.equipes.leads_'.$produit->slug, ['produits' => $produits, 'equipes' => $equipes, 'fiches' => $fiches, 'statusId' => $status, 'conseillers' => $conseillers]);
                    break;                
                
            }

        }

        //$produits = Produit::whereActive(1)->get();

        return view('conseillers.dashboard', ['produits' => $produits, 'fiches' => $fiches]);

    }


    public function changeProduit(Request $request, $id){

        if($request->has('statusId')){
            $statusId = $request->get('statusId');
        }else{
            $statusId = 1;
        }

        if(!$id){
            Session::put('produit_id', 1);
        }else{
            Session::put('produit_id', $id);
        }

        return $statusId;

    }

        public function changeEquipe(Request $request, $id){

        if($request->has('statusId')){
            $statusId = $request->get('statusId');
        }else{
            $statusId = 1;
        }

        if(!$id){
            Session::put('equipe_id', 1);
        }else{
            Session::put('equipe_id', $id);
        }

        return $statusId;

    }

    public function showLead($slug, $id) {

        $ficheStatus        = [];
        
        $produit            = Produit::whereSlug($slug)->first();
        
        $produit            = Produit::find($produit->id);
        
        $groupePrd          = $produit->groupeProduit;
        
        $regimes            = Saregime::whereActive(1)->get();
        
        $groupeProduitsList = Groupeproduit::whereActive(1)->with('produits')->get();
        
        $documents          = Documentfiche::where('produit_id', $produit->id)->get();

        switch($produit->slug) {

            case 'sante':

                $fiche = Fichesante::find($id);
                
                $fiche->increment('nbr_vu');
                
                $groupeProduits = $this->groupeProduitsClient($fiche->client_id);

                $contrats       = Fichesante::getContrats($fiche->client_id, $groupePrd->id);

                $ficheStatus    = Statutaction::where('actionable_id', $id)
                                            ->where('actionable_type', 'fichesantes')
                                            ->orderBy('created_at', 'desc')
                                            ->get();

                break;


            case 'obseque':

                $fiche = Ficheobseque::find($id);

                $fiche->increment('nbr_vu');
                
                $groupeProduits = $this->groupeProduitsClient($fiche->client_id);

                $contrats       = Ficheobseque::getContrats($fiche->client_id, $groupePrd->id);

                $ficheStatus    = [];
                
                $produit_id     = Session::get('produit_id');

                $ficheStatus    = Statutaction::where('actionable_id', $id)
                                            ->where('actionable_type', 'ficheobseques')
                                            ->orderBy('created_at', 'desc')
                                            ->get();


                break;

            default :

                return "default";

        }

        return view("conseillers.$produit->slug", [
                                    'groupeProduits'     => $groupeProduits,
                                    'fiche'              => $fiche,
                                    'regimes'            => $regimes,
                                    'contrats'           => $contrats,
                                    'ficheStatus'        => $ficheStatus,
                                    'groupeProduitsList' => $groupeProduitsList,
                                    'documents'          => $documents,
                                ]
            );
    


    }

    public function groupeProduitsClient($client_id){

        $client = Client::find($client_id);
        //$client->getGroupesProduit();

        $produitIds     = ClientProduit::where('client_id',$client_id)
                                        ->groupBy('produit_id')
                                        ->lists('produit_id');
                
        $gpIds          = Produit::whereIn('id',$produitIds)
                                    ->groupBy('groupeproduit_id')
                                    ->lists('groupeproduit_id');
                
        return $groupeProduits = Groupeproduit::whereIn('id',$gpIds)->get();

    }


    public function dispatchLeads(Request $request)
    {

        $userInfo = $this->userInfo();
        
        $agenceId      = $request->get('agence');
        $siteId        = $request->get('site');
        $equipeId      = $request->get('equipe');
        $conseillerId  = $request->get('conseiller');
        $produitId     = $request->get('produit');
        $arrayIdFiches = $request->get('arrayIdLeads');

        $produit       = Produit::find($produitId);
        $produitSlug   = $produit->slug;


        $equipeUser  = null;
        $observation = null;
        $actionSlug  = 'AFC';

        $userList    = [];

        if($conseillerId)
        {

            $actionSlug  = 'AFC';
            $equipeUser  = Equipeuser::where('user_id',$conseillerId)
                                        ->where('equipe_id',$equipeId)
                                        ->first();
            $user        = $equipeUser->user;
            $observation = "<i class='uk-icon-institution'></i> ".$equipeUser->equipe->site->agence->nom."<br><i class='uk-icon-map-marker'></i> ".$equipeUser->equipe->site->nom."<br><i class='uk-icon-group'></i> ".$equipeUser->equipe->nom."<br><i class='uk-icon-user'></i> ". strtoupper($user->nom)." ".ucfirst($user->prenom)." (".$user->login.")"; 

            array_push($userList, $equipeUser->user);
            if($equipeUser->equipe->responsable()){
                array_push($userList, $equipeUser->equipe->responsable());  
            }

        }
        elseif($equipeId)
        {

            $actionSlug  = 'AFRE';
            $equipe      = Equipe::find($equipeId);
            $observation = "<i class='uk-icon-institution'></i> ".$equipe->site->agence->nom."<br><i class='uk-icon-map-marker'></i> ".$equipe->site->nom."<br><i class='uk-icon-group'></i> ".$equipe->nom;

            if($equipe->responsable()){
                array_push($userList, $equipe->responsable());
            }

        }
        elseif($siteId)
        {
            
            $actionSlug  = 'AFRS';
            $site        = Site::find($siteId);
            $observation = "<i class='uk-icon-institution'></i> ".$site->agence->nom."<br><i class='uk-icon-map-marker'></i> ".$site->nom;

            if($site->responsable()){
                array_push($userList, $site->responsable());
            }
            
        }
        else 
        {

            $actionSlug  = 'AFRA';
            $agence      = Agence::find($agenceId);
            $observation = "<i class='uk-icon-institution'></i> ".$agence->nom;  

            if($agence->responsable()){
                array_push($userList, $agence->responsable());
            }

        }

        $idAction = Action::whereSlug($actionSlug)->value('id');
        $idStatut = Statut::whereSlug($produitSlug.'Appel')->value('id');

        foreach ($arrayIdFiches as $Idfiche) {

            $className = 'App\Fiche'.$produitSlug;
            
            $fiche  = $className::find($Idfiche);
            
            if($conseillerId)
            {
                $equipeUser   = Equipeuser::where('user_id',$conseillerId)
                                        ->where('equipe_id',$equipeId)
                                        ->first();

                $fiche->equipe_user_id    = $equipeUser->id;
                $fiche->dispatchable_id   = $equipeUser->equipe_id;
                $fiche->dispatchable_type = 'equipe';
            }
            elseif($equipeId)
            {
                $fiche->dispatchable_id   = $equipeId;
                $fiche->dispatchable_type = 'equipe';
            }
            elseif($siteId)
            {
                $fiche->dispatchable_id   = $siteId;
                $fiche->dispatchable_type = 'site';
            }
            else 
            {
                $fiche->dispatchable_id   = $agenceId;
                $fiche->dispatchable_type = 'agence';
            }
            
            if($fiche->save()){

                $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
                $event = 'App\Events\EventTraces'.ucfirst($produitSlug);
                event(new $event($tabInfoTrace));

            }

        }

        $notif        = Notification::whereSlug('LEADDISPATCH')->first();
        
        $description  = "Vous avez reçu ".(count($arrayIdFiches) > 1 ? count($arrayIdFiches)." fiches" : "une fiche")." ".$produit->libelle;
        
        $notification = [
            'user_id'         => null,
            'notification_id' => $notif->id,
            'notifiable_id'   => $arrayIdFiches[0],
            'notifiable_type' => $produit->table_produit,
            'rappel_time'     => null,
            'link'            => null,
            'type'            => 'dispatch',
            'description'     => $description
        ];


        foreach ($userList as $usr) {

            $notification['user_id'] = $usr->id;
            $notification['link']    = url($usr->profile->slug.'/leads/'.$idStatut);

            event(new EventNotifications($notification));

        }

        return "Dispatché";

    }


    /**
     * change le statut d'une ou plusieurs fiches
     */
    public function changeStatusLeads(Request $request)
    {
        $userInfo      = $this->userInfo();
        
        $statutId      = $request->get('statut');
        $produitId     = $request->get('produit');
        $arrayIdFiches = $request->get('arrayIdLeads');

        $produit       = Produit::find($produitId);
        $produitSlug   = $produit->slug;

        $statut = Statut::find($statutId);

        $newStatut = $statut->libelle;

        $idAction      = Action::whereSlug('CS')->value('id');

        $className = "App\Fiche".$produitSlug;
        //                       ->whereIn('id', $arrayIdFiches)
        //                       ->update(['statut_id' => $statutId]);

        foreach ($arrayIdFiches as $Idfiche) {
            
            $fiche    = $className::find($Idfiche);

            $oldStatut = $fiche->statut->libelle;

            $fiche->statut_id      = $statut->id;
            $fiche->date_situation = Carbon::now();

            if($fiche->save()){
                
                $observation  = "<i class='uk-text-danger material-icons'>&#xE14C;</i> ".$oldStatut."<br><i class='uk-text-success material-icons'>&#xE876;</i> ".$newStatut;
                
                $motif        = $request->has('modalMotifId') ? $request->get('modalMotifId') : null;
                
                $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
                
                $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
                event(new $event($tabInfoTrace));

            }

        }

        return [
                    "success"   => true,
                    "message"   => "Statut Changé",
                    "statutLib" => $newStatut
                ];

    }

    public function redirectLead($grPrd, $client_id){

        $prd     = Groupeproduit::find($grPrd)->produits()->lists('id');
        
        $cltPrd  = ClientProduit::where('client_id', $client_id)->whereIn('produit_id',$prd)->orderBy('nombre', 'desc')->first();
        
        if(!$cltPrd){
            return redirect('site/leads/1');
        }

        $produitSlug = Produit::find($cltPrd->produit_id)->slug;

        

        switch($produitSlug) {

            // produit Santé
            case "sante":

                $fiche = Fichesante::where('client_id', $client_id)->whereActive(1)->orderBy('date_insertion', 'desc')->first();

                break;

            case "obseque":

                $fiche = Ficheobseque::where('client_id', $client_id)->whereActive(1)->orderBy('date_insertion', 'desc')->first();

                break;

            case "auto":

                break;

            default :

                return redirect('site/leads/1');

                break;
        }

        return redirect('site/leads/'.$produitSlug.'/'.$fiche->id);
    }


    public function DispatchAuto($id)
    {
        $equipe  = Equipe::find($id);

        if($equipe->disp_auto)
        {
            $equipe->disp_auto = 0;
            $active = 0;
        }
        else
        {
            $equipe->disp_auto = 1;
            $active = 1;
        }

        $equipe->save();


        return $active;

    }


    public function ActiveMatiere($id)
    {
        $equipe  = Equipe::find($id);

        if($equipe->active_matiere)
        {
            $equipe->active_matiere = 0;
            $active = 0;
        }
        else
        {
            $equipe->active_matiere = 1;
            $active = 1;
        }

        $equipe->save();


        return $active;

    }


    public function validationDevisCourtier(Request $request){

        $userInfo = $this->userInfo();

        //$equipe                         = Equipe::find($id);
        $idFiche         = $request->get('ficheId'); 
        $observation     = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet      = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
        $statusId        = ($request->get('statusId')) ? $request->get('statusId') : null ; 
        $resultat        = 'ko';

        $slug        = $request->get('slug');
        $nameClass   = "App\Fiche".$slug;
        $eventTrace  = 'App\Events\EventTraces'.ucfirst($slug);
        $eventStatut = 'App\Events\EventStatut'.ucfirst($slug);

        if($idFiche){

            $fiche       = $nameClass::find($idFiche);
            $statutActu  = Statut::find($statusId);

            switch ($statutActu->slug) {

                case 'devis':
                    $slugNouvStatut   = 'devisComplet';
                    $action           = 'VDC';
                    break;

                case 'devisComplet':
                    $slugNouvStatut   = 'devisValide';
                    $action           = 'VDA';
                    break;

                case 'devisRejete':
                    $slugNouvStatut   = 'devisValide';
                    $action           = 'VDA';
                    break;

                case 'devisValide':
                    $slugNouvStatut   = 'nnSigne';
                    $action           = 'VDG';
                    break;
                
                case 'nnSigne':
                    $slugNouvStatut   = 'signe';
                    $action           = 'VCNSG';
                    break;

                case 'signe':
                    $slugNouvStatut   = 'client';
                    $action           = 'VCSG';
                    break;

                default:
                    $resultat         = 'NA';
                    break;
            }
                        
            //return $fiche->id;

            if($fiche and $resultat != 'NA'){

                $statut   = Statut::where('slug', $slugNouvStatut)->first();

                if($statut->groupeStatus->slug=='leads'){
                    $fiche->date_situation = $fiche->date_insertion;
                }elseif($statut->groupeStatus->slug=='devis'){
                    $fiche->date_situation = Carbon::now();
                }elseif($statut->groupeStatus->slug=='contrats'){
                    $fiche->date_situation = Carbon::now();
                }

                $fiche->statut_id = $statut->id;

                if($fiche->save()){

                    $idAction     = Action::where('slug',$action)->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $idFiche, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => $motifRejet, 'idStatut' => $statut->id];
                    event(new $eventTrace($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut = ['idAction' => $idAction, 'idFiche' => $idFiche, 'observation' => $observation, 'motif' => $motifRejet, 'slugProduit' => $slugProduit, 'idStatut' => $statut->id];
                    event(new $eventStatut($tabInfoTraceStatut));
                    
                    //event modification classement dans le cas d'un devis ou contrat validé
                    if($slugNouvStatut == 'devisValide')
                    {
                        $tabInfosDevisValide = ['idFiche' => $idFiche];
                        event(new EventDevisValideSante($tabInfosDevisValide));
                    }
                    elseif ($slugNouvStatut == 'nnSigne') {
                        $tabInfosValidationContrat = ['idFiche' => $idFiche];
                        event(new EventValidationContratSante($tabInfosValidationContrat));
                    }
                    
                    
                    $resultat     = 'ok';
                    
                }
            }
        }

        return $resultat;        
    }


    public function rejetDevisCourtier(Request $request){

        $userInfo = $this->userInfo();

        //$equipe                         = Equipe::find($id);
        $idFiche         = $request->get('ficheId'); 
        $observation     = ($request->get('observation')) ? $request->get('observation') : "" ;
        $motifRejet      = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ; 
        $statusId        = ($request->get('statusId')) ? $request->get('statusId') : null ; 
        $resultat        = 'ko';

        $slug        = $request->get('slug');
        $nameClass   = "App\Fiche".$slug;
        $eventTrace  = 'App\Events\EventTraces'.ucfirst($slug);
        $eventStatut = 'App\Events\EventStatut'.ucfirst($slug);

        if($idFiche){

            $fiche       = $nameClass::find($idFiche);
            $statutActu  = Statut::find($statusId);

            switch ($statutActu->slug) {

                case 'devisValide':
                    $slugNouvStatut   = 'devisRejete';
                    $action           = 'RDG';  
                    break;

                case 'nnSigne':
                    $slugNouvStatut   = 'devisRejete';
                    $action           = 'RDG';  
                    break;
                
                case 'signe':
                    $slugNouvStatut   = 'devisRejete';
                    $action           = 'RDG';  
                    break;

                case 'client':
                    $slugNouvStatut   = 'devisRejete';
                    $action           = 'RDG';  
                    break;

                default:
                    $resultat         = 'NA';
                    break;
            }
          
                        
            //return $fiche->id;

            if($fiche and $resultat != 'NA'){

                $statut   = Statut::where('slug', $slugNouvStatut)->first();

                if($statut->groupeStatus->slug=='leads'){
                    $fiche->date_situation = $fiche->date_insertion;
                }elseif($statut->groupeStatus->slug=='devis'){
                    $fiche->date_situation = Carbon::now();
                }elseif($statut->groupeStatus->slug=='contrats'){
                    $fiche->date_situation = Carbon::now();
                }

                $fiche->statut_id = $statut->id;

                if($fiche->save()){

                    $idAction     = Action::where('slug',$action)->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $idFiche, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => $motifRejet, 'idStatut' => $statut->id];
                    event(new $eventTrace($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut = ['idAction' => $idAction, 'idFiche' => $idFiche, 'observation' => $observation, 'motif' => $motifRejet, 'slugProduit' => $slugProduit, 'idStatut' => $statut->id];
                    event(new $eventStatut($tabInfoTraceStatut));

                    //event modification classement dans le cas d'un devis ou contrat rejeté
                    if($statutActu->slug == 'devisValide')
                    {
                        $tabInfosRejetDevis = ['idFiche' => $idFiche];
                        event(new EventRejetDevisSante($tabInfosRejetDevis));
                    }
                    elseif ($statutActu->slug == 'nnSigne' or $statutActu->slug == 'signe') {
                        $tabInfosRejetContrat = ['idFiche' => $idFiche];
                        event(new EventRejetContratSante($tabInfosRejetContrat));
                    }
                    

                                        
                    $resultat     = 'ok';
                    
                }
            }
        }

        return $resultat;
    }


    public function resilContratCourtier(Request $request){

        $userInfo = $this->userInfo();

        //$equipe                         = Equipe::find($id);
        $idFiche         = $request->get('ficheId'); 
        $motifResil      = ($request->get('motifResil')) ? $request->get('motifResil') : null ; 
        $statusId        = ($request->get('statusId')) ? $request->get('statusId') : null ;
        $dateResil       = ($request->get('dateResil')) ? $request->get('dateResil') : null ; 
        $resultat        = 'ok';
        if(!$motifResil and !$dateResil)
        {
            return response()->json(['etat'=>'ko' , 'msg'=>'merci de renseigner le motif résil et la date résiliation !!']);
        }
        else if(!$motifResil and $dateResil)
        {
            return response()->json(['etat'=>'ko' , 'msg'=>'merci de renseigner le motif résil!']);
        }
        else if($motifResil and !$dateResil)
        {
            return response()->json(['etat'=>'ko' , 'msg'=>'merci de renseigner la date résiliation !!']);
        }

        $slug        = $request->get('slug');
        $nameClass   = "App\Fiche".$slug;
        $eventTrace  = 'App\Events\EventTraces'.ucfirst($slug);
        $eventStatut = 'App\Events\EventStatut'.ucfirst($slug);

        if($idFiche){

            $fiche          = $nameClass::find($idFiche);
            $statutActu     = Statut::find($statusId); 


            switch ($statutActu->slug) {
                
                case 'clientNonSigne':
                    $slugNouvStatut = 'resiliation';
                    $action         = 'RC';  
                    break;

                case 'client':
                    $slugNouvStatut = 'resiliation';
                    $action         = 'RC';  
                    break;

                default:
                    $resultat       = 'NA';
                    break;
            }
          
                        
            //return $fiche->id;

            if($fiche and $resultat != 'NA'){

                $statut   = Statut::where('slug', $slugNouvStatut)->first();

                $fiche->date_reprise   = $dateResil;
                $fiche->date_situation = Carbon::now();
                $fiche->statut_id      = $statut->id;

                if($fiche->save()){

                    $idAction     = Action::where('slug',$action)->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $idFiche, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => '', 'motif' => $motifResil, 'idStatut' => $statut->id];
                    event(new $eventTrace($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut = ['idAction' => $idAction, 'idFiche' => $idFiche, 'observation' => '', 'motif' => $motifResil, 'slugProduit' => $slugProduit, 'idStatut' => $statut->id];
                    event(new $eventStatut($tabInfoTraceStatut));

                    //Calculer le nombre de mois réglé
                    $dateEffetCar       = new Carbon($fiche->date_effet);
                    $dateResilCar       = new Carbon($dateResil);
                    $nbreMoisRegle      = $dateEffetCar->diffInMonths($dateResilCar,false);

                    //event résiliation contrat et insertion d'une ligne decomm
                    $tabInfosResilContrat = ['idFiche' => $idFiche,'nbreMoisRegle' => $nbreMoisRegle];
                    event(new EventResilContratSante($tabInfosResilContrat));
                    
                    //$resultat     = 'ok';
                    return response()->json(['etat'=>'ok' , 'msg'=>'Opération effectuée !!']);
                    
                }
            }
        }

        return $resultat;
    }

    public function annulContratCourtier(Request $request){

        $userInfo = $this->userInfo();

        //$equipe                         = Equipe::find($id);
        $idFiche            = $request->get('ficheId'); 
        $motifAnnulation    = ($request->get('motifAnnulation')) ? $request->get('motifAnnulation') : null ; 
        $statusId           = ($request->get('statusId')) ? $request->get('statusId') : null ;
        $dateAnnulation     = ($request->get('dateAnnulation')) ? $request->get('dateAnnulation') : null ; 
        $resultat           = 'ok';
        if(!$motifAnnulation and !$dateAnnulation)
        {
            return response()->json(['etat'=>'ko' , 'msg'=>'merci de renseigner le motif annulation et la date annulation !!']);
        }
        else if(!$motifAnnulation and $dateAnnulation)
        {
            return response()->json(['etat'=>'ko' , 'msg'=>'merci de renseigner le motif annulation!']);
        }
        else if($motifAnnulation and !$dateAnnulation)
        {
            return response()->json(['etat'=>'ko' , 'msg'=>'merci de renseigner la date annulation !!']);
        }

        $slug        = $request->get('slug');
        $nameClass   = "App\Fiche".$slug;
        $eventTrace  = 'App\Events\EventTraces'.ucfirst($slug);
        $eventStatut = 'App\Events\EventStatut'.ucfirst($slug);

        if($idFiche){

            $fiche          = $nameClass::find($idFiche);
            $statutActu     = Statut::find($statusId); 


            switch ($statutActu->slug) {
                
                case 'nnSigne':
                    $slugNouvStatut = 'annulation';
                    $action         = 'AC';  
                    break;

                case 'signe':
                    $slugNouvStatut = 'annulation';
                    $action         = 'AC';  
                    break;

                default:
                    $resultat       = 'NA';
                    break;
            }
          
                        
            //return $fiche->id;

            if($fiche and $resultat != 'NA'){

                $statut   = Statut::where('slug', $slugNouvStatut)->first();

                $fiche->date_reprise   = $dateAnnulation;
                $fiche->date_situation = Carbon::now();
                $fiche->statut_id      = $statut->id;

                if($fiche->save()){

                    $idAction     = Action::where('slug',$action)->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $idFiche, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => '', 'motif' => $motifAnnulation, 'idStatut' => $statut->id];
                    event(new $eventTrace($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut = ['idAction' => $idAction, 'idFiche' => $idFiche, 'observation' => '', 'motif' => $motifAnnulation, 'slugProduit' => $slugProduit, 'idStatut' => $statut->id];
                    event(new $eventStatut($tabInfoTraceStatut));
                    
                    //$resultat     = 'ok';
                    return response()->json(['etat'=>'ok' , 'msg'=>'Opération effectuée !!']);
                    
                }
            }
        }

        return $resultat;
    }



    public function validateDevisSante(Request $request){

        $statut = [];
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
    
        if($idFiche){

            $fiche  = Fichesante::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="santeDevisNonSigne" or $fiche->statut->slug=="santeDevisSigne"){

                $statut = Statut::where('slug', 'santeContratDepot')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'VDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => null, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesSante($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => null, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutSante($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('DEVISSANTEVAL')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosDevisValide = ['idFiche' => $idFiche];
                    //event(new EventDevisValideSante($tabInfosDevisValide));
                    

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." validé",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function rejectDevisSante(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
    
        if($idFiche){

            $fiche = Fichesante::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="santeDevisNonSigne" or $fiche->statut->slug=="santeDevisSigne"){

                $statut                = Statut::where('slug', 'santeDevisRejete')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'RDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => $motifRejet, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesSante($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => $motifRejet, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutSante($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('DEVISSANTEREJ')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosRejetDevis = ['idFiche' => $idFiche];
                    //event(new EventRejetDevisSante($tabInfosRejetDevis));

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." rejeté",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    
    public function validateContratSante(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
    
        if($idFiche){

            $fiche = Fichesante::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="santeContratDepot") {

                $statut                = Statut::where('slug', 'santeContratEnAttente')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'VCSG')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => null, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesSante($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => null, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutSante($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('CONTRATSANTEVAL')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosValidationContrat = ['idFiche' => $idFiche];
                    //event(new EventValidationContratSante($tabInfosValidationContrat));
                    
                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Contrat numéro : ".$fiche->id." validé",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function rejectContratSante(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
    
        if($idFiche){

            $fiche = Fichesante::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="santeContratDepot" or $fiche->statut->slug=="santeContratEnAttente" or $fiche->statut->slug=="santeClient"){

                if($fiche->statut->slug=="santeContratDepot"){
                    $statut = Statut::where('slug', 'santeAdhesionRejete')->first();
                }else{
                    $statut = Statut::where('slug', 'santeContratRejete')->first();
                }   
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'RDG')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => $motifRejet, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesSante($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => $motifRejet, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutSante($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('CONTRATSANTEREJ')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosRejetContrat = ['idFiche' => $idFiche];
                    //event(new EventRejetContratSante($tabInfosRejetContrat));

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Contrat numéro : ".$fiche->id." rejeté",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function validateDevisObseque(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
    
        if($idFiche){

            $fiche = Ficheobseque::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="obsequeDevisNonSigne" or $fiche->statut->slug=="obsequeDevisSigne"){

                $statut                = Statut::where('slug', 'obsequeContratDepot')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'VDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => null, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesObseque($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => null, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutObseque($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('DEVISOBSEQUEVAL')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosDevisValide = ['idFiche' => $idFiche];
                    //event(new EventDevisValideSante($tabInfosDevisValide));

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." validé",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function rejectDevisObseque(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
    
        if($idFiche){

            $fiche = Ficheobseque::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="obsequeDevisNonSigne" or $fiche->statut->slug=="obsequeDevisSigne"){

                $statut                = Statut::where('slug', 'obsequeDevisRejete')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'RDA')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => $motifRejet, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesObseque($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => $motifRejet, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutObseque($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('DEVISOBSEQUEREJ')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Devis numéro : ".$fiche->id." rejeté",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function validateContratObseque(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
    
        if($idFiche){

            $fiche = Ficheobseque::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="obsequeContratDepot") {

                $statut                = Statut::where('slug', 'obsequeContratEnAttente')->first();
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'VCSG')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => null, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesObseque($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => null, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutObseque($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('CONTRATOBSEQUEVAL')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosValidationContrat = ['idFiche' => $idFiche];
                    //event(new EventValidationContratSante($tabInfosValidationContrat));
                    
                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Contrat numéro : ".$fiche->id." validé",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function rejectContratObseque(Request $request){
        
        $userInfo    = $this->userInfo();
        
        $idFiche     = $request->get('ficheId'); 
        $observation = ($request->get('observation')) ? $request->get('observation') : "" ; 
        $motifRejet  = ($request->get('motifRejet')) ? $request->get('motifRejet') : null ;
    
        if($idFiche){

            $fiche = Ficheobseque::find($idFiche);

            $statut = $fiche->statut;

            if($fiche->statut->slug=="obsequeContratDepot" or $fiche->statut->slug=="obsequeContratEnAttente" or $fiche->statut->slug=="obsequeClient"){

                if($fiche->statut->slug=="obsequeContratDepot"){
                    $statut = Statut::where('slug', 'obsequeAdhesionRejete')->first();
                }else{
                    $statut = Statut::where('slug', 'obsequeContratRejete')->first();
                }   
                
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();

                if($fiche->save()){

                    $userInfo['tracable_id'] = $fiche->dispatchable_id;

                    $idAction     = Action::where('slug', 'RDG')->value('id');
                    $tabInfoTrace = [
                                        'idAction'       => $idAction, 
                                        'idFiche'        => $idFiche, 
                                        'equipe_user_id' => $userInfo['equipe_user_id'], 
                                        'tracable_id'    => $userInfo['tracable_id'], 
                                        'tracable_type'  => $userInfo['tracable_type'], 
                                        'observation'    => $observation, 
                                        'motif'          => $motifRejet, 
                                        'idStatut'       => $statut->id
                                    ];
                    event(new EventTracesObseque($tabInfoTrace));

                    $slugProduit        = 'fiche'.$fiche->produit->slug.'s';
                    $tabInfoTraceStatut =   [
                                                'idAction'    => $idAction, 
                                                'idFiche'     => $idFiche, 
                                                'observation' => $observation, 
                                                'motif'       => $motifRejet, 
                                                'slugProduit' => $slugProduit, 
                                                'idStatut'    => $statut->id
                                            ];
                    event(new EventStatutObseque($tabInfoTraceStatut));

                    // Notification Event

                    $userList = [];

                    if($fiche->equipe_user_id){

                        array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }else{

                        if($fiche->dispatchable->responsable()){
                            array_push( $userList, $fiche->dispatchable->responsable() );
                        }

                    }

                    $notif = Notification::whereSlug('CONTRATOBSEQUEREJ')->first();
                    
                    $notification = [
                        'user_id'         => null,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $fiche->produit->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'lead',
                        'description'     => $observation
                    ];

                    foreach ($userList as $usr) {

                        $notification['user_id'] = $usr->id;
                        $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                       
                        event(new EventNotifications($notification));

                    }

                    //$tabInfosRejetContrat = ['idFiche' => $idFiche];
                    //event(new EventRejetContratSante($tabInfosRejetContrat));

                    return [
                                "success" => true,
                                "statut"  => $statut,
                                "message" => "Contrat numéro : ".$fiche->id." rejeté",
                            ];
                    
                }

            }

        }

        return [
                    "success" => false,
                    "message" => "Vous n'avez pas l'autorisation pour efféctuer cette opération !!",
                ];

    }

    public function userInfo(){

        $user = Auth::user();

        return $userInfo = ['equipe_user_id' => null, 'tracable_id' => $user->courtier_id, 'tracable_type' => 'courtier'];

    }


}
