<?php

namespace App\Http\Controllers\Courtier;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Http\Requests\SocieteAjoutRequest;

use App\Http\Requests;
use App\Societe;
use Image;


class SocieteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $societes    = Societe::all();

        return view("courtiersfiles.societe.index",["societes"=>$societes]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return view("courtiersfiles.societe.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(SocieteAjoutRequest $request)//SocieteAjoutRequest
    {

        $societe                  = new Societe;
        $societe->nom             = $request->get('nom');
        $societe->orias           = $request->get('orias');
        $societe->adresse         = $request->get('adresse');
        $societe->code_postal     = $request->get('codepostal');
        $societe->ville           = $request->get('ville');
        $societe->tel_bureau      = $request->get('telbureau');
        $societe->tel_mobile      = $request->get('telportable');
        $societe->fax             = $request->get('fax');
        $societe->email           = $request->get('email');
        $societe->lien            = $request->get('lien'); 

        //ajout photo
        if($request->file('photo')){
            
            $img                    = $request->file('photo');
            $mime                   = Image::make($img)->mime();

            if($mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif'){

                $imgName            = $societe->nom.'.'.$img->getClientOriginalExtension();
                $societe->logo   = $imgName;
                $image              = Image::make($img)->fit(200, 200)->save('upload/avatars/'.$imgName);

            }else{
                
                return redirect('courtier/societe/create')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
            }

        }

        $societe->save();

        return redirect("courtier/societe");
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $societe      = Societe::find($id);

        return view("courtiersfiles.societe.show",["societe"=>$societe]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $societe = Societe::find($id);

        return view('courtiersfiles.societe.edit',compact("societe"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(SocieteAjoutRequest $request, $id)
    {
        $societe                  = Societe::find($id);
        $societe->nom             = $request->get('nom');
        $societe->orias           = $request->get('orias');
        $societe->adresse         = $request->get('adresse');
        $societe->code_postal     = $request->get('codepostal');
        $societe->ville           = $request->get('ville');
        $societe->tel_bureau      = $request->get('telbureau');
        $societe->tel_mobile      = $request->get('telportable');
        $societe->fax             = $request->get('fax');
        $societe->email           = $request->get('email');
        $societe->lien            = $request->get('lien');

        //ajout photo
        if($request->file('photo')){
            
            $img                    = $request->file('photo');
            $mime                   = Image::make($img)->mime();

            if($mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif'){

                $imgName            = $societe->nom.'.'.$img->getClientOriginalExtension();
                $societe->logo   = $imgName;
                $image              = Image::make($img)->fit(200, 200)->save('upload/avatars/'.$imgName);

            }else{
                
                return redirect('courtier/societe/'.$id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
            }

        }
                
        $societe->save();

        return redirect("courtier/societe");
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function etatSociete($id){

        $societe = Societe::find($id);

        if($societe->active){

            $societe->active = 0;
            $msg = "Societe désactivé.";

        }else{

            $societe->active = 1;
            $msg = "Societe activé.";
        } 

        if($societe->save()){

            return $data = ["resultat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];
        }else{

            return $data = ["resultat" => "error", "msg" => $msg, "titre" => "opération échouée !"];
        }

    }


    //retourne la liste des societes 
    public function listSocietes($id)
    {
        $societes    = Societe::where('active', 1)->get();

        return view("courtiersfiles.societe.index",["societes"=>$societes]);
    }
}
