<?php

namespace App\Http\Controllers\Courtier;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Http\Requests\GroupePubAjoutRequest;

use App\Http\Requests;
use App\Prestataire;
use App\Provenance;
use App\Groupepub;
use App\Groupemotif;
use App\Groupestatut;
use App\Produit;
use App\Fichesante;
use App\Ficheobseque;
use App\Saregime;
use \Carbon\Carbon;
use DB;
use Hash;



class SearchLeadsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Responses
     */
    public function index(Request $request)
    {
             
        $prestataires   = Prestataire::where('active', 1)->orderBy('nom', 'asc')->get();
        //$groupIds       = $prestataire->getGroupepubProvenance->lists('id');
        $idProduit      = Produit::where('slug', 'sante')->value('id');
        //$fiches         = Fichesante::whereIn('groupepub_provenance_id', $groupIds)->where('produit_id',$idProduit)->get();
        $produits       = Produit::lists('libelle', 'slug');
        $motifFermeture = Groupemotif::where('libelle', 'Motifs fermeture')->where('active', 1)->first()->motifs()->where('active', 1)->lists('libelle', 'id');
        $statuts        = Groupestatut::where('libelle', 'Leads')->where('active', 1)->first()->status()->where('active', 1)->lists('libelle', 'id');
        $regimes        = Saregime::lists('libelle', 'id');
        //$provenances    = $prestataire->provenances->lists('nom', 'id');

        return view('courtiersfiles.searchLeads',['prestataires'=>$prestataires, 'produits'=>$produits, 'motifFermeture'=>$motifFermeture, 'statuts'=>$statuts, 'regimes'=>$regimes ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function etatFiche($id){

        $fiche = Fichesante::find($id);

        if($fiche->active) $fiche->active = 0;
        else $fiche->active = 1;

        if($fiche->save()){

            return $data = [
                "msg"   => "opération éfectuée avec succès."
            ];
        }else{

            return $data = [
                "msg"   => "opération échouée !"
            ];
        }
    }


    public function selectPrestataire(Request $request){

        $idPrestataire  = $request->get('idPrestataire');
        return $groupePubs     = Prestataire::find($idPrestataire)->groupepubs()->where('active', 1)->lists('id', 'nom');
    }


    public function RechercheFiche(Request $request){

      switch($request->get('produit_id')){

          case 'sante'  : {return $this->RechercheFicheSante($request);break;}
          case 'obseque': {return $this->RechercheFicheObseque($request);break;}
          case 'auto'   : {return $this->RechercheFicheAuto($request);break;}

      }  
        
        
    }


    public function RechercheFicheSante(Request $request){

        //return $request->all();
        //return $fiches         = Fichesante::where('num_fiche', $request->get('num_fiche'))->first()->client()->where('nom', $request->get('nom'))->get();
        //$groupIds= $prestataire->getGroupepubProvenance->lists('id');
        //return $request->get('groupIds');
        //return $provGrpPub = Provenance::find($request->get('provenance_id'))->groupepubProvenances()->lists('id');
                      //$dateInsertion = Carbon::parse($request->get('date_debut'));
        //dd($request->all());
        //$groupIds = explode(",", str_replace(['[',']'], '', $request->get('groupIds')));
        $statuts            = "";
        $idsProvGroupPub    = collect([]);

        if($request->get('groupePub')){

            $idGroupPub     = $request->get('groupePub');
            $idsProvGroupPub= Groupepub::find($idGroupPub)->provenances()->lists('groupepub_provenance.id');

        }else if($request->get('prestataire')){

            $idPrestataire  = $request->get('prestataire');
            $ProvGroupPub   = "";

            $groupePubs     = Prestataire::find($idPrestataire)->groupepubs()->where('active', 1)->get();  

            foreach($groupePubs as $groupePub){

                $ProvGroupPub       = Groupepub::find($groupePub->id)->provenances()->lists('groupepub_provenance.id');
                $idsProvGroupPub    = $idsProvGroupPub->merge($ProvGroupPub);

            }
        }

        if(!$request->get('status')){

            $statuts        = Groupestatut::where('slug', 'leads')->first()->status()->where('statuts.active', 1)->lists('id');
            //return $statuts;
        }

        $fiches  = DB::table('fichesantes')

                 ->where(function($queryFiche) use ($request, $statuts, $idsProvGroupPub){   

                    if($request->has('produit_id')) {
                        $idProduit = Produit::where('slug', $request->get('produit_id'))->value('id');
                        $queryFiche->where('fichesantes.produit_id', $idProduit );
                    }

                    if($request->get('groupePub') or $request->get('prestataire')){

                        $queryFiche->whereIn("fichesantes.groupepub_provenance_id", $idsProvGroupPub);

                    }

                    if($request->has('nom')) {
                      $queryFiche->where('clients.nom', 'like', "%".$request->get('nom')."%");
                     }

                    if($request->has('prenom')) {
                      $queryFiche->where('clients.prenom', 'like', "%".$request->get('prenom')."%");
                     }

                     if($request->has('code_postal')) {
                      $queryFiche->where('clients.code_postal', $request->get('code_postal'));
                     }

                     if($request->has('tel_mobile')) {
                      $queryFiche->where('clients.tel_mobile', $request->get('tel_mobile'));
                     }

                     if($request->get('regime')) {
                      $queryFiche->where('clients.saregime_id', $request->get('regime'));
                     }

                     if($request->has('ani') and $request->get('ani')!= 2) {
                      $queryFiche->where('clients.ani', $request->get('ani'));
                     }

                     if($request->has('date_debut') and $request->has('date_fin')) {
                      $queryFiche->whereBetween('fichesantes.date_insertion', [$request->get('date_debut'), $request->get('date_fin')]);
                     }

                     if($request->has('doublon') and $request->get('doublon')!= 2) {
                      $queryFiche->where('fichesantes.doublon', $request->get('doublon'));
                     }

                     if($request->has('lu') and $request->get('lu')!= 2) {
                      $queryFiche->where('fichesantes.lu', $request->get('lu'));
                     }

                     if($request->get('motif_farmeture')) {
                      $queryFiche->where('fichesantes.motif_fermeture_id', $request->get('motif_farmeture'));
                     }

                     if($request->get('statut')) {
                         
                      $queryFiche->where('fichesantes.statut_id', $request->get('statut'));

                     }else{

                      $queryFiche->whereIn("fichesantes.statut_id", $statuts);
                     }

                     if($request->has('num_fiche')) {
                      $queryFiche->where('fichesantes.num_fiche', $request->get('num_fiche'));
                     }

                 })
                 ->Join('clients', 'clients.id', '=', 'fichesantes.client_id')
                 ->leftJoin('saregimes', 'saregimes.id', '=', 'fichesantes.saregime_id')
                 ->leftJoin('statuts', 'statuts.id', '=', 'fichesantes.statut_id')
                 ->leftJoin('motifs', 'motifs.id', '=', 'fichesantes.motif_fermeture_id')
                 ->select('clients.nom', 
                        'clients.prenom', 
                        'clients.civilite', 
                        'clients.code_postal',
                        'clients.tel_mobile',
                        'clients.email',
                        'fichesantes.active',
                        'fichesantes.num_fiche',
                        'fichesantes.doublon',
                        'fichesantes.cout',
                        'fichesantes.slug',
                        'fichesantes.statut_id',
                        'fichesantes.motif_fermeture_id',
                        'fichesantes.date_insertion',
                        'saregimes.libelle as libelleRegime',
                        'statuts.libelle as libelleStatut',
                        'statuts.couleur as couleurStatut',
                        'motifs.libelle as libelleMotifFerm',
                        'fichesantes.id as idFiche'
                        )
                 ->orderby('fichesantes.num_fiche', 'asc')
                 ->paginate(10);
            sleep(1);
            return json_encode($fiches);
    }



    public function RechercheFicheObseque(Request $request){

        $statuts            = "";
        $idsProvGroupPub    = collect([]);

        if($request->get('groupePub')){

            $idGroupPub     = $request->get('groupePub');
            $idsProvGroupPub= Groupepub::find($idGroupPub)->provenances()->lists('groupepub_provenance.id');

        }else if($request->get('prestataire')){

            $idPrestataire  = $request->get('prestataire');
            $ProvGroupPub   = "";

            $groupePubs     = Prestataire::find($idPrestataire)->groupepubs()->where('active', 1)->get();  

            foreach($groupePubs as $groupePub){

                $ProvGroupPub       = Groupepub::find($groupePub->id)->provenances()->lists('groupepub_provenance.id');
                $idsProvGroupPub    = $idsProvGroupPub->merge($ProvGroupPub);

            }
        }

        if(!$request->get('status')){

            $statuts        = Groupestatut::where('slug', 'leads')->first()->status()->where('statuts.active', 1)->lists('id');
            //return $statuts;
        }

        $fiches  = DB::table('ficheobseques')

                 ->whereIn('groupepub_provenance_id', $groupIds)

                 ->where(function($queryFiche) use ($request){   

                     if($request->has('produit_id')) {
                        $idProduit = Produit::where('slug', $request->get('produit_id'))->value('id');
                        $queryFiche->where('ficheobseques.produit_id', $ridProduit);
                     }

                    if($request->get('groupePub') or $request->get('prestataire')){

                        $queryFiche->whereIn("fichesantes.groupepub_provenance_id", $idsProvGroupPub);

                    }

                    if($request->has('nom')) {
                      $queryFiche->where('clients.nom', 'like', "%".$request->get('nom')."%");
                     }

                    if($request->has('prenom')) {
                      $queryFiche->where('clients.prenom', 'like', "%".$request->get('prenom')."%");
                     }

                     if($request->has('code_postal')) {
                      $queryFiche->where('clients.code_postal', $request->get('code_postal'));
                     }

                     if($request->has('tel_mobile')) {
                      $queryFiche->where('clients.tel_mobile', $request->get('tel_mobile'));
                     }

                     if($request->get('regime')) {
                      $queryFiche->where('clients.saregime_id', $request->get('regime'));
                     }

                     if($request->has('ani') and $request->get('ani')!= 2) {
                      $queryFiche->where('clients.ani', $request->get('ani'));
                     }

                     if($request->has('date_debut') and $request->has('date_fin')) {
                      $queryFiche->whereBetween('fichesantes.date_insertion', [$request->get('date_debut'), $request->get('date_fin')]);
                     }

                     if($request->has('doublon') and $request->get('doublon')!= 2) {
                      $queryFiche->where('fichesantes.doublon', $request->get('doublon'));
                     }

                     if($request->has('lu') and $request->get('lu')!= 2) {
                      $queryFiche->where('fichesantes.lu', $request->get('lu'));
                     }

                     if($request->get('motif_farmeture')) {
                      $queryFiche->where('fichesantes.motif_fermeture_id', $request->get('motif_farmeture'));
                     }

                     if($request->get('statut')) {
                         
                      $queryFiche->where('fichesantes.statut_id', $request->get('statut'));

                     }else{

                      $queryFiche->whereIn("fichesantes.statut_id", $statuts);
                     }

                     if($request->has('num_fiche')) {
                      $queryFiche->where('fichesantes.num_fiche', $request->get('num_fiche'));
                     }

                 })
                 ->Join('clients', 'clients.id', '=', 'ficheobseques.client_id')
                 ->leftJoin('saregimes', 'saregimes.id', '=', 'ficheobseques.saregime_id')
                 ->leftJoin('statuts', 'statuts.id', '=', 'ficheobseques.statut_id')
                 ->leftJoin('motifs', 'motifs.id', '=', 'ficheobseques.motif_fermeture_id')
                 ->select('clients.nom', 
                        'clients.prenom', 
                        'clients.civilite', 
                        'clients.code_postal',
                        'clients.tel_mobile',
                        'clients.email',
                        'ficheobseques.active',
                        'ficheobseques.num_fiche',
                        'ficheobseques.doublon',
                        'ficheobseques.cout',
                        'ficheobseques.statut_id',
                        'ficheobseques.motif_fermeture_id',
                        'ficheobseques.date_insertion',
                        'saregimes.libelle as libelleRegime',
                        'statuts.libelle as libelleStatut',
                        'motifs.libelle as libelleMotifFerm',
                        'ficheobseques.id as idFiche'
                        )
                 ->orderby('ficheobseques.num_fiche', 'asc')
                 ->paginate(10);
            sleep(1);
            return json_encode($fiches);
    }


    public function CritereRecherched($request, $class, $attribut, $parametre){

        if($request->has($parametre)) $class->$attribut = $request->get($parametre);

    }



}
