<?php

namespace App\Http\Controllers\Courtier;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Http\Requests\PrestataireAjoutRequest;

use App\Http\Requests;
use App\Prestataire;
use Image;

class PrestataireController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $prestataires = Prestataire::all();
        return view('courtiersfiles.prestataire.index',['prestataires'=>$prestataires]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('courtiersfiles.prestataire.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PrestataireAjoutRequest $request)
    {
        //return 1;
        $prestataire                = new Prestataire;
        $prestataire->nom           = $request['nom'];
        $prestataire->responsable   = $request['responsable'];
        $prestataire->tel_bureau    = $request['tel_bureau'];
        $prestataire->tel_portable  = $request['tel_portable'];
        $prestataire->email         = $request['email'];

        //ajout photo
        if($request->file('photo')){
            
            $img                    = $request->file('photo');
            $mime                   = Image::make($img)->mime();

            if($mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif'){

                $imgName            = $prestataire->nom.'.'.$img->getClientOriginalExtension();
                $prestataire->logo  = $imgName;
                $image              = Image::make($img)->fit(200, 200)->save('upload/avatars/'.$imgName);

            }else{
                
                return redirect('courtier/prestataire/create')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
            }

        }

        $prestataire->save();

        //$prestataires = Prestataire::all();
        return redirect('courtier/prestataire/'.$prestataire->id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $prestataire = Prestataire::find($id);
        return view("courtiersfiles.prestataire.show",['prestataire'=>$prestataire]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $prestataire = Prestataire::find($id);

        return view('courtiersfiles.prestataire.edit',compact("prestataire"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PrestataireAjoutRequest $request, $id)
    {
         //return 1;
        $prestataire                = Prestataire::find($id);
        $prestataire->nom           = $request['nom'];
        $prestataire->responsable   = $request['responsable'];
        $prestataire->tel_bureau    = $request['tel_bureau'];
        $prestataire->tel_portable  = $request['tel_portable'];
        $prestataire->email         = $request['email'];

        //ajout photo
        if($request->file('photo')){
            
            $img                    = $request->file('photo');
            $mime                   = Image::make($img)->mime();

            if($mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif'){

                $imgName            = $prestataire->nom.'.'.$img->getClientOriginalExtension();
                $prestataire->logo  = $imgName;
                $image              = Image::make($img)->fit(200, 200)->save('upload/avatars/'.$imgName);

            }else{
                
                return redirect('courtier/prestataire/'.$id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
            }

        }

        $prestataire->save();

        //$prestataires = Prestataire::all();
        return redirect('courtier/prestataire/'.$prestataire->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    //Activer/desactiver u prestataire

    public function etatPrestataire($id){

        $prestataire = Prestataire::find($id);

        if($prestataire->active){

            $prestataire->active = 0;
            $msg = "Prestataire désactivé.";

        }else{

            $prestataire->active = 1;
            $msg = "Prestataire activé.";
        } 

        if($prestataire->save()){

            return $data = ["resultat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];
        }else{

            return $data = ["resultat" => "error", "msg" => $msg, "titre" => "opération échouée !"];
        }

    }
}
