<?php

namespace App\Http\Controllers\Courtier;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Action;
use App\Produit;
use App\Groupeaction;


class ActionController extends Controller
{

    function genererSlug($string){

        $tabMots        = explode(" ", $string);
        $initiale       = '';
        $nbrMots        = count($tabMots);

        if($nbrMots > 2){

            foreach($tabMots as $init){
                $initiale .= $init{0};
            }
            return strtoupper($initiale);

        }elseif($nbrMots == 2){

            return camel_case($string);

        }else{

            return strtolower($string);
        }
        
    }


    public function loadActions(){

        // $users    = User::whereNotIn('profile_id', [1,2,3])->orderBy('updated_at', 'desc')->get();        
        //$produits   = Produit::all();
        //return view('courtiersfiles.status.index', ['produits' => $produits, 'actions' => $actions]);

        return $actions    = Groupeaction::orderBy('ordre', 'asc')->with('actions')->get();  

    }

    public function addGrpAction(Request $request){

    	$groupeAction       = Groupeaction::where('nom','like', $request->get('nom'))->first();
        $resultat           = "";

    	if($groupeAction){

    		$resultat       = ["etatOperation" => 0, "etat" => "warning", "msg" => "Ce groupe d action existe dèja !", "titre" => "Attention !"];
            
    	}else{
            
            $groupeAction           = new Groupeaction;
            $groupeAction->nom      = $request->get('nom');
            $groupeAction->slug     = $this->genererSlug($request->get('nom'));
            $groupeAction->ordre    = Groupeaction::all()->max('ordre')+1;
            $groupeAction->active   = 1;


            if($groupeAction->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "groupe actions ajouté avec succèss", "titre" => "Opération efféctuée", "id" => $groupeAction->id, "slug" => $groupeAction->slug, "ordre" => $groupeAction->ordre];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de l ajout", "titre" => "Opération échouée"];   
                    
            }  
             
        }
        
        return $resultat;
    }

    public function updateGrpAction(Request $request){

    	$groupeAction       = Groupeaction::where('id','!=', $request->get('id'))->where('nom','like', $request->get('nom'))->first();
        $resultat           = "";

    	if($groupeAction){

    		$resultat       = ["etatOperation" => 0, "etat" => "warning", "msg" => "Ce groupe d action existe dèja !", "titre" => "Attention !"];
            
    	}else{

            $groupeAction           = Groupeaction::find($request->get('id'));
            $groupeAction->nom      = $request->get('nom');
            //$groupeAction->slug     = $request->get('slug');

            if($groupeAction->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "Modification efféctuée avec succèss", "titre" => "Opération efféctuée"];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de la modification", "titre" => "Opération échouée"];   
                    
            }  
             
        }
        
        return $resultat;
    }

    public function activerGrpAction(Request $request){

    	$groupeAction = Groupeaction::find($request->get('idGrpAction'));

        if($groupeAction->active){

            $groupeAction->active = 0;
            $msg = "Groupe actions désactivé.";

        }else{

            $groupeAction->active = 1;
            $msg = "Groupe actions activé.";
        } 

        if($groupeAction->save()){

            return $resultat = ["etatOperation" => 1, "active" => $groupeAction->active,"etat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];

        }else{

            return $resultat = ["etatOperation" => 0, "etat" => "error", "msg" => "", "titre" => "opération échouée !"];
        }
    }


    public function addAction(Request $request){

    	$Action             = Action::where('groupeaction_id', $request->get('idGrpAction'))->where('nom','like', $request->get('nom'))->first();
        $resultat           = "";

    	if($Action){

    		$resultat       = ["etatOperation" => 0, "etat" => "warning", "msg" => "Cette action existe dèja !", "titre" => "Attention !"];
            
    	}else{
            
            $Action                     = new Action;
            $Action->nom                = $request->get('nom');
            $Action->groupeaction_id    = $request->get('idGrpAction');
            $Action->slug               = $this->genererSlug($request->get('nom'));
            $Action->ordre              = Action::where('groupeaction_id','==', $request->get('idGrpAction'))->max('ordre')+1;
            $Action->active             = 1;


            if($Action->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "Action ajouté avec succèss", "titre" => "Opération efféctuée", "id" => $Action->id, "slug" => $Action->slug, "ordre" => $Action->ordre];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de l ajout", "titre" => "Opération échouée"];   
                    
            }  
             
        }
        
        return $resultat;
    }

    public function updateAction(Request $request){

    	$action             = Action::where('id','!=', $request->get('id'))
                                ->where('nom','like', $request->get('nom'))
                                ->where('groupeaction_id', $request->get('idGrpAction'))
                                ->first();
        $resultat           = "";

    	if($action){

    		$resultat       = ["etatOperation" => 0, "etat" => "warning", "msg" => "Cette action existe dèja !", "titre" => "Attention !"];
            
    	}else{

            $action         = Action::find($request->get('id'));
            $action->nom    = $request->get('nom');
            //$groupeAction->slug     = $request->get('slug');

            if($action->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "Modification efféctuée avec succèss", "titre" => "Opération efféctuée"];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de la modification", "titre" => "Opération échouée"];   
                    
            }  
             
        }
        
        return $resultat;
    }


    public function activerAction(Request $request){

    	$action = Action::find($request->get('idAction'));

        if($action->active){

            $action->active = 0;
            $msg = "Action désactivée.";

        }else{

            $action->active = 1;
            $msg = "Action activée.";
        } 

        if($action->save()){

            return $resultat = ["etatOperation" => 1, "active" => $action->active,"etat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];

        }else{

            return $resultat = ["etatOperation" => 0, "etat" => "error", "msg" => "", "titre" => "opération échouée !"];
        }
    }


     public function updateClassAction(Request $request)
    {
        
    	$actions    = $request->get('actions');
    	$count      = 1;
        
    	foreach ($actions as $action){

    		$ligneAction        = Action::find($action['id']);
    		$ligneAction->ordre = $count;
    		$ligneAction->save();
    		$count++;
    	}
    }



}
