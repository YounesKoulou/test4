<?php

namespace App\Http\Controllers\Courtier;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Statut;
use App\Produit;
use App\Groupestatut;


class StatutController extends Controller
{
     public function index()
    {
        // $users    = User::whereNotIn('profile_id', [1,2,3])->orderBy('updated_at', 'desc')->get();
        $status     = Statut::where('groupestatut_id', 1)
                            ->orderBy('updated_at', 'desc')
                            ->get();
        
        $produits   = Produit::all();

        return view('courtiersfiles.status.index', ['status' => $status, 'produits' => $produits]);

    }
     public function recuperationStatutContrat(Request $request)
    {
        // $users    = User::whereNotIn('profile_id', [1,2,3])->orderBy('updated_at', 'desc')->get();
        $idGroupeStatut = Groupestatut::where('slug', 'contrats')->first()->id;
        $status         = Statut::where('groupestatut_id', $idGroupeStatut)
                            ->where('slug_produit', $request->get('produit'))
                            ->orderBy('ordre', 'asc')
                            ->get();

        return $status;

    } 

     public function nouveauClassementStatutContrat(Request $request)
    {

    	$statuts = $request->get('statuts');
    	$count   = 1;

    	foreach ($statuts as $statut){

    		$ligneStatut        = Statut::find($statut['id']);
    		$ligneStatut->ordre = $count;
    		$ligneStatut->save();
    		$count++;

    	}
    }


     public function recuperationStatutDevis(Request $request)
    {

      

        // $users    = User::whereNotIn('profile_id', [1,2,3])->orderBy('updated_at', 'desc')->get();
        $idGroupeStatut = Groupestatut::where('slug', 'devis')->first()->id;
        $status         = Statut::where('groupestatut_id', $idGroupeStatut)
                            ->where('slug_produit', $request->get('produit'))
                            ->orderBy('ordre', 'asc')
                            ->get();

        return $status;

    } 

     public function nouveauClassementStatutDevis(Request $request)
    {

    	$statuts = $request->get('statuts');
    	$count  = 1;

    	foreach ($statuts as $statut){

    		$ligneStatut        = Statut::find($statut['id']);
    		$ligneStatut->ordre = $count;
    		$ligneStatut->save();
    		$count++;

    	}
    }

     public function recuperationStatut(Request $request)
    {
        // $users    = User::whereNotIn('profile_id', [1,2,3])->orderBy('updated_at', 'desc')->get();
        $status    = Statut::where('groupestatut_id', 1)
                            ->where('slug_produit', $request->get('produit'))
                            ->orderBy('ordre', 'asc')
                            ->get();

        return $status;

    } 

     public function nouveauClassementStatut(Request $request)
    {

    	$statuts = $request->get('statuts');
    	$count   = 1;

    	foreach ($statuts as $statut){

    		$ligneStatut        = Statut::find($statut['id']);
    		$ligneStatut->ordre = $count;
    		$ligneStatut->save();
    		$count++;

    	}
    }

    public function desactiverStatut(Request $request) 
    {

    		$statut              = $request->get('statut');
    		$ligneStatut         = Statut::find($statut['id']);
    		$ligneStatut->active = 0;
    		$ligneStatut->save();
    }

    public function activerStatut(Request $request) 
    {

    		$statut              = $request->get('statut');
    		$ligneStatut         = Statut::find($statut['id']);
    		$ligneStatut->active = 1;
    		$ligneStatut->save();
    }

      public function editStatut(Request $request)
    {

    	$libelleExistant= Statut::where('id','!=', $request->get('id'))->where('libelle','like', $request->get('libelle'))->where('slug_produit', $request->get('produit'))->first();
        
    	if($libelleExistant){

    		$retourLibelle = ['id' => 0, 'nom' => 'Libelle que vous avez mentionner existe deja'];
    		return $retourLibelle;
    	}

    		$ligneStatut          = Statut::find($request->get('id'));
    		$ligneStatut->couleur = '#'.$request->get('couleur');
    		$ligneStatut->libelle = $request->get('libelle');
    		$ligneStatut->save();
            $retourLibelle        = ['id' => 1, 'nom' => 'Modification effectue avec success'];
    		return $retourLibelle;

    }

      public function saveStatut(Request $request)
    {

    	$idGroupeStatut = Groupestatut::where('slug', 'leads')->first()->id;
    	$maxOrdre 		= Statut::where('groupestatut_id', $idGroupeStatut)->max('ordre');
    	$libelleExistant= Statut::where('libelle', $request->get('libelle'))->first();

    	if($libelleExistant){

    		$retourLibelle = ['id' => 0, 'nom' => 'Libelle que vous avez mentionner existe deja'];
    		return $retourLibelle;
    	}

        $libelle = $request->get('libelle');
        $libelle = explode(" ", $libelle);
        $slug    = $request->get('slug');

        foreach ($libelle as $value) {

            $slug .= ucfirst($value);

        }

        	$statut 				 = new Statut;
            $statut->libelle         = $request->get('libelle');
            $statut->slug            = $slug;
            $statut->ordre           = $maxOrdre + 1;
            $statut->couleur         = '#'.$request->get('couleur');
            $statut->active          = 1;
            $statut->slug_produit    = $request->get('slug');
            $statut->code            = 1;
            $statut->groupestatut_id = $idGroupeStatut;
            $statut->save();
            $retourLibelle = ['id' => 1, 'nom' => 'Ajout effectue avec success'];
    		return $retourLibelle;
    }

    public function create()
    {
        //$profiles = Profile::whereNotIn('slug', ['superadmin', 'admin', 'courtier', 'systeme'])->whereActive(1)->get();

        return view('courtiersfiles.status.create');
    }

    public function store(UserRequest $request)
    {

    	$idGroupeStatut = Groupestatut::where('slug', 'leads')->first()->id;

        	$statut 			     = new Statut;
            $statut->libelle         = $request->get('libelle');
            $statut->slug            = $request->get('slug');
            $statut->ordre           = $request->get('ordre');
            $statut->couleur         = $request->get('couleur');
            $statut->password        = bcrypt($request->get('password'));
            $statut->groupestatut_id = $idGroupeStatut;
            $statut->save();
    }

}
