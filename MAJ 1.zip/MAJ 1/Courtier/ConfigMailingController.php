<?php

namespace App\Http\Controllers\Courtier;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests\StoreTypeModeleRequest;

use App\Http\Requests;

use App\Produit;

use App\Modelemail;

use App\Parametresmodele;

use App\Groupestatut;


class ConfigMailingController extends Controller
{
    public function configMail()
    {
    	$produits    = Produit::where('active',1)->select('id','libelle')->get();
    	//$modelesMail = Modelemail::where('active',1)->select('id','libelle','produit_id')->get();




    	return view('courtiersfiles.configmailing.index',['produits' => $produits]);
    }


    public function getTypesModeles($id)
    {
    	return $modelesMail  = Modelemail::where('produit_id',$id)
    							  ->select('id','libelle')
    							  ->get();

    }

    public function getModeleMail($id)
    {
    	return $modelesMail  = Modelemail::where('id',$id)
    							  //->select('id','libelle','objet','contenu','active')
                                  ->with('groupeStatut')
    							  ->first();
    }


    public function newTypeModele()
    {
    	$produits      = Produit::where('active',1)->select('id','libelle')->lists('libelle','id');
        $groupeStatuts = Groupestatut::where('active',1)->select('id','libelle')->lists('libelle','id');
    	return view('courtiersfiles.configmailing.create',['produits' => $produits ,'groupeStatuts' => $groupeStatuts]);
    }


    public function getParametresModele($id)
    {
    	return $parametresProduit = Parametresmodele::where('active',1)
    												->where('produit_id',$id)
    												->select('id','nom','description')
    												->get();

    }

    public function storeTypeModele(StoreTypeModeleRequest $request)
    {
    	$produit  	    = $request->get('produit');
        $groupeStatut   = $request->get('groupeStatut');
    	$nom_type 	    = $request->get('nom_type');
    	$objet    	    = $request->get('objet');
    	$corpModele     = $request->get('corpModele');

    	$modeleMail  			     = new Modelemail;

    	$modeleMail->produit_id      = $produit;
        $modeleMail->groupestatut_id = $groupeStatut;
    	$modeleMail->libelle         = $nom_type;
    	$modeleMail->objet           = $objet;
    	$modeleMail->contenu 	     = $corpModele;
    	$modeleMail->active          = 1;
    	$modeleMail->save();


    	return redirect('courtier/configMail');

    	//return $request->all();
    }


    public function editTypeModele($id)
    {
    	$modelesMail  = Modelemail::where('id',$id)
    							  //->select('id','libelle','objet','contenu','produit_id')
    							  ->first();

    	$produits      = Produit::where('active',1)->select('id','libelle')->get();
        $groupeStatuts = Groupestatut::where('active',1)->select('id','libelle')->get();

    	return view('courtiersfiles.configmailing.edit',['modelesMail' => $modelesMail , 'produits' => $produits ,'groupeStatuts' => $groupeStatuts]);

    }

    public function updateTypeModele(StoreTypeModeleRequest $request,$id)
    {
    	$produit  	    = $request->get('produit');
        $groupeStatut   = $request->get('groupeStatut');
    	$nom_type 	    = $request->get('nom_type');
    	$objet    	    = $request->get('objet');
    	$corpModele     = $request->get('corpModele');

    	$modeleMail  			     = Modelemail::find($id);

    	$modeleMail->produit_id      = $produit;
        $modeleMail->groupestatut_id = $groupeStatut;
    	$modeleMail->libelle         = $nom_type;
    	$modeleMail->objet           = $objet;
    	$modeleMail->contenu 	     = $corpModele;
    	$modeleMail->save();


    	return redirect('courtier/configMail');

    }

    public function ActiveModele($id)
    {
        $modeleMail   = Modelemail::find($id);

        if($modeleMail->active)
        {
            $modeleMail->active = 0;
            $active = 0;
        }
        else
        {
            $modeleMail->active = 1;
            $active = 1;
        }

        $modeleMail->save();


        return ['active'=> $active , 'msg' => 'ok' ];

    }


    
}
