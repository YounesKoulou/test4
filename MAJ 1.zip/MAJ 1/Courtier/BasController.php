<?php

namespace App\Http\Controllers\Courtier;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;




use App\BAS\BasAuthClient;
use App\BAS\BasObjectAccessClient;
use App\BAS\BasSoapClient;
use App\BAS\BasDto;
use App\BAS\BasParams;
use App\BAS\BasParam;


use XMLWriter;
use SoapVar; 
const BAS_NS_URI = "http://belair-info.com/bas/services";
const BAS_ENVELOPE_NS = "ns1";
const BAS_TYPE_NS = "xsi";
const BAS_DATETIME_FMT = "Y-m-d\TH:i:s.uP"; // W3C with milliseconds  


class BasController extends Controller
{

   


    public function testBas(){

            $BASE_URL = "http://145.239.156.46:8080";

            //
            // IBasAuthService
            //
            print "<h2>IBasAuthService</h2>";
            $authClent = new BasAuthClient($BASE_URL, array("trace" => true, "exceptions" => true)); 

            print "<h3>IBasAuthService::OpenSession()</h3>";
            $auth = $authClent->OpenSession("SUPERVISEUR", "");
            if ($auth->IsAuthenticated)
                print "<p>Nouvelle session. Id: ". $auth->SessionId . "</p>";
            else
                exit("Probleme d ouverture de session !!");




            //
            // IBasObjectAccessService
            //
            print "<h2>IBasObjectAccessService::GetByKey() TIERS</h2>";
            $objAccessClient = new BasObjectAccessClient($BASE_URL, array("trace" => true, "exceptions" => true)); // "cache_wsdl" => WSDL_CACHE_NONE, "soap_version" => SOAP_1_1

            print "------Afficher un tier-------<br>";

            $params = new BasParams();
            $params->AddInt("B_NUMTIERS", 1000);

            $dto    = BasDto::createCopy($objAccessClient->GetByKey($auth, 'TIERS', $params->ToSoapVar('params')));

            echo '<pre>';
            echo 'B_RSOCIALE=' . $dto->Properties->GetByName('B_RSOCIALE')->StrVal . ' B_NUMDPP=' . $dto->Properties->GetByName('B_NUMDPP')->IntVal . PHP_EOL;
            echo '</pre>';    





            print "<h3>IBasObjectAccessService::GetByKey() DPP</h3>";
            $params = new BasParams();
            $params->AddInt("B_NUMTIERS", 1000);
            $params->AddInt("B_NUMDPP", 1);
            try
            {
            $dto = BasDto::CreateCopy($objAccessClient->GetByKey($auth, "DPP", $params->ToSoapVar("params")));
            echo '<pre>';
            echo 'B_PRENOM=' . $dto->Properties->GetByName('B_PRENOM')->StrVal . ' ' . 'B_NOM=' . $dto->Properties->GetByName('B_NOM')->StrVal . PHP_EOL;
            echo 'B_DATENAIS=' . $dto->Properties->GetByName('B_DATENAIS')->DateTimeVal->format(BAS_DATETIME_FMT) . ' ' . 'B_NUMSS=' . $dto->Properties->GetByName('B_NUMSS')->StrVal . PHP_EOL;
            echo '</pre>';
            }
            catch(Exception $e)
            {
            print "<p>Error: " . $e->getMessage() . "</p>";
            print "<p>" . htmlentities($objAccessClient->__getLastRequest()) . "</p>";
            }
            if ($debug) $dto->DebugPrint();
            




            print "<h3>IBasObjectAccessService::GetBySelect() CONT tiers n°1000</h3>";
            $params = new BasParams();
            $params->AddInt("B_NTIERS", 1000);
            $tmp = array();
            try
            {
            $conts = $objAccessClient->GetBySelect($auth, "CONT", "B_NTIERS = :B_NTIERS", $params->ToSoapVar("params"));
            }
            catch(Exception $e)
            {
            print "<p>Error: " . $e->getMessage() . "</p>";
            print "<p>" . htmlentities($objAccessClient->__getLastRequest()) . "</p>";
            }
            if ($conts != null)
            {
            print "<p>" . sizeof($conts->item) . " object(s) selected</p>";
            echo '<table border="1">';
            echo '<tr><th>B_CONTRAT</th><th>B_INTITULE</th><th>B_DERPIECE</th><th>B_TOTANN</th><th>B_AFFNOUV</th></tr>';
            foreach($conts->item as $cont)
            {
                $dto = BasDto::CreateCopy($cont);
                echo '<pre>';
                echo '<tr><td>' . $dto->Properties->GetByName('B_CONTRAT')->IntVal . '</td><td>' . $dto->Properties->GetByName('B_INTITULE')->StrVal . '</td><td>' . $dto->Properties->GetByName('B_DERPIECE')->IntVal . '</td><td>' . $dto->Properties->GetByName('B_TOTANN')->FloatVal . '</td><td>' . $dto->Properties->GetByName('B_AFFNOUV')->DateTimeVal->format(BAS_DATETIME_FMT) . '</td></tr>';
                echo '</pre>';
                $tmp[] = $dto->Properties->GetByName('B_CONTRAT')->IntVal;
            }
                echo '</table>';
            }
            else
            print "<p>Nothing found</p>";
    

    
            // Close session
            print "<h3>IBasAuthService::CloseSession()</h3>";
            $authClent->CloseSession($auth);
            print "<p>Session closed</p>";

    }

}
