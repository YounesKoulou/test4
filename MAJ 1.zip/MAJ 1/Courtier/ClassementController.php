<?php

namespace App\Http\Controllers\Courtier;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use Auth;
use Carbon\Carbon;

use App\Produit, App\Agence, App\User, App\Classementsante;

class ClassementController extends Controller
{

    public function index() {

    	$produits    = Produit::where('active', 1)->get();
        $agences     = Agence::where('active', 1)->get();
        //$sites      = Site::where('id', 1)->first()->nom;
        //$equipes    = Equipe::where('active', 1)->get();

        $date 		  = Carbon::now();
        $dateFirstDay = Carbon::create($date->year, $date->month, 01,00,00,00);
        $year 		  = $date->year;
        $month 		  = $date->month - 1;

    	return view('courtiersfiles.classement.index', ['produits' => $produits,'agences' => $agences, 'year' => $year, 'month' => $month, 'date' => $dateFirstDay, 'activeOnglet' => 1]);

    	//return view('courtiersfiles.classement.test');
    }

    public function indexId($id) {

        $produits    = Produit::where('active', 1)->get();
        $agences     = Agence::where('active', 1)->get();
        //$sites      = Site::where('id', 1)->first()->nom;
        //$equipes    = Equipe::where('active', 1)->get();

        $date         = Carbon::now();
        $dateFirstDay = Carbon::create($date->year, $date->month, 01,00,00,00);
        $year         = $date->year;
        $month        = $date->month - 1;

        return view('courtiersfiles.classement.index', ['produits' => $produits,'agences' => $agences, 'year' => $year, 'month' => $month, 'date' => $dateFirstDay, 'activeOnglet' => $id]);

        //return view('courtiersfiles.classement.test');
    }

    public function getClassement(Request $request) {
        
        //return $request->all();	
        $tableName            = $request->get('produit');
    	$idAgences            = [];
    	$idSites              = [];
    	$idEquipes            = [];
    	$idConseillers        = [];
    	$dateProduction       = "";

    	
    	if($request->has('dateProdHidden')){

            $dateProduction        = $request->get('dateProdHidden');
            $dateProductionCarbon  = new Carbon($dateProduction);
            $annee                 = $dateProductionCarbon->year;
            $mois                  = $dateProductionCarbon->month;
        
        }


        // return $classements     = ClassementSante::whereHas('userEquipe', function ($query)  {
        //                                $query->where('equipe_id', 1);
        //                            })->get();

        $classements        = Classementsante::where('classementsantes.active',1)
        					->where(function($query) use ($request,$mois,$annee){

        					if($request->has('dateProdHidden'))
        					{
        						$query->where('classementsantes.mois',$mois);
        						$query->where('classementsantes.annee',$annee);
        					}

        					if($request->has('agences') and !$request->has('sites') and !$request->has('equipes') and !$request->has('conseillers')){

					           $idAgences      = $request->get('agences');
					           $query->whereIn('classementsantes.agence_id', $idAgences);

					        }

					        if($request->has('sites') and !$request->has('equipes') and !$request->has('conseillers')){

					           $idSites        = $request->get('sites');
					           $query->whereIn('classementsantes.site_id', $idSites);
					        }
					        
					        if($request->has('equipes') and !$request->has('conseillers')){
						        $query->whereHas('userEquipe', function ($q)  use ($request){

								           $idEquipes      = $request->get('equipes');
								           $q->whereIn('equipe_user.equipe_id', $idEquipes);
								        
		                         });
						    }
					        

        					if($request->has('conseillers'))
        					{
        						$idConseillers  = $request->get('conseillers');
        						$query->whereIn('classementsantes.equipe_user_id', $idConseillers);
        					}

        						

        					})
							//->select('users.nom', 'users.prenom')
							->orderBy('classementsantes.CACommissionable','desc')
							->with('userEquipe','site','agence','fichesantesActive')
       						->get();

        					//return json_encode($classements);
        					return ['classement' => $classements , 'mois' => $mois , 'annee' => $annee];


    }

    public function getDetailContratsClassement($id)
    {
    	//return $id;

    	// return $classement = ClassementSante::find($id)->fichesantesActive()
     //                         ->with('statut','garantie')
     //                         ->orderBy("fichesantes.date_situation")
     //                         ->get();

        return $classement = DB::table('classementsante_fichesante')
                                 ->join('fichesantes','classementsante_fichesante.fichesante_id','=','fichesantes.id')
                                 ->join('statuts','classementsante_fichesante.statut_id','=','statuts.id')
                                 ->join('sagaranties','classementsante_fichesante.sagarantie_id','=','sagaranties.id')
                                 ->where('classementsante_fichesante.classementsante_id',$id)
                                 ->where('classementsante_fichesante.active',1)
                                 ->select('fichesantes.num_fiche','statuts.libelle as libelleStatut','classementsante_fichesante.date_effet','classementsante_fichesante.date_situation','sagaranties.libelle as libelleGarantie','classementsante_fichesante.cotisationAnnuelle','classementsante_fichesante.statut_id')
                                 ->orderBy('classementsante_fichesante.date_situation')
                                 ->get();




    }

    public function initializeActualMonthRows()
    {
        $date         = Carbon::now();
        $year         = $date->year;
        $month        = $date->month;

       $conseillers = User::where('active',1)
                            ->where('profile_id',7)
                            ->has('userEquipe')
                            ->get();

        foreach ($conseillers as $conseiller) {

            $equipeUSerId = $conseiller->userEquipe()->first()->pivot->id;
        
            // $classement                     = ClassementSante::firstOrCreate(['equipe_user_id' => $equipeUSerId ,'site_id' => $conseiller->site_id ,'agence_id' => $conseiller->agence_id ,'mois' => $month ,'annee' => $year ,'objectif' => $conseiller->objectif]);

            $ligneClassement = Classementsante::where('active',1)
                                              ->where('equipe_user_id',$equipeUSerId)
                                              ->where('site_id',$conseiller->site_id)
                                              ->where('agence_id',$conseiller->agence_id)
                                              ->where('mois',$month)
                                              ->where('annee',$year)
                                              ->first();
            //tester si cette ligne de classement existe ou pas
            if(!$ligneClassement and !empty($conseiller->objectif))
            {
                $classement                     = new Classementsante;
                $classement->equipe_user_id     = $conseiller->userEquipe()->first()->pivot->id;
                $classement->site_id            = $conseiller->site_id;
                $classement->agence_id          = $conseiller->agence_id;
                $classement->mois               = $month;
                $classement->annee              = $year;
                $classement->objectif           = $conseiller->objectif;
                $classement->active             = 1;
                $classement->save();
            }

            

        }

        return 'ok';

    }

    public function getObjectifs()
    {
        $produits    = Produit::where('active', 1)->get();
        $agences    = Agence::where('active', 1)->get();
        //$sites      = Site::where('active', 1)->get();
        //$equipes    = Equipe::where('active', 1)->get();

        $date         = Carbon::now();
        $dateFirstDay = Carbon::create($date->year, $date->month, 01,00,00,00);
        $year         = $date->year;
        $month        = $date->month - 1;

        return view('courtiersfiles.classement.objectif', ['produits' => $produits,'agences' => $agences, 'year' => $year, 'month' => $month, 'date' => $dateFirstDay]);

    }

    public function showObjectifs(Request $request) {
        
        //return $request->all();   
        $tableName            = $request->get('produit');
        $idAgences            = [];
        $idSites              = [];
        $idEquipes            = [];
        $idConseillers        = [];


        // return $classements     = ClassementSante::whereHas('userEquipe', function ($query)  {
        //                                $query->where('equipe_id', 1);
        //                            })->get();

        $users        = User::where('users.active',1)
                            ->where('profile_id',7)
                            ->where(function($query) use ($request){

                            if($request->has('agences') and !$request->has('sites') and !$request->has('equipes') and !$request->has('conseillers')){

                               $idAgences      = $request->get('agences');
                               $query->whereIn('users.agence_id', $idAgences);

                            }

                            if($request->has('sites') and !$request->has('equipes') and !$request->has('conseillers')){

                               $idSites        = $request->get('sites');
                               $query->whereIn('users.site_id', $idSites);
                            }
                            
                            if($request->has('equipes') and !$request->has('conseillers')){
                                $query->whereHas('userEquipe', function ($q)  use ($request){

                                           $idEquipes      = $request->get('equipes');
                                           $q->whereIn('equipe_user.equipe_id', $idEquipes);
                                        
                                 });
                            }
                            

                            if($request->has('conseillers'))
                            {
                                $idConseillers  = $request->get('conseillers');
                                $query->whereIn('users.id', $idConseillers);
                            }

                                

                            })
                            //->select('users.nom', 'users.prenom')
                            //->orderBy('classementsantes.CACommissionable','desc')
                            ->with('userEquipe','site','agence')
                            ->get();

                            //return json_encode($classements);
                            return json_encode($users);


    }

    public function updateObjectifs(Request $request)
    {

        //return $request->all();
        $idUser  = $request->get('idUser');
        $objUser = $request->get('objUser');

        

            $conseiller = User::where('active',1)
                                ->where('id',$idUser)
                                ->first();
            $conseiller->objectif   = $objUser;

        if($conseiller->save())
            return 'ok';
        else
            return 'notok';

    }


}
