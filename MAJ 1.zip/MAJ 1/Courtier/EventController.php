<?php

namespace App\Http\Controllers\Courtier;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use App\Eventgenre;
use App\Eventsupport;
use App\Evenement;
use App\Eventmotif;
use App\Eventacteur;
use App\Eventtype;
use App\Eventpiecejointe;
use App\Produit;
use App\Modelemail;
use Auth;
use App\User;
use App\Site;
use App\Agence;
use Carbon\Carbon;
use Mail;
use App\Action;
use DB;

use App\Http\Controllers\Partage\LeadController;
use App\Events\EventTracesSante;

class EventController extends Controller
{

	

    public function getGenreEvent()
    {
    	$genres = Eventgenre::where('active',1)->select('id','libelle')->get();

    	return $genres;
    }

    public function getSupportEvent()
    {
    	$supports = Eventsupport::where('active',1)->get();

    	return $supports;
    }

    public function postCriteresEvent(Request $request)
    {
    	//return $request->all();
    	$idFiche     				= $request->get('idFiche');
    	$slugProduit 				= $request->get('slugProduit');
    	$criteres    			 	= $request->get('critere');
    	$user                       = Auth::user();

    	$produit = Produit::where('slug',$slugProduit)
    						->where('active',1)
    						->first();

    	$className = "App\Fiche".$slugProduit;

		$fiche = $className::where('id',$idFiche)->with('client')->first();

		//return $fiche->affectedUser($fiche->equipe_user_id)->id;
    	//return $idFiche;
    	$evenement 				 	= new Evenement;
    	$evenement->ficheable_id 	= $idFiche;
    	$evenement->ficheable_type  = $produit->table_produit;
    	$evenement->user_creation   = $user->userEquipe()->first()->pivot->id;//equipe_user_id
        $evenement->user_affected   = $fiche->equipe_user_id;
    	$evenement->etat            = 'NT';
    	$evenement->eventsupport_id = $criteres['supp'];
    	$evenement->eventgenre_id   = $criteres['gender'];
    	$evenement->sens            = $criteres['senss'];
    	$evenement->active          = 1;
    	$evenement->priorite 		= 1;
    	$insertOk                   = $evenement->save();
    	//return $evenement->eventsupport;
    	//récuperer les motifs des evenements
    	$motifs                     = Eventmotif::where('active',1)->select('id','libelle')->get();
    	$acteurs                    = Eventacteur::where('active',1)->select('id','nom','slug')->get();
    	$types                      = Eventtype::where('active',1)->select('id','libelle')->get();
    	$modeleMails                = Modelemail::where('active',1)
    											  ->where('produit_id',$produit->id)
    											  ->where('groupestatut_id',$fiche->statut->groupestatut_id)
    											  ->get();	

        $conseillers = collect(DB::table('equipe_user')
                                ->leftjoin('users','equipe_user.user_id','=','users.id')
                                ->leftjoin('equipes','equipe_user.equipe_id','=','equipes.id')
                                ->where('users.active',1)
                                ->where('equipe_user.active',1)
                                ->where('users.profile_id',7)
                                ->where('users.agence_id',$user->agence_id)
                                ->select('users.id','users.prenom','users.nom','equipe_user.id as equipe_user_id','equipes.nom as nom_equipe')
                                ->get());


    	if($insertOk)
    		return ["etat"=> "ok", "msg"=> "évènement crée avec succès !!", "fiche"=> $fiche,"createdEvent"=> $evenement, "support"=>$evenement->eventsupport,"genre"=>$evenement->eventgenre ,"motifs" =>$motifs ,"acteurs" =>$acteurs ,"types" =>$types,"user"=>$user , "userAffected"=>$evenement->userAffected, "userUpdated"=>$evenement->userUpdated, "modeleMails" => $modeleMails , "conseillers"=>$conseillers];
    	else
    		return ["etat"=> "notok", "msg"=> "erreur de création de l'évènement !!"];

    }

    public function postStoreEditEvent(Request $request)
    {
    	//return $request->all();
    	$idEvent 					= $request->get('idEvent');
    	$priorite 					= $request->get('priorite');
    	$etat 						= $request->get('etat');
    	$motifFermeture 			= $request->get('motifFermeture');
    	$slugSupport 				= $request->get('support');
    	$idGenre 					= $request->get('genre');
    	$sens 						= $request->get('sens');
    	$type 						= $request->get('type');
    	$dateDebut 					= $request->get('dateDebut');
    	$dateFin 					= $request->get('dateFin');
    	$enPause 					= $request->get('enPause');
    	$automatique 				= $request->get('automatique');
    	$source 					= $request->get('source');
    	$destination 				= $request->get('destination');
    	$emetteur 					= $request->get('emetteur');
    	$destinataire 				= $request->get('destinataire');
    	$cc 						= $request->get('cc');
    	$modeleMailId 				= $request->get('modeleMailId');
    	$objet 						= $request->get('objet');
    	$commentaire 				= $request->get('commentaire');
    	$reaffecter 				= $request->get('reaffecter');
    	$insertOrEdit               = $request->get('insertOrEdit');

    	
    	$evenement 					= Evenement::find($idEvent);

    	if($insertOrEdit == 2 and ($slugSupport == 'email' or $slugSupport == 'document'))
    	{
    		//$piecesJointesExisted   = $evenement->eventpiecejointe;
    		//$piecesJointesExisted->delete;
    		$piecesJointesSelected  = $request->get('piecesJointesSelected');
    		DB::table('eventpiecejointes')->where('evenement_id', $idEvent)->delete();
    		if($request->has('piecesJointesSelected'))
    		{
    			DB::table('eventpiecejointes')->insert($piecesJointesSelected);
    		}
    		
    	}


    	
    	$evenement->priorite		= $priorite;
    	$evenement->etat 			= $etat;
    	if($motifFermeture)
    	{
    		$evenement->eventmotif_id   = $motifFermeture;
    	}    	
    	$evenement->eventsupport_id = Eventsupport::where('slug',$slugSupport)->first()->id;
    	$evenement->eventgenre_id   = $idGenre;
    	$evenement->sens            = $sens;
    	$evenement->date_debut      = $dateDebut;
    	if($dateFin)
    	{
    		$evenement->date_fermeture  = $dateFin;
    	}

    	if($type)
    	{
    		$evenement->eventtypes_id   = $type;
    	}
    	
    	if($enPause)
    	{
    		$evenement->enpause         = 1;
    	}    	
    	else
    	{
    		$evenement->enpause         = 0;
    	}

    	if($automatique)
    	{
    		$evenement->automatique         = 1;
    	}    	
    	else
    	{
    		$evenement->automatique         = 0;
    	}

    	if($source)
    	{
    		$evenement->source          = Eventacteur::where('slug',$source)->first()->id;
    	}

    	if($destination)
    	{
    		$evenement->destination     = Eventacteur::where('slug',$destination)->first()->id;
    	}

    	if($emetteur)
    	{
    		$evenement->emetteur     	= $emetteur;
    	}

    	if($destinataire)
    	{
    		$evenement->destinataire    = $destinataire;
    	}

    	if($cc)
    	{
    		$evenement->cc              = $cc;
    	}

    	if($modeleMailId)
    	{
    		$evenement->modelemail_id   = $modeleMailId;
    	}

    	if($commentaire)
    	{
    		$evenement->commentaire   	= $commentaire;
    	}

    	if($objet)
    	{
    		$evenement->objet   		= $objet;
    	}

    	if($reaffecter)
    	{
    		$evenement->user_affected   = $reaffecter;
    	}

    	$evenement->user_update         = Auth::user()->userEquipe()->first()->pivot->id;

    	$saveOk  = $evenement->save();

    	if($saveOk)
    		return 'ok';
    	else
    		return 'notok';


    }

    public function postUploadFileEvent(Request $request)
    {
    	//return $request->all();
    	$slugSupport = $request->get('supportHidden');
    	$numFiche    = $request->get('numFiche');
    	$slugProd    = $request->get('slugProd');
    	$idEvent     = $request->get('idEvenement');
    	//uploader en cas de support email ou document
    	if($slugSupport == 'email' or $slugSupport == 'document')
    	{
    		$files       = $request->file('file');
	    	//dd($files);
	    	foreach ($files as $file ) {
	    		$fileName    = $file->getClientOriginalName();
	    		$path        = "upload/Event_documents/".$slugProd."/".$numFiche;
	    		$fileStored  = $file->move($path,$fileName);

	    		if($fileStored)
	    		{
	    			$pieceJointe 				= new Eventpiecejointe;
	    			$pieceJointe->nom_piece		= $fileName;
	    			$pieceJointe->chemin_piece  = $path;
	    			$pieceJointe->evenement_id  = $idEvent;
	    			$pieceJointe->active 		= 1;
	    			$pieceJointe->save();
	    		}
	    			

	    	}
    	}

    	
    	
    }

    public function getEventList()
    {
    	//return 'tooot';
    	$user 				= Auth::user();
    	$listEvenements     = Evenement::where('user_affected',$user->userEquipe()->first()->pivot->id)
    								   ->where('active',1)
    								   ->orderBy('created_at','desc')
    								   ->with('eventsupport','eventgenre','source','destination','modelemail')
    								   ->get();
    	return $listEvenements;
    }

    public function getDetailEvent(Request $request)
    {
    	//return $request->all();	

    	$idEvent                    = $request->get('idEvent');
    	$slugProduit                = $request->get('slugProduit');

    	$evenement 					= Evenement::find($idEvent);
    	$produit 					= Produit::where('slug',$slugProduit)
    									->where('active',1)
    									->first();

    	$className 					= "App\Fiche".$slugProduit;

		$fiche 						= $className::where('id',$evenement->ficheable_id)->with('client')->first();
   	
    	$motifs                     = Eventmotif::where('active',1)->select('id','libelle')->get();
    	$acteurs                    = Eventacteur::where('active',1)->select('id','nom','slug')->get();
    	$types                      = Eventtype::where('active',1)->select('id','libelle')->get();
    	$modeleMails                = Modelemail::where('active',1)
    											  ->where('produit_id',$produit->id)
    											  ->where('groupestatut_id',$fiche->statut->groupestatut_id)
    											  ->get();	
    	$user       = Auth::user();
        $conseillers = collect(DB::table('equipe_user')
                                ->leftjoin('users','equipe_user.user_id','=','users.id')
                                ->leftjoin('equipes','equipe_user.equipe_id','=','equipes.id')
                                ->where('users.active',1)
                                ->where('equipe_user.active',1)
                                ->where('users.profile_id',7)
                                ->where('users.courtier_id', $user->courtier_id)
                                ->select('users.id','users.prenom','users.nom','equipe_user.id as equipe_user_id','equipes.nom as nom_equipe')
                                ->get());

		//$piecesJointes              = $evenement->eventpiecejointe()->select('id','nom_piece','chemin_piece')->get();
		$piecesJointes              = $evenement->eventpiecejointe;

		return ["fiche"=>$fiche,"motifs" =>$motifs ,"acteurs" =>$acteurs ,"types" =>$types,"user"=>$evenement->userCreated , "userAffected"=>$evenement->userAffected, "userUpdated"=>$evenement->userUpdated, "modeleMails" => $modeleMails , "conseillers"=>$conseillers , "piecesJointes"=>$piecesJointes];

    }

    public function getDetailEventSearch(Request $request)
    {
    	$request->all();	

    	$idEvent                    = $request->get('idEvent');
    	$slugProduit                = $request->get('slugProduit');

    	$evenement 					= Evenement::where('id',$idEvent)
    								  			->with('eventsupport','eventgenre','source','destination','modelemail')
    								   			->first();
    	$produit 					= Produit::where('slug',$slugProduit)
    									->where('active',1)
    									->first();

    	$className 					= "App\Fiche".$slugProduit;

		$fiche 						= $className::where('id',$evenement->ficheable_id)->with('client')->first();
   	
    	$motifs                     = Eventmotif::where('active',1)->select('id','libelle')->get();
    	$acteurs                    = Eventacteur::where('active',1)->select('id','nom','slug')->get();
    	$types                      = Eventtype::where('active',1)->select('id','libelle')->get();
    	$modeleMails                = Modelemail::where('active',1)
    											  ->where('produit_id',$produit->id)
    											  ->where('groupestatut_id',$fiche->statut->groupestatut_id)
    											  ->get();	
    	$user       = Auth::user();
        $conseillers = collect(DB::table('equipe_user')
                                ->leftjoin('users','equipe_user.user_id','=','users.id')
                                ->leftjoin('equipes','equipe_user.equipe_id','=','equipes.id')
                                ->where('users.active',1)
                                ->where('equipe_user.active',1)
                                ->where('users.profile_id',7)
                                ->where('users.courtier_id', $user->courtier_id)
                                ->select('users.id','users.prenom','users.nom','equipe_user.id as equipe_user_id','equipes.nom as nom_equipe')
                                ->get());

		//$piecesJointes              = $evenement->eventpiecejointe()->select('id','nom_piece','chemin_piece')->get();
		$piecesJointes              = $evenement->eventpiecejointe;

		return ["fiche"=>$fiche,"motifs" =>$motifs ,"acteurs" =>$acteurs ,"types" =>$types,"user"=>$evenement->userCreated , "userAffected"=>$evenement->userAffected, "userUpdated"=>$evenement->userUpdated, "modeleMails" => $modeleMails , "conseillers"=>$conseillers , "piecesJointes"=>$piecesJointes, "event"=>$evenement];

    }

    public function getEventSearchingPage()
    {
    	$produits    	  = Produit::where('active', 1)->get();
    	$motifs           = Eventmotif::where('active',1)->select('id','libelle')->get();
    	$supports         = Eventsupport::where('active',1)->get();
    	$genres 		  = Eventgenre::where('active',1)->select('id','libelle')->get();
    	$types            = Eventtype::where('active',1)->select('id','libelle')->get();

        $user             = Auth::user();
        $courtier         = $user->courtier;
        $courtier_id      = $courtier->id;        
        $agences          = $courtier->agences;        
        $sites            = $courtier->sites;        
        $equipes          = collect([]);
        
        foreach ($sites as $site) { $equipes = $equipes->push($site->equipes);}

        $equipes     =  $equipes->flatten(1);
        
        $conseillers = collect(DB::table('equipe_user')
                                ->leftjoin('users','equipe_user.user_id','=','users.id')
                                ->where('users.active',1)
                                ->where('equipe_user.active',1)
                                ->where('users.profile_id',7)
                                ->where('users.courtier_id', $courtier_id)
                                ->select('users.id','users.prenom','users.nom','equipe_user.id as equipe_user_id')
                                ->get());

    	return view('courtiersfiles.events.listEvents',['motifs' => $motifs, 'supports' => $supports, 'genres' => $genres, 'types' => $types, 'produits' => $produits,'agences' => $agences,'sites' => $sites, 'equipes' => $equipes, 'conseillers' => $conseillers]);
    }

    public function rechercheEvents(Request $request) {
        
        $tableName          = $request->get('produit');
        $user               = Auth::user();
        $courtier           = $user->courtier;
        $courtier_id        = $courtier->id;        
        $agences            = $courtier->agences;        
        $sites              = $courtier->sites;        
        $equipes            = collect([]);
        
        foreach ($sites as $site) { $equipes = $equipes->push($site->equipes);}

        $equipes     =  $equipes->flatten(1);

        $idsUserEquipe = "";

        if($request->get('conseiller') and !$request->get('equipe')){
            //return $request->get('conseiller');
            $idUser         = $request->get('conseiller');
            $idsUserEquipe  = User::find($idUser)->allUserEquipe()->lists("equipe_user.id"); 

        }else if($request->get('conseiller') and $request->get('equipe')){
            //return $request->get('conseiller');
            $idUser         = $request->get('conseiller');
            $idEquipe       = $request->get('equipe');
            $idsUserEquipe  = User::find($idUser)->allUserEquipe()->where("equipes.id", $idEquipe)->lists("equipe_user.id"); 

        }

        $evenements         = Evenement::join("$tableName", 'evenements.ficheable_id', '=', "$tableName.id")
        								->where('evenements.active',1)
        								//->where('evenements.user_affected',$user->id)
        								->where(function($query) use ($request,$tableName){
        									if($request->has('numComtrat'))
        									{        										
        										$query->where("$tableName.num_fiche", $request->get('numComtrat'));
        									}

        									if($request->has('numEvent')){

				                                $query->where("evenements.id", $request->get('numEvent'));
				                            } 

				                            if($request->has('dateDebutRech') and $request->has('dateFinRech')){

				                                $query->whereBetween("evenements.".$request->get("typeDate"), [$request->get('dateDebutRech')." 00:00:00", $request->get('dateFinRech')." 23:59:59"]);

				                            }else if($request->has('dateDebutRech')){

				                                $query->where("evenements.".$request->get("typeDate"), '>=', $request->get('dateDebutRech')." 00:00:00");

				                            }else if($request->has('dateFinRech')){

				                                $query->where("evenements.".$request->get("typeDate"), '<=', $request->get('dateFinRech')." 23:59:59");
				                            } 

				                            if($request->has('support') and $request->get('support') != "0" ){

				                                $query->where("evenements.eventsupport_id", $request->get('support'));
				                            } 

				                            if($request->has('genre') and $request->get('genre') != "0" ){

				                                $query->where("evenements.eventgenre_id", $request->get('genre'));
				                            } 

				                            if($request->has('sens') and $request->get('sens') != "0" ){

				                                $query->where("evenements.sens", $request->get('sens'));
				                            } 

				                            if($request->has('priorite')){

				                                $query->where("evenements.priorite", $request->get('priorite'));
				                            }  

				                            if($request->has('etat') and $request->get('etat') != "0" ){

				                                $query->where("evenements.etat", $request->get('etat'));
				                            } 

				                            if($request->has('type') and $request->get('type') != "0" ){

				                                $query->where("evenements.eventtypes_id", $request->get('type'));
				                            } 

				                            if($request->has('motifFermeture') and $request->get('motifFermeture') != "0" ){

				                                $query->where("evenements.eventmotif_id", $request->get('motifFermeture'));
				                            }     

        								})

                                        ->where(function($query) use ($request, $tableName, $user, $idsUserEquipe, $equipes){
                                
                                            if($request->get('conseiller')){
                                                
                                                $query->whereIn('evenements.user_affected', $idsUserEquipe);

                                            }else if($request->get('equipe') and !$request->get('conseiller')){

                                                $query->whereHas('userAffected', function ($q)  use ($request){

                                                           $idEquipes      = $request->get('equipe');
                                                           $q->where('equipe_user.equipe_id', $idEquipes);
                                                        
                                                 });

                                            }
                                            else if($request->get('site') and !$request->get('conseiller') and !$request->get('equipe')){

                                               $site = Site::where('id',$request->get('site'))->first();

                                                //if(count($site)>0){ 

                                                    //$site_id   = $request->get('site');
                                                    $equipesSite     = $site->equipes;
                                                    $equipeIdsSite   = $equipesSite->lists('id');

                                                    $query->whereHas('userAffected', function ($q)  use ($equipeIdsSite){

                                                           $q->whereIn('equipe_user.equipe_id', $equipeIdsSite);
                                                        
                                                    });

                                                //}  

                                            }else if(!$request->get('conseiller') and !$request->get('equipe') and !$request->get('site') and $request->get('agence')){

                                                $agence = Agence::where('id',$request->get('agence'))->first();                                 

                                                $query->whereHas('userAffected', function ($q)  use ($agence){
                                
                                                        $equipesAgence   = $agence->equipes;
                                                        $equipeIdsAgence = $equipesAgence->lists('id');

                                                        $q->whereIn('equipe_user.equipe_id', $equipeIdsAgence);
                                                        
                                                 });

                                            }else if(!$request->get('conseiller') and !$request->get('equipe') and !$request->get('site') and !$request->get('agence')){

                                                $query->whereHas('userAffected', function ($q)  use ($equipes){
                                
                                                        $equipeIds       = $equipes->lists('id');

                                                        $q->whereIn('equipe_user.equipe_id', $equipeIds);
                                                        
                                                 });
                                            }   
                                                                                                                                        
                                       })

        								->with('eventsupport','eventgenre','eventtype','userAffected')
       									//->get());
       									//->orderBy("evenements.date_debut")
       									->select('evenements.id','evenements.date_debut','evenements.date_fermeture','evenements.eventgenre_id','evenements.eventsupport_id','evenements.sens','evenements.priorite','evenements.etat','evenements.eventtypes_id','evenements.eventmotif_id',"$tableName.num_fiche",'evenements.user_affected',"$tableName.id as idfiche","$tableName.slug")
                       					->paginate(20);
                       					return json_encode($evenements);

 

    }

	
}
