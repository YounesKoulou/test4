<?php

namespace App\Http\Controllers\Courtier;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Produit;
use App\Statut;
use App\Groupestatut;
use App\Process;
use App\ProcessStatut;


class ProcesseStatutController extends Controller
{

    function genererSlug($string){

        $tabMots        = explode(" ", $string);
        $initiale       = '';
        $nbrMots        = count($tabMots);

        if($nbrMots > 2){

            foreach($tabMots as $init){
                $initiale .= $init{0};
            }
            return strtoupper($initiale);

        }elseif($nbrMots == 2){

            return camel_case($string);

        }else{

            return strtolower($string);
        }
        
    }


    public function loadProsesseStatuts(Request $request){

        // retourne la liste des statuts du produit selectionner avec ces processes
        
        $statuts          = Statut::where('slug_produit', $request->get('slugProduit'))->get();
        $processes        = Process::where('active', 1)->get();
        $slugProduit      = $request->get('slugProduit');

        $grpStatuts       = Groupestatut::orderBy('ordre', 'asc')

                            ->with(['statuts' => function($req) use ($slugProduit){

                                $req->where('slug_produit', $slugProduit);                                            
                                
                                $req->with(['processStatus' => function($q){

                                    $q->with('process');
                                    
                                }]);

                            }])

                            ->get();                   

        return ['statuts' => $statuts, 'grpStatuts' => $grpStatuts, 'processes' => $processes];      
    }

   public function loadProsesseStatutsStatut(Request $request){

        // retourne la liste des statuts du produit et statut selectionner avec ces processes 

        $idStatus         = $request->get('idStatut');
        $grpStatuts       = Groupestatut::orderBy('ordre', 'asc')

                            ->with(['statuts' => function($req) use ($idStatus){

                                $req->where('id', $idStatus);                                            
                                
                                $req->with(['processStatus' => function($q){

                                    $q->with('process');
                                    
                                }]);

                            }])

                            ->get();                   

        return ['grpStatuts' => $grpStatuts];      
    }

    public function loadMotifsStatut(Request $request){

        // retourne la liste des groupes motifs avec ces motifs du statut selectionner
        $idStatus       = $request->get('idStatut');
        $grpMotifs      = Groupemotif::orderBy('ordre', 'asc')
                            ->with(['motifs' => function($q) use ($idStatus){
                                $q->where('statut_id', $idStatus);
                                $q->with('statut');                                                                   
                            }])
                            ->get(); 
                            
        return ['grpMotifs' => $grpMotifs];      
    }    


    public function addProcess(Request $request){

    	$process               = Process::where('libelle','like', $request->get('nom'))->first();
        $resultat              = "";

    	if($process){

    		$resultat          = ["etatOperation" => 0, "etat" => "warning", "msg" => "Cette étape existe dèja !", "titre" => "Attention !"];
            
    	}else{
            
            $process           = new Process;
            $process->libelle  = $request->get('nom');
            $process->slug     = $this->genererSlug($request->get('nom'));
            $process->icon     = $request->get('icon');;
            $process->active   = 1;


            if($process->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "Etape ajoutée avec succèss", "titre" => "Opération efféctuée", "id" => $process->id, "slug" => $process->slug];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de l ajout", "titre" => "Opération échouée"];   
                    
            }  
             
        }
        
        return $resultat;
    }



    public function updateProcess(Request $request){

    	$process        = Process::where('id','!=', $request->get('id'))->where('libelle','like', $request->get('nom'))->first();
        $resultat       = "";

    	if($process){

    		$resultat   = ["etatOperation" => 0, "etat" => "warning", "msg" => "Ce groupe d motif existe dèja !", "titre" => "Attention !"];
            
    	}else{

            $process           = Process::find($request->get('id'));
            $process->libelle  = $request->get('nom');
            $process->icon     = $request->get('icon');

            if($process->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "Modification efféctuée avec succèss", "titre" => "Opération efféctuée"];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de la modification", "titre" => "Opération échouée"];   
                    
            }  
             
        }
        
        return $resultat;
    }

    public function activerProcess(Request $request){

    	$process = Process::find($request->get('idProcess'));

        if($process->active){

            $process->active = 0;
            $msg = "Etape désactivée.";

        }else{

            $process->active = 1;
            $msg = "Etape activée.";
        } 

        if($process->save()){

            return $resultat = ["etatOperation" => 1, "active" => $process->active,"etat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];

        }else{

            return $resultat = ["etatOperation" => 0, "etat" => "error", "msg" => "", "titre" => "opération échouée !"];
        }
    }


    public function addProcessStatut(Request $request){

    	// $processStatutExist = processStatut::where('statut_id', $request->get('idStatut'))
        //                                     ->where('process_id', $request->get('idProcess'))
        //                                     ->first();
        // $resultat           = "";

    	// if($processStatutExist){

    	// 	$resultat       = ["etatOperation" => 0, "etat" => "warning", "msg" => "Cette étape existe dèja !", "titre" => "Attention !"];
            
    	// }else{
            
            $processStatut                  = new ProcessStatut;
            $processStatut->statut_id       = $request->get('idStatut');
            $processStatut->process_id      = $request->get('idProcess');
            $processStatut->duree           = $request->get('dureeProcess');
            $processStatut->active          = 1;
            $maxOrder                       = processStatut::where('statut_id', $request->get('idStatut'))->max('ordre');

            if($maxOrder){

                $processStatut->ordre       = $maxOrder + 1;

            }else{

                $processStatut->ordre       = 1;
            }
            if($processStatut->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "Etape afféctée avec succèss", "titre" => "Opération efféctuée", "id" => $processStatut->id, "ordre" => $processStatut->ordre];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de l afféctation", "titre" => "Opération échouée"];                       
            }  
             
        // }
        
        return $resultat;
    }

    public function suppProcessStatut(Request $request){

    	//return $request->get('idStatut').' '.$request->get('idProcess');
        $processStatutDelete = ProcessStatut::where('id', $request->get('idProcessStatut'))->delete();

        if($processStatutDelete){

            return $resultat = ["etatOperation" => 1,"etat" => "success", "msg" => "", "titre" => "opération éfectuée"];

        }else{

            return $resultat = ["etatOperation" => 0, "etat" => "error", "msg" => "", "titre" => "opération échouée !"];
        }
    } 

    public function updateClassProcessStatut(Request $request){
        
    	$processStatuts     = $request->get('processStatuts');
    	$count              = 1;
        
    	foreach ($processStatuts as $processStatut){

    		$ligneProcessStatut         = ProcessStatut::find($processStatut['id']);
    		$ligneProcessStatut->ordre  = $count;
    		$ligneProcessStatut->save();
    		$count++;
    	}
    }       

    public function updateMotif(Request $request){

    	$motif              = Motif::where('id','!=', $request->get('id'))
                                ->where('libelle','like', $request->get('nom'))
                                ->where('groupemotif_id', $request->get('idGrpMotif'))
                                ->where('statut_id', $request->get('statutMotif'))
                                ->first();
        $resultat           = "";

    	if($motif){

    		$resultat       = ["etatOperation" => 0, "etat" => "warning", "msg" => "Ce motif existe dèja !", "titre" => "Attention !"];
            
    	}else{

            $motif              = Motif::find($request->get('id'));
            $motif->libelle     = $request->get('nom');
            $motif->statut_id   = $request->get('statutMotif');
            //$groupeMotif->slug     = $request->get('slug');

            if($motif->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "Modification efféctuée avec succèss", "titre" => "Opération efféctuée"];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de la modification", "titre" => "Opération échouée"];   
                    
            }  
             
        }
        
        return $resultat;
    }


    public function activerMotif(Request $request){

    	$motif = Motif::find($request->get('idMotif'));

        if($motif->active){

            $motif->active = 0;
            $msg = "Motif désactivée.";

        }else{

            $motif->active = 1;
            $msg = "Motif activée.";
        } 

        if($motif->save()){

            return $resultat = ["etatOperation" => 1, "active" => $motif->active,"etat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];

        }else{

            return $resultat = ["etatOperation" => 0, "etat" => "error", "msg" => "", "titre" => "opération échouée !"];
        }
    }






}
