<?php

namespace App\Http\Controllers\Courtier;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Http\Requests;
use App\Produit;
use App\Documentation;

class DocumentationController extends Controller
{
    public function index(){

    	//$idProduit 	= $request->get('id');
		$produits 	= Produit::where('active', 1)->with('documentations')->get();
		//return $produits;
    	return view('courtiersfiles.documentation.index',["produits" => $produits]);
    }


    public function edit($idProduit){

		$produit 	= Produit::where('id', $idProduit)->with('documentations')->first();
		//return $produit; 
    	return view('courtiersfiles.documentation.edit',["produit" => $produit]);
    }


    public function update(Request $request, $id){

    	//return $request->all();

		$documentation 					= Documentation::where('produit_id', $id)->first();

    	$documentation->documentation 	= $request->get("documentation");	

    	$documentation->save();

	    $produits 	= Produit::where('active', 1)->with('documentations')->get();

	    return redirect('courtier/documentation')->with("idProduit", $id);



    }

}
