<?php

namespace App\Http\Controllers\Courtier;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Courtier;
use App\User;
use App\Messagerie;
use Auth;
use App\Tracessante;

class ProfileController extends Controller
{
    public function index() {
       
        $idcourtier = Auth::user()->courtier_id;
        $courtier   = Courtier::find($idcourtier);
        $agences    = Courtier::find($idcourtier)->agences()->paginate(5);
        $user = Auth::user();
        $nombreMessageNonLu = Messagerie::where('vu', 0)->whereActive(1)->where('to_id', $user->id)->orderBy('created_at', 'desc')->get();
        $oriasCourtier = Courtier::first()->orias;

        $traces = Tracessante::where('user_id', $user->id)->orderBy('created_at', 'desc')->take(10)->get();
       return view('courtiersfiles.courtiers.profile', ['courtier' => $courtier, 'agences' => $agences, 'user' => $user, 'nombreMessageNonLu' => $nombreMessageNonLu, 'traces' => $traces, 'oriasCourtier' => $oriasCourtier]);
    }


    public function DispatchAuto($id)
    {
        $courtier  = Courtier::find($id);
        $msg     = "";

        if($courtier->disp_auto)
        {
            $courtier->disp_auto = 0;
            $msg = "Dispatching automatique désactivé.";
        }
        else
        {
            $courtier->disp_auto = 1;
            $msg = "Dispatching automatique activé.";
        }

        if($courtier->save()){

            return $data = ["resultat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];
        }else{

            return $data = ["resultat" => "error", "msg" => $msg, "titre" => "opération échouée !"];
        }

    }


    public function ActiveMatiere($id)
    {
        $courtier  = Courtier::find($id);
        $msg     = "";

        if($courtier->active_matiere)
        {
            $courtier->active_matiere = 0;
            $msg = "Matière désactivée.";
        }
        else
        {
            $courtier->active_matiere = 1;
            $msg = "Matière activée.";
        }

        if($courtier->save()){

            return $data = ["resultat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];
        }else{

            return $data = ["resultat" => "error", "msg" => $msg, "titre" => "opération échouée !"];
        }

    }
}
