<?php
namespace App\Http\Controllers\Courtier;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\ProvenanceAjoutRequest;
use App\Http\Requests;
use App\Prestataire;
use App\Provenance;
class ProvenanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $idPrestataire  = $request->get('id');
        $prestataire    = Prestataire::find($idPrestataire);
        //$provenances    = Prestataire::find($idPrestataire)->provenances;
        $provenances    = $prestataire->provenances;
        return view("courtiersfiles.prestataire.provenance.index",["prestataire"=>$prestataire, "provenances"=>$provenances]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $idPrestataire = $request->get('id');
        return view("courtiersfiles.prestataire.provenance.create",["id"=>$idPrestataire]);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ProvenanceAjoutRequest $request)
    {
        //eturn $request->all();
        $provenance = new Provenance;
        $provenance->nom                = $request->get('nom');
        $provenance->lien               = $request->get('lien');
        $provenance->page_confirmation  = $request->get('page_confirmation');
        $provenance->page_rejet         = $request->get('page_rejet');
        $idPrestataire                  = $request->get('id');
        $provenance->prestataire_id     = $idPrestataire;    
        $provenance->save();
        return redirect("courtier/provenance?id=".$idPrestataire);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $provenance      = Provenance::find($id);
        return view("courtiersfiles.prestataire.provenance.show",["provenance"=>$provenance]);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $provenance = Provenance::find($id);
        return view('courtiersfiles.prestataire.provenance.edit',compact("provenance"));
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ProvenanceAjoutRequest $request, $id)
    {
        $provenance                     = Provenance::find($id);
        $provenance->nom                = $request->get('nom');
        $provenance->lien               = $request->get('lien');
        $provenance->page_confirmation  = $request->get('page_confirmation');
        $provenance->page_rejet         = $request->get('page_rejet');
        $provenance->save();
        return redirect("courtier/provenance?id=".$provenance->prestataire_id);
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function etatProvenance($id){
        $provenance = Provenance::find($id);
        if($provenance->active){
            $provenance->active = 0;
            $msg = "Provenance désactivé.";
        }else{
            $provenance->active = 1;
            $msg = "Provenance activé.";
        } 
        if($provenance->save()){
            return $data = ["resultat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];
        }else{
            return $data = ["resultat" => "error", "msg" => $msg, "titre" => "opération échouée !"];
        }
    }
    //retourne la liste des provenances d'un prestataire
    public function listProvenances($id)
    {
         $prestataire    = Prestataire::find($id);
         $provenances    = $prestataire->provenances;
        return view("courtiersfiles.prestataire.provenance.index",["prestataire"=>$prestataire, "provenances"=>$provenances]);
    }
}