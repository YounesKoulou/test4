<?php

namespace App\Http\Controllers\Courtier;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Http\Requests\StoreEquipeRequest;

use App\Http\Requests\EditEquipeRequest;

use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\Publique\FicheController;

use App\Categoryequipe;

use App\Equipe;

use App\Profile;

use App\Site;

use App\User;

use App\Ip;

use Carbon\Carbon;

use Image;



class EquipeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $idsite           = Input::get('id');
        $site             = Site::find($idsite);
        $idcategoryequipe = Categoryequipe::where('slug','commercial')->first();
        $profilequipe     = Profile::whereSlug('equipe')->first();
        $animateurs       = $site->animateurs();
        return view('courtiersfiles.equipes.create', ['site'=> $site, 'idcategoryequipe'=> $idcategoryequipe, 'profilequipe' => $profilequipe ,'animateurs' => $animateurs]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreEquipeRequest $request)
    {
        $idsite                         = $request->get('idsite');
        $site                           = Site::where('id',$idsite)
                                                ->first();
        $agence                         = $site->agence;

        $equipe                         = new Equipe();
        $equipe->nom                    = $request->get('nomequipe');       
        $equipe->site_id                = $idsite;
        $equipe->categoryequipe_id      = $request->get('idcategoryequipe');
        $equipe->active                 = 1;

        if($equipe->save() and $request->get('check_produit')){

            $idsEquipeProduit = $request->get('check_produit');
            $equipe->produits()->attach($idsEquipeProduit, ['active' => 1]);
        }  

        if($request->has('choixAnimateur') and $request->get('choixAnimateur')==1)//Si on a choisit un animateur deja existant
        {
            $idAnimateur                    = $request->get('animateur');
            $equipeAdmin                    = User::find($idAnimateur);
        }
        else//On cree un nouveau animateur
        { 

            $equipeAdmin                    = new User();
            $equipeAdmin->nom               = $request->get('nomanimateur');
            $equipeAdmin->prenom            = $request->get('prenom');
            $equipeAdmin->login             = $request->get('login');
            $equipeAdmin->profile_id        = $request->get('profilequipe');
            $equipeAdmin->email             = $request->get('email');
            $equipeAdmin->password          = bcrypt($request->get('password'));
            $equipeAdmin->site_id           = $idsite;
            $equipeAdmin->agence_id         = $site->agence_id;
            $equipeAdmin->courtier_id       = $agence->courtier_id;
            $equipeAdmin->save();

            $ip = new Ip;
            $ip->ip_internet = $request->ip();

            $equipeAdmin->ips()->save($ip);

        }

        $todayDate                      = date('Y-m-d');

        $equipe->equipeAnimateur()->attach($equipeAdmin->id,['date_debut' => $todayDate, 'active' => 1]);

        return redirect('courtier/agence/site/equipe/'.$equipe->id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $equipe                = Equipe::find($id);
        //return $conseillers    = $equipe->equipeConseillers;

        return view('courtiersfiles.equipes.show',['equipe'=> $equipe]);
    }

    public function showResp($id)
    {
        $equipe                = Equipe::find($id);
        //$equipeAdmin           = $equipe->equipeAnimateur()->first();

        return view('courtiersfiles.equipes.showResp',[
                                                        'equipe'=> $equipe 
                                                      ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $equipe                = Equipe::find($id);
        
        return view('courtiersfiles.equipes.edit',['equipe'=> $equipe]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $equipe                         = Equipe::find($id);
        $equipe->nom                    = $request->get('nom');  

        if($request->file('photo')){
                
                $img = $request->file('photo');
                $mime = Image::make($img)->mime();
                if( $mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif')
                {
                    $imgName       = $equipe->nom.'.'.$img->getClientOriginalExtension();
                    $equipe->photo = $imgName;
                    $image         = Image::make($img)->resize(100, 100)->save('upload/avatars/equipe/'.$imgName);
                }
                else
                {
                    return redirect('courtier/agence/site/equipe/'.$id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
                }

        }     

        if($equipe->save()){

            $idsEquipeProduit = ($request->has('check_produit') ?  $request->get('check_produit') : []);            
            $equipe->produits()->sync($idsEquipeProduit, ['active' => 1]);
            
        } 

        return redirect('courtier/agence/site/equipe/'.$id);
    }


    public function activeEquipe($id)
    {
        $equipe  = Equipe::find($id);
        
        if(count($equipe))
        {
            if($equipe->active)
            {
                $equipe->active = 0;
                $value          = 0;
            }
            else
            {
                $equipe->active = 1;
                $value          = 1;
            }

            $equipe->save();
            $msg = 'ok';

        }
        else
        {
            $msg = 'notok';
        }

        return ['msg'=>$msg , 'value'=>$value];    


    }

    public function DispatchAuto(Request $request){
        
        $equipe  = Equipe::find($request->get('idEquipe'));

        if($equipe->disp_auto){

            $equipe->disp_auto          = 0;

            if($equipe->save()) 
                $resultat = ["code" => 1, "etat" => "success", "msg" => "Dispatching automatique désactivé", "titre" => "opération éfectuée", "dispAuto" => $equipe->disp_auto];
            else    
                $resultat = ["code" => 3, "etat" => "error", "msg" => "", "titre" => "opération échouée !", "dispAuto" => $equipe->disp_auto];
            
        }else{

            if($equipe->active_matiere){

                $equipe->disp_auto      = 1;

                if($equipe->save()){

                    $FicheController    = new FicheController();
                    $resultatDisp       = $FicheController->dispatchingConseiller($equipe->id);
                    $resultat           = $resultat = ["code" => 4, "etat" => "success", "dispAuto" => $equipe->disp_auto, "resultatDisp" => $resultatDisp];
                    
                }else{

                    $resultat = ["code" => 3, "etat" => "error", "msg" => "", "titre" => "opération échouée !", "dispAuto" => $equipe->disp_auto];
                }
            }else{

                $resultat = ["code" => 2, "etat" => "warning", "msg" => "Vous devez activer la matière ", "titre" => "Attention !", "dispAuto" => $equipe->disp_auto];

            }
            
        }

        return $resultat;

    }


    public function ActiveMatiere(Request $request)
    {
        $equipe  = Equipe::find($request->get('idEquipe'));
        $msg     = "";

        if($equipe->active_matiere)
        {
            $equipe->active_matiere = 0;
            $msg = "Matière désactivée.";
        }
        else
        {
            $equipe->active_matiere = 1;
            $msg = "Matière activée.";
        }

        if($equipe->save()){

            return $data = ["etat" => "success", "msg" => $msg, "titre" => "opération éfectuée", "matiere" => $equipe->active_matiere];
        }else{

            return $data = ["etat" => "error", "msg" => "", "titre" => "opération échouée !", "matiere" => $equipe->active_matiere];
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
