<?php

namespace App\Http\Controllers\Courtier;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Motif;
use App\Produit;
use App\Statut;
use App\Groupemotif;


class MotifController extends Controller
{

    function genererSlug($string){

        $tabMots        = explode(" ", $string);
        $initiale       = '';
        $nbrMots        = count($tabMots);

        if($nbrMots > 2){

            foreach($tabMots as $init){
                $initiale .= $init{0};
            }
            return strtoupper($initiale);

        }elseif($nbrMots == 2){

            return camel_case($string);

        }else{

            return strtolower($string);
        }
        
    }


    public function loadMotifs(Request $request){

        // retourne la liste des groupes motifs avec ces motifs du produit selectionner
        $statuts          = Statut::where('slug_produit', $request->get('slugProduit'))->get();
        $idsStatus        = $statuts->lists("id");

        $grpMotifs        = Groupemotif::orderBy('ordre', 'asc')
                            ->with(['motifs' => function($q) use ($idsStatus){
                                $q->whereIn('statut_id', $idsStatus);
                                $q->with('statut');                                                                   
                            }])
                            ->get(); 
                            // ->whereHas('motifs' , function($q) use ($idsStatus){
                            //     $q->whereIn('statut_id', $idsStatus);                                                                   
                            // })
                            
        return ['statuts' => $statuts, 'grpMotifs' => $grpMotifs];      
    }

    public function loadMotifsStatut(Request $request){

        // retourne la liste des groupes motifs avec ces motifs du statut selectionner
        $idStatus       = $request->get('idStatut');
        $grpMotifs      = Groupemotif::orderBy('ordre', 'asc')
                            ->with(['motifs' => function($q) use ($idStatus){
                                $q->where('statut_id', $idStatus);
                                $q->with('statut');                                                                   
                            }])
                            ->get(); 
                            
        return ['grpMotifs' => $grpMotifs];      
    }    


    public function addGrpMotif(Request $request){

    	$groupeMotif       = Groupemotif::where('libelle','like', $request->get('nom'))->first();
        $resultat          = "";

    	if($groupeMotif){

    		$resultat       = ["etatOperation" => 0, "etat" => "warning", "msg" => "Ce groupe d motif existe dèja !", "titre" => "Attention !"];
            
    	}else{
            
            $groupeMotif           = new Groupemotif;
            $groupeMotif->libelle  = $request->get('nom');
            $groupeMotif->slug     = $this->genererSlug($request->get('nom'));
            $groupeMotif->ordre    = Groupemotif::all()->max('ordre')+1;
            $groupeMotif->active   = 1;


            if($groupeMotif->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "groupe motifs ajouté avec succèss", "titre" => "Opération efféctuée", "id" => $groupeMotif->id, "slug" => $groupeMotif->slug, "ordre" => $groupeMotif->ordre];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de l ajout", "titre" => "Opération échouée"];   
                    
            }  
             
        }
        
        return $resultat;
    }

    public function updateGrpMotif(Request $request){

    	$groupeMotif       = Groupemotif::where('id','!=', $request->get('id'))->where('libelle','like', $request->get('nom'))->first();
        $resultat           = "";

    	if($groupeMotif){

    		$resultat       = ["etatOperation" => 0, "etat" => "warning", "msg" => "Ce groupe d motif existe dèja !", "titre" => "Attention !"];
            
    	}else{

            $groupeMotif           = Groupemotif::find($request->get('id'));
            $groupeMotif->libelle      = $request->get('nom');
            //$groupeMotif->slug     = $request->get('slug');

            if($groupeMotif->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "Modification efféctuée avec succèss", "titre" => "Opération efféctuée"];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de la modification", "titre" => "Opération échouée"];   
                    
            }  
             
        }
        
        return $resultat;
    }

    public function activerGrpMotif(Request $request){

    	$groupeMotif = Groupemotif::find($request->get('idGrpMotif'));

        if($groupeMotif->active){

            $groupeMotif->active = 0;
            $msg = "Groupe motifs désactivé.";

        }else{

            $groupeMotif->active = 1;
            $msg = "Groupe motifs activé.";
        } 

        if($groupeMotif->save()){

            return $resultat = ["etatOperation" => 1, "active" => $groupeMotif->active,"etat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];

        }else{

            return $resultat = ["etatOperation" => 0, "etat" => "error", "msg" => "", "titre" => "opération échouée !"];
        }
    }


    public function addMotif(Request $request){

    	$Motif              = Motif::where('groupemotif_id', $request->get('idGrpMotif'))
                                ->where('libelle','like', $request->get('nom'))
                                ->where('statut_id', $request->get('statutMotif'))
                                ->first();
        $resultat           = "";

    	if($Motif){

    		$resultat       = ["etatOperation" => 0, "etat" => "warning", "msg" => "Ce motif existe dèja !", "titre" => "Attention !"];
            
    	}else{
            
            $Motif                     = new Motif;
            $Motif->libelle            = $request->get('nom');
            $Motif->groupemotif_id     = $request->get('idGrpMotif');
            $Motif->slug               = $this->genererSlug($request->get('nom'));
            $Motif->ordre              = Motif::where('groupemotif_id','==', $request->get('idGrpMotif'))->max('ordre')+1;
            $Motif->code               = $Motif->ordre;            
            $Motif->statut_id          = $request->get('statutMotif');
            $Motif->active             = 1;


            if($Motif->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "Motif ajouté avec succèss", "titre" => "Opération efféctuée", "id" => $Motif->id, "slug" => $Motif->slug, "ordre" => $Motif->ordre];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de l ajout", "titre" => "Opération échouée"];                       
            }  
             
        }
        
        return $resultat;
    }

    public function updateMotif(Request $request){

    	$motif              = Motif::where('id','!=', $request->get('id'))
                                ->where('libelle','like', $request->get('nom'))
                                ->where('groupemotif_id', $request->get('idGrpMotif'))
                                ->where('statut_id', $request->get('statutMotif'))
                                ->first();
        $resultat           = "";

    	if($motif){

    		$resultat       = ["etatOperation" => 0, "etat" => "warning", "msg" => "Ce motif existe dèja !", "titre" => "Attention !"];
            
    	}else{

            $motif              = Motif::find($request->get('id'));
            $motif->libelle     = $request->get('nom');
            $motif->statut_id   = $request->get('statutMotif');
            //$groupeMotif->slug     = $request->get('slug');

            if($motif->save()){

                $resultat   = ["etatOperation" => 1, "etat" => "success", "msg" => "Modification efféctuée avec succèss", "titre" => "Opération efféctuée"];

            }else{

                $resultat   = ["etatOperation" => 0, "etat" => "error", "msg" => "Problème lors de la modification", "titre" => "Opération échouée"];   
                    
            }  
             
        }
        
        return $resultat;
    }


    public function activerMotif(Request $request){

    	$motif = Motif::find($request->get('idMotif'));

        if($motif->active){

            $motif->active = 0;
            $msg = "Motif désactivée.";

        }else{

            $motif->active = 1;
            $msg = "Motif activée.";
        } 

        if($motif->save()){

            return $resultat = ["etatOperation" => 1, "active" => $motif->active,"etat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];

        }else{

            return $resultat = ["etatOperation" => 0, "etat" => "error", "msg" => "", "titre" => "opération échouée !"];
        }
    }


     public function updateClassMotif(Request $request)
    {
        
    	$motifs    = $request->get('motifs');
    	$count     = 1;
        
    	foreach ($motifs as $motif){

    		$ligneMotif        = Motif::find($motif['id']);
    		$ligneMotif->ordre = $count;
    		$ligneMotif->save();
    		$count++;
    	}
    }



}
