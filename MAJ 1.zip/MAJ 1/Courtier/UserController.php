<?php


namespace App\Http\Controllers\Courtier;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Http\Requests\UserRequest;
use App\Http\Requests\AddIpRequest;

use App\Http\Requests\UpdateUserRequest;
use App\Events\EventInitialiserClassementSante; 
use App\Events\EventConfigTauxCommUserSante;

use App\User;
use App\Profile;
use App\Courtier;
use App\Agence;
use App\Site;
use App\Equipe;
use App\Equipeuser;
use App\Ip;

use Image;
use Carbon\Carbon;
use Auth;
use DB;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $profiles = Profile::whereNotIn('slug', ['superadmin', 'admin', 'courtier', 'systeme'])->whereActive(1)->get();

        // $users    = User::whereNotIn('profile_id', [1,2,3])->orderBy('updated_at', 'desc')->get();
        $users    = User::whereHas('profile', function($q){
                                $q->whereNotIn('slug', ['superadmin', 'admin', 'courtier', 'systeme']);
                            })
                            ->orderBy('updated_at', 'desc')
                            ->get();

        return view('courtiersfiles.users.index', ['users' => $users, 'profiles' => $profiles]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $profiles = Profile::whereNotIn('slug', ['superadmin', 'admin', 'courtier', 'systeme'])->whereActive(1)->get();

        return view('courtiersfiles.users.create', ['profiles' => $profiles]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserRequest $request)
    {
        
        $request->all();

        $profileId = $request->get('profile_id');

        $user = new User;
        $user->nom        = $request->get('nom');
        $user->prenom     = $request->get('prenom');
        $user->login      = $request->get('login');
        $user->profile_id = $profileId;
        $user->email      = $request->get('email');
        $user->password   = bcrypt($request->get('password'));
        $user->id_appel   = $request->get('idAppel');

        if($profileId==7)
            $user->objectif   = $request->get('objectif');
        
        //$user->save();

        $courtier = Courtier::whereActive(1)->first();

        if($request->has('profileSlug')){

            $profileSlug = $request->get('profileSlug');

            switch ($profileSlug) {

                case  'courtier':

                    $user->courtier_id     = $courtier->id;

                    break;

                case  'agence':

                    if($request->get('profileList') == "" or !$request->has('profileList')){

                        return redirect('courtier/users/create')->withInput()->withErrors(['profile_id' => 'Séléctionnez une agence']);

                    }else{

                        $agence = Agence::find($request->get('profileList'));

                        $user->courtier_id  = $agence->courtier->id;

                        $user->agence_id    = $agence->id;

                        $user->save();

                        break;
                    }

                case  'site':

                    if($request->get('profileList') == "" or !$request->has('profileList')){

                        return redirect('courtier/users/create')->withInput()->withErrors(['profile_id' => 'Séléctionnez un site']);

                    }else{

                        $site = Site::find($request->get('profileList'));

                        $agence = $site->agence;

                        $user->courtier_id  = $agence->courtier->id;

                        $user->agence_id    = $agence->id;

                        $user->site_id      = $site->id;

                        $user->save();

                        break;

                    }

                case  'equipe':

                    if($request->get('profileList') == "" or !$request->has('profileList')){

                        return redirect('courtier/users/create')->withInput()->withErrors(['profile_id' => 'Séléctionnez une equipe']);

                    }else{

                        $equipe = Equipe::find($request->get('profileList'));
                        
                        $site = $equipe->site;

                        $agence = $site->agence;

                        $user->courtier_id  = $agence->courtier->id;

                        $user->agence_id    = $agence->id;

                        $user->site_id      = $site->id;

                        $user->save();

                        $equipeuser = new Equipeuser;

                            $equipeuser->user_id    = $user->id;
                            $equipeuser->equipe_id  = $equipe->id;
                            $equipeuser->date_debut = Carbon::now()->format('Y-m-d');
                            $equipeuser->date_fin   = '0000-00-00';
                            $equipeuser->active     = 1;

                        $equipeuser->save();

                        break;

                    }

                case  'conseiller':

                    if($request->get('profileList') == "" or !$request->has('profileList')){

                        return redirect('courtier/users/create')->withInput()->withErrors(['profile_id' => 'Séléctionnez une equipe']);

                    }else{

                        $equipe = Equipe::find($request->get('profileList'));
                        
                        $site = $equipe->site;

                        $agence = $site->agence;

                        $user->courtier_id  = $agence->courtier->id;

                        $user->agence_id    = $agence->id;

                        $user->site_id      = $site->id;

                        $user->save();

                        $equipeuser = new Equipeuser;

                            $equipeuser->user_id    = $user->id;
                            $equipeuser->equipe_id  = $equipe->id;
                            $equipeuser->date_debut = Carbon::now()->format('Y-m-d');
                            $equipeuser->date_fin   = '0000-00-00';
                            $equipeuser->active     = 1;

                        $equipeuser->save();

                        //Initialser la ligne de classement du mois en cours santé

                        $tabInfosInitClassement = ['conseiller'        => $user];

                        event(new EventInitialiserClassementSante($tabInfosInitClassement));

                        //Initialser les lignes des taux commissions des gammes santé

                        $tabInfosConfigTauxComm = ['conseiller'        => $user];

                        event(new EventConfigTauxCommUserSante($tabInfosConfigTauxComm));

                        
                        break;

                    }

                case 'gestion':

                    if($request->get('profileList') == "" or !$request->has('profileList')){

                        return redirect('courtier/users/create')->withInput()->withErrors(['profile_id' => 'Séléctionnez une agence']);

                    }else{

                        $agence = Agence::find($request->get('profileList'));
                        
                        $user->courtier_id = $agence->courtier->id;
                        
                        $user->agence_id   = $agence->id;
                        
                        $user->site_id     = null;

                        $user->save(); 

                        break;

                    }

            }
        }

        $user->save();

        $ip = new Ip;
        $ip->ip_internet = $request->ip();

        $user->ips()->save($ip);

        return redirect('courtier/users');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $user = User::find($id);

        //$profiles = Profile::whereActive(1)->get();

        $profiles = Profile::whereNotIn('slug', ['superadmin', 'admin', 'courtier', 'systeme'])->whereActive(1)->get();

        $agences = Agence::where('active', 1)
                            ->with(['sites' => function ($site) {
                                $site->where('active', 1)
                                        ->with(['equipes' => function ($equipe) {
                                                $equipe->where('active', 1);
                                            }])
                                        ->get();
                            }])
                            ->get();

        $equipeIdsResp = null;

        if($user->profile->slug=="equipe"){
            $equipeIdsResp  = $user->userEquipe()->where('equipe_user.active', 1)->get()->lists('id');
        }
        
        return view('courtiersfiles.users.edit', ['user' => $user, 'profiles' => $profiles, 'agences' => $agences, 'equipeIdsResp' => $equipeIdsResp]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function update(UpdateUserRequest $request, $id)
    {

        $user             = User::find($id);

        $user->nom        = $request->get('nom');
        $user->prenom     = $request->get('prenom');
        $user->profile_id = $request->get('profile_id');
        $user->tel        = $request->get('tel');
        $user->fax        = $request->get('fax');
        $user->id_appel   = $request->get('idAppel');


        if($request->file('photo')){
            
            $img = $request->file('photo');
            $mime = Image::make($img)->mime();
            if( $mime == 'image/jpeg' or 'image/png' or $mime == 'image/gif'){
                $imgName     = $user->login.'.'.$img->getClientOriginalExtension();
                $user->photo = $imgName;
                $image       = Image::make($img)->fit(200, 200)->save('upload/avatars/'.$imgName);
            }else{
                return redirect('courtier/users/'.$id.'/edit')->withErrors(['photo' => 'Les Extentions autorisées: PNG, JPG ou GIF']);
            }

        }

        if($request->has('password')){

            if($request->get('password') == $request->get('password_confirmation')){
                $user->password = bcrypt($request->get('password'));
            }else{
                return redirect('courtier/users/'.$id.'/edit')->withErrors(['password' => 'Vérifier votre mot de passe']);
            }

        }

        if($request->has('email')){

            $email = $request->get('email');

            if($email != $user->email){
                $userEmail = User::where('email', $email)->count();
                if($userEmail>0){
                    return redirect('courtier/users/'.$id.'/edit')->withErrors(['email' => 'Email Déjà Existe']);
                }else{
                    $user->email = $email;
                }
            }

        }

        // return  $request->all();

        if($request->has('profileSlug')){

            $profileSlug = $request->get('profileSlug');

            $courtier = Courtier::whereActive(1)->first();

            switch ($profileSlug) {

                case  'courtier':

                    $user->courtier_id = $courtier->id;
                    
                    $user->agence_id   = null;
                    
                    $user->site_id     = null;

                    $user->save(); 

                    break;

                case  'agence':

                    if($request->get('profileList') == "" or !$request->has('profileList')){

                        return redirect('courtier/users/'.$id.'/edit')->withInput()->withErrors(['profile_id' => 'Séléctionnez une agence']);

                    }else{

                        $agence = Agence::find($request->get('profileList'));
                        
                        $user->courtier_id = $agence->courtier->id;
                        
                        $user->agence_id   = $agence->id;
                        
                        $user->site_id     = null;

                        $user->save(); 

                        break;

                    }

                case  'site':

                    if($request->get('profileList') == "" or !$request->has('profileList')){

                        return redirect('courtier/users/'.$id.'/edit')->withInput()->withErrors(['profile_id' => 'Séléctionnez un site']);

                    }else{

                        $site = Site::find($request->get('profileList'));

                        $agence = $site->agence;

                        $user->courtier_id  = $agence->courtier->id;

                        $user->agence_id    = $agence->id;

                        $user->site_id      = $site->id;

                        $user->save(); 

                        break;

                    }

                case  'equipe':

                    if($request->get('equipeCheck') == "" or !$request->has('equipeCheck')){

                        return redirect('courtier/users/'.$id.'/edit')->withInput()->withErrors(['profile_id' => 'Séléctionnez une equipe']);

                    }else{

                        $equipe = Equipe::find($request->get('equipeCheck')[0]);
                    
                        $site = $equipe->site;

                        $agence = $site->agence;

                        $user->courtier_id  = $agence->courtier->id;

                        $user->agence_id    = $agence->id;

                        $user->site_id      = $site->id;
                        
                        $user->save(); 

                        

                        if($request->has('equipeCheck')){

                            $equipesId = $request->get('equipeCheck');

                            $equipeIdsResp  = $user->userEquipe()->where('equipe_user.active', 1)->get()->lists('id')->toArray();

                            foreach($equipesId as $equipe_id) {

                                if(!in_array($equipe_id, $equipeIdsResp)){

                                    $equipeUser = new Equipeuser;
                                        $equipeUser->user_id    = $user->id;
                                        $equipeUser->equipe_id  = $equipe_id;
                                        $equipeUser->date_debut = date('Y-m-d');
                                        $equipeUser->date_fin   = '0000-00-00';
                                        $equipeUser->active     = 1;
                                    $equipeUser->save();

                                }

                            }

                            DB::table('equipe_user')
                                ->where('user_id', $user->id)
                                ->whereNotIn('equipe_id', $equipesId)
                                ->whereActive(1)
                                ->update([ 'date_fin' => date('Y-m-d'), 'active' => 0 ]);


                        }else{

                            DB::table('equipe_user')
                                ->where('user_id', $user->id)
                                ->whereActive(1)
                                ->update([ 'date_fin' => date('Y-m-d'), 'active' => 0 ]);

                        }

                        break;

                    }

                case  'conseiller':

                    if($request->get('profileList') == "" or !$request->has('profileList')){

                        return redirect('courtier/users/'.$id.'/edit')->withInput()->withErrors(['profile_id' => 'Séléctionnez une equipe']);

                    }else{
                        
                        $equipe = Equipe::find($request->get('profileList'));
                        
                        $site = $equipe->site;

                        $agence = $site->agence;

                        $user->courtier_id  = $agence->courtier->id;

                        $user->agence_id    = $agence->id;

                        $user->site_id      = $site->id;

                        $user->save(); 

                        
                        $equipeuser = Equipeuser::where('user_id', $user->id)->whereActive(1)->first();

                        if(!$equipeuser){
                            $equipeuser = new Equipeuser;
                                $equipeuser->user_id    = $user->id;
                                $equipeuser->equipe_id  = $equipe->id;
                                $equipeuser->date_debut = Carbon::now()->format('Y-m-d');
                                $equipeuser->date_fin   = '0000-00-00';
                                $equipeuser->active     = 1;
                            $equipeuser->save();
                        }else if($equipeuser->equipe_id != $equipe->id){

                            $equipeuser->active = 0;
                            $equipeuser->date_fin = Carbon::now()->format('Y-m-d');
                            $equipeuser->save();

                            $equipeuser = new Equipeuser;
                                $equipeuser->user_id    = $user->id;
                                $equipeuser->equipe_id  = $equipe->id;
                                $equipeuser->date_debut = Carbon::now()->format('Y-m-d');
                                $equipeuser->date_fin   = '0000-00-00';
                                $equipeuser->active     = 1;
                            $equipeuser->save();

                        }

                        
                        break;

                    }

                case 'gestion':

                    if($request->get('profileList') == "" or !$request->has('profileList')){

                        return redirect('courtier/users/'.$id.'/edit')->withInput()->withErrors(['profile_id' => 'Séléctionnez une agence']);

                    }else{

                        $agence = Agence::find($request->get('profileList'));
                        
                        $user->courtier_id = $agence->courtier->id;
                        
                        $user->agence_id   = $agence->id;
                        
                        $user->site_id     = null;

                        $user->save(); 

                        break;

                    }

            }

        }else{
            return redirect('courtier/users/'.$id.'/edit')->withInput();
        }

        

        return redirect('courtier/users');


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function changeStatus(Request $request) {

        $id     = $request->get('user_id');
        $status = $request->get('status');

        $user = User::find($id);
            $user->active = $status;
        $user->save();

        $active = ($status) ? 'activé' : 'desactivé';

        return ['success' => true, 'message' => "l'utilisateur a été ".$active];

    }

    
    public function getList(Request $request) {

        $profile_id = $request->get('profileId');

        $slug = Profile::find($profile_id)->slug;
        
        $list    = [];
        
        $profile = 0;

        $label   = "";

        $equipeIdsResp = null;

        switch ($slug) {

            case  'courtier':

                $profile = 1;

                break;

            case  'agence':

                // La liste des agences 

                //$list = Courtier::whereActive(1)->with('agences')->get();
                //$list = Agence::whereActive(1)->get();

                $list = Agence::whereActive(1)->get();

                $profile = 2;

                $label   = "La liste des agences";

                break;

            case  'site':

                // La liste des sites 

                $list = Agence::where('active', 1)
                              ->with(['sites' => function ($site) {
                                    $site->where('active', 1);
                                }])
                              ->get();

                $profile = 3;

                $label   = "La liste des sites";

                break;

            case  'equipe':

                // La liste des equipes 

                $list = Agence::where('active', 1)
                              ->with(['sites' => function ($site) {
                                    $site->where('active', 1)
                                    ->with(['equipes' => function ($equipe) {
                                            $equipe->where('active', 1);
                                    }])
                                    ->get();
                                }])
                              ->get();

                $user_id = $request->get('userId');
                $user    = User::find($user_id);
                $isRespEquipe = 0;

                $profile = 4;

                $label   = "La liste des equipes";

                $site    = $user->site()->first();
                $equipes = collect([]);

                foreach ($site->equipes as $value) {

                    $equipe   = collect($value);
                    
                    $equipe   = $equipe->merge(['responsable' => $value->equipeAnimateur->first()]);
                    
                    $equipes = $equipes->push($equipe);

                }

                $isRespEquipe = 1;

                if($user->profile->slug=='equipe'){
                    $equipeIdsResp = $user->userEquipe()->where('equipe_user.active', 1)->get()->lists('id');
                }else{
                    $equipeIdsResp = [];
                }

                return [ 
                    'success' => true,
                    'list'    => $list,
                    'profile' => $profile,
                    'label'   => $label,
                    'equipes' => $equipes,
                    'isRespEquipe' => $isRespEquipe,
                    'equipeIdsResp' => $equipeIdsResp,
                ];

                // if($user->profile->slug=='equipe'){

                //     $site    = $user->site;
                //     $equipes = collect([]);

                //     foreach ($site->equipes as $value) {

                //         $equipe   = collect($value);
                        
                //         $equipe   = $equipe->merge(['responsable' => $value->equipeAnimateur->first()]);
                        
                //         $equipes = $equipes->push($equipe);

                //     }

                //     $isRespEquipe = 1;
                //     $equipeIdsResp = $user->userEquipe()->where('equipe_user.active', 1)->get()->lists('id');

                //     return [ 
                //         'success' => true,
                //         'list'    => $list,
                //         'profile' => $profile,
                //         'label'   => $label,
                //         'equipes' => $equipes,
                //         'isRespEquipe' => $isRespEquipe,
                //         'equipeIdsResp' => $equipeIdsResp,
                //     ];

                // }else{

                //     $list = Agence::where('active', 1)
                //           ->with(['sites' => function ($site) {
                //                 $site->where('active', 1)
                //                 ->with(['equipes' => function ($equipe) {
                //                         $equipe->where('active', 1)
                //                         ->where();
                //                 }])
                //                 ->get();
                //             }])
                //           ->get();

                // }

                break;

            case  'conseiller':

                // La liste des equipes 

                $list = Agence::where('active', 1)
                              ->with(['sites' => function ($site) {
                                    $site->where('active', 1)
                                    ->with(['equipes' => function ($equipe) {
                                            $equipe->where('active', 1);
                                        }])
                                    ->get();
                                }])
                              ->get();

                $profile = 5;

                $label   = "La liste des equipes";

                break;

            case  'gestion':

                // La liste des agences 

                //$list = Courtier::whereActive(1)->with('agences')->get();
                //$list = Agence::whereActive(1)->get();

                $list = Agence::whereActive(1)->get();

                $profile = 2;

                $label   = "La liste des agences";

                break;


        }

        return [ 
                    'success' => true,
                    'list'    => $list,
                    'profile' => $profile,
                    'label'   => $label
                ];

    }

    public function verifyIp(Request $request){

        $message = "";
        $userId  = $request->get('user_id');
        $status  = $request->get('status');

        $user = User::find($userId);

        if($user){

            $user->verify_ip = $status;

            if($user->save()){

                $message = $status ? "Vous avez activé la vérification des IPs." : "Vous avez désactivé la vérification des IPs." ;

                return [ 
                    "success" => true,
                    "message" => $message
                ];

            }else{

                return [ 
                    "success" => false,
                    "message" => "Erreur en activation la vérification des IPs !!"
                ];

            }

        }else{

            return [ 
                "success" => false,
                "message" => "Erreur en activation la vérification des IPs !!"
            ];

        }


    }

    public function manageIp(Request $request){
        
        $message = "";
        $ipId    = $request->get('ip_id');
        $status  = $request->get('status');

        $ip = Ip::find($ipId);

        if($ip){

            $ip->active = $status;

            if($ip->save()){

                $message = ($status ? "Vous avez activé d'IP: " : "Vous avez désactivé d'IP: ") .$ip->ip_internet;

                return [ 
                    "success" => true,
                    "message" => $message
                ];

            }else{

                return [ 
                    "success" => false,
                    "message" => "Erreur en activation d'IP !!"
                ];

            }

        }else{

            return [ 
                "success" => false,
                "message" => "Erreur en activation d'IP !!"
            ];

        }

    }

    public function addIp(AddIpRequest $request){
        
        $userId  = $request->get('user_id');

        $user = User::find($userId);

        if($user){

            if($user->save()){

                $adressIp = $request->get('ip');

                $count = Ip::where('user_id', $userId)->where('ip_internet', $adressIp)->count();

                if(!$count){

                    $ip = new IP;

                    $ip->ip_internet = $adressIp;
                    $ip->user_id     = $userId;

                    if($ip->save()){

                        return [ 
                            "success" => true,
                            "ip"      => $ip,
                            "message" => "Adresse IP Ajoutée."
                        ];

                    }

                }else{

                    return [ 
                        "success" => false,
                        "message" => "Adresse IP Déjà Affectée À L'Utilisateur !!"
                    ];

                }

            }else{

                return [ 
                    "success" => false,
                    "message" => "Erreur En Ajout d'IP !!"
                ];

            }

        }else{

            return [ 
                "success" => false,
                "message" => "Erreur en ajout d'IP !!"
            ];

        }

    }




}
