<?php

namespace App\Http\Controllers\Courtier;

use Illuminate\Http\Request;
use App\Http\Requests\StoreImportRequest;
use App\Http\Requests;
use Validator;
use App\Http\Controllers\Controller;
use Excel;
use Illuminate\Support\Facades\Input;
use App\Client;
use App\Fichesante;
use App\Ficheobseque;
use App\Ficheauto;
use App\Produit;
use App\Prestataire;
use App\Provenance;
use App\Groupepub;
use App\Importfile;
use App\Conjoint;
use App\Enfant;
use File;
use Carbon\Carbon;
use App\Groupemotif;
use App\Groupestatut;
use App\Saregime;
use DB;
use App\Leadsante;
use App\Leadobseque;
use App\Leadauto;
use App\ClientProduit;
use App\Agence;
use App\Site;
use App\Equipe;
use App\Equipeuser;
use App\Statut;
use App\Societe;
use App\Vehicule;
use App\Sinistre;
use Auth;
use App\User;
use App\Action;
use App\Events\EventTracesSante;
use App\Events\EventTracesObseque;
use App\Events\EventTracesAuto;
use App\Events\EventNotifications;
use App\Http\Controllers\Publique\FicheController;
use App\Notification;


class UploadLeadsController extends Controller
{


	// public $nbreValide = 0;
	// public $nbreErrone = 0;
 //    public $validRowTab = [];
 //    public $errorRowTab = [];

	//public $fichesErronees = [];

    public function uploadLeads()
    {
    	
    	$produits   		= Produit::where('active',1)->select('id','libelle')->get();
    	$prestataires		= Prestataire::where('active',1)->select('id','nom')->get();
        //$groupePubs         = Groupepub::where('active',1)->select('id','nom','prestataire_id')->get();
        $provenances        = Provenance::where('active',1)->select('id','nom','prestataire_id')->get();
        //$societes           = Societe::where('active',1)->select('id','nom')

    	// $agences 			= Agence::where('active',1)->select('id','nom')->get();
     //    $sites              = Site::where('active',1)->select('id','nom','agence_id')->get();
     //    $equipes            = Equipe::where('active',1)->select('id','nom','site_id')->get();
     //   //return $conseillers        = $equipes->equipeConseillers;
     //    $conseillers        = collect(DB::table('equipe_user')
     //                            ->leftjoin('users','equipe_user.user_id','=','users.id')
     //                            ->where('users.active',1)
     //                            ->where('users.profile_id',7)
     //                            ->select('users.id','users.nom','equipe_user.equipe_id')
     //                            ->get());

        $user        = Auth::user();
        $courtier    = $user->courtier;
        $courtier_id = $courtier->id;
        
        $agences     = $courtier->agences()->get();

        $agencesIds  = $agences->lists('id');
        
        $sites       = $courtier->sites()->get();

        $sitesIds    = $sites->lists('id');
        
        $equipes     = collect([]);
        
        foreach ($sites as $site) {
            
            $equipes = $equipes->push(
                                    $site->equipes()->get()
                                );
            
        }

        $equipes     = $equipes->flatten(1);
        $equipeIds   = $equipes->lists('id');

        $conseillers = collect([]);

        foreach($equipes as $equipe){

            $conseillers    = $conseillers->push(
                                    $equipe->getUserEquipe()
                                            ->where('users.active',1)
                                            ->where('users.connected', 1)
                                            ->where('users.courtier_id', $courtier->id)
                                            ->select('users.id','users.login','equipe_user.equipe_id', 'equipe_user.id as equipeUserId')
                                            ->get()
                                    );

        }

        $conseillers = $conseillers->flatten(1);

        

    	


    	return view("courtiersfiles.leads.uploadleads",['produits' => $produits, 'prestataires' => $prestataires, 'provenances' => $provenances, 'agences' => $agences ,'sites' => $sites , 'equipes' => $equipes , 'conseillers' => $conseillers]);

    }

    //Return groupe pub from prestataire

    public function selectPrestataire(Request $request){

        $idPrestataire          = $request->get('idPrestataire');
        $idProduit              = $request->get('idProduit');
        return $groupePubs      = Prestataire::find($idPrestataire)->groupepubs()->where('produit_id',$idProduit)->lists('id', 'nom');
    }

    public function selectGroupePub(Request $request){

        $idGrpPub        = $request->get('idGrpPub');

        $provenances      = Groupepub::find($idGrpPub)->provenances()->lists('provenances.id', 'provenances.nom');
        $societes         = Groupepub::find($idGrpPub)->societes()->lists('societes.id', 'societes.nom');


       return ['provenances' => $provenances, 'societes' => $societes];
    }

    //Insertion du fichier d'import

    public function postImport(StoreImportRequest $request)
    {
        //return $request->all();
        //return $leads->getClientOriginalExtension();
        $produit            = $request->get('produits');
        $prestataire        = $request->get('prestataires');
        $groupepubId        = $request->get('groupePubs');
        $provenance         = $request->get('provenances');
        $societe            = $request->get('societes');
        $leads              = $request->file('leads');
        $dispatchingAutoChar  = $request->get('dispatchingAuto');

        $dispatchingAuto    = ($dispatchingAutoChar == 'true');
        //dd($dispatchingAuto);
        
        //$groupepub          = Groupepub::where('prestataire_id',$prestataire)
                                       //->where('produit_id',$produit)
                                       //->first();
        $groupepub          = Groupepub::find($groupepubId);
        //Id de la table intermédiaire groupe pub provenance
        $idGrpPubProv       = $groupepub->provenances()->where('provenance_id',$provenance)->first()->pivot->id;
        //Id de la table intermédiaire groupe pub société
        $idGrpPubSte        = $groupepub->societes()->where('societe_id',$societe)->first()->pivot->id;

        $produitModel       = Produit::find($produit);
        $produitSlug        = $produitModel->slug;


        switch ($produitSlug) {
            case 'sante':
                $this->traiteImportedFileSante($produit,$leads,$prestataire,$idGrpPubProv,$idGrpPubSte,$groupepubId,$dispatchingAuto);
                break;
            case 'obseque':
                $this->traiteImportedFileObseques($produit,$leads,$prestataire,$idGrpPubProv,$idGrpPubSte,$groupepubId,$dispatchingAuto);
                break;
            case 'auto':
                $this->traiteImportedFileAuto($produit,$leads,$prestataire,$idGrpPubProv,$idGrpPubSte,$groupepubId,$dispatchingAuto);
                break;
            
        }

        return redirect("courtier/uploadLeads/upload");

    }

    //Recherche des imports des leads

    public function searchUploadedFiles(Request $request)
    {
        //return $request->all();
    	//$ImportedFiles 		= Importfile::orderBy('created_at', 'desc')
    									//->paginate(3);

    	$ImportedFiles      = DB::table('importfiles')
		
		  ->where(function($queryleads) use ($request){

		  	if($request->has('prestataire') and $request->get('prestataire') != 0)
    		 {
    			$queryleads->where('prestataires.id', $request->get('prestataire'));
    		 }

    		 if($request->has('provenance') and $request->get('provenance') != 0)
    		 {
    			$queryleads->where('provenances.id', $request->get('provenance'));
    		 }

    		 if($request->has('produit') and $request->get('produit') != 0)
    		 {
    			$queryleads->where('produits.id', $request->get('produit'));
    		 }

             if($request->has('groupePub') and $request->get('groupePub') != 0)
             {
                $queryleads->where('groupepubs.id', $request->get('groupePub'));
             }

             if($request->has('societe') and $request->get('societe') != 0)
             {
                $queryleads->where('societes.id', $request->get('societe'));
             }

			if($request->get('dateDebut') and $request->get('dateFin')){

				$queryleads->whereBetween('importfiles.created_at', [$request->get('dateDebut')." 00:00:00", $request->get('dateFin')." 23:59:59"]);

			}else if($request->get('dateDebut')){

				$queryleads->where('importfiles.created_at', '>=', $request->get('dateDebut')." 00:00:00");

			}else if($request->get('dateFin')){

				$queryleads->where('importfiles.created_at', '<=', $request->get('dateFin')." 23:59:59");
			}  


		  })
		  ->where('importfiles.dispatch',0)
		  ->join('groupepub_provenance','importfiles.groupepub_provenance_id','=','groupepub_provenance.id')
		  ->join('provenances','groupepub_provenance.provenance_id','=','provenances.id')
		  ->join('groupepubs','groupepub_provenance.groupepub_id','=','groupepubs.id')
		  ->join('prestataires','provenances.prestataire_id','=','prestataires.id')
		  ->join('produits','groupepubs.produit_id','=','produits.id')
          ->join('groupepub_societe','importfiles.groupepub_societe_id','=','groupepub_societe.id')
          ->join('societes','groupepub_societe.societe_id','=','societes.id')
		  ->select('importfiles.nom_fichier_original',
		  	'importfiles.chemin_fichier_original',
		  	'importfiles.nom_fichier_valide',
		  	'importfiles.nom_fichier_errone',
		  	'importfiles.nbre_fiche_valide',
		  	'importfiles.nbre_fiche_errone',
		  	'prestataires.nom as nomPrestataire',
		  	'provenances.nom as nomProvenance',
		  	'produits.libelle as libelleProduit',
            'groupepubs.nom as nomGroupePub',
            'societes.nom as nomSociete',
		  	'importfiles.id',
		  	'importfiles.created_at')
		  ->orderBy('importfiles.created_at','desc')
		  ->paginate(6);
          //return $ImportedFiles;
          //dd($ImportedFiles);


          //Envoyer les infos de dispatching par produit choisi
            $idPdt       = $request->get('produit');
            $produit     = Produit::find($idPdt);

            $slugPrd     = $produit->slug;
        
            $produitId   = $produit->id;

            $user        = Auth::user();
            $courtier    = $user->courtier;
            $courtier_id = $courtier->id;
            
            $agences     = $courtier->agences()->get();

            $agencesIds  = $agences->lists('id');
            
            $sites       = $courtier->sites()->get();

            $sitesIds    = $sites->lists('id');
            
            $equipes     = collect([]);
            
            foreach ($sites as $site) {
                
                $equipes = $equipes->push(
                                        $site->equipes()->get()
                                    );
                
            }

            $equipes     = $equipes->flatten(1);
            $equipeIds   = $equipes->lists('id');

            $conseillers = collect([]);

            foreach($equipes as $equipe){

                $conseillers    = $conseillers->push(
                                        $equipe->getUserEquipe()
                                                ->where('users.active',1)
                                                ->where('users.connected', 1)
                                                ->where('users.courtier_id', $courtier->id)
                                                ->whereHas('produits', function ($query) use ($produitId) {
                                                    $query->where('produit_id', $produitId);
                                                })
                                                ->select('users.id','users.login','equipe_user.equipe_id', 'equipe_user.id as equipeUserId')
                                                ->get()
                                        );

            }

            $conseillers = $conseillers->flatten(1);

    	return json_encode(['ImportedFiles' => $ImportedFiles ,'agences' => $agences ,'sites' => $sites , 'equipes' => $equipes , 'conseillers' => $conseillers]);

    }


    public function getImportedLeads(Request $request)
    {
    	$importId      = $request->get('importId');

    	$produitId       = Importfile::find($importId)->grouppubprov->getGroupePub->produit_id;
        $produit         = Produit::find($produitId);
        $produitSlug     = $produit->slug;

    	

    	switch ($produitSlug) {
    		case 'sante':
    			$tablefiche = 'fichesantes';
    			break;
    		
    		case 'obseque':
    			$tablefiche = 'ficheobseques';
    			break;

            case 'auto':
                $tablefiche = 'ficheautos';
                break;
    	}

    	$ImportedLeads  = DB::table($tablefiche)
    					  ->join('clients',$tablefiche.'.client_id', '=','clients.id')
    					  ->where($tablefiche.'.importfile_id',$importId)
    					  ->where($tablefiche.'.dispatchable_type','courtier')
    					  ->select('clients.nom', 
                        'clients.prenom', 
                        'clients.civilite', 
                        'clients.code_postal',
                        'clients.tel_mobile',
                        'clients.email',
                        'clients.date_naissance',
                        $tablefiche.'.id as idFiche',
                        $tablefiche.'.active',
                        $tablefiche.'.num_fiche',
                        $tablefiche.'.doublon',
                        $tablefiche.'.cout',
						$tablefiche.'.slug',
                        DB::raw("DATE_FORMAT(".$tablefiche.".date_insertion,'%Y-%m-%d') as date_insertion"))
    					  ->orderBy($tablefiche.'.num_fiche')
    					  ->get();
        //dd($ImportedLeads);


    	return json_encode(['ImportedLeads' => $ImportedLeads, 'produitSlug' => $produitSlug]);

    }

    public function dispatchLeads(Request $request)
    {
    	$agenceId      = $request->get('agence');
        $siteId        = $request->get('site');
        $equipeId      = $request->get('equipe');
        $conseillerId  = $request->get('conseiller');
        //dd($agenceId);
        //dd($siteId);
        //dd($equipeId);
        //dd($conseillerId);
    	$produitId     = $request->get('produit');
    	$arrayIdFiches = $request->get('arrayIdLeads');

    	$produit       = Produit::find($produitId);
    	$produitSlug   = $produit->slug;

        //Vérifier la destination des fiches

        $infosDestination           = array();
        $infosDestination['id']     = 0;
        $infosDestination['table']  = "";
    	$infosDestination['idUserEquipe'] = null;

    	foreach ($arrayIdFiches as $Idfiche) {



    		switch ($produitSlug) {

    		case 'sante':
    			$fiche  = Fichesante::find($Idfiche);
    			break;
    		
    		case 'obseque':
    			$fiche  = Ficheobseque::find($Idfiche);
    			break;

            case 'auto':
                $fiche  = Ficheauto::find($Idfiche);
                break;
    		}

        	if($conseillerId)
            {
                $equipeUser   = Equipeuser::where('user_id',$conseillerId)
                                        ->where('equipe_id',$equipeId)
                                        ->first();

                $fiche->equipe_user_id    = $equipeUser->id;
                $fiche->dispatchable_id   = $equipeUser->equipe_id;
                $fiche->dispatchable_type = 'equipe';

                $infosDestination['id']             = $equipeId;
                $infosDestination['table']          = "equipe";  
                $infosDestination['idUserEquipe']   = $equipeUser->id;
                $slugAction                         = 'DMCI';
            }
            else if($equipeId)
            {
                $fiche->dispatchable_id    = $equipeId;
                $fiche->dispatchable_type  = 'equipe';

                $infosDestination['id']    = $equipeId;
                $infosDestination['table'] = "equipe";
                $slugAction                = 'DMEI';  
            }
            else if($siteId)
            {
                $fiche->dispatchable_id    = $siteId;
                $fiche->dispatchable_type  = 'site'; 

                $infosDestination['id']    = $siteId;
                $infosDestination['table'] = "site";
                $slugAction                = 'DMSI';  
            }
            else
            {
                $fiche->dispatchable_id    = $agenceId;
                $fiche->dispatchable_type  = 'agence';

                $infosDestination['id']    = $agenceId;
                $infosDestination['table'] = "agence";
                $slugAction                = 'DMAI';
            }

              
            //enregistrer les traces de dispatching
            $idUserDisp                   = User::where('login', 'Dispatch')->value('id');
            $idAction                     = Action::where('slug',$slugAction)->value('id');
            $groupePubProv                = $fiche->groupePub;
            //dd($groupePubProv);

            $tabInfoTrace                 = ['idAction' => $idAction, 'idFiche' => $Idfiche, 'observation' => null, 'motif' => null, 'idStatut' => $fiche->statut_id,'user_id' => $idUserDisp, 'equipe_user_id' => $infosDestination['idUserEquipe'], 'tracable_id' => $infosDestination['id'], 'tracable_type' => $infosDestination['table'], 'idGrouprPub' => $groupePubProv->groupepub_id];
            $event = 'App\Events\EventTraces'.ucfirst($produitSlug);
            event(new $event($tabInfoTrace));


            $fiche->is_dispatched         = 1;

    		
    		$fiche->save();

    		//Mettre le champ dispatch d'un import à 1 si tout ses fiches sont dispatchés

    		//$this->setDispatchImportFile($fiche->importfile_id);

            //Envoyer notification au conseiller ou responsable en question

                $notif              = Notification::whereSlug('LEADDISPATCH')->first();

                if(isset($infosDestination['idUserEquipe'])){

                    $userNotif      = Equipeuser::find($infosDestination['idUserEquipe'])->user()->first(); 

                }else{

                    $className      = "App\\".ucfirst($infosDestination['table']);                    
                    $userNotif      = $className::find($infosDestination['id'])->responsable();
                }

                if($userNotif){

                    $idUserNotif    = $userNotif->id;
                    $linkNotif      = url($userNotif->profile->slug.'/leads/'.$fiche->statut_id);

                }else{

                    $idUserNotif    = "";
                    $linkNotif      = "";                    
                }

                $description        = "Vous avez reçu une fiche ".$produit->libelle." numéro : ".$fiche->num_fiche.".";
                
                $notification       = [
                    'user_id'         => $idUserNotif,
                    'notification_id' => $notif->id,
                    'notifiable_id'   => $fiche->id,
                    'notifiable_type' => $produit->table_produit,
                    'rappel_time'     => null,
                    'link'            => null,
                    'type'            => 'dispatch',
                    'description'     => $description,
                    'link'            => $linkNotif
                ];

                event(new EventNotifications($notification));
    	}

    }

    //Mettre le champ dispatch d'un import à 1 si tout ses fiches sont dispatchés

    public function setDispatchImportFile($idImport)
    {
    	$ImportFile      = Importfile::find($idImport);
    	$produitId       = Importfile::find($idImport)->grouppubprov->getGroupePub->produit_id;
    	$produit         = Produit::find($produitId);
    	$produitSlug     = $produit->slug;

    	switch ($produitSlug) {

    		case 'sante':
    			$nbrLeadsNonDispatche  = $ImportFile->fichesantesnondispatche()->count();
    			break;
    		
    		case 'obseque':
    			$nbrLeadsNonDispatche  = $ImportFile->ficheobsequesnondispatche()->count();
    			break;

            case 'auto':
                $nbrLeadsNonDispatche  = $ImportFile->ficheautosnondispatche()->count();
                break;
    	}

    	if($nbrLeadsNonDispatche == 0)
    	{
    		$ImportFile->dispatch = 1;
    		$ImportFile->save();
    	}
    }


    //traitement d'import d'un fichier Santé

    public function traiteImportedFileSante($produit,$leads,$prestataire,$idGrpPubProv,$idGrpPubSte,$groupepubId,$dispatchingAuto)
    {
        ini_set('memory_limit', '2048M');
        //ini_set('MAX_EXECUTION_TIME', 3600);
        //set_time_limit(3600);
    	//Stocker  le fichier uploadé
    	$importedFile     = $this->stockOriginalLeadsFile($leads,$prestataire,$idGrpPubProv,$idGrpPubSte,$produit);
    	//echo $idOriginalFile;

    	//$importedFile  		 					= Importfile::find($idOriginalFile);
    	$OriginalFilePath                       = $importedFile->chemin_fichier_original;
    	$OriginalFileName                       = $importedFile->nom_fichier_original;

    	

        //dd($leads);
        
		//Parser le fichier uploadé
        $validRowTab = [];
        $errorRowTab = [];
        $nbreValide = 0;
        $nbreErrone = 0;

        array_push($validRowTab,array(
                     'nom', 'prenom', 'civilite', 'sexe', 'sit_familiale', 'date_naissance', 'adresse', 'code_postal', 'ville', 'tel_bureau', 'tel_domicile', 'tel_mobile', 'fax', 'email', 'profession', 'regime', 'date_effet', 'regime_c', 'sexe_c', 'date_naissance_c', 'date_naissance_enf'
                ));
        array_push($errorRowTab,array(
             'nom', 'prenom', 'civilite', 'sexe', 'sit_familiale', 'date_naissance', 'adresse', 'code_postal', 'ville', 'tel_bureau', 'tel_domicile', 'tel_mobile', 'fax', 'email', 'profession', 'regime', 'date_effet', 'regime_c', 'sexe_c', 'date_naissance_c', 'date_naissance_enf'
        ));
        Excel::filter('chunk')->load($OriginalFilePath."/".$OriginalFileName)->chunk(50, function($reader) use ($produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto,&$validRowTab,&$errorRowTab,&$nbreValide,&$nbreErrone)
        {

            //$reader->each(function($sheet) use ($produit,$idGrpPubProv,$prestataire,$importedFile) {
            //dd($reader);
                // Loop through all rows
                
                $reader->each(function($row) use ($produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto,&$validRowTab,&$errorRowTab,&$nbreValide,&$nbreErrone) {
                    //dd($row);
                    
                        $fixedRow = [];
                        $fixedRow = $this->fixRowSante($row);
                        // echo '<pre>';
                        // print_r($validRow);
                        // echo '</pre>';
                        //dd($validRow->toArray());

                   $returnTab = $this->InsertLeadsSante($fixedRow->toArray(),$produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto);
                   //dd($returnTab);
                   if($returnTab['valid'])
                   {
                        array_push($validRowTab,$returnTab['row']);
                        $nbreValide++;
                        //   echo '<pre>';
                        // print_r($this->validRowTab);
                        // echo '</pre>===============================\n';
                   }
                   else
                   {
                        array_push($errorRowTab,$returnTab['row']);
                        $nbreErrone++;
                   }

                });

                

            //});

        },false);
                //dd($validRowTab);
                // echo '<pre>';
                // print_r($this->validRowTab);
                // echo '</pre>';
                // echo '<pre>';
                // print_r($this->errorRowTab);
                // echo '</pre>';

                $importedFile->nbre_fiche_valide = $nbreValide;
                $importedFile->nbre_fiche_errone = $nbreErrone;
                $importedFile->save();
                //Creer le fichier des leads valides
                $this->createImportedLeadsFileSante($importedFile,$validRowTab);

            //Creer le fichier des leads non valides
                $this->createImportedErrorLeadsFileSante($importedFile,$errorRowTab);
            

            

		// Excel::load($OriginalFilePath."/".$OriginalFileName,function($reader) use ($produit,$idGrpPubProv,$prestataire,$importedFile){
		// 	//echo "tiiiiiit";
  //           //$reader->ignoreEmpty();

  //   		$reader->each(function($sheet) use ($produit,$idGrpPubProv,$prestataire,$importedFile) {

		// 	    // Loop through all rows
		// 	    $sheet->each(function($row) use ($produit,$idGrpPubProv,$prestataire,$importedFile) {

		// 	    	//echo "<pre>".print_r($row->toArray()).exit("</pre>");
  //                   dd($row);

  //   				$this->InsertLeadsSante($row->toArray(),$produit,$idGrpPubProv,$prestataire,$importedFile);

		// 	    });

		// 	});
  //   		$importedFile->nbre_fiche_valide = $this->nbreValide;
  //   		$importedFile->nbre_fiche_errone = $this->nbreErrone;
  //   		$importedFile->save();

    		//$Clients   = Client::all();
    		//return redirect("admin/leads/upload",['Clients'=> $Clients]);

    	//});


    }


    //traitement d'import d'un fichier Obseques

    public function traiteImportedFileObseques($produit,$leads,$prestataire,$idGrpPubProv,$idGrpPubSte,$groupepubId,$dispatchingAuto)
    {

    	//echo "produit :".$produit;

    	//Stocker  le fichier uploadé
    	$importedFile     = $this->stockOriginalLeadsFile($leads,$prestataire,$idGrpPubProv,$idGrpPubSte,$produit);
    	//echo $idOriginalFile;

    	//$importedFile  		 					= Importfile::find($idOriginalFile);
    	$OriginalFilePath                       = $importedFile->chemin_fichier_original;
    	$OriginalFileName                       = $importedFile->nom_fichier_original;

    	//Creer le fichier des leads valides
		//$this->createImportedLeadsFileObseques($importedFile);

		//Creer le fichier des leads non valides
		//$this->createImportedErrorLeadsFileObseques($importedFile);


		//Parser le fichier uploadé
        $validRowTab = [];
        $errorRowTab = [];
        $nbreValide = 0;
        $nbreErrone = 0;

        array_push($validRowTab,array(
                     'nom', 'prenom', 'civilite', 'sexe', 'sit_familiale', 'date_naissance', 'adresse', 'code_postal', 'ville', 'tel_bureau', 'tel_domicile', 'tel_mobile', 'fax', 'email', 'profession', 'regime', 'date_effet', 'capital'
                ));
        array_push($errorRowTab,array(
                     'nom', 'prenom', 'civilite', 'sexe', 'sit_familiale', 'date_naissance', 'adresse', 'code_postal', 'ville', 'tel_bureau', 'tel_domicile', 'tel_mobile', 'fax', 'email', 'profession', 'regime', 'date_effet', 'capital'
                ));

        Excel::filter('chunk')->load($OriginalFilePath."/".$OriginalFileName)->chunk(50, function($reader) use ($produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto,&$validRowTab,&$errorRowTab,&$nbreValide,&$nbreErrone)
        {

            //$reader->each(function($sheet) use ($produit,$idGrpPubProv,$prestataire,$importedFile) {
            //dd($reader);
                // Loop through all rows
                
                $reader->each(function($row) use ($produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto,&$validRowTab,&$errorRowTab,&$nbreValide,&$nbreErrone) {
                    //dd($row);
                    
                        $fixedRow = [];
                        $fixedRow = $this->fixRowObseques($row);
                        // echo '<pre>';
                        // print_r($validRow);
                        // echo '</pre>';
                        //dd($validRow->toArray());

                   $returnTab = $this->InsertLeadsObseques($fixedRow->toArray(),$produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto);
                   //dd($returnTab);
                   if($returnTab['valid'])
                   {
                        array_push($validRowTab,$returnTab['row']);
                        $nbreValide++;
                        //   echo '<pre>';
                        // print_r($this->validRowTab);
                        // echo '</pre>===============================\n';
                   }
                   else
                   {
                        array_push($errorRowTab,$returnTab['row']);
                        $nbreErrone++;
                   }

                });

                

            //});

        },false);

		// Excel::load($OriginalFilePath."/".$OriginalFileName,function($reader) use ($produit,$idGrpPubProv,$prestataire,$leads,$importedFile){
		// 	//echo "tiiiiiit";

  //   		$reader->each(function($sheet) use ($produit,$idGrpPubProv,$prestataire,$leads,$importedFile) {

		// 	    // Loop through all rows
		// 	    $sheet->each(function($row) use ($produit,$idGrpPubProv,$prestataire,$leads,$importedFile) {

		// 	    	//echo "<pre>".print_r($row->toArray()).exit("</pre>");

  //   				$this->InsertLeadsObseques($row->toArray(),$produit,$idGrpPubProv,$prestataire,$leads,$importedFile);

		// 	    });

		// 	});
    		

  //   		//$Clients   = Client::all();
  //   		//return redirect("admin/leads/upload",['Clients'=> $Clients]);

  //   	});

        $importedFile->nbre_fiche_valide = $nbreValide;
        $importedFile->nbre_fiche_errone = $nbreErrone;
        $importedFile->save();
        //Creer le fichier des leads valides
            $this->createImportedLeadsFileObseques($importedFile,$validRowTab);

        //Creer le fichier des leads non valides
            $this->createImportedErrorLeadsFileObseques($importedFile,$errorRowTab);


    }

    //traitement d'import d'un fichier Auto


    public function traiteImportedFileAuto($produit,$leads,$prestataire,$idGrpPubProv,$idGrpPubSte,$groupepubId,$dispatchingAuto)
    {
        ini_set('memory_limit', '2048M');
        //ini_set('MAX_EXECUTION_TIME', 3600);
        //set_time_limit(3600);
        //Stocker  le fichier uploadé
        $importedFile     = $this->stockOriginalLeadsFile($leads,$prestataire,$idGrpPubProv,$idGrpPubSte,$produit);
        //echo $idOriginalFile;

        //$importedFile                             = Importfile::find($idOriginalFile);
        $OriginalFilePath                       = $importedFile->chemin_fichier_original;
        $OriginalFileName                       = $importedFile->nom_fichier_original;

        

        //dd($leads);
        
        //Parser le fichier uploadé
        $validRowTab = [];
        $errorRowTab = [];
        $nbreValide = 0;
        $nbreErrone = 0;

        array_push($validRowTab,array(
                     'nom', 'prenom', 'civilite', 'sexe', 'sit_familiale', 'date_naissance', 'adresse', 'code_postal', 'ville', 'tel_bureau', 'tel_domicile', 'tel_mobile', 'fax', 'email', 'profession', 'date_effet', 'date_permis', 'type_permi', 'deja_assure', 'conducteur_secondaire', 'origine_vehicule', 'etat_vehicule', 'mode_acquisition', 'date_acquisition', 'kilometre_parcouru', 'usage_vehicule', 'frequence_utilisation', 'titulaire_carte_grise', 'nombre_sinistre' , 'date_sinistre', 'nature_sinistre'));
        array_push($errorRowTab,array(
             'nom', 'prenom', 'civilite', 'sexe', 'sit_familiale', 'date_naissance', 'adresse', 'code_postal', 'ville', 'tel_bureau', 'tel_domicile', 'tel_mobile', 'fax', 'email', 'profession', 'date_effet', 'date_permis', 'type_permi', 'deja_assure', 'conducteur_secondaire', 'origine_vehicule', 'etat_vehicule', 'mode_acquisition', 'date_acquisition', 'kilometre_parcouru', 'usage_vehicule', 'frequence_utilisation', 'titulaire_carte_grise', 'nombre_sinistre' , 'date_sinistre', 'nature_sinistre'));
        Excel::filter('chunk')->load($OriginalFilePath."/".$OriginalFileName)->chunk(50, function($reader) use ($produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto,&$validRowTab,&$errorRowTab,&$nbreValide,&$nbreErrone)
        {

            //$reader->each(function($sheet) use ($produit,$idGrpPubProv,$prestataire,$importedFile) {
            //dd($reader);
                // Loop through all rows
                
                $reader->each(function($row) use ($produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,&$validRowTab,&$errorRowTab,$dispatchingAuto,&$nbreValide,&$nbreErrone) {
                    //dd($row);
                    
                        $fixedRow = [];
                        $fixedRow = $this->fixRowAuto($row);
                        // echo '<pre>';
                        // print_r($validRow);
                        // echo '</pre>';
                        //dd($validRow->toArray());

                   $returnTab = $this->InsertLeadsAuto($fixedRow->toArray(),$produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto);
                   //dd($returnTab);
                   if($returnTab['valid'])
                   {
                        array_push($validRowTab,$returnTab['row']);
                        $nbreValide++;
                        //   echo '<pre>';
                        // print_r($this->validRowTab);
                        // echo '</pre>===============================\n';
                   }
                   else
                   {
                        array_push($errorRowTab,$returnTab['row']);
                        $nbreErrone++;
                   }

                });

                

            //});

        },false);
                //dd($validRowTab);
                // echo '<pre>';
                // print_r($this->validRowTab);
                // echo '</pre>';
                // echo '<pre>';
                // print_r($this->errorRowTab);
                // echo '</pre>';

                $importedFile->nbre_fiche_valide = $nbreValide;
                $importedFile->nbre_fiche_errone = $nbreErrone;
                $importedFile->save();
                //Creer le fichier des leads valides
                $this->createImportedLeadsFileSante($importedFile,$validRowTab);

            //Creer le fichier des leads non valides
                $this->createImportedErrorLeadsFileSante($importedFile,$errorRowTab);
            

            

        // Excel::load($OriginalFilePath."/".$OriginalFileName,function($reader) use ($produit,$idGrpPubProv,$prestataire,$importedFile){
        //  //echo "tiiiiiit";
  //           //$reader->ignoreEmpty();

  //        $reader->each(function($sheet) use ($produit,$idGrpPubProv,$prestataire,$importedFile) {

        //      // Loop through all rows
        //      $sheet->each(function($row) use ($produit,$idGrpPubProv,$prestataire,$importedFile) {

        //          //echo "<pre>".print_r($row->toArray()).exit("</pre>");
  //                   dd($row);

  //                $this->InsertLeadsSante($row->toArray(),$produit,$idGrpPubProv,$prestataire,$importedFile);

        //      });

        //  });
  //        $importedFile->nbre_fiche_valide = $this->nbreValide;
  //        $importedFile->nbre_fiche_errone = $this->nbreErrone;
  //        $importedFile->save();

            //$Clients   = Client::all();
            //return redirect("admin/leads/upload",['Clients'=> $Clients]);

        //});


    }



    public function InsertLeadsSante($row,$produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto)
    {

    		//dd($row);
    	
    	$validator       	= Validator::make($row,[
    					
			            //Les informations personnelles du prospect
			            'nom'                  => 'required|regex:/^[a-zA-Z-_ ]+$/i|max:50',
			            'prenom'               => 'required|regex:/^[a-zA-Z-_ ]+$/i|max:50',
			            'civilite'             => 'regex:/^[a-zA-Z.]+$/i|max:4',
			            'sexe'                 => 'alpha|max:1',
			            'sit_familiale'        => 'alpha|max:1',
			            'date_naissance'       => 'required|date',
			            'code_postal'          => 'alpha_num|max:8',
			            'ville'                => 'regex:/^[a-zA-Z0-9,-_ ]+$/i|max:50',
                        'adresse'              => 'regex:/^[a-zA-Z0-9,-_ ]+$/i',
			            'tel_bureau'           => 'max:15',
			            'tel_domicile'         => 'max:15',
			            'tel_mobile'           => 'max:15',
			            'fax'                  => 'max:15',
			            'email'                => 'email',
			            'profession'           => 'integer',
			            'regime'               => 'required|integer',
			            'date_effet'           => 'required|date',
			            //informations conjoint           
			            'regime_c'             => 'integer',
			            'sexe_c'        	   => 'alpha|max:1',
			            'date_naissance_c' 	   => 'date'

    				]);




    	//$importedFile  		 					= Importfile::find($idOriginalFile);
    	$OriginalFilePath                       = $importedFile->chemin_fichier_original;
    	$validLeadsFileName                     = $importedFile->nom_fichier_valide;
    	$errorLeadsFileName                     = $importedFile->nom_fichier_errone;

    	if($validator->passes())
    	{

    		//Insertion dans la table leadsSante

    		$leadsante                     				                  = new Leadsante;
	        
	        if(!empty($row['nom'])) $leadsante->nom                       = $row['nom'];
    		if(!empty($row['prenom'])) $leadsante->prenom                 = $row['prenom'];
    		if(!empty($row['civilite'])) $leadsante->civilite             = $row['civilite'];
    		if(!empty($row['sexe'])) $leadsante->sexe                     = $row['sexe'];
    		if(!empty($row['sit_familiale'])) $leadsante->sit_familiale   = $row['sit_familiale'];
    		if(!empty($row['date_naissance'])) $leadsante->date_naissance = $row['date_naissance'];
    		if(!empty($row['adresse'])) $leadsante->adresse               = $row['adresse'];
    		if(!empty($row['code_postal'])) $leadsante->code_postal       = $row['code_postal'];
    		if(!empty($row['ville'])) $leadsante->ville                   = $row['ville'];
    		if(!empty($row['tel_bureau'])) $leadsante->tel_bureau         = $row['tel_bureau'];
    		if(!empty($row['tel_domicile'])) $leadsante->tel_domicile     = $row['tel_domicile'];
    		if(!empty($row['tel_mobile'])) $leadsante->tel_mobile         = $row['tel_mobile'];
    		if(!empty($row['fax'])) $leadsante->fax                       = $row['fax'];
    		if(!empty($row['email'])) $leadsante->email                   = $row['email'];
    		if(!empty($row['profession'])) $leadsante->profession_id      = $row['profession'];
    		if(!empty($row['regime'])) $leadsante->saregime_id            = $row['regime'];

            $leadsante->groupepub_provenance_id                           = $idGrpPubProv;
			$leadsante->groupepub_societe_id 		                      = $idGrpPubSte;
    		$leadsante->active             				                  = 1;
			
			if(!empty($row['date_naissance_c']))
			{
				$leadsante->date_naissance_conj 			                        = $row['date_naissance_c'];
				if(!empty($row['regime_c'])) $leadsante->saregime_conj_id           = $row['regime_c'];
				if(!empty($row['sexe_c'])) $leadsante->sexe_conj                    = $row['sexe_c'];
			}
	        $nomClient = $row['nom'];
            //echo "nomclient : ".$nomClient;
    		//echo "<pre>".print_r($row).exit("</pre>");

    		if(!empty($row['date_naissance_enf']))
    		{

    			$tabDateNaissance              = explode(',', $row['date_naissance_enf']);

    			$leadsante->date_naissance_enf = json_encode($tabDateNaissance);

    		}

    		//dd(json_encode(explode(',', $row['date_naissance_enf'])));               

	        $leadsante->save();

	        //On teste si le client existe deja 
        	$clientOrigine  = $this->clientExistant($row);

        	//echo "tooot:".$clientOrigine;
    		
    		//$messages 					= $validator->errors();

    		//echo "<pre>".print_r($row).exit("</pre>");

    		if(!$clientOrigine){ //Si le client n'existe pas on l'ajoute

    		$client         			                                  = new Client;
    		

    		if(!empty($row['nom'])) $client->nom                          = $row['nom'];
    		if(!empty($row['prenom'])) $client->prenom                    = $row['prenom'];
    		if(!empty($row['civilite'])) $client->civilite                = $row['civilite'];
    		if(!empty($row['sexe'])) $client->sexe                        = $row['sexe'];
    		if(!empty($row['sit_familiale'])) $client->sit_familiale      = $row['sit_familiale'];
    		if(!empty($row['date_naissance'])) $client->date_naissance    = $row['date_naissance'];
    		if(!empty($row['adresse'])) $client->adresse                  = $row['adresse'];
    		if(!empty($row['code_postal'])) $client->code_postal          = $row['code_postal'];
    		if(!empty($row['ville'])) $client->ville                      = $row['ville'];
    		if(!empty($row['tel_bureau'])) $client->tel_bureau            = $row['tel_bureau'];
    		if(!empty($row['tel_domicile'])) $client->tel_domicile        = $row['tel_domicile'];
    		if(!empty($row['tel_mobile'])) $client->tel_mobile            = $row['tel_mobile'];
    		if(!empty($row['fax'])) $client->fax                          = $row['fax'];
    		if(!empty($row['email'])) $client->email                      = $row['email'];
    		if(!empty($row['profession'])) $client->profession_id         = $row['profession'];
    		if(!empty($row['regime'])) $client->saregime_id               = $row['regime'];
    		$client->active                                               = 1;	
    		$storeclient                                                  = $client->save();

    		}else{

                $client = $clientOrigine;
        	}

            $prdt                       = Produit::find($produit);

        	//Si le client a une fiche sante
        	$ficheExist 				= $this->ficheExistante($client->id,$prdt->slug);

        	$doublon     				= 0;

        	if($ficheExist){ $doublon   = 1;}


    		
    			$fiche      				    = new Fichesante;
    			//Selectionner le cout du groupe pub du prestataire

    			$coutGroupPub      				= Groupepub::find($groupepubId);
    			//$dateNaissCarbon                = $this->dateCarbon($row['date_naissance']); 
    			$dateNaissCarbon                = 	$row['date_naissance'];										
    			//echo $dateNaissCarbon->age;

        		($dateNaissCarbon->age >= 55 or $row['regime'] == 3) ? $fiche->ani = 0 : $fiche->ani = 1;


	    		$fiche->date_effet              = $row['date_effet'];
	    		$fiche->date_insertion 			= Carbon::now();
                $fiche->date_situation          = Carbon::now();
	    		$fiche->groupepub_provenance_id = $idGrpPubProv;
                $fiche->groupepub_societe_id    = $idGrpPubSte;
		        $fiche->client_id               = $client->id;
		        $fiche->importfile_id           = $importedFile->id;
                $fiche->slug                    = uniqid();
		        //$fiche->user_id                 = 41;//dispatch
		        $fiche->produit_id              = $prdt->id;// id produit sante 
                $statut                         = Statut::where('slug','santeAppel')->first();
		        $fiche->statut_id               = $statut->id;// il faut creer ce statut dans la bd
		        $fiche->motif_id                = null;// il faut creer ce motif dans la bd
		        $fiche->cout 					= $coutGroupPub->cout;
		        $fiche->etat                    = "E";
		        $fiche->active                  = 1;
		        $fiche->save();

                $numContrat                     = $this->mask(2,$prdt->id).$this->mask(7,$fiche->id);
                $fiche->num_fiche               = $numContrat;
                $fiche->leadsante_id            = $leadsante->id;
                $fiche->doublon                 = $doublon;
                $storefiche                     = $fiche->save();

                //Trace insertion fiche

                $idUserDisp     = User::where('login', 'Dispatch')->value('id');
                $idAction       = Action::where('slug','IFI')->value('id');

                $tabInfoTrace   = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'observation' => null, 'motif' => null, 'idStatut' => $statut->id,'user_id' => $idUserDisp, 'equipe_user_id' => null, 'tracable_id' => Auth::user()->courtier_id, 'tracable_type' => 'courtier'];
                event(new EventTracesSante($tabInfoTrace));
		        
	    	     //dd($storefiche); 

                //Dispatching automatique ou manuel (les fiches restent au panier du courtier)

                if($storefiche)
                {

                    if($dispatchingAuto)//Dispatching auto
                    {
                        //$idUserDisp         = User::where('login', 'Dispatch')->value('id');

                        $ficheController    = new FicheController();

                        $infosDestination   = $ficheController->dispatching($groupepubId, $prdt->id, $fiche->id, $idUserDisp, $prdt->slug, $statut->id);

                        //$infosDestination   = $this->dispatching($groupe->id, $produit->id, $fiche->id, $idUserDisp, $produit->slug, $idStatut);

                        if($infosDestination['id']){

                            $fiche->dispatchable_id     = $infosDestination['id'];
                            $fiche->dispatchable_type   = $infosDestination['table'];  

                            if(isset($infosDestination['idUserEquipe'])){

                                $fiche->equipe_user_id  = $infosDestination['idUserEquipe'];
                            }   

                        }else{

                            //return json_encode(['status' => 0, 'message'=>'Erreur d insertion numero : 4.']);            
                        }

                        //Enregistrer les traces de l insertion

                        $idAction       = Action::where('slug','DAI')->value('id');

                        $tabInfoTrace   = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'observation' => null, 'motif' => null, 'idStatut' => $statut->id,'user_id' => $idUserDisp, 'equipe_user_id' => null, 'tracable_id' => $fiche->dispatchable_id, 'tracable_type' => $fiche->dispatchable_type];
                        event(new EventTracesSante($tabInfoTrace));


                        //Envoyer notification au conseiller ou responsable en question

                        $notif          = Notification::whereSlug('LEADDISPATCH')->first();

                        if(isset($infosDestination['idUserEquipe'])){

                            $userNotif      = Equipeuser::find($infosDestination['idUserEquipe'])->user()->first(); 

                        }else{

                            $className      = "App\\".ucfirst($infosDestination['table']);                    
                            $userNotif      = $className::find($infosDestination['id'])->responsable();
                        }

                        if($userNotif){

                            $idUserNotif    = $userNotif->id;
                            $linkNotif      = url($userNotif->profile->slug.'/leads/'.$statut->id);

                        }else{

                            $idUserNotif    = "";
                            $linkNotif      = "";                    
                        }

                        $description        = "Vous avez reçu une fiche ".$prdt->libelle." numéro : ".$fiche->num_fiche.".";
                        
                        $notification       = [
                            'user_id'         => $idUserNotif,
                            'notification_id' => $notif->id,
                            'notifiable_id'   => $fiche->id,
                            'notifiable_type' => $prdt->table_produit,
                            'rappel_time'     => null,
                            'link'            => null,
                            'type'            => 'dispatch',
                            'description'     => $description,
                            'link'            => $linkNotif
                        ];

                        event(new EventNotifications($notification));

                    }
                    else //Dispatching manuel
                    {
                        $fiche->dispatchable_id         = Auth::user()->courtier_id;
                        $fiche->dispatchable_type       = 'courtier';
                        $fiche->is_dispatched           = 1;
                    }

                    
                }


                $fiche->save();

                

	        //Enregistrer les infos du conjoint
	        if (!empty($row['date_naissance_c']) and $storefiche) {
		        //return "dakhl conjoint";
                //dd($storefiche);
		        $conjoint   				= new Conjoint;
		        $conjoint->fichesante_id    = $fiche->id;
		        $conjoint->date_naissance   = $row['date_naissance_c'];
		        if(!empty($row['regime_c'])) $conjoint->saregime_id      = $row['regime_c'];
		        if(!empty($row['sexe_c'])) $conjoint->sexe               = $row['sexe_c'];
		        $conjoint->save();

	    	}
            // else
            // {
            //     //dd($storefiche);
            //    return "madkhlch conjoint"; 
            // }

            // return "fat conjoint";

	    	//Enregistrer les infos des enfants
	    	if(!empty($row['date_naissance_enf']) and $storefiche)
	    	{
	    		if(count($tabDateNaissance)>0)
	    		{
		    		//echo "<pre>".print_r($tabDateNaissance).exit("</pre>");

		    		//echo "enf:".count($tabDateNaissance)."<br>";
				
		        	for($i = 0; $i < count($tabDateNaissance); $i++){

		        		//echo "enf:".$tabDateNaissance[$i]."<br>";

		        	${'enfant'.$i}		             = new Enfant;
			        ${'enfant'.$i}->date_naissance   = $tabDateNaissance[$i];
			        ${'enfant'.$i}->fichesante_id    = $fiche->id;
			        ${'enfant'.$i}->active           = 1;
			        ${'enfant'.$i}->save();

		    		}

		    	}

	    	}

	    	$leadsante->doublon = $doublon;
        	$leadsante->save();

        	$this->incrementClientProduit($client->id, $produit);

	    	//Inserer la fiche dans le fichier excel creé

            
	    	// //Excel::load($OriginalFilePath."/".$importedFile->nom_fichier_original,function($file) use($row)
      //       Excel::filter('chunk')->load($OriginalFilePath."/".$validLeadsFileName)->chunk(20, function($reader) use($row)
      //       {

	    	// 	dd($reader); 
      //           //$results = $reader->first();

	    	// 	//$sheet = $reader->getActiveSheet();
      //           //$sheet->prependRow(2, $row);
      //           //dd($results);
	    	// 	//$reader->sheet('feuille 1',function($sheet) use ($row)
      //           //$reader->each(function($sheet) use ($row) 

      //           foreach($reader as $sheet)
      //           {
      //               //dd($sheet);
      //               // get sheet title
      //               //$sheetTitle = $sheet->getTitle();
      //               $sheet->prependRow(2, $row);
      //           }


      //  //          $reader->sheet('feuille 1',function($sheeet) use($row) 
			   //  // {
                    
			   //  //     //$sheet->appendRow($row);
			   //  //     //dd($sheet);
			   //  //     //echo "valid : <pre>".print_r($row)."</pre>";
      //  //              //dd($row);

			   //  //     $sheeet->prependRow(2, $row);

			   //  //     //$sheet->rows($row);
			   //  // });

    			


    		// })->store('csv');

      //       array_push($this->validRowTab,$row);
      //       echo "<pre>",print_r($this->validRowTab),"</pre>";
	    	// $this->nbreValide ++;

            return ['row'=> $row , 'valid' => true];
	    	

	    	//echo "fiches uploaded !!";

	    	//return true;

    	}
    	else
    	{
    		//dd($validator->errors());

    		//echo "error uploaded !!";
    		//$this->fichesErronees[] = $row;

    		//Inserer la fiche erronée dans le fichier excel des fiches non valides


	    	// Excel::load($OriginalFilePath."/".$errorLeadsFileName,function($reader) use($row){

	    	// 	//echo $temp; 

	    	// 	//$sheet = $reader->getActiveSheet();
                
	    	// 	//$reader->sheet('feuille 1',function($sheet) use ($row)
      //           //$reader->each(function($sheet) use ($row)
      //           $reader->sheet('feuille 1',function($sheet) use($row)               
			   //  {
      //               //dd($sheet);
			   //      //$sheet->appendRow($row);
			   //      //echo $IncremNotOk."<br>";

			   //      //echo "error : <pre>".print_r($row)."</pre>";
      //               //dd($row);

			   //      //$sheet->prependRow(2, $row);
			   //  });

    			


    		// })->store('csv',$OriginalFilePath);

      //       array_push($this->errorRowTab,$row);
    		// $this->nbreErrone ++;

            return ['row'=> $row , 'valid' => false];



    		//return false;
    	}


    }

    public function InsertLeadsObseques($row,$produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto)
    {
    	
    	$validator       	= Validator::make($row,[
    					
			            //Les informations personnelles du prospect
			            'nom'                  => 'required|regex:/^[a-zA-Z-_ ]+$/i|max:50',
			            'prenom'               => 'required|regex:/^[a-zA-Z-_ ]+$/i|max:50',
			            'civilite'             => 'regex:/^[a-zA-Z.]+$/i|max:4',
                        'sexe'                 => 'alpha|max:1',
                        'sit_familiale'        => 'alpha|max:1',
                        'date_naissance'       => 'required|date',
                        'code_postal'          => 'alpha_num|max:8',
                        'ville'                => 'regex:/^[a-zA-Z0-9,-_ ]+$/i|max:50',
                        'adresse'              => 'regex:/^[a-zA-Z0-9,-_ ]+$/i',
                        'tel_bureau'           => 'max:15',
                        'tel_domicile'         => 'max:15',
                        'tel_mobile'           => 'max:15',
                        'fax'                  => 'max:15',
                        'email'                => 'email',

			            //Informations produit
			            'date_effet'           => 'required|date',
			            'profession'           => 'integer',
			            'regime'               => 'required|integer',
			            'capital'              => 'numeric',

    				]);

    	//$importedFile  		 					= Importfile::find($idOriginalFile);
    	$OriginalFilePath                       = $importedFile->chemin_fichier_original;
    	$validLeadsFileName                     = $importedFile->nom_fichier_valide;
    	$errorLeadsFileName                     = $importedFile->nom_fichier_errone;

    	if($validator->passes())
    	{

    		//Insertion dans la table leadsSante

    		$Leadobseque                     				= new Leadobseque;
	        
	        if(!empty($row['nom'])) $Leadobseque->nom                       = $row['nom'];
            if(!empty($row['prenom'])) $Leadobseque->prenom                 = $row['prenom'];
            if(!empty($row['civilite'])) $Leadobseque->civilite             = $row['civilite'];
            if(!empty($row['sexe'])) $Leadobseque->sexe                     = $row['sexe'];
            if(!empty($row['sit_familiale'])) $Leadobseque->sit_familiale   = $row['sit_familiale'];
            if(!empty($row['date_naissance'])) $Leadobseque->date_naissance = $row['date_naissance'];
            if(!empty($row['adresse'])) $Leadobseque->adresse               = $row['adresse'];
            if(!empty($row['code_postal'])) $Leadobseque->code_postal       = $row['code_postal'];
            if(!empty($row['ville'])) $Leadobseque->ville                   = $row['ville'];
            if(!empty($row['tel_bureau'])) $Leadobseque->tel_bureau         = $row['tel_bureau'];
            if(!empty($row['tel_domicile'])) $Leadobseque->tel_domicile     = $row['tel_domicile'];
            if(!empty($row['tel_mobile'])) $Leadobseque->tel_mobile         = $row['tel_mobile'];
            if(!empty($row['fax'])) $Leadobseque->fax                       = $row['fax'];
            if(!empty($row['email'])) $Leadobseque->email                   = $row['email'];
            if(!empty($row['profession'])) $Leadobseque->profession_id      = $row['profession'];
            if(!empty($row['regime'])) $Leadobseque->saregime_id            = $row['regime'];
			if(!empty($row['capital'])) $Leadobseque->capital        		= $row['capital'];
            $Leadobseque->groupepub_provenance_id                           = $idGrpPubProv;
	        $Leadobseque->groupepub_societe_id 			                    = $idGrpPubSte;
    		$Leadobseque->active             				                = 1;


    		//dd(json_encode(explode(',', $row['date_naissance_enf'])));               

	        $Leadobseque->save();

	        //On teste si le client existe deja 
        	$clientOrigine  = $this->clientExistant($row);

        	if(!$clientOrigine)
        	{ //Si le client n'existe pas on l'ajoute

    		$client         			= new Client;
    		

    		if(!empty($row['nom'])) $client->nom                          = $row['nom'];
            if(!empty($row['prenom'])) $client->prenom                    = $row['prenom'];
            if(!empty($row['civilite'])) $client->civilite                = $row['civilite'];
            if(!empty($row['sexe'])) $client->sexe                        = $row['sexe'];
            if(!empty($row['sit_familiale'])) $client->sit_familiale      = $row['sit_familiale'];
            if(!empty($row['date_naissance'])) $client->date_naissance    = $row['date_naissance'];
            if(!empty($row['adresse'])) $client->adresse                  = $row['adresse'];
            if(!empty($row['code_postal'])) $client->code_postal          = $row['code_postal'];
            if(!empty($row['ville'])) $client->ville                      = $row['ville'];
            if(!empty($row['tel_bureau'])) $client->tel_bureau            = $row['tel_bureau'];
            if(!empty($row['tel_domicile'])) $client->tel_domicile        = $row['tel_domicile'];
            if(!empty($row['tel_mobile'])) $client->tel_mobile            = $row['tel_mobile'];
            if(!empty($row['fax'])) $client->fax                          = $row['fax'];
            if(!empty($row['email'])) $client->email                      = $row['email'];
            if(!empty($row['profession'])) $client->profession_id         = $row['profession'];
            if(!empty($row['regime'])) $client->saregime_id               = $row['regime'];
    		$client->active             = 1;	
    		$storeclient                = $client->save();

    		}else
    		{

                $client = $clientOrigine;
        	}

            $prdt                       = Produit::find($produit);

        	//Si le client a une fiche sante
        	$ficheExist 				= $this->ficheExistante($client->id,$prdt->slug);

        	$doublon     				= 0;

        	if($ficheExist){ $doublon   = 1;}

        	$fiche      				    = new Ficheobseque;
			//Selectionner le cout du groupe pub du prestataire

			$coutGroupPub      				= Groupepub::find($groupepubId);
			//$dateNaissCarbon                = $this->dateCarbon($row['date_naissance']); 
			$dateNaissCarbon      			= 	$row['date_naissance'];										
			//echo $dateNaissCarbon->age;

    		($dateNaissCarbon->age >= 55 or $row['regime'] == 3) ? $fiche->ani = 0 : $fiche->ani = 1;

    		if(!empty($row['capital'])) $fiche->capital	                = $row['capital'];
    		if(!empty($row['date_effet'])) $fiche->date_effet           = $row['date_effet'];
    		$fiche->date_insertion 			= Carbon::now();
            $fiche->date_situation          = Carbon::now();
    		$fiche->groupepub_provenance_id = $idGrpPubProv;
            $fiche->groupepub_societe_id    = $idGrpPubSte;
	        $fiche->client_id               = $client->id;
	        $fiche->importfile_id           = $importedFile->id;
	        $fiche->leadobseque_id          = $Leadobseque->id;
            // $fiche->dispatchable_id         = Auth::user()->courtier_id;
            // $fiche->dispatchable_type       = 'courtier';
            $fiche->slug                    = uniqid();
	        //$fiche->user_id                 = 41;//dispatch
	        $fiche->produit_id              = $prdt->id;// id produit sante 
            $statut                         = Statut::where('slug','obsequeAppel')->first();
	        $fiche->statut_id               = $statut->id;// il faut creer ce statut dans la bd
	        $fiche->motif_id                = 1;// il faut creer ce motif dans la bd
	        $fiche->cout 					= $coutGroupPub->cout;
	        $fiche->etat                    = "E";
	        $fiche->active                  = 1;
	        $fiche->save();
	        $numContrat  					= $this->mask(2,$prdt->id).$this->mask(7,$fiche->id);
	        $fiche->num_fiche   			= $numContrat;
    		$fiche->doublon                 = $doublon;
	        $storefiche 					= $fiche->save();

            // Enregistrer les traces de l insertion

            $idUserDisp     = User::where('login', 'Dispatch')->value('id');
            $idAction       = Action::where('slug','IFI')->value('id');

            $tabInfoTrace   = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'observation' => null, 'motif' => null, 'idStatut' => $statut->id,'user_id' => $idUserDisp, 'equipe_user_id' => null, 'tracable_id' => Auth::user()->courtier_id, 'tracable_type' => 'courtier'];
            event(new EventTracesObseque($tabInfoTrace));


            //Dispatching automatique ou manuel (les fiches restent au panier du courtier)

            if($storefiche)
            {

                if($dispatchingAuto)//Dispatching auto
                {
                    //$idUserDisp         = User::where('login', 'Dispatch')->value('id');

                    $ficheController    = new FicheController();

                    $infosDestination   = $ficheController->dispatching($groupepubId, $prdt->id, $fiche->id, $idUserDisp, $prdt->slug, $statut->id);

                    //$infosDestination   = $this->dispatching($groupe->id, $produit->id, $fiche->id, $idUserDisp, $produit->slug, $idStatut);

                    if($infosDestination['id']){

                        $fiche->dispatchable_id     = $infosDestination['id'];
                        $fiche->dispatchable_type   = $infosDestination['table'];  

                        if(isset($infosDestination['idUserEquipe'])){

                            $fiche->equipe_user_id  = $infosDestination['idUserEquipe'];
                        }   

                    }else{

                        //return json_encode(['status' => 0, 'message'=>'Erreur d insertion numero : 4.']);            
                    }

                    //Enregistrer les traces de l insertion

                    $idAction       = Action::where('slug','DAI')->value('id');

                    $tabInfoTrace   = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'observation' => null, 'motif' => null, 'idStatut' => $statut->id,'user_id' => $idUserDisp, 'equipe_user_id' => null, 'tracable_id' => $fiche->dispatchable_id, 'tracable_type' => $fiche->dispatchable_type];
                    event(new EventTracesObseque($tabInfoTrace));


                    //Envoyer notification au conseiller ou responsable en question

                    $notif          = Notification::whereSlug('LEADDISPATCH')->first();

                    if(isset($infosDestination['idUserEquipe'])){

                        $userNotif      = Equipeuser::find($infosDestination['idUserEquipe'])->user()->first(); 

                    }else{

                        $className      = "App\\".ucfirst($infosDestination['table']);                    
                        $userNotif      = $className::find($infosDestination['id'])->responsable();
                    }

                    if($userNotif){

                        $idUserNotif    = $userNotif->id;
                        $linkNotif      = url($userNotif->profile->slug.'/leads/'.$statut->id);

                    }else{

                        $idUserNotif    = "";
                        $linkNotif      = "";                    
                    }

                    $description        = "Vous avez reçu une fiche ".$prdt->libelle." numéro : ".$fiche->num_fiche.".";
                    
                    $notification       = [
                        'user_id'         => $idUserNotif,
                        'notification_id' => $notif->id,
                        'notifiable_id'   => $fiche->id,
                        'notifiable_type' => $prdt->table_produit,
                        'rappel_time'     => null,
                        'link'            => null,
                        'type'            => 'dispatch',
                        'description'     => $description,
                        'link'            => $linkNotif
                    ];

                    event(new EventNotifications($notification));

                }
                else //Dispatching manuel
                {
                    $fiche->dispatchable_id         = Auth::user()->courtier_id;
                    $fiche->dispatchable_type       = 'courtier';
                    $fiche->is_dispatched           = 1;
                }

                
            }


            $fiche->save();






	        $Leadobseque->doublon 			= $doublon;
        	$Leadobseque->save();

        	$this->incrementClientProduit($client->id, $prdt->id);

            

        	//Inserer la fiche dans le fichier excel creé


	    	// Excel::load($OriginalFilePath."/".$validLeadsFileName,function($reader) use ($row){

	    	// 	//dd($reader); 

	    	// 	//$sheet = $reader->getActiveSheet();
	    	// 	//$reader->sheet('feuille 1',function($sheet) use ($row)
      //           $reader->each(function($sheet) use ($row)
			   //  {
			   //      //$sheet->appendRow($row);
			   //      //dd($row);
			   //      //echo "<pre>".print_r($row).exit("</pre>");

			   //      $sheet->prependRow(2, $row);

			   //      //$sheet->rows($row);
			   //  });

    			


    		// })->store('xls',$OriginalFilePath);


	    	//$this->nbreValide ++;

             //echo "fiche obseques valide";
            return ['row'=> $row , 'valid' => true];


        }
        else
        {
            return ['row'=> $row , 'valid' => false];
        	//dd($validator->errors());
        	//Inserer la fiche erronée dans le fichier excel des fiches non valides
            //echo "fiche obseques erronée";

	    	// Excel::load($OriginalFilePath."/".$errorLeadsFileName,function($reader) use ($row){

	    	// 	//echo $temp; 

	    	// 	//$sheet = $reader->getActiveSheet();
	    	// 	//$reader->sheet('feuille 1',function($sheet) use ($row)
      //           $reader->each(function($sheet) use ($row)
			   //  {
			   //      //$sheet->appendRow($row);
			   //      //echo $IncremNotOk."<br>";

			   //      //echo "<pre>".print_r($row).exit("</pre>");


			   //      $sheet->prependRow(2, $row);
			   //  });

    			


    		// })->store('xls',$OriginalFilePath);

    		// $this->nbreErrone ++;
        }
    }

    //Insertion fiche auto

    public function InsertLeadsAuto($row,$produit,$idGrpPubProv,$idGrpPubSte,$groupepubId,$importedFile,$dispatchingAuto)
    {

            //dd($dispatchingAuto);
        
        $validator          = Validator::make($row,[
                        
                        //Les informations personnelles du prospect
                        'nom'                  => 'required|regex:/^[a-zA-Z-_ ]+$/i|max:50',
                        'prenom'               => 'required|regex:/^[a-zA-Z-_ ]+$/i|max:50',
                        'civilite'             => 'regex:/^[a-zA-Z.]+$/i|max:4',
                        'sexe'                 => 'alpha|max:1',
                        'sit_familiale'        => 'alpha|max:1',
                        'date_naissance'       => 'required|date',
                        'code_postal'          => 'alpha_num|max:8',
                        'ville'                => 'regex:/^[a-zA-Z0-9,-_ ]+$/i|max:50',
                        'adresse'              => 'regex:/^[a-zA-Z0-9,-_ ]+$/i',
                        'tel_bureau'           => 'max:15',
                        'tel_domicile'         => 'max:15',
                        'tel_mobile'           => 'max:15',
                        'fax'                  => 'max:15',
                        'email'                => 'required|email',
                        'profession'           => 'integer',
                        'date_effet'           => 'required|date',
                        'date_permis'          => 'date',
                        'type_permi'           => 'integer',
                        'deja_assure'          => 'required|integer',
                        'conducteur_secondaire' => 'required|integer',
                        
                        //informations véhicule           
                        'origine_vehicule'     => 'required|integer',
                        'etat_vehicule'        => 'required|integer',
                        'mode_acquisition'     => 'required|integer',
                        'date_acquisition'     => 'date',
                        'kilometre_parcouru'   => 'integer',
                        'usage_vehicule'       => 'integer',
                        'frequence_utilisation' => 'integer',
                        'titulaire_carte_grise' => 'integer'

                    ]);




        //$importedFile                             = Importfile::find($idOriginalFile);
        $OriginalFilePath                       = $importedFile->chemin_fichier_original;
        $validLeadsFileName                     = $importedFile->nom_fichier_valide;
        $errorLeadsFileName                     = $importedFile->nom_fichier_errone;

        if($validator->passes())
        {

            //Insertion dans la table leadsSante

            $leadauto                                                                      = new Leadauto;
            
            if(!empty($row['nom'])) $leadauto->nom                                         = $row['nom'];
            if(!empty($row['prenom'])) $leadauto->prenom                                   = $row['prenom'];
            if(!empty($row['civilite'])) $leadauto->civilite                               = $row['civilite'];
            if(!empty($row['sexe'])) $leadauto->sexe                                       = $row['sexe'];
            if(!empty($row['sit_familiale'])) $leadauto->sit_familiale                     = $row['sit_familiale'];
            if(!empty($row['date_naissance'])) $leadauto->date_naissance                   = $row['date_naissance'];
            if(!empty($row['adresse'])) $leadauto->adresse                                 = $row['adresse'];
            if(!empty($row['code_postal'])) $leadauto->code_postal                         = $row['code_postal'];
            if(!empty($row['ville'])) $leadauto->ville                                     = $row['ville'];
            if(!empty($row['tel_bureau'])) $leadauto->tel_bureau                           = $row['tel_bureau'];
            if(!empty($row['tel_domicile'])) $leadauto->tel_domicile                       = $row['tel_domicile'];
            if(!empty($row['tel_mobile'])) $leadauto->tel_mobile                           = $row['tel_mobile'];
            if(!empty($row['fax'])) $leadauto->fax                                         = $row['fax'];
            if(!empty($row['email'])) $leadauto->email                                     = $row['email'];
            if(!empty($row['profession'])) $leadauto->profession_id                        = $row['profession'];

            //Conducteur principal
            if(!empty($row['conducteur_secondaire'])) $leadauto->conducteursecondaire_id   = $row['conducteur_secondaire'];
            if(!empty($row['type_permi'])) $leadauto->typepermi_id                         = $row['type_permi'];
            if(!empty($row['date_permis'])) $leadauto->date_permis                         = $row['date_permis'];
            if(!empty($row['deja_assure'])) $leadauto->dejaassure_id                       = $row['deja_assure'];

            //Infos vehicule
            if(!empty($row['origine_vehicule'])) $leadauto->origine_vehicule_id            = $row['origine_vehicule'];
            if(!empty($row['etat_vehicule'])) $leadauto->etatvehicule_id                   = $row['etat_vehicule'];
            if(!empty($row['mode_acquisition'])) $leadauto->mode_acquisition_id            = $row['mode_acquisition'];
            if(!empty($row['date_acquisition'])) $leadauto->date_acquisition               = $row['date_acquisition'];
            if(!empty($row['kilometre_parcouru'])) $leadauto->kilometre_parcouru_id        = $row['kilometre_parcouru'];
            if(!empty($row['frequence_utilisation'])) $leadauto->frequenceutilisation_id   = $row['frequence_utilisation'];
            if(!empty($row['titulaire_carte_grise'])) $leadauto->titulaire_carte_grise_id  = $row['titulaire_carte_grise'];

            // informations sinistre
            if(!empty($row['nombre_sinistre'])) $leadauto->nombre_sinistre  = $row['nombre_sinistre'];


            $leadauto->groupepub_provenance_id                           = $idGrpPubProv;
            $leadauto->groupepub_societe_id                              = $idGrpPubSte;
            $leadauto->active                                            = 1;
            
            //on recupere la liste des sinistres ss forme d un tableau et on l 'enregistre ss format json 
            if(!empty($row['nombre_sinistre']) and $row['nombre_sinistre'] > 0)
            {

                $tabDateSinistres              = explode(',', $row['date_sinistre']);
                $leadauto->date_sinistre      = json_encode($tabDateSinistres);

                $tabNatureSinistres            = explode(',', $row['nature_sinistre']);
                $leadauto->nature_sinistre_id = json_encode($tabNatureSinistres);

            }

            //dd(json_encode(explode(',', $row['date_naissance_enf'])));               

            if($leadauto->save()){
                //return '1111-'.$leadauto->save();
            }else{

                return ['row'=> $row , 'valid' => false];           
            }

            //On teste si le client existe deja 
            $clientOrigine  = $this->clientExistant($row);

            //echo "tooot:".$clientOrigine;
            
            //$messages                     = $validator->errors();

            //echo "<pre>".print_r($row).exit("</pre>");

            if(!$clientOrigine){ //Si le client n'existe pas on l'ajoute

                $client                                                       = new Client;
                

                if(!empty($row['nom'])) $client->nom                          = $row['nom'];
                if(!empty($row['prenom'])) $client->prenom                    = $row['prenom'];
                if(!empty($row['civilite'])) $client->civilite                = $row['civilite'];
                if(!empty($row['sexe'])) $client->sexe                        = $row['sexe'];
                if(!empty($row['sit_familiale'])) $client->sit_familiale      = $row['sit_familiale'];
                if(!empty($row['date_naissance'])) $client->date_naissance    = $row['date_naissance'];
                if(!empty($row['adresse'])) $client->adresse                  = $row['adresse'];
                if(!empty($row['code_postal'])) $client->code_postal          = $row['code_postal'];
                if(!empty($row['ville'])) $client->ville                      = $row['ville'];
                if(!empty($row['tel_bureau'])) $client->tel_bureau            = $row['tel_bureau'];
                if(!empty($row['tel_domicile'])) $client->tel_domicile        = $row['tel_domicile'];
                if(!empty($row['tel_mobile'])) $client->tel_mobile            = $row['tel_mobile'];
                if(!empty($row['fax'])) $client->fax                          = $row['fax'];
                if(!empty($row['email'])) $client->email                      = $row['email'];
                if(!empty($row['profession'])) $client->profession_id         = $row['profession'];
                $client->active                                               = 1;  
                $storeclient                                                  = $client->save();


                if($storeclient){
                    //return '1111-'.$leadauto->save();
                }else{

                    return ['row'=> $row , 'valid' => false];           
                }

            }else{

                $client = $clientOrigine;
            }

            //Si le client a une fiche auto
            $prdt                       = Produit::find($produit);

            $ficheExist                 = $this->ficheExistante($client->id,$prdt->slug);

            $doublon                    = 0;

            if($ficheExist){ $doublon   = 1;}


            
                $fiche                          = new Ficheauto;
                //Selectionner le cout du groupe pub du prestataire

                $coutGroupPub                   = Groupepub::find($groupepubId);
                //$dateNaissCarbon                = $this->dateCarbon($row['date_naissance']); 

                if(!empty($row['conducteur_secondaire'])) $fiche->conducteursecondaire_id    = $row['conducteur_secondaire'];
                if(!empty($row['date_permis'])) $fiche->date_permis                          = $row['date_permis'];
                if(!empty($row['type_permi']))  $fiche->typepermi_id                         = $row['type_permi'];
                if(!empty($row['deja_assure'])) $fiche->dejaassure_id                        = $row['deja_assure'];
                if(!empty($row['date_effet']))  $fiche->date_effet                           = $row['date_effet'];

                $fiche->date_insertion          = Carbon::now();
                $fiche->date_situation          = Carbon::now();
                $fiche->groupepub_provenance_id = $idGrpPubProv;
                $fiche->groupepub_societe_id    = $idGrpPubSte;
                $fiche->client_id               = $client->id;
                $fiche->importfile_id           = $importedFile->id;
                $fiche->slug                    = uniqid();
                //$fiche->user_id                 = 41;//dispatch
                $fiche->produit_id              = $prdt->id;// id produit sante 
                $statutId                       = Statut::whereSlug($prdt->slug.'Appel')->value('id');
                //dd($statut);
                $fiche->statut_id               = $statutId;// il faut creer ce statut dans la bd
                $fiche->motif_id                = null;// il faut creer ce motif dans la bd
                $fiche->cout                    = $coutGroupPub->cout;
                $fiche->etat                    = "E";
                $fiche->active                  = 1;
                $fiche->save();

                $numContrat                     = $this->mask(2,$produit).$this->mask(7,$fiche->id);
                $fiche->num_fiche               = $numContrat;
                $fiche->leadauto_id             = $leadauto->id;
                // $fiche->dispatchable_id         = Auth::user()->courtier_id;
                // $fiche->dispatchable_type       = 'courtier';
                $fiche->doublon                 = $doublon;
                $storefiche                     = $fiche->save();
                 //dd($storefiche); 


                // Enregistrer les traces de l insertion

                $idUserDisp     = User::where('login', 'Dispatch')->value('id');
                $idAction       = Action::where('slug','IFI')->value('id');

                $tabInfoTrace   = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'observation' => null, 'motif' => null, 'idStatut' => $statutId,'user_id' => $idUserDisp, 'equipe_user_id' => null, 'tracable_id' => Auth::user()->courtier_id, 'tracable_type' => 'courtier'];
                event(new EventTracesAuto($tabInfoTrace));

                //Dispatching automatique ou manuel (les fiches restent au panier du courtier)

                if($storefiche)
                {

                    if($dispatchingAuto)//Dispatching auto
                    {
                        dd($dispatchingAuto);
                        //$idUserDisp         = User::where('login', 'Dispatch')->value('id');

                        $ficheController    = new FicheController();

                        $infosDestination   = $ficheController->dispatching($groupepubId, $prdt->id, $fiche->id, $idUserDisp, $prdt->slug, $statutId);

                        //$infosDestination   = $this->dispatching($groupe->id, $produit->id, $fiche->id, $idUserDisp, $produit->slug, $idStatut);

                        if($infosDestination['id']){

                            $fiche->dispatchable_id     = $infosDestination['id'];
                            $fiche->dispatchable_type   = $infosDestination['table'];  

                            if(isset($infosDestination['idUserEquipe'])){

                                $fiche->equipe_user_id  = $infosDestination['idUserEquipe'];
                            }   

                        }else{

                            //return json_encode(['status' => 0, 'message'=>'Erreur d insertion numero : 4.']);            
                        }

                        //Enregistrer les traces de l insertion

                        $idAction       = Action::where('slug','DAI')->value('id');

                        $tabInfoTrace   = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'observation' => null, 'motif' => null, 'idStatut' => $statutId,'user_id' => $idUserDisp, 'equipe_user_id' => null, 'tracable_id' => $fiche->dispatchable_id, 'tracable_type' => $fiche->dispatchable_type];
                        event(new EventTracesAuto($tabInfoTrace));


                        //Envoyer notification au conseiller ou responsable en question

                        $notif          = Notification::whereSlug('LEADDISPATCH')->first();

                        if(isset($infosDestination['idUserEquipe'])){

                            $userNotif      = Equipeuser::find($infosDestination['idUserEquipe'])->user()->first(); 

                        }else{

                            $className      = "App\\".ucfirst($infosDestination['table']);                    
                            $userNotif      = $className::find($infosDestination['id'])->responsable();
                        }

                        if($userNotif){

                            $idUserNotif    = $userNotif->id;
                            $linkNotif      = url($userNotif->profile->slug.'/leads/'.$statutId);

                        }else{

                            $idUserNotif    = "";
                            $linkNotif      = "";                    
                        }

                        $description        = "Vous avez reçu une fiche ".$prdt->libelle." numéro : ".$fiche->num_fiche.".";
                        
                        $notification       = [
                            'user_id'         => $idUserNotif,
                            'notification_id' => $notif->id,
                            'notifiable_id'   => $fiche->id,
                            'notifiable_type' => $prdt->table_produit,
                            'rappel_time'     => null,
                            'link'            => null,
                            'type'            => 'dispatch',
                            'description'     => $description,
                            'link'            => $linkNotif
                        ];

                        event(new EventNotifications($notification));

                    }
                    else //Dispatching manuel
                    {
                        $fiche->dispatchable_id         = Auth::user()->courtier_id;
                        $fiche->dispatchable_type       = 'courtier';
                        $fiche->is_dispatched           = 1;
                    }

                    
                }


                //$fiche->save();




            if($storefiche)
            {
                $vehicule                       = new Vehicule;

                if(!empty($row['origine_vehicule'])) $vehicule->origine_vehicule_id            = $row['origine_vehicule'];
                if(!empty($row['etat_vehicule'])) $vehicule->etatvehicule_id                   = $row['etat_vehicule'];
                if(!empty($row['mode_acquisition'])) $vehicule->mode_acquisition_id            = $row['mode_acquisition'];
                if(!empty($row['date_acquisition'])) $vehicule->date_acquisition               = $row['date_acquisition'];
                if(!empty($row['kilometre_parcouru'])) $vehicule->kilometre_parcouru_id        = $row['kilometre_parcouru'];
                if(!empty($row['frequence_utilisation'])) $vehicule->frequenceutilisation_id   = $row['frequence_utilisation'];
                if(!empty($row['titulaire_carte_grise'])) $vehicule->titulaire_carte_grise_id  = $row['titulaire_carte_grise'];

                if($vehicule->save())
                {

                }
                else
                {
                    return ['row'=> $row , 'valid' => false];           
                }

            }
            else
            {
                return ['row'=> $row , 'valid' => false];           
            }


            $fiche->vehicule_id         = $vehicule->id;
            $fiche->save();


            // Inserer dans la table sinistre
            if(!empty($row['date_sinistre'])){
 
              if(count($tabDateSinistres)>0)
              {  
                $i                                 = 0;

                foreach($tabDateSinistres as $tabDateSinistre){
                                        
                    ${'sinistre'.$i}                        = new Sinistre;
                    ${'sinistre'.$i}->date_sinistre         = $tabDateSinistre;
                    ${'sinistre'.$i}->nature_sinistre_id    = ($tabNatureSinistres[$i] ? $tabNatureSinistres[$i] : "");
                    ${'sinistre'.$i}->ficheauto_id          = $fiche->id;
                    

                    if(${'sinistre'.$i}->save()){

                    }else{

                        return ['row'=> $row , 'valid' => false];            
                    } 

                    $i++;  
                }
              }
            }
             

            $leadauto->doublon = $doublon;
            $leadauto->save();

            $this->incrementClientProduit($client->id, $produit);

            return ['row'=> $row , 'valid' => true];
            

            //echo "fiches uploaded !!";

            //return true;

        }
        else
        {
            //dd($validator->errors());

            //echo "error uploaded !!";
            //$this->fichesErronees[] = $row;

            //Inserer la fiche erronée dans le fichier excel des fiches non valides


            // Excel::load($OriginalFilePath."/".$errorLeadsFileName,function($reader) use($row){

            //  //echo $temp; 

            //  //$sheet = $reader->getActiveSheet();
                
            //  //$reader->sheet('feuille 1',function($sheet) use ($row)
      //           //$reader->each(function($sheet) use ($row)
      //           $reader->sheet('feuille 1',function($sheet) use($row)               
               //  {
      //               //dd($sheet);
               //      //$sheet->appendRow($row);
               //      //echo $IncremNotOk."<br>";

               //      //echo "error : <pre>".print_r($row)."</pre>";
      //               //dd($row);

               //      //$sheet->prependRow(2, $row);
               //  });

                


            // })->store('csv',$OriginalFilePath);

      //       array_push($this->errorRowTab,$row);
            // $this->nbreErrone ++;

            return ['row'=> $row , 'valid' => false];



            //return false;
        }


    }


    public function stockOriginalLeadsFile($leads,$prestataire,$idGrpPubProv,$idGrpPubSte,$produit)
    {

    	//Get product libelle
    	//$produit   = 8;

    	//echo "produit :".$produit."<br>";

    	                      $libelleProduit   = Produit::find($produit);

    	                         //echo "produit :".$libelleProduit->libelle."<br>";
    	                         //echo '<pre>', print_r($libelleProduit), exit('</pre>');
 

    													 
    	//echo "produit :".$libelleProduit->libelle."<br>";
    	
    	$dateNow = Carbon::now();
    	//echo $dateNow;
    	$extension   							= $leads->getClientOriginalExtension();
    	$fileName                               = "original_".$dateNow.".".$extension;
    	$path        							= "upload/prestataires/prestataire_".$prestataire."/imported_leads/".$libelleProduit->libelle;

    	//echo "path :".$path."<br>";
    	//stocker le fichier
    	$leads->move($path,$fileName);
    	//Inserer le fichier dans la bd
    	$importedFile  		 					= new Importfile;
    	$importedFile->nom_fichier_original     = $fileName;
    	$importedFile->chemin_fichier_original  = $path;
        $importedFile->groupepub_provenance_id  = $idGrpPubProv;
        $importedFile->groupepub_societe_id     = $idGrpPubSte;
    	$importedFile->produit_id 	            = $produit;
    	$importedFile->active                   = 1;
    	$importedFile->save();

    	return $importedFile;
    	

    }

    //Creer le fichier des leads sante valides
    public function createImportedLeadsFileSante($importedFile,$validRowTab)
    {
    	//Inserer le fichier dans la BD

    	//$importedFile  		 					= Importfile::find($idOriginalFile);
    	$OriginalFileName                       = $importedFile->nom_fichier_original;
    	$OriginalFilePath                       = $importedFile->chemin_fichier_original;

    	//file name without extension
    	//echo $OriginalFileName;
    	//echo "<br>";
    	$fileNameValide                         = "valide_".substr($OriginalFileName, 9,-4);
    	//echo $fileNameValide;
    	$importedFile->nom_fichier_valide   	= $fileNameValide.".csv";
    	$importedFile->save();

    	Excel::create($fileNameValide ,function($excel) use($validRowTab){

    		$excel->sheet('feuille 1',function($sheet) use($validRowTab){

    			// Manipulate first row
				$sheet->rows($validRowTab);

    			//$sheet->fromArray($export);
    		});
    	})->store('csv',$OriginalFilePath);

    }

    //Creer le fichier des leads obseques valides
    public function createImportedLeadsFileObseques($importedFile,$validRowTab)
    {
    	//Inserer le fichier dans la BD

    	//$importedFile  		 					= Importfile::find($idOriginalFile);
    	$OriginalFileName                       = $importedFile->nom_fichier_original;
    	$OriginalFilePath                       = $importedFile->chemin_fichier_original;

    	//file name without extension
    	//echo $OriginalFileName;
    	//echo "<br>";
    	$fileNameValide                         = "valide_".substr($OriginalFileName, 9,-4);
    	//echo $fileNameValide;
    	$importedFile->nom_fichier_valide   	= $fileNameValide.".csv";
    	$importedFile->save();

    	Excel::create($fileNameValide ,function($excel) use($validRowTab){

    		$excel->sheet('feuille 1',function($sheet) use($validRowTab){

    			// Manipulate first row
				$sheet->rows($validRowTab);

    			//$sheet->fromArray($export);
    		});
    	})->store('csv',$OriginalFilePath);

    }

    //Creer le fichier des leads non valides
    public function createImportedErrorLeadsFileSante($importedFile,$errorRowTab)
    {
    	//Inserer le fichier dans la BD

    	//$importedFile  		 					= Importfile::find($idOriginalFile);
    	$OriginalFileName                       = $importedFile->nom_fichier_original;
    	$OriginalFilePath                       = $importedFile->chemin_fichier_original;

    	//file name without extension
    	$fileNameErrone                         = "errone_".substr($OriginalFileName, 9,-4);

    	$importedFile->nom_fichier_errone    	= $fileNameErrone.".csv";
    	$importedFile->save();

    	Excel::create($fileNameErrone ,function($excel) use($errorRowTab){

    		$excel->sheet('feuille 1',function($sheet) use($errorRowTab){

    			// Manipulate first row
				// $sheet->row(1, array(
				//      'nom', 'prenom', 'civilite', 'sexe', 'sit_familiale', 'date_naissance', 'adresse', 'code_postal', 'ville', 'tel_bureau', 'tel_domicile', 'tel_mobile', 'fax', 'email', 'profession', 'regime', 'date_effet', 'regime_c', 'sexe_c', 'date_naissance_c', 'date_naissance_enf'
				// ));
                $sheet->rows($errorRowTab);

    			//$sheet->fromArray($export);
    		});
    	})->store('csv',$OriginalFilePath);
    }

    //Creer le fichier des leads non valides
    public function createImportedErrorLeadsFileObseques($importedFile,$errorRowTab)
    {
    	//Inserer le fichier dans la BD

    	//$importedFile  		 					= Importfile::find($idOriginalFile);
    	$OriginalFileName                       = $importedFile->nom_fichier_original;
    	$OriginalFilePath                       = $importedFile->chemin_fichier_original;

    	//file name without extension
    	$fileNameErrone                         = "errone_".substr($OriginalFileName, 9,-4);

    	$importedFile->nom_fichier_errone    	= $fileNameErrone.".csv";
    	$importedFile->save();

    	Excel::create($fileNameErrone ,function($excel) use($errorRowTab){

    		$excel->sheet('feuille 1',function($sheet) use($errorRowTab){

    			// Manipulate first row
				// $sheet->row(1, array(
				//      'nom', 'prenom', 'civilite', 'sexe', 'sit_familiale', 'date_naissance', 'adresse', 'code_postal', 'ville', 'tel_bureau', 'tel_domicile', 'tel_mobile', 'fax', 'email', 'profession', 'regime', 'date_effet', 'capital'
				// ));
                $sheet->rows($errorRowTab);

    			//$sheet->fromArray($export);
    		});
    	})->store('csv',$OriginalFilePath);
    }


    //fonction qui retourne une valeur etendue dans n bits
    public function mask($nbrbits, $valeur){

        $nbrBitsValeur  = $nbrbits - strlen($valeur);
        $resultat       = $valeur;

        if($nbrBitsValeur > 0){

            for($i=0; $i<$nbrBitsValeur; $i++){

                $resultat = '0'.$resultat;

            }
        }

        return $resultat;
    }

    public function etatFiche($id){

        $fiche = Fichesante::find($id);

        if($fiche->active) $fiche->active = 0;
        else $fiche->active = 1;

        if($fiche->save()){

            return $data = [
                "msg"   => "opération éfectuée avec succès."
            ];
        }else{

            return $data = [
                "msg"   => "opération échouée !"
            ];
        }
    }


    //verifier si le client existe deja

    public function clientExistant($infofiche){

        $listTel    = [trim($infofiche['tel_bureau']), trim($infofiche['tel_domicile']), trim($infofiche['tel_mobile'])];
        $listTel    = array_filter($listTel);

        $CltExist   = Client::Where(function ($query) use ($listTel){

                            $query->whereIn('tel_bureau', $listTel)
                                    ->orWhereIn('tel_domicile', $listTel)
                                    ->orWhereIn('tel_mobile', $listTel);

                            })->orWhere(function ($query) use ($infofiche){

                                $query->where('nom', $infofiche['nom'])
                                    ->Where('prenom', $infofiche['prenom'])
                                    ->Where('email', $infofiche['email']);
                            })->first();   

        return $CltExist;   
    }


    public function ficheExistante($idClient, $slugProduit){

        $nomTableFiche  = 'App\Fiche'.$slugProduit;
        $ficheExist     = $nomTableFiche::where("client_id", $idClient)
                            ->where("statut_id", "<", 7)
                            ->first();

        return $ficheExist;
    }
    
    
    public function ficheExistanteObseque($idClient){

        $ficheExist = Ficheobseque::where("client_id", $idClient)
                            ->where("statut_id", "<", 7)
                            ->first();

        return $ficheExist;
    }

    public function incrementClientProduit($idClient, $idProduit){

        $clientProduit = ClientProduit::where("client_id", $idClient)
                            ->where("produit_id", $idProduit)
                            ->first();
                            
        if($clientProduit){
            
            $clientProduit->increment('nombre');  
            
        }else{
            
            $clientProduit              = new ClientProduit;
            $clientProduit->client_id   = $idClient;
            $clientProduit->produit_id  = $idProduit;
            $clientProduit->nombre      = 1;
            $clientProduit->save();
                        
        }

    }

    //date vers objet carbon 
    public function dateCarbon($date){

        $tabDate    = explode('-', $date);
        $dateCarbon = Carbon::create($tabDate[0], $tabDate[1], $tabDate[2], 0);
        return $dateCarbon;
    }

    public function fixChunkDate($date)
    {
        $UNIX_DATE   = ($date - 25569) * 86400;
        $validDate = gmdate("Y-m-d", $UNIX_DATE);
        return $validDate;
    }

    public function fixRowSante($row)
    {
        $fixedRow = [];
        $fixedRow = $row;
        if(!empty($row['nom']))
        $fixedRow['nom']                    = trim($row['nom']);
        if(!empty($row['prenom']))
        $fixedRow['prenom']                 = trim($row['prenom']);
        if(!empty($row['civilite']))
        $fixedRow['civilite']               = trim($row['civilite']);
        if(!empty($row['sexe']))
        $fixedRow['sexe']                   = trim($row['sexe']);
        if(!empty($row['sit_familiale']))
        $fixedRow['sit_familiale']          = trim($row['sit_familiale']);
        if(!empty($row['adresse']))
        $fixedRow['adresse']                = trim($row['adresse']);
        if(!empty($row['code_postal']))
        $fixedRow['code_postal']            = trim($row['code_postal']);
        if(!empty($row['ville']))
        $fixedRow['ville']                  = trim($row['ville']);
        if(!empty($row['tel_bureau']))
        $fixedRow['tel_bureau']             = trim($row['tel_bureau']);
        if(!empty($row['tel_domicile']))
        $fixedRow['tel_domicile']           = trim($row['tel_domicile']);
        if(!empty($row['tel_mobile']))
        $fixedRow['tel_mobile']             = trim($row['tel_mobile']);
        if(!empty($row['tel_domicile']))
        $fixedRow['tel_domicile']           = trim($row['tel_domicile']);
        if(!empty($row['fax']))
        $fixedRow['fax']                    = trim($row['fax']);
        if(!empty($row['email']))
        $fixedRow['email']                  = trim($row['email']);
        if(!empty($row['profession']))
        $fixedRow['profession']             = trim($row['profession']);
        if(!empty($row['regime']))
        $fixedRow['regime']                 = trim($row['regime']);
        if(!empty($row['regime_c']))
        $fixedRow['regime_c']               = trim($row['regime_c']);
        if(!empty($row['sexe_c']))
        $fixedRow['sexe_c']                 = trim($row['sexe_c']);
        if(!empty($row['date_naissance']))
        $fixedRow['date_naissance']         = $this->dateCarbon($row['date_naissance']);
        if(!empty($row['date_effet']))
        $fixedRow['date_effet']             = $this->dateCarbon($row['date_effet']);
        if(!empty($row['date_naissance_c']))
        $fixedRow['date_naissance_c']       = $this->dateCarbon($row['date_naissance_c']); 

        return $fixedRow;
    }

    public function fixRowObseques($row)
    {
        $fixedRow = [];
        $fixedRow = $row;
        if(!empty($row['nom']))
        $fixedRow['nom']                    = trim($row['nom']);
        if(!empty($row['prenom']))
        $fixedRow['prenom']                 = trim($row['prenom']);
        if(!empty($row['civilite']))
        $fixedRow['civilite']               = trim($row['civilite']);
        if(!empty($row['sexe']))
        $fixedRow['sexe']                   = trim($row['sexe']);
        if(!empty($row['sit_familiale']))
        $fixedRow['sit_familiale']          = trim($row['sit_familiale']);
        if(!empty($row['adresse']))
        $fixedRow['adresse']                = trim($row['adresse']);
        if(!empty($row['code_postal']))
        $fixedRow['code_postal']            = trim($row['code_postal']);
        if(!empty($row['ville']))
        $fixedRow['ville']                  = trim($row['ville']);
        if(!empty($row['tel_bureau']))
        $fixedRow['tel_bureau']             = trim($row['tel_bureau']);
        if(!empty($row['tel_domicile']))
        $fixedRow['tel_domicile']           = trim($row['tel_domicile']);
        if(!empty($row['tel_mobile']))
        $fixedRow['tel_mobile']             = trim($row['tel_mobile']);
        if(!empty($row['tel_domicile']))
        $fixedRow['tel_domicile']           = trim($row['tel_domicile']);
        if(!empty($row['fax']))
        $fixedRow['fax']                    = trim($row['fax']);
        if(!empty($row['email']))
        $fixedRow['email']                  = trim($row['email']);
        if(!empty($row['profession']))
        $fixedRow['profession']             = trim($row['profession']);
        if(!empty($row['regime']))
        $fixedRow['regime']                 = trim($row['regime']);
        if(!empty($row['capital']))
        $fixedRow['capital']                = trim($row['capital']);
        if(!empty($row['date_naissance']))
        $fixedRow['date_naissance']         = $this->dateCarbon($row['date_naissance']);
        if(!empty($row['date_effet']))
        $fixedRow['date_effet']             = $this->dateCarbon($row['date_effet']);

        return $fixedRow;
    }

    public function fixRowAuto($row)
    {
        $fixedRow = [];
        $fixedRow = $row;
        if(!empty($row['nom']))
        $fixedRow['nom']                    = trim($row['nom']);
        if(!empty($row['prenom']))
        $fixedRow['prenom']                 = trim($row['prenom']);
        if(!empty($row['civilite']))
        $fixedRow['civilite']               = trim($row['civilite']);
        if(!empty($row['sexe']))
        $fixedRow['sexe']                   = trim($row['sexe']);
        if(!empty($row['sit_familiale']))
        $fixedRow['sit_familiale']          = trim($row['sit_familiale']);
        if(!empty($row['adresse']))
        $fixedRow['adresse']                = trim($row['adresse']);
        if(!empty($row['code_postal']))
        $fixedRow['code_postal']            = trim($row['code_postal']);
        if(!empty($row['ville']))
        $fixedRow['ville']                  = trim($row['ville']);
        if(!empty($row['tel_bureau']))
        $fixedRow['tel_bureau']             = trim($row['tel_bureau']);
        if(!empty($row['tel_domicile']))
        $fixedRow['tel_domicile']           = trim($row['tel_domicile']);
        if(!empty($row['tel_mobile']))
        $fixedRow['tel_mobile']             = trim($row['tel_mobile']);
        if(!empty($row['tel_domicile']))
        $fixedRow['tel_domicile']           = trim($row['tel_domicile']);
        if(!empty($row['fax']))
        $fixedRow['fax']                    = trim($row['fax']);
        if(!empty($row['email']))
        $fixedRow['email']                  = trim($row['email']);
        if(!empty($row['profession']))
        $fixedRow['profession']             = trim($row['profession']);
        if(!empty($row['type_permi']))
        $fixedRow['type_permi']             = trim($row['type_permi']);
        if(!empty($row['deja_assure']))
        $fixedRow['deja_assure']            = trim($row['deja_assure']);
        if(!empty($row['conducteur_secondaire']))
        $fixedRow['conducteur_secondaire']  = trim($row['conducteur_secondaire']);
        if(!empty($row['date_naissance']))
        $fixedRow['date_naissance']         = $this->dateCarbon($row['date_naissance']);
        if(!empty($row['date_effet']))
        $fixedRow['date_effet']             = $this->dateCarbon($row['date_effet']);
        if(!empty($row['date_permis']))
        $fixedRow['date_permis']            = $this->dateCarbon($row['date_permis']);
        if(!empty($row['origine_vehicule']))
        $fixedRow['origine_vehicule']       = trim($row['origine_vehicule']);
        if(!empty($row['etat_vehicule']))
        $fixedRow['etat_vehicule']          = trim($row['etat_vehicule']);
        if(!empty($row['mode_acquisition']))
        $fixedRow['mode_acquisition']       = trim($row['mode_acquisition']);
        if(!empty($row['date_acquisition']))
        $fixedRow['date_acquisition']       = $this->dateCarbon($row['date_acquisition']);
        if(!empty($row['kilometre_parcouru']))
        $fixedRow['kilometre_parcouru']     = trim($row['kilometre_parcouru']);
        if(!empty($row['usage_vehicule']))
        $fixedRow['usage_vehicule']         = trim($row['usage_vehicule']);
        if(!empty($row['frequence_utilisation']))
        $fixedRow['frequence_utilisation']  = trim($row['frequence_utilisation']);
        if(!empty($row['titulaire_carte_grise']))
        $fixedRow['titulaire_carte_grise']  = trim($row['titulaire_carte_grise']); 

        return $fixedRow;
    }
}
