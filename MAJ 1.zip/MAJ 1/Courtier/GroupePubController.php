<?php

namespace App\Http\Controllers\Courtier;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Http\Requests\GroupePubAjoutRequest;

use App\Http\Requests;
use App\Prestataire;
use App\Provenance;
use App\Groupepub;
use App\Produit;
use App\Societe;
use Hash;


class GroupePubController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $idPrestatire   = $request->get('id');

        $prestataire    = Prestataire::find($idPrestatire);
        $groupePubs     = $prestataire->groupepubs;

        //return 1;
        return view('courtiersfiles.prestataire.groupepub.index',['prestataire'=>$prestataire, 'groupePubs'=>$groupePubs]);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $idPrestataire  = $request->get('id');    
        $Produits       = Produit::lists('libelle', 'id');
        $idProduitFirst = $Produits->first();
        $typefiches     = Produit::where('libelle', $idProduitFirst)->first()->typefiche->lists('libelle', 'id');
        $Provenances    = Prestataire::find($idPrestataire)->provenances;
        $societes       = Societe::where('active', 1)->get();
       
        return view("courtiersfiles.prestataire.groupepub.create",["id"=>$idPrestataire, 'produits'=>$Produits, 'provenances'=>$Provenances, 'societes'=>$societes, 'typefiches' => $typefiches]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(GroupePubAjoutRequest $request)
    {
        //return $request->all();
        $groupepub = new Groupepub;
        $groupepub->nom                = $request->get('nom');
        if($request->get('payant'))    
        $groupepub->payant             = 1;
        $groupepub->cout               = $request->get('cout');
        $groupepub->produit_id         = $request->get('produit_id');
        if($request->get('typefiche_id'))
        $groupepub->typefiche_id       = $request->get('typefiche_id');
        $idPrestataire                 = $request->get('id');
        $groupepub->prestataire_id     = $idPrestataire;    

        //$groupepub->save();

        $groupepub->cle                = Hash::make($groupepub->id);
        $groupepub->save();

        $groupepub->provenances()->attach($request->get('provenances'));
        $groupepub->societes()->attach($request->get('societes'));

        return redirect("courtier/groupepub?id=".$idPrestataire);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $groupepub      = Groupepub::find($id);

        return view("courtiersfiles.prestataire.groupepub.show",["groupepub"=>$groupepub]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $groupepub      = Groupepub::find($id);
        //return $groupepub->provenances()->lists('provenance_id');
        $Produits       = Produit::lists('libelle', 'id');
        $typefiches     = Produit::find($groupepub->produit_id)->typefiche->lists('libelle', 'id');        
        $Provenances    = Prestataire::find($groupepub->prestataire_id)->provenances;
        $societes       = Societe::where('active', 1)->get();

        return view("courtiersfiles.prestataire.groupepub.edit",["groupepub"=>$groupepub, 'produits'=>$Produits, 'provenances'=>$Provenances, 'societes'=>$societes, 'typefiches'=>$typefiches]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(GroupePubAjoutRequest $request, $id)
    {
        //return $request->all();
        $groupepub                      = Groupepub::find($id);
        $groupepub->nom                 = $request->get('nom');
        if($request->get('payant'))     
        $groupepub->payant              = 1;
        $groupepub->cout                = $request->get('cout');
        $groupepub->produit_id          = $request->get('produit_id');
        if($request->get('typefiche_id'))
        $groupepub->typefiche_id       = $request->get('typefiche_id');

        $groupepub->save();

        $groupepub->provenances()->sync($request->get('provenances'));
        $groupepub->societes()->sync($request->get('societes'));

        return redirect("courtier/groupepub?id=".$groupepub->prestataire_id);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function etatGroupePub($id){

        $groupepub = Groupepub::find($id);

        if($groupepub->active){

            $groupepub->active = 0;
            $msg = "groupe publicitaire désactivé.";

        }else{

            $groupepub->active = 1;
            $msg = "groupe publicitaire activé.";
        } 

        if($groupepub->save()){

            return $data = ["resultat" => "success", "msg" => $msg, "titre" => "opération éfectuée"];
        }else{

            return $data = ["resultat" => "error", "msg" => $msg, "titre" => "opération échouée !"];
        }
    }

    public function genererNouvelleCle($id){
        //return $id;
        $groupepub          = Groupepub::find($id);
        $groupepub->cle     = Hash::make($groupepub->id);

        if($groupepub->save()){

            return $data = ["resultat" => 1, "cle" => $groupepub->cle];
            
        }else{

            return $data = ["resultat" => 0, "cle" => $groupepub->cle];
        }
    }


    public function loadTypeFiche(Request $request){

        $idProduit      = $request->get('idProduit');   
        $typefiches     = Produit::find($idProduit)->typefiche()->where('typefiches.active', 1)->lists('id', 'libelle');
        return json_encode($typefiches);
    }
}
