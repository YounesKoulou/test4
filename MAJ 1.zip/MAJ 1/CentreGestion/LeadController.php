<?php

namespace App\Http\Controllers\CentreGestion;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Controllers\Client\SouscriptionController;
use App\Http\Controllers\Client\SouscriptionObsequeController;
use App\Http\Controllers\SettingController;

use App\Http\Requests;


use App\Events\EventTracesObseque;
use App\Events\EventTracesSante;

use App\Events\EventStatutObseque;
use App\Events\EventStatutSante;
use App\Events\EventValidationCieContratSante;

use App\Events\EventNotifications;
use App\Events\EventCreateProcessesLead;
use App\Events\EventChangeStateProcessLead;

use App\Http\Requests\EditLeadSanteRequest;
use App\Http\Requests\EditLeadObsequeRequest;
use App\Http\Requests\DuplicateLeadSanteRequest;
use App\Http\Requests\DuplicateLeadObsequeRequest;
use App\Http\Requests\GetHistoryFicheRequest;
use App\Http\Requests\GetCommentaireFicheRequest;
use App\Http\Requests\AddCommentaireFicheRequest;
use App\Http\Requests\SaveInfoClientRequest;
use App\Http\Requests\ReaffectationFicheRequest;
use App\Http\Requests\DocumentRequest;
use Illuminate\Support\Facades\Input;

use App\User;
use App\Fichesante;
use App\Ficheobseque;
use App\Produit;
use App\Groupeproduit;
use App\Groupestatut;
use App\Statut;
use App\Client;
use App\Enfant;
use App\Conjoint;
use App\Saregime;
use App\Statutaction;
use App\Documentfiche;
use App\ClientProduit;
use App\Commentaire;
use App\Proposition;
use App\Informationbancaire;
use App\Modepaiement;
use App\Typepaiement;
use App\Prelevement;
use App\Equipe;
use App\Groupemotif;
use App\Site;
use App\Equipeuser;
use App\Parametre;
use App\Action;
use App\Sagarantie;
use App\Sacompagnie;
use App\Obgarantie;
use App\Obgamme;
use App\Notification;
use App\Profession;

use Auth;
use DB;
use File;
use Session;
use Carbon\Carbon;
use Mail;
use mikehaertl\pdftk\Pdf;

class LeadController extends Controller
{


    public function addPolice(Request $request) {


        $statut = [];

        try{

            if($request->has('numPolice')){

                $numPolice = $request->get('numPolice');
                $numFiche  = $request->get('ficheNum');
                $prdSlug   = $request->get('prdSlug');

                try{

                    $produit = Produit::whereSlug($prdSlug)->first();

                    $className = "App\Fiche".$produit->slug;

                    try{

                        $userInfo = $this->userInfo();
                        
                        $fiche    = $className::where("num_fiche", $numFiche)->first();

                        $statut   = $fiche->statut;

                        $fiche->num_police = $numPolice;

                        $client      = $fiche->client;
                        
                        $ficheStatut = $fiche->statut->slug;

                        $slugPrd = $produit->slug;

                        if( $ficheStatut == $slugPrd.'ContratDepot' ){

                            $statutSlug = $slugPrd.'Client';

                            $statut = Statut::whereSlug($statutSlug)->first();

                            $fiche->statut_id      = $statut->id;

                            $fiche->date_situation = Carbon::now();

                        }else if( $ficheStatut == $slugPrd.'Client' ){

                            $fiche->date_situation = Carbon::now();

                        }

                        if($fiche->save()){

                            $user = [];

                            if($fiche->equipe_user_id){

                                $user = $fiche->affectedUser($fiche->equipe_user_id);

                            }else{

                                $user = $fiche->dispatchable->responsable();

                            }

                            Mail::send('emails.validation_contrat', ['user' => $user, 'client' => $client, 'fiche' => $fiche], function ($m) use ($client, $user)  {

                                $m->from($user->courtier->email, $user->courtier->nom);

                                $m->to($client->email, $client->nom)->subject('Validation du contrat');

                            });

                            $idAction     = Action::whereSlug('ANP')->value('id');
                            $observation  = "N° Police: ".$numPolice;

                            $tabInfoTrace = [
                                            'idAction'       => $idAction,
                                            'idFiche'        => $fiche->id,
                                            'idStatut'       => $fiche->statut_id,
                                            'equipe_user_id' => $userInfo['equipe_user_id'],
                                            'tracable_id'    => $userInfo['tracable_id'], 
                                            'tracable_type'  => $userInfo['tracable_type'], 
                                            'observation'    => $observation,
                                            'motif'          => null
                                        ];
                            $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
                            event(new $event($tabInfoTrace));

                            // Debut Notification
                            if( $fiche->statut->slug == $slugPrd.'ContratDepot' ){

                                $userList = [];

                                if($fiche->equipe_user_id){

                                    array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                                    
                                    if($fiche->dispatchable->responsable()){
                                        array_push( $userList, $fiche->dispatchable->responsable() );
                                    }

                                }else{

                                    if($fiche->dispatchable->responsable()){
                                        array_push( $userList, $fiche->dispatchable->responsable() );
                                    }

                                }

                                $notif = Notification::whereSlug('CONTRATSANTEVAL')->first();
                                
                                $notification = [
                                    'user_id'         => null,
                                    'notification_id' => $notif->id,
                                    'notifiable_id'   => $fiche->id,
                                    'notifiable_type' => $fiche->produit->table_produit,
                                    'rappel_time'     => null,
                                    'link'            => null,
                                    'type'            => 'lead',
                                    'description'     => $observation
                                ];

                                foreach ($userList as $usr) {

                                    $notification['user_id'] = $usr->id;
                                    $notification['link']    = url($usr->profile->slug.'/leads/'.$fiche->produit->slug.'/'.$fiche->slug);
                                   
                                    event(new EventNotifications($notification));

                                }
                                
                            }
                            // Fin Notification
                            

                            $tabInfosValidCieContrat = ['idFiche' => $fiche->id];
                            
                            if($fiche->equipe_user_id){

                                event(new EventValidationCieContratSante($tabInfosValidCieContrat));

                            }

                        }


                        return [
                            'success' => true,
                            'fiche'   => $fiche->slug,
                            'statut'  => $statut,
                            'message' => 'Le Numéro De Police A',
                        ];

                    }catch(\Exception $e){

                        return [
                            'success' => false,
                            'message' => 'Problème D\'Ajout De N° De Police !!!',
                        ];

                    }

                }catch(\Exception $e){

                    return [
                        'success' => false,
                        'message' => 'Problème D\'Ajout De N° De Police !!!',
                    ];

                }
                
            }else{

                return [
                    'success' => false,
                    'message' => "SVP, Entrez Le Numéro De Police !!!",
                ];

            }

        }catch(\Exception $e){

        }


    }

    public function printDocs($id)
    {
        $fiche  = Fichesante::find($id);
        return view('partage.printDocs',['fiche' => $fiche]);
    }

    public function tracePrintDocs($id,Request $request)
    {
        //return $request->all();
        $idFiche                 = $id;
        $prdSlug                 = $request->get('prdSlug');
        
        $produit                 = Produit::whereSlug($prdSlug)->first();
        $className               = "App\Fiche".$produit->slug;

        $userInfo                = $this->userInfo();                
        $fiche                   = $className::where("id", $idFiche)->first();

        $infosImpression         = $fiche->infos_impression;

        $collectInfosImpression  = collect(json_decode($infosImpression));

        $collectInfosImpression['is_printed'] = 2;
        $collectInfosImpression['date_impression'] = Carbon::now();

        //$infosImpression['is_printed'] = 1;
        //$infosImpression['date_impression'] = Carbon::now();
        $fiche->infos_impression = $collectInfosImpression->toJson();
        //$fiche->is_printed  = 1;
        $statutSlug              = $prdSlug.'Client';
        $statut                  = Statut::whereSlug($statutSlug)->first();
        $fiche->statut_id        = $statut->id;
        
        
        $fiche->save();


        $idAction           = Action::whereSlug('ID')->value('id');
        $observation        = "";

        $tabInfoTrace = [
                        'idAction'       => $idAction,
                        'idFiche'        => $fiche->id,
                        'idStatut'       => $fiche->statut_id,
                        'equipe_user_id' => $userInfo['equipe_user_id'],
                        'tracable_id'    => $userInfo['tracable_id'], 
                        'tracable_type'  => $userInfo['tracable_type'], 
                        'observation'    => $observation,
                        'motif'          => null
                        ];
        $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
        event(new $event($tabInfoTrace));

        return [
            'success' => true,
            'fiche'   => $fiche->slug,
            'statut'  => $fiche->statut,
            'message' => 'Impression effectuée',
        ];
    }

    /**
     * save les modifications sur la fiche sante
     */
    public function editClientSante(EditLeadSanteRequest $request) {

        $userInfo = $this->userInfo();

        $conjointId   = 0;
        $enfantIds    = [];
        $ficheId      = $request->get("ficheId");

        $fiche = Fichesante::find($ficheId);
            $fiche->date_effet  = $request->get('date_effet');
            $fiche->saregime_id = $request->get('saregime_id');
        
        
        if($fiche->save()){

            $observation  = '' ;
            $actionSlug   = 'GF';

            if($request->get('etatSave')){
                $observation  = 'Type: '.$fiche->statut->groupeStatus->libelle ;
                $actionSlug   = 'MI';
            }else{
                $observation  = null ;
                $actionSlug   = 'GF';
            }

            $idAction     = Action::whereSlug($actionSlug)->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));
        }

        $clientId = $request->get('clientId');
        
        $client = Client::find($clientId);
            $client->nom            = $request->get('nom');
            $client->prenom         = $request->get('prenom');
            $client->civilite       = $request->get('civilite');
            $client->sexe           = $request->get('sexe');
            $client->sit_familiale  = $request->get('sit_familiale');
            $client->date_naissance = $request->get('date_naissance');
            $client->email          = $request->get('email');
            $client->email_pro      = $request->get('email_pro');
            $client->profession_id     = $request->get('profession');
            $client->ville          = $request->get('ville');
            $client->adresse        = $request->get('adresse');
            $client->tel_mobile     = $request->get('tel_mobile');
            $client->code_postal    = $request->get('code_postal');
            //$client->saregime_id    = $request->get('saregime_id');
        $client->save();

        if($request->has('has_conjoint')){

            $conjoint_id = $request->get('conjoint_id');

            if($conjoint_id == 0){
                $conjoint = new Conjoint;
                    $conjoint->nom            = $request->get('conjoint_nom');
                    $conjoint->prenom         = $request->get('conjoint_prenom');
                    $conjoint->civilite       = $request->get('conjoint_civilite');
                    $conjoint->sexe           = $request->get('conjoint_sexe');
                    $conjoint->date_naissance = $request->get('conjoint_date_naissance');
                    $conjoint->sit_familiale  = $request->get('conjoint_sit_familiale');
                    $conjoint->saregime_id    = $request->get('conjoint_saregime_id');
                    $conjoint->fichesante_id  = $ficheId;

                if($conjoint->save()){
                    $idAction     = Action::whereSlug('AC')->value('id');
                    $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => 'ID conjoint: '.$conjoint->id, 'motif' => null];
                    event(new EventTracesSante($tabInfoTrace));
                }
                
            }else{
                $conjoint = Conjoint::find($conjoint_id);
                    $conjoint->nom            = $request->get('conjoint_nom');
                    $conjoint->prenom         = $request->get('conjoint_prenom');
                    $conjoint->civilite       = $request->get('conjoint_civilite');
                    $conjoint->sexe           = $request->get('conjoint_sexe');
                    $conjoint->date_naissance = $request->get('conjoint_date_naissance');
                    $conjoint->sit_familiale  = $request->get('conjoint_sit_familiale');
                    $conjoint->fichesante_id  = $ficheId;
                    $conjoint->saregime_id    = $request->get('conjoint_saregime_id');
                $conjoint->save();
            }

            $conjointId = $conjoint->id;

         }

        if($request->has('enfant')){

            $enfants = $request->get('enfant');
            
            $nbrEnfants = 0;

            foreach ($enfants as $enfant) {

                $enfant_id            = $enfant['id'];
                $enfant_sexe          = $enfant['sexe'];
                $enfant_nom           =  $enfant['nom'];
                $enfant_prenom        = $enfant['prenom'];
                $enfant_dateNaissance = $enfant['date_naissance'];
                $enfant_ayantDroit    = $enfant['ayant_droit'];

                if($enfant_id == 0){
                    $enfant = new Enfant;
                        $enfant->sexe           = $enfant_sexe;
                        $enfant->nom            = $enfant_nom;
                        $enfant->prenom         = $enfant_prenom;
                        $enfant->date_naissance = Carbon::createFromFormat('d/m/Y', $enfant_dateNaissance)->format('Y-m-d');
                        $enfant->ayant_droit    = $enfant_ayantDroit;
                        $enfant->fichesante_id  = $ficheId;
                    $enfant->save();

                    $nbrEnfants++;
                
                }else{
                    $enfant = Enfant::find($enfant_id);
                        $enfant->sexe           = $enfant_sexe;
                        $enfant->nom            = $enfant_nom;
                        $enfant->prenom         = $enfant_prenom;
                        $enfant->date_naissance = Carbon::createFromFormat('d/m/Y', $enfant_dateNaissance)->format('Y-m-d');
                        $enfant->ayant_droit    = $enfant_ayantDroit;
                        $enfant->ayant_droit    = $enfant_ayantDroit;
                        $enfant->fichesante_id  = $ficheId;
                    $enfant->save();
                }


                array_push($enfantIds, $enfant->id);

            }

            if($nbrEnfants>0){
                $idAction     = Action::whereSlug('AE')->value('id');
                $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $nbrEnfants." ".str_plural('enfant', $nbrEnfants)." ".str_plural('ajouté',$nbrEnfants), 'motif' => null];
                event(new EventTracesSante($tabInfoTrace));
            }

        }

        return [
            'success'      => true,
            'message'      => 'Les Modifications ont été sauvegardées.',
            'conjointId'   => $conjointId,
            // 'enfantIds'    => $enfantIds,
            'enfants'      => $fiche->enfants,
        ];

    }


    /**
     * save les modifications sur la fiche obseque
     */
    public function editClientObseque(EditLeadObsequeRequest $request) {

        $userInfo = $this->userInfo();

        $ficheId = $request->get("ficheId");

        $clientId = $request->get('clientId');

        $fiche = Ficheobseque::find($ficheId);
            $fiche->date_effet  = $request->get('date_effet');
            $fiche->saregime_id = $request->get('saregime_id');
            $fiche->capital     = $request->get('capital');

        if($fiche->save()){

            $observation  = '' ;
            $actionSlug   = 'GF';

            if($request->get('etatSave')){
                $observation  = 'Type: '.$fiche->statut->groupeStatus->libelle ;
                $actionSlug   = 'MI';
            }else{
                $observation  = null ;
                $actionSlug   = 'GF';
            }
            
            $idAction     = Action::whereSlug($actionSlug)->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'idStatut' => $fiche->statut_id, 'observation' => $observation, 'motif' => null];
            event(new EventTracesObseque($tabInfoTrace));
        }
        
        $client = Client::find($clientId);
            $client->nom            = $request->get('nom');
            $client->prenom         = $request->get('prenom');
            $client->civilite       = $request->get('civilite');
            $client->sexe           = $request->get('sexe');
            $client->sit_familiale  = $request->get('sit_familiale');
            $client->date_naissance = $request->get('date_naissance');
            $client->email          = $request->get('email');
            $client->email_pro      = $request->get('email_pro');
            $client->profession_id     = $request->get('profession');
            $client->ville          = $request->get('ville');
            $client->adresse        = $request->get('adresse');
            $client->tel_mobile     = $request->get('tel_mobile');
            $client->code_postal    = $request->get('code_postal');
            //$client->saregime_id    = $request->get('saregime_id');
        $client->save();

        $fiche = Ficheobseque::find($ficheId);
            $fiche->capital= $request->get('capital');
        $fiche->save();

        return [
            'success'    => true,
            'message'    => 'Les Modifications ont été sauvegardées.',
        ];

    }


    /**
     * supprimer l'enfant
     */
    public function deleteChild(Request $request) {

        $userInfo = $this->userInfo();

        $id = $request->get("id");

        $enfant = Enfant::find($id);

        $fiche = $enfant->fichesante;

        if($enfant->delete()){
            $idAction     = Action::whereSlug('SE')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => ' ID enfant: '.$id, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));

            return "l'enfant a été supprimé";
        }

    }


    /**
     * supprimer le conjoint
     */
    public function deleteConjoint(Request $request) {

        $userInfo = $this->userInfo();

        $id = $request->get("id");

        $conjoint = Conjoint::find($id);

        $fiche = $conjoint->fichesante;

        if($conjoint->delete()){
            $idAction     = Action::whereSlug('SC')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => ' ID conjoint: '.$id, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));

            return "le conjoint a été supprimé";
        }

    }




    /**
     * Recevoir le status de la fiche
     */
    public function getStatut(Request $request){

        $statut_id = $request->get('statutId');
        $fiche_id  = $request->get('ficheId');
        $prd_id    = $request->get('prdId');

        $statut = Statut::find($statut_id);

         $rappel = [];

    
        if($statut_id==2){
            $rappel = $this->lastRappel($fiche_id, $statut_id, $prd_id);
        }

        return [
            'statutId'     => $statut->id,
            'statutLib'    => $statut->libelle,
            'motifs'       => $statut->motifs,
            'rappelActive' => ( ($statut->id==2) ? 1 : 0 ),
            'rappel'       => $rappel,
        ];

    }

    
    /**
     * Recevoir le dernier rappel
     */
    public function lastRappel($fiche_id, $statut_id, $prd_id){

        $produit = Produit::find($prd_id);

        $rappel = Statutaction::where('actionable_id', $fiche_id)
                                ->where('actionable_type', "fiche".$produit->slug."s")
                                ->where('statut_id', $statut_id)
                                ->orderBy('created_at', 'desc')
                                ->first();

        return $rappel;

    }


    /**
     * changer le statut de la fiche
     */
    public function changeStatut(Request $request){

        $userInfo = $this->userInfo();

        $user                          =   Auth::user();
        
        //$produit_id                  = Session::get('produit_id');
        $produit_id                    = $request->get('prdId');
        $produit                       = Produit::find($produit_id);

        $slugPrd = $produit->slug;
        
        $fiche_id                      = $request->get('modalFicheId');
        $statut_id                     = $request->get('modalStatutId');
        
        $statutAction                  = new Statutaction;
        
        $className                     = "App\Fiche".$produit->slug;
        
        $fiche                         = $className::find($fiche_id);

        $oldStatut = $fiche->statut->libelle;

        $statutAction->actionable_type = "fiche".$produit->slug."s";

        $statut = Statut::find($statut_id);

        // if($statut->groupeStatus->slug=='leads'){
        //     $fiche->date_situation = $fiche->date_insertion;
        // }elseif($statut->groupeStatus->slug=='devis'){
        //     $fiche->date_situation = Carbon::now();
        // }elseif($statut->groupeStatus->slug=='contrats'){
        //     $fiche->date_situation = Carbon::now();
        // }

        $fiche->date_situation = Carbon::now();

        $fiche->statut_id              = $statut_id;
        
        $statutAction->complement      = $request->get('action_complement');
        $statutAction->user_id         = $user->id;
        $statutAction->statut_id       = $statut_id;
        $statutAction->actionable_id   = $fiche_id;
        
        if($request->has('modalMotifId')){
            $statutAction->motif_id = $request->get('modalMotifId');
            $fiche->motif_id        = $request->get('modalMotifId');
        }

        $timeRappel = '';

        if($request->has('rappel_date')){
            $statutAction->date_rappel     = $request->get('rappel_date');
            $timeRappel .= " <i class='uk-icon-calendar'></i> ".$request->get('rappel_date');
        }

        if($request->has('rappel_heure')){
            $statutAction->heure_rappel    = $request->get('rappel_heure');
            $timeRappel .= " <i class='uk-icon-clock-o'></i> ".$request->get('rappel_heure');
        }

        // $fiche->save();

        // $statutAction->save();

        if($fiche->save() and $statutAction->save()){

            $idAction     = Action::whereSlug('CS')->value('id');
            $observation  = "<i class='uk-text-danger material-icons'>&#xE14C;</i> ".$oldStatut."<br><i class='uk-text-success material-icons'>&#xE876;</i> ".$statutAction->statut->libelle."<br>".$timeRappel;
            $motif        = $request->has('modalMotifId') ? $request->get('modalMotifId') : null;
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => $motif];
            $event        = 'App\Events\EventTraces'.ucfirst($produit->slug);
            event(new $event($tabInfoTrace));

            if($statut->slug==$slugPrd."Rappel"){

                $userList = [];

                array_push( $userList, $user );

                if($fiche->equipe_user_id){

                    array_push( $userList, $fiche->affectedUser($fiche->equipe_user_id) );
                    array_push( $userList, $fiche->dispatchable->responsable() );

                }else{

                    array_push( $userList, $fiche->dispatchable->responsable() );

                }

                $notif = Notification::whereSlug('LEADRAPPEL')->first();
                
                $notification = [
                    'user_id'         => null,
                    'notification_id' => $notif->id,
                    'notifiable_id'   => $fiche->id,
                    'notifiable_type' => $fiche->produit->table_produit,
                    'rappel_time'     => $request->get('rappel_date') .' '. $request->get('rappel_heure'),
                    'link'            => null,
                    'type'            => 'rappel',
                    'description'     => $request->get('action_complement')
                ];

                foreach ($userList as $usr) {

                    $notification['user_id'] = $usr->id;
                    $notification['link']    = url($usr->profile->slug.'/leads/'.$produit->slug.'/'.$fiche->slug);
                   
                    event(new EventNotifications($notification));

                }

            }

            $info_fiche = [
                            'fiche_id'     => $fiche->id,
                            'prd_slug'     => $fiche->produit->slug
                        ];
                        
            $collection = collect(event(new EventCreateProcessesLead($info_fiche)));
            $processes  = $collection->flatten(1);
            $processes->values()->all();

            return [
                    "success"   => true,
                    "message"   => "Bien ajouté",
                    "statutLib" => $request->get("statutLib"),
                    "processes" => $processes
                ];

        }
 
        
    }


    /**
     * Ajouter un document à une fiche
     */
    public function addDoc(DocumentRequest $request){

        $userInfo = $this->userInfo();

        $produit_id                    = Session::get('produit_id');
        $produit                       = Produit::find($produit_id);

        $doc_id   = $request->get('docId');
        $fiche_id = $request->get('ficheId');
        $doc_file = $request->file('document');
        
        $user     = Auth::user();

        $className = "App\Fiche".$produit->slug;
        
        $fiche    = $className::find($fiche_id);
        $document = Documentfiche::find($doc_id);

        $dir = "upload/documents/".$produit->slug;

        if (!file_exists($dir)) {
            File::makeDirectory($dir);
        }
        
        $directory = $dir."/$fiche_id";

        if (!file_exists($directory)) {
            File::makeDirectory($directory);
        }

        $doc_ext  = $doc_file->getClientOriginalExtension();
        $doc_name = str_slug($document->nom).'-'.date('Y-m-d h:i:s').'.'.$doc_ext;

        $fichier = $doc_file->move($directory,$doc_name);

        $fiche->documentFiche()->detach($doc_id);

        $fiche->documentFiche()->attach($doc_id, ['active' => 1, 'path' => $fichier, 'user_id' => $user->id]);
        
        $idAction     = Action::whereSlug('AD')->value('id');
        $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => "<a href='".asset($fichier)."' target='_blank'>".$document->nom."</a>", 'motif' => null];
        $event = 'App\Events\EventTraces'.ucfirst($produit->slug);
        event(new $event($tabInfoTrace));

        $docFile = $fiche->documentFiche()->where('documentfiche_id', $doc_id)->first();

        if($doc_ext =='pdf'){
            $icon = 'pdf';
        }elseif($doc_ext =='doc' or $doc_ext =='docx'){
            $icon = 'word';
        }else{
            $icon = 'image';
        }

        return [ 
                    "success" => true,
                    "message" => "le document a été ajouté.",
                    "path"    => url($fichier),
                    "user"    => "$user->login ($user->nom $user->prenom)",
                    "date"    => Carbon::parse($docFile->pivot->created_at)->format('d/m/Y H:i:s'),
                    "icon"    => $icon
                ];

    }

    
    /**
     * Dupliquer une fiche santé
     */
    public function duplicateSante(Request $request, $client_id, $fiche_id, $produit_id){
        
        $conjoint     = [];
        $enfants      = [];
        
        $user         = Auth::user();

        $access = 0;
        
        $produitSlug    = $request->segment(5);
        $currentProduit = Produit::whereSlug($produitSlug)->first();
        
        $client         = Client::find($client_id);
        
        $agence         = $user->agence;
        
        $sites          = $agence->sites;
        
        $siteids      = collect($sites->lists('id'));
        
        $equipes        = $agence->equipes;
        
        $equipeIds      = collect($equipes->lists('id'));
        
        if($currentProduit->id == $produit_id){

            $fiche         = Fichesante::find($fiche_id);
            $conjoint      = $fiche->conjoint;
            $enfants       = $fiche->enfants;
            

            if($fiche->equipe_user_id==null){
                return redirect('centregestion/leads/sante/'.$fiche->slug)->with('duplicate_message', 'Le statut de la fiche ne permet pas de la dupliquer!!!');
            }

            if(
                ( $equipeIds->contains($fiche->dispatchable_id) and $fiche->dispatchable_type == 'equipe' )
                or 
                ( $siteIds->contains($fiche->dispatchable_id) and $fiche->dispatchable_type == 'site' ) 
                or
                ( $site->id == $fiche->dispatchable_id and $fiche->dispatchable_type == 'agence' ) 
            ){
                
                $access = 1;

            }


        }else{
            
            $prd       = Produit::find($produit_id);
            $className = "App\Fiche".$prd->slug;
            $fiche1    = $className::find($fiche_id);
            
            // if($fiche1->equipe_user_id==null){
            //     return redirect('gestion/leads/'.$prd->slug.'/'.$fiche1->slug)->with('duplicate_message', 'Le statut de la fiche ne permet pas de la dupliquer!!!');
            // }

            if(
                ( $equipeIds->contains($fiche1->dispatchable_id) and $fiche1->dispatchable_type == 'equipe' )
                or 
                ( $siteIds->contains($fiche1->dispatchable_id) and $fiche->dispatchable_type == 'site' ) 
                or
                ( $site->id == $fiche1->dispatchable_id and $fiche->dispatchable_type == 'agence' ) 
            ){
                
                $access = 1;

            }

        }

        $produit            = Produit::find($currentProduit->id);
        
        $produitIds         = Fichesante::where('client_id',$client->id)
                                            ->groupBy('produit_id')
                                            ->lists('produit_id');
        
        $gpIds              = Produit::whereIn('id',$produitIds)
                                        ->groupBy('groupeproduit_id')
                                        ->lists('groupeproduit_id');
        
        $groupeProduits     = Groupeproduit::whereIn('id',$gpIds)->get();
        
        $regimes            = Saregime::whereActive(1)->get();

        $regimePardefaut    = Saregime::where('code', 'SES')->first();
        
        $groupePrd          = $produit->groupeProduit;
        
        $groupeProduitsList = Groupeproduit::whereActive(1)->with('produits')->get();
        
        $contrats           = Fichesante::getContrats($client->id, $groupePrd->id);
        
        $documents          = Documentfiche::where('produit_id', $produit_id)->get();

        $professions = Profession::whereActive(1)->orderBy('libelle', 'asc')->get();

        return view('shared.produits.duplicate_sante', [
                                    'user'               => $user,
                                    'client'             => $client,
                                    'groupeProduits'     => $groupeProduits,
                                    'regimes'            => $regimes,
                                    'regimePardefaut'    => $regimePardefaut,
                                    'groupeProduitsList' => $groupeProduitsList,
                                    'contrats'           => $contrats,
                                    'documents'          => $documents,
                                    'conjoint'           => $conjoint,
                                    'enfants'            => $enfants,
                                    'currentProduit'     => $currentProduit,
                                    'access'             => $access,
                                    'professions'        => $professions,
                                ]
            );

    }


    /**
     * Dupliquer une fiche obseque
     */
    public function duplicateObseque(Request $request, $client_id, $fiche_id, $produit_id){

        $capital        = 0;
        
        $user           = Auth::user();
        
        $access         = 0;
        
        $produitSlug    = $request->segment(5);
        
        $currentProduit = Produit::whereSlug($produitSlug)->first();
        
        $client         = Client::find($client_id);
        
        $agence         = $user->agence;

        $sites          = $agence->sites;
        
        $siteids        = collect($sites->lists('id'));
        
        $equipes        = $agence->equipes;
        
        $equipeIds      = collect($equipes->lists('id'));

        
        if($currentProduit->id == $produit_id){

            $fiche    = Ficheobseque::find($fiche_id);
            $capital  = $fiche->capital;

            if($fiche->equipe_user_id==null){
                return redirect('centregestion/leads/obseque/'.$fiche->slug)->with('duplicate_message', 'Le statut de la fiche ne permet pas de la dupliquer!!!');
            }

            if(
                ( $equipeIds->contains($fiche->dispatchable_id) and $fiche->dispatchable_type == 'equipe' )
                or 
                ( $siteIds->contains($fiche->dispatchable_id) and $fiche->dispatchable_type == 'site' ) 
                or
                ( $site->id == $fiche->dispatchable_id and $fiche->dispatchable_type == 'agence' ) 
            ){
                
                $access = 1;

            }

        }else{
            
            $prd = Produit::find($produit_id);
            $className = "App\Fiche".$prd->slug;
            $fiche1 = $className::find($fiche_id);

            // if($fiche1->equipe_user_id==null){
            //     return redirect('gestion/leads/'.$prd->slug.'/'.$fiche1->slug)->with('duplicate_message', 'Le statut de la fiche ne permet pas de la dupliquer!!!');
            // }

            if(
                ( $equipeIds->contains($fiche1->dispatchable_id) and $fiche1->dispatchable_type == 'equipe' )
                or 
                ( $siteIds->contains($fiche1->dispatchable_id) and $fiche->dispatchable_type == 'site' ) 
                or
                ( $site->id == $fiche1->dispatchable_id and $fiche->dispatchable_type == 'agence' ) 
            ){
                
                $access = 1;

            }

        }


        $produit            = Produit::find($currentProduit->id);
        
        $produitIds         = Fichesante::where('client_id',$client->id)
                                            ->groupBy('produit_id')
                                            ->lists('produit_id');
        
        $gpIds              = Produit::whereIn('id',$produitIds)
                                        ->groupBy('groupeproduit_id')
                                        ->lists('groupeproduit_id');
        
        $groupeProduits     = Groupeproduit::whereIn('id',$gpIds)->get();
        
        $regimes            = Saregime::whereActive(1)->get();
        
        $groupePrd          = $produit->groupeProduit;
        
        $groupeProduitsList = Groupeproduit::whereActive(1)->with('produits')->get();
        
        $contrats           = Ficheobseque::getContrats($client->id, $groupePrd->id);
        
        $documents          = Documentfiche::where('produit_id', $produit_id)->get();

        $professions = Profession::whereActive(1)->orderBy('libelle', 'asc')->get();
        
        return view('shared.produits.duplicate_obseque', [
                                    'user'               => $user,
                                    'client'             => $client,
                                    'groupeProduits'     => $groupeProduits,
                                    'capital'            => $capital,
                                    'regimes'            => $regimes,
                                    'groupeProduitsList' => $groupeProduitsList,
                                    'contrats'           => $contrats,
                                    'documents'          => $documents,
                                    'currentProduit'     => $currentProduit,
                                    'access'             => $access,
                                    'professions'        => $professions,
                                ]
        );

    }


    /**
     * Créer une fiche santé
     */
    public function newSante(DuplicateLeadSanteRequest $request){

        $userInfo = $this->userInfo();

        $user         = Auth::user();
        
        $conjointId   = 0;
        
        $enfantIds    = [];
        
        $produit      = Produit::whereSlug($request->get('produitSlug'))->first();
        
        $clientId     = $request->get('clientId');

        $statut     = Statut::whereSlug('santeAppel')->first();
        
        $client = Client::find($clientId);
            $client->nom            = $request->get('nom');
            $client->prenom         = $request->get('prenom');
            $client->civilite       = $request->get('civilite');
            $client->sexe           = $request->get('sexe');
            $client->sit_familiale  = $request->get('sit_familiale');
            $client->date_naissance = $request->get('date_naissance');
            $client->email          = $request->get('email');
            $client->email_pro      = $request->get('email_pro');
            $client->profession_id     = $request->get('profession');
            $client->ville          = $request->get('ville');
            $client->adresse        = $request->get('adresse');
            $client->tel_mobile     = $request->get('tel_mobile');
            $client->code_postal    = $request->get('code_postal');
            $client->saregime_id    = $request->get('saregime_id');
        $client->save();

        $fiche = new Fichesante;
            $fiche->client_id               = $client->id;
            $fiche->slug                    = uniqid();
            $fiche->produit_id              = $produit->id;
            $fiche->equipe_user_id          = null;
            $fiche->dispatchable_id         = $user->agence_id;
            $fiche->dispatchable_type       = 'agence';
            $fiche->statut_id               = $statut->id;
            $fiche->groupepub_provenance_id = 1;
            $fiche->active                  = 1;
            $fiche->date_insertion          = Carbon::now()->format('Y-m-d H:i:s');
            $fiche->date_effet              = $request->get('date_effet');
            $fiche->saregime_id             = $request->get('saregime_id');
        if($fiche->save()){

            $srcPrd       = Produit::find($request->get('srcPrd'));
            $srcClass     = "App\Fiche".$srcPrd->slug;
            $srcFiche     = $srcClass::find($request->get('srcFiche'));
            $observation  = "<i class='material-icons'>".$srcPrd->icon."</i> ".$srcPrd->libelle."<br>source: <span class='uk-text-bold'>#".$srcFiche->num_fiche."</span>";
            $idAction     = Action::whereSlug('DF')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));
        }

        $fiche->num_fiche = $this->mask(2,$fiche->produit_id).$this->mask(7,$fiche->id);
        $fiche->save();

        $cltPrd = ClientProduit::firstOrCreate(['client_id' => $client->id, 'produit_id' => $produit->id]);
        $cltPrd->increment('nombre');

        $ficheId = $fiche->id;

        $info_fiche = [
                'fiche_id' => $ficheId,
                'prd_slug' => $produit->slug,
            ];

        event(new EventCreateProcessesLead($info_fiche));

        if($request->has('has_conjoint')){

            $conjoint = new Conjoint;
                $conjoint->nom            = $request->get('conjoint_nom');
                $conjoint->prenom         = $request->get('conjoint_prenom');
                $conjoint->civilite       = $request->get('conjoint_civilite');
                $conjoint->sexe           = $request->get('conjoint_sexe');
                $conjoint->date_naissance = $request->get('conjoint_date_naissance');
                $conjoint->sit_familiale  = $request->get('conjoint_sit_familiale');
                $conjoint->fichesante_id  = $ficheId;
                $conjoint->saregime_id    = $request->get('conjoint_saregime_id');
            $conjoint->save();

            $conjointId = $conjoint->id;

         }

        if($request->has('enfant')){

            $enfants = $request->get('enfant');

            foreach ($enfants as $enfant) {

                $enfant_sexe          = $enfant['sexe'];
                $enfant_nom           =  $enfant['nom'];
                $enfant_prenom        = $enfant['prenom'];
                $enfant_dateNaissance = $enfant['date_naissance'];
                $enfant_ayantDroit    = $enfant['ayant_droit'];

                $enfant = new Enfant;
                    $enfant->sexe           = $enfant_sexe;
                    $enfant->nom            = $enfant_nom;
                    $enfant->prenom         = $enfant_prenom;
                    $enfant->date_naissance = Carbon::createFromFormat('d/m/Y', $enfant_dateNaissance)->format('Y-m-d');
                    $enfant->ayant_droit    = $enfant_ayantDroit;
                    $enfant->fichesante_id  = $ficheId;
                $enfant->save();

            }

        }

        $url = url('centregestion/leads/sante/'.$fiche->slug);

        return [
            'success' => true,
            'message' => 'La fiche a été dupliquée',
            'url'     => $url

        ];

    }


    /**
     * Créer une fiche obseque
     */
    public function newObseque(DuplicateLeadObsequeRequest $request){

        $userInfo = $this->userInfo();

        $user         = Auth::user();
        $produit      = Produit::whereSlug($request->get('produitSlug'))->first();
        
        $clientId     = $request->get('clientId');

        $statut       = Statut::whereSlug('obsequeAppel')->first();
        
        $client = Client::find($clientId);
            $client->nom            = $request->get('nom');
            $client->prenom         = $request->get('prenom');
            $client->civilite       = $request->get('civilite');
            $client->sexe           = $request->get('sexe');
            $client->sit_familiale  = $request->get('sit_familiale');
            $client->date_naissance = $request->get('date_naissance');
            $client->email          = $request->get('email');
            $client->email_pro      = $request->get('email_pro');
            $client->profession_id     = $request->get('profession');
            $client->ville          = $request->get('ville');
            $client->adresse        = $request->get('adresse');
            $client->tel_mobile     = $request->get('tel_mobile');
            $client->code_postal    = $request->get('code_postal');
            $client->saregime_id    = $request->get('saregime_id');
        $client->save();

        $fiche = new Ficheobseque;
            $fiche->client_id               = $client->id;
            $fiche->slug                    = uniqid();
            $fiche->produit_id              = $produit->id;
            $fiche->equipe_user_id          = null;
            $fiche->dispatchable_id         = $user->agence_id;
            $fiche->dispatchable_type       = 'site';
            $fiche->statut_id               = $statut->id;
            $fiche->groupepub_provenance_id = 1;
            $fiche->active                  = 1;
            $fiche->date_insertion          = Carbon::now()->format('Y-m-d H:i:s');
            $fiche->date_effet              = $request->get('date_effet');
            $fiche->capital                 = $request->get('capital');
            //$fiche->saregime_id             = $request->get('saregime_id');
        
        if($fiche->save()){
            $srcPrd       = Produit::find($request->get('srcPrd'));
            $srcClass     = "App\Fiche".$srcPrd->slug;
            $srcFiche     = $srcClass::find($request->get('srcFiche'));
            $observation  = "<i class='material-icons'>".$srcPrd->icon."</i> ".$srcPrd->libelle."<br>source: <span class='uk-text-bold'>#".$srcFiche->num_fiche."</span>";
            $idAction     = Action::whereSlug('DF')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => $observation, 'motif' => null];
            event(new EventTracesObseque($tabInfoTrace));
        }

        $fiche->num_fiche = $this->mask(2,$fiche->produit_id).$this->mask(7,$fiche->id);
        $fiche->save();

        $cltPrd = ClientProduit::firstOrCreate(['client_id' => $client->id, 'produit_id' => $produit->id]);
        $cltPrd->increment('nombre');

        $ficheSlug = $fiche->slug;

        $ficheId = $fiche->id;

        $info_fiche = [
                'fiche_id' => $ficheId,
                'prd_slug' => $produit->slug,
            ];

        event(new EventCreateProcessesLead($info_fiche));

        $url = url('centregestion/leads/obseque/'.$ficheSlug);

        return [
            'success' => true,
            'message' => 'La fiche a été dupliquée',
            'url'     => $url
        ];

    }

    
    /**
     * Ajouter un commentaire
     */
    public function addComment(AddCommentaireFicheRequest $request){

        $userInfo = $this->userInfo();

        $slug        = $request->get("slugPrd");
        $ficheId     = $request->get("ficheId");

        $className = "App\Fiche".$slug;

        $fiche = $className::find($ficheId);

        $commentaire = $request->get("commentaire");

        $commentable = "fiche".$slug."s";

        $user       = Auth::user();

        $comment = new Commentaire;
            $comment->commentable_id    = $ficheId;
            $comment->commentable_type  = $commentable;
            $comment->message           = $commentaire;
            $comment->user_id           = $user->id;
        
        if($comment->save()){
            $idAction     = Action::whereSlug('EC')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' =>  str_limit($commentaire, 50), 'motif' => null];
            $event = 'App\Events\EventTraces'.ucfirst($slug);
            event(new $event($tabInfoTrace));
        }

        return [ 'success' => true, 'message' => 'Le commentaire a été ajouté.'];

    }


    /**
     * Recevoir les commentaires de la fiche 
     */
    public function getComments(GetCommentaireFicheRequest $request){
        
        $slug       = $request->get("slugPrd");
        $ficheId    = $request->get("ficheId");

        $className  = "App\Fiche".$slug;

        $fiche      = $className::find($ficheId);
        
        $comments   = $fiche->comments;

        return $comments;

    }


    /**
     * Recevoir l'historique de la fiche
     */
    public function getHistory(GetHistoryFicheRequest $request){
        
        $slug      = $request->get("slugPrd");
        $ficheId   = $request->get("ficheId");
        
        $className = "App\Fiche".$slug;
        
        $fiche     = $className::find($ficheId);

        return $fiche->getHistory();

    }

    /**
     * Recevoir les propoitions envoyées au client
     */
    public function getProposition(Request $request){

        $user = Auth::user();

        if($request->has('propositionId')){

            $propositionId = $request->get('propositionId');
            
            $proposition   = Proposition::find($propositionId);
            
            $propositionId = base64_encode($proposition->id);

            $ficheNum      = base64_encode($proposition->num_fiche);
            
            $fiche         = $proposition->getFiche();

            $client        = $proposition->client;

            $ficheCrypter  = rawurlencode(base64_encode($fiche->slug));
            
            return view('emails.read_proposition', [
                                                        'societe'    => $fiche->societe->societe, 
                                                        'client'        => $client, 
                                                        'produit'       => $fiche->produit->slug,
                                                        'user'          => $user, 
                                                        'ficheCrypter'  => $ficheCrypter, 
                                                        'client'        => $proposition->client, 
                                                        'proposition'   => $proposition, 
                                                        'propositionId' => $propositionId, 
                                                        'ficheNum'      => $ficheNum
                                                    ]
                        );

        }else{

            return "Pas de proposition";

        }

    }


    /**
     * Renvoyer les propoitions envoyées au client
     */
    public function resendProposition(Request $request){

        if($request->has('propositionId')){

            $user          = Auth::user();
            
            $proposition   = Proposition::find($request->get('propositionId'));
            
            $client        = $proposition->client;
            
            $fiche         = $proposition->getFiche();
            
            $propositionId = base64_encode($proposition->id);

            $ficheNum      = base64_encode($proposition->num_fiche);

            $ficheCrypter  = rawurlencode(base64_encode($fiche->slug));

            try{

                Mail::send('emails.proposition_tarifs', ['societe' => $fiche->societe->societe, 'client' => $client, 'produit' => $fiche->produit->slug, 'user' => $user, 'ficheCrypter' => $ficheCrypter, 'client' => $client, 'proposition' => $proposition, 'propositionId' => $propositionId, 'ficheNum' => $ficheNum], function ($m) use ($client, $user)  {

                    $m->from($user->agence->email, $user->agence->nom);

                    $m->to($client->email, $client->nom)->subject('Votre proposition de tarif');

                });

                $userInfo = $this->userInfo();
                
                $idAction = Action::whereSlug('RP')->value('id');

                $tabInfoTrace = [
                                    'idAction'       => $idAction, 
                                    'idFiche'        => $fiche->id, 
                                    'idStatut'       => $fiche->statut_id, 
                                    'equipe_user_id' => $userInfo['equipe_user_id'], 
                                    'tracable_id'    => $userInfo['tracable_id'], 
                                    'tracable_type'  => $userInfo['tracable_type'], 
                                    'observation'    => "Source: ".$proposition->id, 
                                    'motif'          => null
                                ];

                $event = 'App\Events\EventTraces'.ucfirst($fiche->produit->slug);
                event(new $event($tabInfoTrace));

                return ['success' => true, 'message' => 'La proposition a été renvoyée.'];

            }catch(\Exception $e){

               return ['success' => false, 'message' => 'problème en renvoi de proposition.'];

            } 

        }else{

            return ['success' => false, 'message' => 'problème en renvoi de proposition.'];

        }

    }


    /**
     * Proposer une ou plusieurs formules à un prospect
     */
    public function proposeSanteFormules(Request $request){

        $user  = Auth::user();

        $ficheNum = $request->get('ficheNum');
        $fiche    = Fichesante::where('num_fiche', $ficheNum)->first();

        $clientId = $request->get('clientId');
        $client   = Client::find($clientId);

        $formules = $request->get('formules');

        $garanties      = [];
        $tarifsGarantie = [];

        foreach($formules as $index => $formule){

            $produit            = $request->get('produit');
            $dossierCompagnie   = 'compagnie';
            $verifydirectory    = 'upload/proposition/BA/'.$produit;
            //$linkPdf            = Parametre::whereKey('dossier_pdf')->first()->value;
        
            if (!file_exists($verifydirectory)) 
            {
                $result = File::makeDirectory('upload/proposition/BA/'.$produit, 0777, true);
            }

            $dossierCompagnie   = str_replace(' ', '_', $dossierCompagnie);
            $verify             = 'upload/proposition/BA/'.$produit.'/'.$dossierCompagnie;
        
            if (!file_exists($verify)) 
            {
                $result = File::makeDirectory('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie, 0777, true);
            }

            $fileName               = uniqid();
            $libelleGamme           = $formules[$index]['gamme'];
            $codeGarantie           = $formules[$index]['code_garantie'];
            $idGarantie             = $formules[$index]['id'];
            $tarifGarantie           = $formules[$index]['tarif'];
            array_push($garanties, $idGarantie);
            //array_push($tarifsGarantie, $tarifGarantie);
            $tarifsGarantie[$codeGarantie] = $tarifGarantie;
            //$ba                     = Sagamme::where('libelle', $libelleGamme)->first()->code;
            $ba                     = Sagarantie::whereCode($codeGarantie)->first()->gamme->code;
            $ba                     = strtoupper(str_replace(' ', '', $ba));
            $souscription           = new SouscriptionController();            
            $verifierSouscription   = 0;
            $tableau                = $souscription->{$ba}($user, $client, $fiche->enfants, $fiche->conjoint, $fiche, $verifierSouscription, $formule);
            //return $tableau;
            
            //Importer le fichier BA depuis le tarificateur
            $resultatImport         = $souscription->ImportFichierBA($ba);
            // return $resultatImport;
            
            if($resultatImport ){

            $pdf                = new Pdf('upload/'.$ba.'.pdf');
                //$pdf              = new Pdf($directory . $fileName);
                //$pdf              = new Pdf($fileContents);
            $pdf->allow('Printing')
            ->fillForm($tableau)
                ->needAppearances()
                ->saveAs('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

                // $fiche           = Fichesante::where('num_fiche', $contratId)->first(); 
                // $fiche->lien_pdf = asset('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
                // $fiche->save();
                $lienPdf                     = asset('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
                $formules[$index]['lienPdf'] = $lienPdf;                               
            }
        }

        $proposition            = new Proposition;
        $proposition->num_fiche = $ficheNum;
        $proposition->user_id   = $user->id;
        $proposition->client_id = $clientId;
        $proposition->formules  = json_encode($formules);
        $proposition->active    = 1;
        
        if($proposition->save()){

            $userInfo     = $this->userInfo();
            $idAction     = Action::whereSlug('EP')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => null, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));
            // traitement tableau garantie debut
            $dataGarantie = [

                'garantie'          => $garanties,
                'tarif'             => $tarifsGarantie,
                'objetProposition'     => $proposition->id,
                'Border'            => ''

            ];

            $data            = serialize($dataGarantie);
            $dataCrypter     = base64_encode($data);
            $tableauGarantie = url('propositionLien?q='.$dataCrypter);
            

            $urlshort         = new SettingController();
            $key = 'AIzaSyBHxOoC-ICQGKDUAHfzOqAZLeGF-HVyUWU';
            $shorURL = $urlshort->shorten($tableauGarantie, $key, "https://www.googleapis.com/urlshortener/v1/url");
            // traitement tableau garantie fin 

        }


        $propositionId  = base64_encode($proposition->id);
        $ficheNum       = base64_encode($proposition->num_fiche);
        $ficheCrypter   = rawurlencode(base64_encode($fiche->slug));

        try{

            Mail::send('emails.proposition_tarifs', ['societe' => $fiche->societe->societe, 'client' => $client, 'produit' => $fiche->produit->slug, 'user' => $user, 'ficheCrypter' => $ficheCrypter, 'client' => $client, 'proposition' => $proposition, 'propositionId' => $propositionId, 'ficheNum' => $ficheNum, 'shorURL' => $shorURL], function ($m) use ($client, $user)  {

                $m->from($user->agence->email, $user->agence->nom);

                $m->to($client->email, $client->nom)->subject('Votre proposition de tarif');

            });

            $info_fiche = [
                'fiche_id'     => $fiche->id,
                'prd_slug'     => $fiche->produit->slug,
                'process_slug' => 'proposition',
            ];
            event(new EventChangeStateProcessLead($info_fiche));

            return ['success' => true, 'message' => 'La proposition a été enregistrée.'];

        }catch(\Exception $e){

            dd($e);
            return ['success' => false, 'message' => 'problème en envoi de mail'];
        } 
     

    }

    /**
     * Proposer une ou plusieurs formules à un prospect
     */
    public function proposeObsequeFormules(Request $request){

        $user  = Auth::user();

        $ficheNum = $request->get('ficheNum');
        $fiche    = Ficheobseque::where('num_fiche', $ficheNum)->first();

        $clientId = $request->get('clientId');
        $client   = Client::find($clientId);

        $formules = $request->get('formules');

        foreach($formules as $index => $formule){

            $produit            = $request->get('produit');
            $dossierCompagnie   = 'compagnie';
            $verifydirectory    = 'upload/proposition/BA/'.$produit;
            //$linkPdf            = Parametre::whereKey('dossier_pdf')->first()->value;
        
            if (!file_exists($verifydirectory)){
                $result = File::makeDirectory('upload/proposition/BA/'.$produit, 0777, true);
            }

            $dossierCompagnie   = str_replace(' ', '_', $dossierCompagnie);
            $verify             = 'upload/proposition/BA/'.$produit.'/'.$dossierCompagnie;
        
            if (!file_exists($verify)){
                $result = File::makeDirectory('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie, 0777, true);
            }

            $fileName               = uniqid();
            $codeGarantie           = $formules[$index]['code_garantie'];
            $ba                     = Obgarantie::whereCode($codeGarantie)->first()->gamme->code;
            $ba                     = strtoupper(str_replace(' ', '', $ba));
            $souscription           = new SouscriptionObsequeController();            
            $verifierSouscription   = 0;
            //$tableau                = $souscription->{$ba}($user, $client, $fiche, $verifierSouscription, $formule);
            
            //Importer le fichier BA depuis le tarificateur
            //$resultatImport         = $souscription->ImportFichierBA($ba);
            
            // if($resultatImport ){

            //     $pdf = new Pdf('upload/'.$ba.'.pdf');
            //     $pdf->fillForm($tableau)
            //         ->needAppearances()
            //         ->saveAs('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

            //     $lienPdf                     = asset('upload/proposition/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
            //     $formules[$index]['lienPdf'] = $lienPdf;

            // }

        }

        $proposition            = new Proposition;
        $proposition->num_fiche = $ficheNum;
        $proposition->user_id   = $user->id;
        $proposition->client_id = $clientId;
        $proposition->formules  = json_encode($formules);
        $proposition->active    = 1;
        
        if($proposition->save()){
            $userInfo     = $this->userInfo();
            $idAction     = Action::whereSlug('EP')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => null, 'motif' => null];
            event(new EventTracesObseque($tabInfoTrace));
        }
            // traitement tableau garantie debut
            $dataGarantie = [

                'garantie'          => $garanties,
                'tarif'             => $tarifsGarantie,
                'objetProposition'  => $proposition->id,
                'Border'            => ''

            ];

            $data            = serialize($dataGarantie);
            $dataCrypter     = base64_encode($data);
            $tableauGarantie = url('propositionLien'.$request->get('produit').'?q='.$dataCrypter);

            $urlshort = new SettingController();
            $key      = 'AIzaSyBHxOoC-ICQGKDUAHfzOqAZLeGF-HVyUWU';
            $shorURL  = $urlshort->shorten($tableauGarantie, $key, "https://www.googleapis.com/urlshortener/v1/url");
            // traitement tableau garantie fin  


        $propositionId  = base64_encode($proposition->id);
        $ficheNum       = base64_encode($proposition->num_fiche);
        $ficheCrypter   = rawurlencode(base64_encode($fiche->slug));

        try{

            Mail::send('emails.proposition_tarifs', ['societe' => $fiche->societe->societe, 'client' => $client, 'produit' => $fiche->produit->slug, 'user' => $user, 'ficheCrypter' => $ficheCrypter, 'client' => $client, 'proposition' => $proposition, 'propositionId' => $propositionId, 'ficheNum' => $ficheNum], function ($m) use ($client, $user)  {

                $m->from($user->agence->email, $user->agence->nom);

                $m->to($client->email, $client->nom)->subject('Votre proposition de tarif');

            });

            $info_fiche = [
                'fiche_id'     => $fiche->id,
                'prd_slug'     => $fiche->produit->slug,
                'process_slug' => 'proposition',
            ];
            event(new EventChangeStateProcessLead($info_fiche));

            return ['success' => true, 'message' => 'La proposition a été enregistrée.'];

        }catch(\Exception $e){

            return ['success' => false, 'message' => 'problème en envoi de mail'];
        }
     
    }



    /**
     * Sauvegarder les info du clients (bancaire ...)
     */
    public function saveInfoClientSante(SaveInfoClientRequest $request){

        $userInfo = $this->userInfo();

        $garantie_code = $request->get('garantie_code');

        $garantie = Sagarantie::whereCode($garantie_code)->first();

        $clientId  = $request->get('info_num_client');
        $contratId = $request->get('info_num_contrat');

        $fiche  = Fichesante::where('num_fiche', $contratId)->first(); 
        $client = $fiche->client;
        
        // $fiche->sagamme_id          = $request->get('gamme_id');
        // $fiche->sagarantie_id       = $request->get('garantie_id');
        $fiche->sagamme_id          = $garantie->gamme->id;
        $fiche->sagarantie_id       = $garantie->id;

        $fiche->soins_val           = $request->get('soins_val');
        $fiche->optique_val         = $request->get('optique_val');
        $fiche->dentaire_val        = $request->get('dentaire_val');
        $fiche->hospitalisation_val = $request->get('hospitalisation_val');
        
        $fiche->cotisation          = $request->get('info_montant');
        $fiche->num_formule         = $request->get('info_formule');
        //$fiche->num_compagnie     = $request->get('info');
        $fiche->num_affiliate       = $request->get('info_num_aff');
        $fiche->num_security_social = $request->get('info_num_ss');
        
        $fiche->modepaiement_id     = $request->get('mode_paiement');
        $fiche->typepaiement_id     = $request->get('type_paiement');
        $fiche->prelevement_id      = $request->get('prelevement');
        $fiche->nbr_mois_gratuit    = $request->get('nbr_mois_gratuit');
        $fiche->paiement_cb         = $request->get('paiement_cb');
        $fiche->remise              = $request->get('remise');
        //$fiche->frais_dossier_offert = $request->get('frais_dossier_offert');
        $fiche->frais_dossier       = $request->get('frais_dossier') ;

        $fiche->date_situation      = Carbon::now();

        $fiche->save();

        $conjoint = $fiche->conjoint;

        if($conjoint){
            $conjoint->cotisation          = $request->get('info_montant');
            $conjoint->num_affiliate       = $request->get('info_num_aff_conj');
            $conjoint->num_security_social = $request->get('info_num_ss_conj');
            $conjoint->save();
        }

        $infoBanque = Informationbancaire::where('client_id', $clientId)->where('contrat_id', $contratId)->first();

        if(!$infoBanque){
            $infoBanque = new Informationbancaire;
        }

        $infoBanque->client_id              = $clientId;
        $infoBanque->contrat_id             = $contratId;
        
        if($request->has("iban_pre")){

            $iban_pre = str_replace('-', '', $request->get("iban_pre"));

            $infoBanque->nom_banque_pre         = $request->get('nom_banque_pre');
            $infoBanque->adresse_banque_pre     = $request->get('adresse_banque_pre');
            $infoBanque->ville_banque_pre       = $request->get('ville_banque_pre');
            $infoBanque->code_pays_pre          = substr($iban_pre, 0, 2);
            $infoBanque->cle_iban_pre           = substr($iban_pre, 2, 2);
            $infoBanque->code_etablissement_pre = substr($iban_pre, 4, 5);
            $infoBanque->code_guichet_pre       = substr($iban_pre, 9, 5);
            $infoBanque->num_compte_pre         = substr($iban_pre, 14, 11);
            $infoBanque->cle_rib_pre            = substr($iban_pre, 25, 2);
            $infoBanque->code_bic_pre           = Crypt::encrypt($request->get('code_bic_pre'));

            $infoBanque->iban_pre               = Crypt::encrypt($iban_pre);

        }


        if($request->has("iban_rem")){

            $iban_rem = str_replace('-', '', $request->get("iban_rem"));
        
            $infoBanque->nom_banque_rem         = $request->get('nom_banque_rem');
            $infoBanque->adresse_banque_rem     = $request->get('adresse_banque_rem');
            $infoBanque->ville_banque_rem       = $request->get('ville_banque_rem');
            $infoBanque->code_pays_rem          = substr($iban_rem, 0, 2);
            $infoBanque->cle_iban_rem           = substr($iban_rem, 2, 2);
            $infoBanque->code_etablissement_rem = substr($iban_rem, 4, 5);
            $infoBanque->code_guichet_rem       = substr($iban_rem, 9, 5);
            $infoBanque->num_compte_rem         = substr($iban_rem, 14, 11);
            $infoBanque->cle_rib_rem            = substr($iban_rem, 25, 2);
            $infoBanque->code_bic_rem           = Crypt::encrypt($request->get('code_bic_rem'));

            $infoBanque->iban_rem               = Crypt::encrypt($iban_rem);

        }

        $infoBanque->active                 = 1;

        
        if($infoBanque->save()){
            $idAction     = Action::whereSlug('SCP')->value('id');
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => null, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));
        }

        if( $fiche->statut->groupeStatus->slug == "leads" ) {
            $statut = Statut::whereSlug('devis')->first();
            $fiche->statut_id      = $statut->id;
            $fiche->date_situation = Carbon::now();
            $fiche->save();
            $tabInfoTrace = ['idAction' => $idAction, 'idFiche' => $fiche->id, 'idStatut' => $fiche->statut_id, 'equipe_user_id' => $userInfo['equipe_user_id'], 'tracable_id' => $userInfo['tracable_id'], 'tracable_type' => $userInfo['tracable_type'], 'observation' => null, 'motif' => null];
            event(new EventTracesSante($tabInfoTrace));
        }

 
        $user = [];

        if(is_null($fiche->equipe_user_id)){
            $user = $fiche->dispatchable->responsable();
        }else{
            $user = $fiche->affectedUser($fiche->equipe_user_id);
        }


            $nomClient = $fiche->client->nom;
            $prenomClient = $fiche->client->prenom;
            $emailClient = $fiche->client->email;
            $civiliteClient = $fiche->client->sexe;
            //$page = "documents.$formule->compagnie.$formule->gamme.BA" ;

            //return view($page, [ 'proposition' => $proposition, 'formule' => $formule, 'user' => $user, 'fiche' => $fiche ]);
        if($conjoint){

            $data = [ 
                'nomConseiller'               => $user->nom,
                'prenomConseiller'            => $user->prenom,
                'telConseiller'               => $user->tel,
                'emailConseiller'             => $user->email,
                'faxConseiller'               => $user->fax,
                'logo'                        => $request->get('logo'),
                'civiliteClient'              => $fiche->client->sexe,
                'nomClient'                   => $fiche->client->nom,
                'prenomClient'                => $fiche->client->prenom,
                'dateNaissanceClient'         => $fiche->client->date_naissance,
                'adresseClient'               => $fiche->client->adresse,
                'codePostalClient'            => $fiche->client->code_postal,
                'emailClient'                 => $fiche->client->email,
                'telDomicileClient'           => $fiche->client->tel_domicile,
                'telMobileClient'             => $fiche->client->tel_mobile,
                'telBureauClient'             => $fiche->client->tel_bureau,
                'villeClient'                 => $fiche->client->ville,
                'professionClient'            => $fiche->client->profession_id, 
                'sitFamilialeClient'          => $fiche->client->sit_familiale,
                'garantie'                    => $request->get('garantie'), 
                'nomConjoint'                 => $fiche->conjoint->nom,
                'prenomConjoint'              => $fiche->conjoint->prenom,
                'dateNaissanceConjoint'       => $fiche->conjoint->date_naissance,
                'nomCompagnie'                => $request->get('compagnie'),
                'lienCrm'                     => public_path().'/uploads/BA'
                 //'proposition' => json_decode([$proposition]), 
                // 'formule'     => json_decode([$formule]), 
                // 'user'        => json_decode([$user]), 
                // 'client'      => json_decode($fiche->client),
                // 'clientR'     => json_decode($fiche->client->regime),
                // 'fiche'       => json_decode($fiche),
                // 'conjoint'    => ($fiche->conjoint) ? json_decode($fiche->conjoint) : [],
                // 'conjointR'   => ($fiche->conjoint) ? $fiche->conjoint->regime : [],
                // 'enfants'     => json_decode(($fiche->enfants) ? $fiche->enfants : [])
            ];
        }else{
            $data = [ 
                'nomConseiller'               => $user->nom,
                'prenomConseiller'            => $user->prenom,
                'telConseiller'               => $user->tel,
                'emailConseiller'             => $user->email,
                'faxConseiller'               => $user->fax,
                'logo'                        => $request->get('logo'),
                'civiliteClient'              => $fiche->client->sexe,
                'nomClient'                   => $fiche->client->nom,
                'prenomClient'                => $fiche->client->prenom,
                'dateNaissanceClient'         => $fiche->client->date_naissance,
                'adresseClient'               => $fiche->client->adresse,
                'codePostalClient'            => $fiche->client->code_postal,
                'emailClient'                 => $fiche->client->email,
                'telDomicileClient'           => $fiche->client->tel_domicile,
                'telMobileClient'             => $fiche->client->tel_mobile,
                'telBureauClient'             => $fiche->client->tel_bureau,
                'villeClient'                 => $fiche->client->ville,
                'professionClient'            => $fiche->client->profession_id, 
                'sitFamilialeClient'          => $fiche->client->sit_familiale,
                'garantie'                    => $request->get('garantie'), 
                'nomConjoint'                 => '',
                'prenomConjoint'              => '',
                'dateNaissanceConjoint'       => '',
                'nomCompagnie'                => $request->get('compagnie'),
                'lienCrm'                     => public_path().'/uploads/BA'
                 //'proposition' => json_decode([$proposition]), 
                // 'formule'     => json_decode([$formule]), 
                // 'user'        => json_decode([$user]), 
                // 'client'      => json_decode($fiche->client),
                // 'clientR'     => json_decode($fiche->client->regime),
                // 'fiche'       => json_decode($fiche),
                // 'conjoint'    => ($fiche->conjoint) ? json_decode($fiche->conjoint) : [],
                // 'conjointR'   => ($fiche->conjoint) ? $fiche->conjoint->regime : [],
                // 'enfants'     => json_decode(($fiche->enfants) ? $fiche->enfants : [])
            ];
        }
// lien serveur
        $produit ='SANTE';
        $dossierCompagnie = $request->get('compagnie');
        $verifydirectory    = 'upload/souscription/BA/'.$produit;
        $linkPdf = Parametre::whereKey('dossier_pdf')->first()->value;
       
        if (!file_exists($verifydirectory)) 
                     {
            $result = File::makeDirectory('upload/souscription/BA/'.$produit);
                    }
                    $dossierCompagnie    = str_replace(' ', '_', $dossierCompagnie);

                    $verify    = 'upload/souscription/BA/'.$produit.'/'.$dossierCompagnie;
       
        if (!file_exists($verify)) 
                     {
            $result = File::makeDirectory('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie);
                    }

        $fileName = uniqid();
        $gamme      = $garantie->gamme;
        $ba       = $gamme->libelle;
        $ba = strtoupper(str_replace(' ', '', $ba));
        $tableau = $this->{$ba}($user, $client, $fiche->enfants, $fiche->conjoint, $fiche);
        $pdf = new Pdf('upload/'.$ba.'.pdf');
        $pdf->allow('Printing')
            ->fillForm($tableau)
                ->needAppearances()
            ->saveAs('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');


        $fiche  = Fichesante::where('num_fiche', $contratId)->first(); 
        $fiche->lien_pdf = asset('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
        $fiche->save();
        $lienPdf = asset('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

            //$link = Parametre::whereKey('ba_link')->first()->value;

            // $link = "http://ec2-52-40-189-99.us-west-2.compute.amazonaws.com/emma/public/pdf?";


            //  //$link = "http://localhost:7777/pdf?";

        
            // // $params = http_build_query($data);
            // //  return file_get_contents($link."?".$params);
            

            //  //echo link_to($link.http_build_query($data), $title = null, $attributes = null);
            //  $url = $link.http_build_query($data);
            //  $ch       = curl_init();
            // $timeout  = 0;
            // curl_setopt($ch, CURLOPT_URL,$url);
            // curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
            // curl_setopt($ch, CURLOPT_SAFE_UPLOAD, true);
            // curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,$timeout);
            // $rawdata=curl_exec($ch);
            // curl_close($ch);


        //     try{

        //     Mail::send('emails.proposition_BA', ['client' => $client, 'logo' => $request->get('logo'), 'compagnie' => $request->get('compagnie')], function ($m) use ($client)  {

                
        //         $m->from($client->email, $client->nom);

        //         $m->to($client->email, $client->nom)->subject('Votre proposition de tarif');
        //     });

        //     return ['success' => true, 'message' => 'La proposition a été enregistré.'];

        // }catch(\Exception $e){
        //     dd($e);

        //    return ['success' => false, 'message' => 'probleme en envoi de mail'];

        // } 

            // fin pdf

        $info_fiche = [
                    'fiche_id'     => $fiche->id,
                    'prd_slug'     => $fiche->produit->slug
                ];
                    
        $collection = collect(event(new EventCreateProcessesLead($info_fiche)));
        $processes  = $collection->flatten(1);
        $processes->values()->all();
 
        return ['garantie' => $garantie->libelle,'lienPdf' => $lienPdf, 'dossierCompagnie' => $dossierCompagnie, 'fileName' => $fileName, 'success' => true, 'message' => 'les informations sont enregistrées.', 'logo' => $request->get('logo'), 'nomClient' => $nomClient, 'prenomClient' => $prenomClient, 'emailClient' => $emailClient, 'civiliteClient' => $civiliteClient, 'tarif' => $request->get('info_montant'), 'processes' => $processes];

    }


    /**
     * Afficher de la fiche
     */
    public function showLead($slug, $id) {

        $ficheStatus        = [];
        
        $produit            = Produit::whereSlug($slug)->first();
        
        $produit            = Produit::find($produit->id);
        
        $groupePrd          = $produit->groupeProduit;
        
        $regimes            = Saregime::whereActive(1)->get();

        $regimePardefaut    = Saregime::where('code', 'SES')->first();
        
        $groupeProduitsList =  Groupeproduit::whereActive(1)->with('produits')->get();
        
        $documents          = Documentfiche::where('produit_id', $produit->id)->get();

        $className = "App\Fiche".$produit->slug;

        $fiche = $className::whereSlug($id)->first();

        if(!$fiche){

            return abort(404);

        }
        
        $fiche->increment('nbr_vu');
        
        $groupeProduits = $this->groupeProduitsClient($fiche->client_id);

        $contrats       = $className::getContrats($fiche->client_id, $groupePrd->id);

        $ficheStatus    = Statutaction::where('actionable_id', $id)
                                    ->where('actionable_type', 'fiche'.$produit->slug.'s')
                                    ->orderBy('created_at', 'desc')
                                    ->get();

        $modePaiements = Modepaiement::whereActive(1)->get();
        $typePaiements = Typepaiement::whereActive(1)->get();
        $prelevements  = Prelevement::whereActive(1)->get();
        
        $infoBanque    = Informationbancaire::whereActive(1)->where('contrat_id', $fiche->num_fiche)->where('client_id', $fiche->client_id)->first();
        
        $user          = Auth::user();
        $agence        = $user->agence;
        $sites         = $agence->sites;
        $equipes       = $agence->equipes;
        
        $siteIds       = collect($sites->lists('id'));
        $equipeIds     = collect($equipes->lists('id'));

        $equipesUser = Equipeuser::whereIn('equipe_id', $equipeIds)->get();
        $equipeUserIds = collect($equipesUser->lists('id'));


        $conseillers = collect(DB::table('equipe_user')
                                ->leftjoin('users','equipe_user.user_id','=','users.id')
                                ->where('users.active',1)
                                ->where('equipe_user.active',1)
                                ->where('users.agence_id', $agence->id)
                                ->select('users.id','users.login','equipe_user.equipe_id', 'equipe_user.id as equipeUserId')
                                ->get());

        $access = 0;

        if(
            (
                ( $equipeIds->contains($fiche->dispatchable_id) and $fiche->dispatchable_type == 'equipe' )
                or
                ( $siteIds->contains($fiche->dispatchable_id) and $fiche->dispatchable_type == 'site' )
                or
                ( $agence->id == $fiche->dispatchable_id and $fiche->dispatchable_type == 'agence' ) 
            )
            and
                $fiche->statut->groupeStatus->slug == 'contrats'
        ){
            
            $access = 1;
            
        }

        $tarifLink = Parametre::whereKey('tarif_link')->first()->value;
        $tarifKey  = Parametre::whereKey('tarif_key')->first()->value;

        $ibanApiKey  = Parametre::whereKey('iban_api_key')->first()->value;
        $ibanApiLink = Parametre::whereKey('iban_api_link')->first()->value;
        
        //$motifsRejet = Groupemotif::find(2)->motifs()->get();
        $motifsRejet = Groupemotif::where('slug', 'motifsRejet')->first()->motifs()->where('statut_id', $fiche->statut_id)->where('active', 1)->get();

        $professions = Profession::whereActive(1)->orderBy('libelle', 'asc')->get();

        $processes   = [];

        $traitement = collect(json_decode($fiche->traitements))->where('statut', $fiche->statut->slug)->first();

        if($traitement && $traitement->processes){
            $processes = $traitement->processes ;
        } 


        return view("centregestion.$produit->slug.$produit->slug", [
                                    'groupeProduits'     => $groupeProduits,
                                    'fiche'              => $fiche,
                                    'regimes'            => $regimes,
                                    'regimePardefaut'    => $regimePardefaut,
                                    'contrats'           => $contrats,
                                    'ficheStatus'        => $ficheStatus,
                                    'groupeProduitsList' => $groupeProduitsList,
                                    'documents'          => $documents,
                                    'modePaiements'      => $modePaiements,
                                    'typePaiements'      => $typePaiements,
                                    'prelevements'       => $prelevements,
                                    'infoBanque'         => $infoBanque,
                                    'access'             => $access,
                                    'sites'              => $sites,
                                    'equipes'            => $equipes,
                                    'conseillers'        => $conseillers,
                                    'tarifLink'          => $tarifLink,
                                    'tarifKey'           => $tarifKey,
                                    'motifsRejet'        => $motifsRejet,
                                    'professions'        => $professions,
                                    'ibanApiKey'         => $ibanApiKey,
                                    'ibanApiLink'        => $ibanApiLink,
                                    'processes'          => json_encode($processes),
                                ]
            );

    }


    /**
     * Recevoir les groupes de produits
     */
    public function groupeProduitsClient($client_id){

        $client = Client::find($client_id);
        //$client->getGroupesProduit();

        $produitIds     = ClientProduit::where('client_id',$client_id)
                                        ->groupBy('produit_id')
                                        ->lists('produit_id');
                
        $gpIds          = Produit::whereIn('id',$produitIds)
                                    ->groupBy('groupeproduit_id')
                                    ->lists('groupeproduit_id');
                
        return $groupeProduits = Groupeproduit::whereIn('id',$gpIds)->get();

    }


    /**
     * Afficher les fiches selon le statut
     */
    public function leads(Request $request, $status=null) {

        $user      = Auth::user();

        if(!Session::has('produit_id')){
            
            $productsession = Produit::whereSlug("sante")->first();
            Session::put('produit_id', $productsession->id);

        }

        $id        = Session::get('produit_id');
        $produit   = Produit::find($id);

        $slugPrd   = $produit->slug;

        $produitId   = $produit->id;
        
        $agence      = $user->agence;
        $agence_id   = $agence->id;

        $sites       = $agence->sites()
                                    // ->whereHas('produits', function ($query) use ($produitId) {
                                    //     $query->where('produit_id', $produitId);
                                    // })
                                    ->get();
        $sitesIds    = $sites->lists('id');
        
        $equipes     = $agence->equipes()
                                    // ->whereHas('produits', function ($query) use ($produitId) {
                                    //     $query->where('produit_id', $produitId);
                                    // })
                                    ->get();
        $equipeIds   = $equipes->lists('id');

        $conseillers = collect([]);
        $users       = collect([]);

        foreach($equipes as $equipe){

            $conseillers    = $conseillers->push(
                                    $equipe->getUserEquipe()
                                            ->where('users.active',1)
                                            ->where('users.connected', 1)
                                            ->where('users.courtier_id', $agence->courtier_id)
                                            ->where('users.agence_id', $agence_id)
                                            // ->whereHas('produits', function ($query) use ($produitId) {
                                            //     $query->where('produit_id', $produitId);
                                            // })
                                            ->select('users.id','users.login','equipe_user.equipe_id', 'equipe_user.id as equipeUserId')
                                            ->get()
                                    );

            $users = $users->push(
                                    $equipe->getUserEquipe()
                                            ->where('users.active',1)
                                            ->where('users.courtier_id', $agence->courtier_id)
                                            ->where('users.agence_id', $agence_id)
                                            ->whereHas('produits', function ($query) use ($produitId) {
                                                $query->where('produit_id', $produitId);
                                            })
                                            ->select('users.id','users.login','equipe_user.equipe_id', 'equipe_user.id as equipeUserId')
                                            ->get()
                                    );

        }

        $conseillers = $conseillers->flatten(1);
        $users       = $users->flatten(1);

        
        //$conseillers = $equipe->equipeConseillers; // la liste des conseillers de cette equipe  
        //$produits      = Produit::whereActive(1)->get(); // retourner la liste des produits  
        
        // Display Active Products
        $produits       = $agence->produits;
        //$produits     = Produit::whereActive(1)->get();

        $statut = collect($produit->status)->where('id', (int)$status)->first();

        if(count($statut)==0){ 
            $statut = Statut::whereSlug($slugPrd."Appel")->first();
            return redirect('centregestion/leads/'.$statut->id);
        }

        $groupeStatus = $statut->groupeStatus; 

        // $motifsRejet   = Groupemotif::find(2)->motifs()->get();
        $motifsRejet = Groupemotif::where('slug', 'motifsRejet')->first()->motifs()->where('statut_id', $statut->id)->where('active', 1)->get();

        if($produit->slug) {

            $classFicheProduit   = 'App\Fiche'.$produit->slug;

            $queryOrder = 'dispatchable_type';
            $ordre = 'asc';

            if($groupeStatus->slug=='leads' and $statut->slug=='appel'){
                $queryOrder = 'dispatchable_type';
                $ordre = 'asc';
            }if($groupeStatus->slug=='leads' and $statut->slug!='appel'){
                $queryOrder = 'created_at';
                $ordre = 'desc';
            }elseif($groupeStatus->slug=='devis'){
                $queryOrder = 'date_situation';
                $ordre = 'desc';
            }elseif($groupeStatus->slug=='contrats'){
                $queryOrder = 'date_situation';
                $ordre = 'desc';
            }


            $dateFilter = 'created_at' ;

            if($groupeStatus->slug == 'leads'){

                $dateFilter = 'created_at' ;

            }elseif($groupeStatus->slug == 'devis' or $groupeStatus->slug == 'contrats'){

                $dateFilter = 'date_situation' ;

            }

            

            $fiches = $classFicheProduit::whereActive(1)

                                        ->where(function($query) use ($request, $agence_id, $sitesIds, $equipeIds) {
                                            if(!$request->has('u') and !$request->has('s') and !$request->has('e')){
                                                $query->where(function($qE) use ($equipeIds) {
                                                    $qE->whereIn('dispatchable_id', $equipeIds);
                                                    $qE->where('dispatchable_type', 'equipe');
                                                });
                                                $query->orWhere(function($qS) use ($sitesIds) {
                                                    $qS->whereIn('dispatchable_id', $sitesIds);
                                                    $qS->where('dispatchable_type', 'site');
                                                });
                                                $query->orWhere(function($qA) use ($agence_id) {
                                                    $qA->where('dispatchable_id', $agence_id);
                                                    $qA->where('dispatchable_type', 'agence');
                                                });
                                            }
                                        })

                                        ->where(function($q) use ($request, $agence_id) {

                                            if($request->has('s') and !$request->has('e') and !$request->has('u')){

                                                $site = Site::whereId($request->get('s'))->where('agence_id', $agence_id)->first();

                                                if(count($site)>0){

                                                    $site_id     = $site->id;

                                                    $equipes     = $site->equipes;
                                                    $equipeIds   = $equipes->lists('id');

                                                    $q->where(function($qE) use ($equipeIds) {
                                                        $qE->whereIn('dispatchable_id', $equipeIds);
                                                        $qE->where('dispatchable_type', 'equipe');
                                                    });

                                                    $q->orWhere(function($qS) use ($site_id) {
                                                        $qS->where('dispatchable_id', $site_id);
                                                        $qS->where('dispatchable_type', 'site');
                                                    });

                                                }else{
                                                    return abort(404);
                                                }

                                            }

                                        })

                                        ->where(function($qE) use ($request) {

                                            if( $request->has('e') and !$request->has('u') ){

                                                $qE->where('dispatchable_id', Input::get('e'));
                                                $qE->where('dispatchable_type', 'equipe');

                                            }

                                        })

                                        ->where(function($qU) use ($request) {

                                                if($request->has('u')){
                                                    $qU->where('equipe_user_id', Input::get('u'));
                                                }
                                            
                                        })

                                        ->where(function($query) use ($request, $dateFilter) {
                                            if($request->has('dd') and $request->has('df')){
                                                $dd = $request->get('dd');
                                                $df = $request->get('df');
                                                $query->whereBetween($dateFilter, [$dd.' 00:00:00', $df.' 23:59:59']);
                                            }elseif($request->has('dd') and !$request->has('df')){
                                                $dd = $request->get('dd');
                                                $query->where($dateFilter, '>=', $dd.' 00:00:00');
                                            }elseif(!$request->has('dd') and $request->has('df')){
                                                $df = $request->get('df');
                                                $query->where($dateFilter, '<=', $df.' 23:59:59');
                                            }
                                        })

                                        ->where('produit_id', $id)
                                        ->where('statut_id', $statut->id)
                                        ->orderBy( $queryOrder, $ordre)
                                        ->orderBy('created_at', 'desc')
                                        ->paginate(30);

            $dureeImpressionSysteme   = Parametre::whereKey('duree_impression')->first()->value;


            switch($groupeStatus->slug) {

                case 'leads':
                    return view('centregestion.'.$produit->slug.'.leads_'.$produit->slug, ['produits' => $produits, 'sites' => $sites, 'equipes' => $equipes, 'users' => $users, 'conseillers' => $conseillers, 'fiches' => $fiches, 'statut' => $statut]);
                    break;

                case 'devis':
                    return view('centregestion.'.$produit->slug.'.devis_'.$produit->slug, ['produits' => $produits, 'sites' => $sites, 'equipes' => $equipes, 'fiches' => $fiches, 'users' => $users, 'conseillers' => $conseillers, 'motifsRejet' => $motifsRejet, 'statut' => $statut]);
                    break;

                case 'contrats':
                    return view('centregestion.'.$produit->slug.'.contrats_'.$produit->slug, ['produits' => $produits, 'sites' => $sites, 'equipes' => $equipes, 'users' => $users, 'conseillers' => $conseillers, 'fiches' => $fiches, 'motifsRejet' => $motifsRejet, 'statut' => $statut, 'dureeImpressionSysteme' => $dureeImpressionSysteme]);
                    break;             
                
            }

        }

        //$produits = Produit::whereActive(1)->get();

        return view('conseillers.dashboard', ['produits' => $produits, 'fiches' => $fiches]);

    }


    /**
     * Générer le numero du contrat
     */
    public function mask($nbrbits, $valeur){

        $nbrBitsValeur  = $nbrbits - strlen($valeur);
        $resultat       = $valeur;

        if($nbrBitsValeur > 0){

            for($i=0; $i<$nbrBitsValeur; $i++){

                $resultat = '0'.$resultat;

            }
        }

        return $resultat;
    }


    /**
     * Changer le produit
     */
    public function changeProduit(Request $request, $id){

        $user = Auth::user();

        if(!$id){
            Session::put('produit_id', $user->getProducts()->first()->id);
        }else{
            Session::put('produit_id', $id);
        }

        try {

            $produit   = Produit::whereId(Session::get('produit_id'))->first();

            $statusId  = Statut::where('slug_produit', $produit->slug)
                                        ->with(['groupeStatus' => function($q){
                                            $q->whereSlug('leads');
                                        }])
                                        ->orderBy('ordre', 'asc')
                                        ->first()
                                        ->id;

            return ($statusId) ? $statusId : 0 ;

        }catch(\Exception $e){

            return 0;

        }

    }



    public function userInfo(){

        $user = Auth::user();

        return $userInfo = ['equipe_user_id' => null, 'tracable_id' => $user->agence_id, 'tracable_type' => 'agence'];

    }


    /**
     * Sauvegarder les info du clients (bancaire ...)
     */
    public function saveInfoClientObseque(SaveInfoClientRequest $request){

        $userInfo = $this->userInfo();

        $garantie_code = $request->get('garantie_code');

        $garantie = Obgarantie::whereCode($garantie_code)->first();

        $clientId  = $request->get('info_num_client');
        $contratId = $request->get('info_num_contrat');

        $fiche  = Ficheobseque::where('num_fiche', $contratId)->first(); 
        $client = $fiche->client;
        
        // $fiche->sagamme_id          = $request->get('gamme_id');
        // $fiche->sagarantie_id       = $request->get('garantie_id');
        $fiche->obgamme_id          = $garantie->gamme->id;
        $fiche->obgarantie_id       = $garantie->id;
        
        $fiche->cotisation          = $request->get('info_montant');
        $fiche->num_formule         = $request->get('info_formule');
        //$fiche->num_compagnie     = $request->get('info');
        $fiche->num_affiliate       = $request->get('info_num_aff');
        $fiche->num_security_social = $request->get('info_num_ss');
        
        $fiche->modepaiement_id     = $request->get('mode_paiement');
        $fiche->typepaiement_id     = $request->get('type_paiement');
        $fiche->prelevement_id      = $request->get('prelevement');
        $fiche->nbr_mois_gratuit    = $request->get('nbr_mois_gratuit');
        $fiche->paiement_cb         = $request->get('paiement_cb');
        $fiche->remise              = $request->get('remise');
        //$fiche->frais_dossier_offert = $request->get('frais_dossier_offert');
        $fiche->frais_dossier       = $request->get('frais_dossier') ;
        $fiche->date_situation      = Carbon::now();

        $fiche->capital             = $request->get('montant_capital');

        $fiche->save();


        $infoBanque = Informationbancaire::where('client_id', $clientId)->where('contrat_id', $contratId)->first();

        if(!$infoBanque){
            $infoBanque = new Informationbancaire;
        }

        $infoBanque->client_id                  = $clientId;
        $infoBanque->contrat_id                 = $contratId;
        $infoBanque->active                     = 1;
        
        if($request->has("iban_pre") and $request->get("iban_pre")){

            $iban_pre = str_replace('-', '', $request->get("iban_pre"));

            $infoBanque->nom_banque_pre         = $request->get('nom_banque_pre');
            $infoBanque->adresse_banque_pre     = $request->get('adresse_banque_pre');
            $infoBanque->ville_banque_pre       = $request->get('ville_banque_pre');
            $infoBanque->code_pays_pre          = substr($iban_pre, 0, 2);
            $infoBanque->cle_iban_pre           = substr($iban_pre, 2, 2);
            $infoBanque->code_etablissement_pre = substr($iban_pre, 4, 5);
            $infoBanque->code_guichet_pre       = substr($iban_pre, 9, 5);
            $infoBanque->num_compte_pre         = substr($iban_pre, 14, 11);
            $infoBanque->cle_rib_pre            = substr($iban_pre, 25, 2);
            $infoBanque->code_bic_pre           = Crypt::encrypt($request->get('code_bic_pre'));

            $infoBanque->iban_pre               = Crypt::encrypt($iban_pre);

            if($request->has("iban_rem") and $request->get("iban_rem")){

                $iban_rem = str_replace('-', '', $request->get("iban_rem"));
            
                $infoBanque->nom_banque_rem         = $request->get('nom_banque_rem');
                $infoBanque->adresse_banque_rem     = $request->get('adresse_banque_rem');
                $infoBanque->ville_banque_rem       = $request->get('ville_banque_rem');
                $infoBanque->code_pays_rem          = substr($iban_rem, 0, 2);
                $infoBanque->cle_iban_rem           = substr($iban_rem, 2, 2);
                $infoBanque->code_etablissement_rem = substr($iban_rem, 4, 5);
                $infoBanque->code_guichet_rem       = substr($iban_rem, 9, 5);
                $infoBanque->num_compte_rem         = substr($iban_rem, 14, 11);
                $infoBanque->cle_rib_rem            = substr($iban_rem, 25, 2);
                $infoBanque->code_bic_rem           = Crypt::encrypt($request->get('code_bic_rem'));

                $infoBanque->iban_rem               = Crypt::encrypt($iban_rem);

            }

        }


        if($request->has("iban_pre") and $request->get("iban_pre")){

            if($infoBanque->save()){

                $statut                = Statut::whereSlug('nnSigne')->first();
                $fiche->statut_id      = $statut->id;
                $fiche->date_situation = Carbon::now();
                $fiche->save();

                //changer le statut de la fiche => nnsigne
                $idAction              = Action::whereSlug('SCP')->value('id');
                $tabInfoTrace          = [
                                            'idAction'       => $idAction,
                                            'idFiche'        => $fiche->id,
                                            'idStatut'       => $fiche->statut_id,
                                            'equipe_user_id' => $userInfo['equipe_user_id'],
                                            'tracable_id'    => $userInfo['tracable_id'],
                                            'tracable_type'  => $userInfo['tracable_type'],
                                            'observation'    => null,
                                            'motif'          => null
                                        ];
                event(new EventTracesObseque($tabInfoTrace));

            }

        }else if( $fiche->statut->groupeStatus->slug == "leads" ) {

            $statut                = Statut::whereSlug('devis')->first();
            $fiche->statut_id      = $statut->id;
            $fiche->date_situation = Carbon::now();
            $fiche->save();

        }


        $user = [];

        if(is_null($fiche->equipe_user_id)){
            $user = $fiche->dispatchable->responsable();
        }else{
            $user = $fiche->affectedUser($fiche->equipe_user_id);
        }

        $nomClient      = $fiche->client->nom;
        $prenomClient   = $fiche->client->prenom;
        $emailClient    = $fiche->client->email;
        $civiliteClient = $fiche->client->sexe;

        $data = [ 
                'nomConseiller'         => $user->nom,
                'prenomConseiller'      => $user->prenom,
                'telConseiller'         => $user->tel,
                'emailConseiller'       => $user->email,
                'faxConseiller'         => $user->fax,
                'logo'                  => $request->get('logo'),
                'civiliteClient'        => $fiche->client->sexe,
                'nomClient'             => $fiche->client->nom,
                'prenomClient'          => $fiche->client->prenom,
                'dateNaissanceClient'   => $fiche->client->date_naissance,
                'adresseClient'         => $fiche->client->adresse,
                'codePostalClient'      => $fiche->client->code_postal,
                'emailClient'           => $fiche->client->email,
                'telDomicileClient'     => $fiche->client->tel_domicile,
                'telMobileClient'       => $fiche->client->tel_mobile,
                'telBureauClient'       => $fiche->client->tel_bureau,
                'villeClient'           => $fiche->client->ville,
                'professionClient'      => $fiche->client->profession_id, 
                'sitFamilialeClient'    => $fiche->client->sit_familiale,
                'garantie'              => $request->get('garantie'), 
                'nomConjoint'           => '',
                'prenomConjoint'        => '',
                'dateNaissanceConjoint' => '',
                'nomCompagnie'          => $request->get('compagnie'),
                'lienCrm'               => public_path().'/uploads/BA'
            ];

        // lien serveur
        $produit          ='OBSEQUE';
        $dossierCompagnie = $request->get('compagnie');
        $verifydirectory  = 'upload/souscription/BA/'.$produit;
        //$linkPdf = Parametre::whereKey('dossier_pdf')->first()->value;
       
        if (!file_exists($verifydirectory)){

            $result = File::makeDirectory('upload/souscription/BA/'.$produit, 0777, true);

        }
        
        $dossierCompagnie    = str_replace(' ', '_', $dossierCompagnie);

        $verify    = 'upload/souscription/BA/'.$produit.'/'.$dossierCompagnie;
       
        if (!file_exists($verify)){

            $result = File::makeDirectory('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie, 0777, true);
        
        }

        $fileName   = uniqid();
        $gamme      = $garantie->gamme;
        $ba         = $gamme->code;
        $ba         = strtoupper(str_replace(' ', '', $ba));

        $souscription         = new SouscriptionObsequeController();
        $verifierSouscription = 1;
        $formule              = ''; 
        $tableau              = $souscription->{$ba}($user, $client, $fiche, $verifierSouscription, $formule);

        //Importer le fichier BA depuis le tarificateur
        $resultatImport       = $souscription->ImportFichierBA($ba);
        
        $pdf = new Pdf('upload/'.$ba.'.pdf');
        $pdf->allow('Printing')
            ->fillForm($tableau)
                ->needAppearances()
           ->saveAs('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

        $fiche->lien_pdf = asset('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');
        $fiche->save();
        $lienPdf = asset('upload/souscription/BA/'.$produit.'/'.$dossierCompagnie.'/'.$fileName.'.pdf');

        $info_fiche = [
                    'fiche_id'     => $fiche->id,
                    'prd_slug'     => $fiche->produit->slug
                ];
                    
        $collection = collect(event(new EventCreateProcessesLead($info_fiche)));
        $processes  = $collection->flatten(1);
        $processes->values()->all();

        return [
                'garantie'         => $garantie->libelle,
                'lienPdf'          => $lienPdf, 
                'dossierCompagnie' => $dossierCompagnie, 
                'fileName'         => $fileName, 
                'success'          => true, 
                'message'          => 'les informations sont enregistrées.', 'logo' => $request->get('logo'), 'nomClient' => $nomClient, 
                'prenomClient'     => $prenomClient, 
                'emailClient'      => $emailClient, 
                'civiliteClient'   => $civiliteClient, 
                'tarif'            => $request->get('info_montant'),
                'processes'        => $processes,
            ];

    }



}   
