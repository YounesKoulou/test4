@extends('layouts.admin')

@section('stylesheets')


    <meta name="csrf-token" id="csrf-token" content="<?php echo csrf_token() ?>"/>

    <link rel="stylesheet" href="{{ asset('components/kendo-ui/styles/kendo.common-material.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('components/kendo-ui/styles/kendo.material.min.css') }}"/>
    
    <!-- <link rel="stylesheet" href="{{ asset('assets/css/sweetalert.css') }}"/> -->
    <link rel="stylesheet" href="{{ asset('assets/css/sweetalert2.css') }}"/>
    <link rel="stylesheet" href="{{ asset('assets/css/rating.css') }}"/>

    {{ Html::style('assets/css/animatecss.css') }}
    {{ Html::style('assets/css/font-awesome.min.css') }}

    <style type="text/css">


        .progressLeads {
            border: 1px solid rgba(0, 0, 0, 0.12);
            position: relative;
            height: 6px;
            background: rgb(255, 0, 250);
            background: -moz-linear-gradient(left, rgba(255, 0, 0, 1) 0%, rgba(0, 255, 0, 1) 100%);
            background: -webkit-gradient(linear, left top, right top, color-stop(0%, rgba(255, 0, 0, 1)), color-stop(100%, rgba(0, 255, 0, 1)));
            background: -webkit-linear-gradient(left, rgba(255, 0, 0, 1) 0%, rgba(0, 255, 0, 1) 100%);
            background: -o-linear-gradient(left, rgba(255, 0, 0, 1) 0%, rgba(0, 255, 0, 1) 100%);
            background: -ms-linear-gradient(left, rgba(255, 0, 0, 1) 0%, rgba(0, 255, 0, 1) 100%);
            background: linear-gradient(to right, rgb(255, 94, 0) 0%, rgba(0, 255, 0, 1) 100%);
            filter: progid: DXImageTransform.Microsoft.gradient(startColorstr='#ff0000', endColorstr='#00ff00', GradientType=1);
        }

        .amountLeads {
            position: absolute;
            top: 0;
            right: 0;
            height: 100%;
            transition: all 0.8s;
            background: #eaeaea;
            width: 0;
        }

        .progressLeads:before {
            position: absolute;
            top: 0;
            left: 0;
            width: 40%;
            height: 100%;
            z-index: 10;
            text-align: center;
            line-height: 6px;
            font-size: 10px;
            color: black;
            padding-top: 2px;
        }

        .heightModal{
            height: 600px !important;
        }
        
        .not-found {
            display: table;
            font-weight: 100;
            font-family: 'Lato';
            text-align: center;
            display: table-cell;
            vertical-align: middle;
            display: inline-block;
            font-size: 90px;
            color: #C0C0C0;
        }

        .uk-dropdown, .uk-dropdown-blank {
           z-index: 99990;
           box-sizing: border-box;
          
        }
        .selection {
            background-color:#C6E5EF;

        }

        .uk-tooltip {
            z-index: 1350;
        }

        .displayTR {
            display: none;
        }

        .displayComment {
            
        }
                                                            
        .showTR {
            cursor: pointer;
        }
        .showComment {
            cursor: pointer;
        }
        .addIcon {
            color: white;
        }
        .iconSize {
            font-size: 25px;
            margin: 1px;
            color: #1e90ff;
        }
        .uk-subnav-pill > * > * {
            padding: 1px 2px !important;
        }
        .paddingCompagnie {
            padding: 3px 9px !important;
        }
        .img-tarif{
            height: 48px !important;
            margin-top: -5px !important;
            width: 48px !important;
        }
        .backgroundTarifColor{
            background-color: white !important;
        }
        .filterTarifColor{
            background-color: #FAFAFA !important;
        }
        .docTarifColor{
            background-color: #efebe9 !important;
        }
        .marginTarif{
            padding-top:15px !important;
        }
        .tdGarantie {
            text-align:right;
            padding-right: 10px;
            font-size: 16px;
        }
        .tdGarantie span:first-child {
            float:left;
        }

        .uk-table td {
            border: 1px solid black;
            border-color: rgba(192, 192, 192, 0.44);
        }

        .txtFilterTarif{
            font-size: 13px;
            margin-top: 5px;
            margin-bottom: 6px;
        }

        .imgCall{
            height: 40px !important;
            border: 10px !important;
        }

        .wzd > .uk-active {
            background-color: #00acc1 !important;
        }

        .wzd > .uk-active > a {
            color: #fff !important;
        }
        .renfort {
            min-height: 30px !important;
            padding-left: 15px !important;
        }
        
        .motif_header{
            /*background-image: url("{{ asset('assets/img/motif_header.png') }}") !important;
            background-repeat: repeat !important;*/
        }

    </style>

@stop


@section('processes')

    <div id="vueProc" class="uk-dropdown-grid">

        <ul class="uk-navbar-nav">

            <li v-for="process in processes">

                <a data-uk-tooltip v-title="process.libelle" href="#" style="cursor:default;" id="" class="">
                    
                    <i v-if="process.done" style="cursor:default;" class="material-icons md-icon md-fab md-24 md-fab-success md-light" v-html="process.icon"></i>

                    <i v-else style="cursor:default;" class="material-icons md-icon md-fab md-24 md-bg-grey-500" v-html="process.icon"></i>

                </a>

            </li>

        </ul>

    </div>

@endsection


@section('content')
    
    <div id="sante">

        <?php $profileSlug = Auth::user()->profile->slug; ?>

        <input type='hidden' value="{{ url($tarifLink) }}" name='tarif_link' id='tarif_link'>
        <input type='hidden' value="{{ $tarifKey }}" name='tarif_key' id='tarif_key'>
        <input type='hidden' value="{!! asset('upload/avatars/') !!}" name='url_base' id='url_base'>
        <input type='hidden' value="{{$profileSlug}}" name='profile_slug' id='profile_slug'>
        <input type='hidden' value="{{$fiche->produit_id}}" name='produit_id' id='produit_id'>
        <input type='hidden' value="{{$fiche->produit->slug}}" name='prdSlug' id='prdSlug'>
        <input type='hidden' value="{!! asset('storage/') !!}" name='url_record' id='url_record'>
        <input type='hidden' value="{{$fiche->options}}" name='optionsHidden' id='optionsHidden'>
        <input type='hidden' value="{{ $ibanApiKey }}" name='iban_api_key' id='iban_api_key'>
        <input type='hidden' value="{{ url($ibanApiLink) }}" name='iban_api_link' id='iban_api_link'>

        <div class="uk-grid">
            
            <div class="uk-width-1-1">

                <div v-bind:style="{backgroundColor:statut.couleur}" class="motif_header" id="page_heading" data-uk-sticky="{ top: 48, media: 960 }">

                    @include("shared.product_list_header")

                    @yield("call_history")
                    
                        <div class="heading_actions uk-margin-top">
                            <div data-uk-dropdown>
                                <i class="md-icon material-icons">&#xE5D4;</i>
                                <div class="uk-dropdown uk-dropdown-small">
                                    <ul class="uk-nav">

                                        <li><a href="#" id="getOriginalFiche" data-fiche="{{$fiche->id}}" data-slug="{{$fiche->produit->slug}}"  data-uk-modal><i class="material-icons">&#xE24D;</i> Originale Fiche</a></li>

                                        <li><a id="loadComments" data-fiche="{{ $fiche->id }}" data-slug="{{ $fiche->produit->slug }}"><i class="material-icons">&#xE253;</i> Commentaire</a></li>

                                        <li><a id="loadHistory" data-fiche="{{ $fiche->id }}" data-slug="{{ $fiche->produit->slug }}"  data-uk-modal><i class="material-icons">&#xE889;</i> Historique</a></li>

                                        <li><a href="#uploadModal" data-uk-modal><i class="material-icons">&#xE2C6;</i> Upload</a></li>

                                        @if($fiche->equipe_user_id != null)
                                            <li>
                                                <a href="#" id="loadEnvoiMail" data-fiche="{{ $fiche->id }}" data-produit="{{ $fiche->produit->id }}" data-uk-modal>
                                                    <i class="material-icons">&#xE0BE;</i> Envoi Email
                                                </a>
                                            </li>
                                        @endif

                                        @if($fiche->statut->slug=='santeDevisSigne' || $fiche->statut->groupeStatus->slug == 'contrats')
                                            <li><a target="_blank" href="{{ $fiche->signed_pdf }}"><i class="material-icons">&#xE14D;</i> Signature </a></li>
                                        @endif

                                        @yield('gestionMenu')

                                        <li><a href="#"><i class="material-icons">&#xE8AD;</i> Imprimer</a></li>

                                    </ul>
                                </div>
                            </div>

                            <a href="#newContratModal" data-uk-tooltip title="Sélectionner un produit" data-uk-modal><i class="addIcon md-icon md-fab md-fab-success material-icons">&#xE145;</i></a>
                            @if($access)
                                <a href="#multiDetModal" data-uk-tooltip data-uk-modal title="Multidétention" ><i class="md-icon md-fab md-fab-success material-icons">&#xE14D;</i></a>
                            @endif
                            <i data-uk-tooltip title="Détails" id="showInfoGeneral" class=" md-icon md-fab md-fab-success material-icons">&#xE313;</i>

                        </div>
                        
                        <div class="uk-grid ">

                            <div class="uk-width-medium-1-1">
                                
                                <ul v-bind:style="{backgroundColor:statut.couleur}" id="listGpPrd" class="uk-tab uk-tab-grid" >

                                    @foreach($groupeProduits as $groupeProduit)
                                        
                                        <li class=" @if($fiche->produit->groupeproduit_id == $groupeProduit->id) uk-active @endif">
                                            
                                            <a href="{{ url("groupeproduit/$groupeProduit->id/$fiche->client_id") }}">
                                                
                                                <span class=""> {{ $groupeProduit->libelle }}
                                                    
                                                    <span class="uk-text-right"> ({{ $groupeProduit->getNumberFiches($fiche->client_id) }})</span>
                                                
                                                </span>

                                            </a>

                                        </li>

                                    @endforeach

                                </ul>

                            </div>

                        </div>
   

                    </div>
                
                </div>
            
            </div>
     

            <?php

                $prefixe = Auth::user()->profile->slug;
                
            ?>

            <div id="getOriginalFiche" class="uk-modal">
                <div class="uk-modal-dialog uk-modal-dialog-large" style="text-align: center;">
                    <div class="uk-modal-header">
                        <p id="">
                            
                            <h3 class="heading_a uk-margin-bottom"><i class="material-icons">&#xE24D;</i> Originale Fiche</h3>
                        </p>
                    </div>
                    <p>            
                        <div class="uk-width-1-1">

                            <div id="" class="md-preloader uk-container-center" >

                                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="48"  width="48" viewbox="0 0 75 75">
                                    <circle cx="37.5" cy="37.5" r="33.5" stroke-width="4" />
                                </svg>
                                
                            </div>

                            <div id="">
                                <div class="uk-grid uk-grid-medium" data-uk-grid-margin>
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </p>
                    <div class="uk-modal-footer uk-text-right">
                        <button type="button" class="md-btn md-btn-flat uk-modal-close">Fermer</button>
                    </div>
                </div>
            </div>


            <div id="uk-grid">

                <div id="page_content_inner">

                        @if(Session::has('duplicate_message'))

                            <div class="uk-margin uk-alert uk-alert-danger" data-uk-alert>

                                <a class="uk-alert-close uk-close"></a>

                                {{ Session::get('duplicate_message') }}
                                
                            </div>

                        @endif


                    <div class="md-card uk-margin-medium-bottom">
                        <div class="md-card-content">
                            <div class="uk-grid">

                                <div class="uk-width-1-1">
                                       
                                    <div class="md-card md-card-warning ">
                                       
                                        <div id="infoGeneral" style="display:none;" class="md-card-content">

                                            <ul class="uk-tab" >
                                                @foreach($contrats as $contrat)
                                                    <li  @if($contrat->id == $fiche->id) class="uk-active" @endif>
                                                        <a href="{{ url($profileSlug.'/leads/sante/'.$contrat->slug) }}">
                                                            <i id="leadCol{{$contrat->id}}" @if($contrat->statut->id == $fiche->statut->id) v-bind:style="{color:statut.couleur}" @else style="color:{{ $contrat->statut->couleur }}" @endif class="material-icons">
                                                                {{ $contrat->produit->icon }}
                                                            </i>
                                                            <span class="uk-hidden-small" id="leadLib{{$contrat->id}}" @if($contrat->statut->id == $fiche->statut->id) v-text="statut.libelle" @endif>@if($contrat->statut->id != $fiche->statut->id) {{ $contrat->statut->libelle }} @endif </span>
                                                            <br>
                                                            {{ \Carbon\Carbon::parse($contrat->date_effet)->format('d/m/Y') }}
                                                        </a>
                                                    </li>
                                                @endforeach
                                            </ul>
                                            <br>

                                            <div class="uk-grid">

                                                <div class="uk-grid uk-width-1-1">

                                                    <div class="uk-margin-small uk-width-small-1-1 uk-width-medium-1-3 uk-width-large-1-3">
                                                                                
                                                        <span class="uk-text-right">Statut: </span>
                                                        
                                                        @yield('statutList')

                                                    </div>
                                                    
                                                    <div class="uk-margin-small uk-width-small-1-1 uk-width-medium-1-3 uk-width-large-1-3">
                                                        
                                                        <span class="uk-text-right">Inséré le: {{ \Carbon\Carbon::parse($fiche->date_insertion)->format('d/m/Y H:i') }}</span>
                                                    
                                                    </div>

                                                    <div class="uk-margin-small uk-width-small-1-1 uk-width-medium-1-3 uk-width-large-1-3">
                                                                                
                                                        <span class="uk-text-right">

                                                            Cette fiche attribué à:
                                                            <span id="affectedFiche">
                                                                @if($fiche->equipe_user_id)
                                                                    {{ $fiche->affectedUser($fiche->equipe_user_id)->login }} ({{ $fiche->affectedUser($fiche->equipe_user_id)->nom }} {{ $fiche->affectedUser($fiche->equipe_user_id)->prenom }})
                                                                @endif
                                                            </span>
                                                        
                                                        </span>
                                                    
                                                    </div>
                                                    
                                                </div>

                                                <div class="uk-grid uk-width-1-1">

                                                    <div class="uk-margin-small uk-width-small-1-1 uk-width-medium-1-3 uk-width-large-1-3">
                                                                                
                                                        <span class="uk-text-right">Source: </span>
                                                        <span class="uk-badge"> {{ $fiche->getGroupePubProv->getGroupePub->nom }} </span>
                                                    
                                                    </div>
                                                    
                                                    <div class="uk-margin-small uk-width-small-1-1 uk-width-medium-1-3 uk-width-large-1-3">
                                                                                
                                                        <span class="uk-text-right">Fiche Visualisée: </span>
                                                        <span class="uk-badge uk-badge-notification uk-badge-success"><b>{{ $fiche->nbr_vu }}</b></span>
                                                    
                                                    </div>

                                                    <div class="uk-margin-small uk-width-small-1-1 uk-width-medium-1-3 uk-width-large-1-3">
                                                                                
                                                        @yield('details')
                                                        
                                                    </div>
                                                    
                                                </div>
                                            </div> 
                                        </div>
                                        
                                    </div>
                                        
                                    @yield('dispaly_tab')

                                    @include('partage.externalLinks')

                                    
                                    <div class="md-card">

                                        <div class="md-card-content">
                                            
                                            <div class="uk-width-1-1">
                                                <div data-uk-tooltip id="barStatut" v-bind:title="statut.percentage+'%'" class="uk-width-1-1 progressLeads" v-bind:data-mount="(100 - statut.percentage)">
                                                    <div class="amountLeads" v-bind:style="{width:(100 - statut.percentage)+'%'}"></div>
                                                </div>
                                            </div>

                                        <div class="uk-grid uk-grid-divider" data-uk-grid-margin>

                                            <div class="infoPersonnel uk-width-medium-1-5">
                                                <form id="clientForm" >
                                                    <input name="_token" type="hidden" value="{!! csrf_token() !!}" />
                                                    <input id="etatSave" name="etatSave" type="hidden" value="1" />
                                                    <div class="uk-grid">
                                                        <div class="uk-width-medium-1-1">
                                                            <span id="msgClient">
                                                            </span>
                                                        </div>
                                                    </div>
                                                        <div class="uk-grid" data-uk-grid-margin>

    
                                                            <div class="uk-width-medium-1-1">
                                                                <label for="date_effet">Date Effet</label>
                                                                <input type="text" id="date_effet" name="date_effet" readonly="true" class="resetTarif md-input" data-uk-datepicker="{format:'DD/MM/YYYY', minDate:<?php echo -1*(\Carbon\Carbon::parse('now')->day -1 ); ?>, maxDate:365, i18n: { months:['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre']}}"  value="@if($fiche->date_effet and $fiche->date_effet!='0000-00-00 00:00:00'){{\Carbon\Carbon::parse($fiche->date_effet)->format('d/m/Y')}} @else{{\Carbon\Carbon::parse('now')->format('d/m/Y')}}@endif" />
                                                                <span class="uk-form-danger"></span>
                                                            </div>
                                                            
                                                        </div>
                                                        <div class="uk-grid" data-uk-grid-margin>
                                                            {{ Form::hidden('clientId', $fiche->client->id) }}
                                                            <div class="uk-width-medium-1-1">
                                                                <label for="nom">Nom</label>
                                                                <input class="md-input" type="text" v-model="nom" value="{{$fiche->client->nom}}" id="nom" name="nom" />
                                                                <span class="uk-form-danger"></span>
                                                            </div>
                                                            <div class="uk-width-medium-1-1">
                                                                <label for="prenom">Prenom</label>
                                                                <input class="md-input" type="text" v-model="prenom" value="{{$fiche->client->prenom}}" id="prenom" name="prenom" />
                                                                <span class="uk-form-danger"></span>
                                                            </div>
                                                        </div>
                                                        <div class="uk-grid" data-uk-grid-margin>
                                                            <div class="uk-width-medium-1-1">
                                                                <label for="civilite">Civilité</label>
                                                                <select name="civilite" data-md-selectize>
                                                                    <option value="M" {{ ($fiche->client->civilite == 'M') ? 'selected' : '' }}>
                                                                        M.
                                                                    </option>
                                                                    <option value="Mlle" {{ ($fiche->client->civilite == 'Mlle') ? 'selected' : '' }}>
                                                                        Mlle
                                                                    </option>
                                                                    <option value="Mme" {{ ($fiche->client->civilite == 'Mme') ? 'selected' : '' }}>
                                                                        Mme
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="uk-grid" data-uk-grid-margin>
                                                            
                                                            <div class="uk-width-medium-1-1">
                                                                <label for="sexe">Sexe</label>
                                                                <select name="sexe" data-md-selectize>
                                                                    <option value="H" {{ ($fiche->client->sexe == 'H') ? 'selected' : '' }}>
                                                                        Homme
                                                                    </option>
                                                                    <option value="F" {{ ($fiche->client->sexe == 'F') ? 'selected' : '' }}>
                                                                        Femme
                                                                    </option>
                                                                </select>
                                                            </div>
                                                        </div>

                                                        <div class="uk-grid" data-uk-grid-margin>
                                                            
                                                        </div>

                                                        <div class="uk-grid" data-uk-grid-margin>
                                                            <div class="uk-width-8-10 uk-input-group">
                                                                <label for="date_naissance">Date Naissance</label>
                                                                <input type="text" value="{{\Carbon\Carbon::parse($fiche->client->date_naissance)->format('d/m/Y')}}" name="date_naissance" id="date_naissance" required class="resetTarif md-input"  data-uk-datepicker="{format:'DD/MM/YYYY',maxDate:0,minDate:'01/01/1900', i18n: { months:['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre']}}"  readonly="true" />
                                                                <span class="uk-form-danger"></span>
                                                                {{ Form::hidden('ficheId', $fiche->id) }}
                                                            </div>
                                                            <div class="uk-width-2-10">
                                                                <a data-uk-tooltip title="@if($fiche->ani) ANI @else HORS ANI @endif" class="md-fab md-fab-small md-fab-primary md-fab-wave-light waves-effect waves-button waves-light" >
                                                                    <i style="font-size:22px" class="@if($fiche->ani) uk-icon-font @else uk-icon-header @endif"></i>
                                                                </a>
                                                            </div>
                                                        </div>

                                                        @if($access)
                                                            <div class="uk-grid" data-uk-grid-margin>
                                                                
                                                                <div class="uk-width-1-1">
                                                                    <label for="tel_mobile">Tel Mobile</label>
                                                                    <input class="md-input" type="text" value="{{ $fiche->client->tel_mobile }}" id="tel_mobile" name="tel_mobile" />
                                                                    <span class="uk-form-danger"></span>
                                                                </div>

                                                            </div>
                                                            <div class="uk-grid" data-uk-grid-margin>
                                                                <div class="uk-width-1-1">
                                                                    <label for="email">Email Personnel</label>
                                                                    <input class="md-input" type="text" value="{{$fiche->client->email}}" id="email" name="email" />
                                                                    <span class="uk-form-danger"></span>
                                                                </div>
                                                            </div>
                                                            <div class="uk-grid" data-uk-grid-margin>
                                                                <div class="uk-width-1-1">
                                                                    <label for="email_pro">Email Professionnel</label>
                                                                    <input class="md-input" type="text" value="{{$fiche->client->email_pro}}" id="email_pro" name="email_pro" />
                                                                    <span class="uk-form-danger"></span>
                                                                </div>
                                                            </div>
                                                        @endif

                                                        <div class="uk-grid" data-uk-grid-margin>
                                                            <div class="uk-width-medium-1-1">
                                                                <label for="saregime_id">Régime</label>
                                                                @if($fiche->saregime_id)
                                                                    <select class='resetTarif' id="saregime_id" name="saregime_id" data-md-selectize>
                                                                        @foreach($regimes as $regime)
                                                                            <option value="{{$regime->id}}" {{ ($fiche->saregime_id == $regime->id) ? 'selected' : '' }}>
                                                                                {{$regime->libelle}}
                                                                            </option>
                                                                        @endforeach
                                                                    </select>
                                                                @else
                                                                    <select class='resetTarif' id="saregime_id" name="saregime_id" data-md-selectize>
                                                                        <option value="{{$regimePardefaut->id}}" selected>{{$regimePardefaut->libelle}}</option>
                                                                        @foreach($regimes as $regime)
                                                                            <option value="{{$regime->id}}" {{ ($fiche->saregime_id == $regime->id) ? 'selected' : '' }}>
                                                                                {{$regime->libelle}}
                                                                            </option>
                                                                        @endforeach
                                                                    </select>
                                                                @endif
                                                                <span class="uk-form-danger"></span>
                                                            </div>
                                                        </div>
                                                        
                                                    </form>
                                            </div>
                                            <div class="infoFiche uk-width-medium-4-5">

                                                 <div class="md-card">

                                                    <div class="md-card-toolbar">
                                                                                    
                                                        <div class="md-card-toolbar-actions">
                                                    
                                                            <span style='display: inline;' id="tarif_list_filter2" >
                                                            </span>

                                                            <i data-uk-tooltip title="Detail Prestation" class="md-icon material-icons" data-uk-modal="{target:'#modal_overflow'}" id="detailPrestations" style="display: none;">&#xE875;</i>

                                                            <i data-uk-tooltip title="Envoyer la proposition" id="iconeProposition" data-client="{{ $fiche->client_id }}" data-fiche="{{ $fiche->num_fiche }}" style="display: none;" class="md-icon material-icons">&#xE0BE;</i>

                                                            <i data-uk-tooltip title="Prestations" id="showFilterRate" class="md-icon material-icons">&#xE8C1;</i>

                                                            <i data-uk-tooltip title="Agrandir" class="md-icon material-icons md-card-fullscreen-activate">&#xE5D0;</i>

                                                            <i data-uk-tooltip title="Changer dimension" class="md-icon material-icons affichage" id="">&#xE915;</i>
                                                        </div>
                                                
                                                
                                                    </div>

                                            
                                            <div class="md-card">
                                               
                                                <div class="md-card-content">

                                                    <ul class="uk-tab uk-tab-grid ad-tab wzd" data-uk-switcher="{connect:'#tabs_wizard', animation:'slide-horizontal'}">
                                                        <li class="{{ $divClass }} uk-active"><a href="#"><i class="uk-icon-user uk-icon-small"></i> Assuré</a></li>
                                                        @if($access and $displayTab)
                                                            <li class="{{ $divClass }}" id="comparateur"><a href="#" data-uk-switcher-item="0"><i class="uk-icon-sliders uk-icon-small"></i> Comparateur</a></li>
                                                        @endif
                                                        <li class="{{ $divClass }}" id="souscription"><a href="#" data-uk-switcher-item="1"><i class="uk-icon-credit-card uk-icon-small"></i> Souscription</a data-uk-switcher-item="2"></li>
                                                    </ul>

                                                   
                                                    <ul id="tabs_wizard" class="uk-switcher uk-margin">
                                                        <li>
                                                        <section>

                                                    <div class="uk-grid">
                                                    
                                                    <div class="uk-width-medium-1-2 uk-width-small-1-1">
                                                    
                                                        <div class="md-card md-card-primary" style="background-color:#E7F1F4;">
                                                            <div class="md-card-toolbar">
                                                                <div class="md-card-toolbar-actions">
                                                                    <i class="md-icon material-icons md-card-toggle">&#xE316;</i>
                                                                </div>
                                                                <h3 class="md-card-toolbar-heading-text">
                                                                    Les informations de l'assuré
                                                                </h3>
                                                            </div>
                                                            <div class="md-card-content">
                                                                <form  id="formAssure">
                                                                    <div class="uk-grid" uk-margin>
                                                                        
                                                                        <div class="uk-width-medium-1-2">
                                                                            <label for="sit_familiale">Situation familiale</label>
                                                                            <select data-md-selectize name="sit_familiale">
                                                                                <option value="C" {{ ($fiche->client->sit_familiale == 'C') ? 'selected' : '' }} >
                                                                                    Célibataire
                                                                                </option>
                                                                                <option class="selection" value="D" {{ ($fiche->client->sit_familiale == 'D') ? 'selected' : '' }}>
                                                                                    Divorcé (e)
                                                                                </option>
                                                                                <option value="M" {{ ($fiche->client->sit_familiale == 'M') ? 'selected' : '' }}>
                                                                                    Marié (e)
                                                                                </option>
                                                                                <option value="V" {{ ($fiche->client->sit_familiale == 'V') ? 'selected' : '' }}>
                                                                                    Veuf (ve)
                                                                                </option>
                                                                                <option value="N" {{ ($fiche->client->sit_familiale == 'N') ? 'selected' : '' }}>
                                                                                    Concubin (e)
                                                                                </option>
                                                                                <option value="P" {{ ($fiche->client->sit_familiale == 'P') ? 'selected' : '' }}>
                                                                                    Partenaire lié par PAC'S
                                                                                </option>
                                                                            </select>
                                                                        </div>

                                                                    </div>
                                                                    
                                                                    <div class="uk-grid" uk-margin>

                                                                        <div class="uk-width-medium-1-2">
                                                                            <label for="code_postal">Code postal</label>
                                                                            <input v-model="code" v-on:keyup.enter="getCities(this.code)" focus="true" class="resetTarif md-input" type="text" value="{{$fiche->client->code_postal}}" id="code_postal" name="code_postal" />
                                                                            <span class="uk-form-danger"></span>
                                                                        </div>
                                            
                                                                        <div class="uk-width-medium-1-2">
                                                                            <label for="">Ville</label>
                                                                                <input v-model="ville" v-on:keyup.enter="getCities(this.ville)" class=" md-input" type="text" value="{{$fiche->client->ville}}" id="ville" name="ville" />
                                                                            <span class="uk-form-danger"></span>
                                                                        </div>

                                                                        <div id="output" class="uk-width-medium-1-1">
                                                                            
                                                                            <ul>
                                                                                <li v-for="city in cities">
                                                                                    <a href="#" v-on:click="chooseCity(city)" v-text="city.code+' '+city.city"></a>
                                                                                </li>
                                                                            </ul>
                                                                            
                                                                        </div>
                                                                    
                                                                    </div>

                                                                    <div class="uk-grid" uk-margin>
                                                                        
                                                                        <div class="uk-width-8-10">
                                                                            <label for="adresse">Adresse</label>
                                                                            <input class="md-input" type="text" v-model="adresse" value="{{$fiche->client->adresse}}" id="adresse" name="adresse" />
                                                                            <span class="uk-form-danger"></span>
                                                                        </div>
                                                                        
                                                                        <div class="uk-width-2-10">
                                                                            <a href="#gmModal" data-uk-modal data-uk-tooltip  title="Géocalisation" class="md-fab md-fab-small md-fab-danger md-fab-wave-light waves-effect waves-button waves-light" >
                                                                                <i class="uk-icon-map-marker"  style="font-size:24px"></i>
                                                                            </a>
                                                                        </div>

                                                                    </div>

                                                                    <div class="uk-grid" uk-margin>
                                                                        <div class="uk-width-medium-1-1">
                                                                            <label for="profession">Profession</label>
                                                                            <select data-md-selectize id="profession" name="profession">
                                                                                <option value="" ></option>
                                                                                @foreach($professions as $profession)
                                                                                    <option class="selection" value="{{$profession->id}}" {{ ($fiche->client->profession && $fiche->client->profession->id == $profession->id) ? 'selected' : '' }}>
                                                                                        {{$profession->libelle}}
                                                                                    </option>
                                                                                @endforeach
                                                                            </select>
                                                                            <span class="uk-form-danger"></span>
                                                                        </div>
                                                                    </div>

                                                                    <div id="gmModal" class="uk-modal" >
                                                                        <div class="uk-modal-dialog uk-modal-dialog-large" style="text-align: center;" >
                                                                            <a data-uk-tooltip title="Fermer" class="uk-modal-close uk-close"></a>
                                                                            <div class="uk-modal-content heightModal" >
                                                                                <iframe class="uk-width-1-1" height="100%" v-bind:src="mapLink"></iframe>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                </form>
                                                            </div>
                                                        </div>

                                                    </div>

                                                    <div class="uk-width-medium-1-2 uk-width-small-1-1">

                                                        <div class="md-card md-card-primary" style="background-color:#E7F1F4;">
                                                            <div class="md-card-toolbar">
                                                                @if($access)
                                                                <div class="md-card-toolbar-actions">
                                                                    <i class="md-icon material-icons md-card-toggle">&#xE316;</i>
                                                                    <i class='resetTarif md-icon material-icons md-color-red-500' onclick="deleteConjoint()" @if(count($fiche->conjoint)>0) style='display: inline;' @else style='display: none;' @endif id="deleteIconConjoint" data-uk-modal>&#xE872;</i>
                                                                    <a class='resetTarif'  @if(count($fiche->conjoint)>0) style='display: none;' @else style='display: inline;' @endif id="addIconConjoint" onclick="addIconConjoint()" >
                                                                        <i class="md-icon material-icons md-color-green-500">&#xE145;</i>
                                                                    </a>
                                                                </div>
                                                                @endif
                                                                <h3 class="md-card-toolbar-heading-text">
                                                                    Le conjoint
                                                                </h3>
                                                            </div>

                                                            <div class="md-card-content">
                                                            <span id="form_conjoint">
                                                                @if(count($fiche->conjoint)>0)

                                                                <form id="formConjoint">
                                                                    <input id="has_conjoint" name="has_conjoint" type="hidden" value="1"> 
                                                                        <div class="uk-grid">
                                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                                <div class="uk-input-group">
                                                                                    <span class="uk-input-group-addon">
                                                                                        <i class=" uk-icon-justify uk-icon-user"></i>
                                                                                    </span>
                                                                                    <label for="conjoint_nom">Nom</label>
                                                                                    <input type="text" class="md-input" name="conjoint_nom" value="@if($fiche->conjoint){{$fiche->conjoint->nom}}@endif" />
                                                                                </div>
                                                                            </div>
                                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                                <div class="uk-input-group">
                                                                                    <span class="uk-input-group-addon">
                                                                                        <i class=" uk-icon-justify uk-icon-user"></i>
                                                                                    </span>
                                                                                    <label for="conjoint_prenom">Prenom</label>
                                                                                    <input type="text" class="md-input" name="conjoint_prenom" value="@if($fiche->conjoint){{$fiche->conjoint->prenom}}@endif" />
                                                                                    <span class="uk-form-danger"></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="uk-grid">
                                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                                <div class="uk-input-group">
                                                                                    <span class="uk-input-group-addon">
                                                                                        <i class=" uk-icon-justify uk-icon-genderless"></i>
                                                                                    </span>
                                                                                    <label for="conjoint_civilite">Civilité</label>
                                                                                    <select data-md-selectize name="conjoint_civilite">
                                                                                        <option value="M" {{ ($fiche->conjoint->civilite == 'M') ? 'selected' : '' }}>
                                                                                            M.
                                                                                        </option>
                                                                                        <option value="Mlle" {{ ($fiche->conjoint->civilite == 'Mlle') ? 'selected' : '' }}>
                                                                                            Mlle
                                                                                        </option>
                                                                                        <option value="Mme" {{ ($fiche->conjoint->civilite == 'Mme') ? 'selected' : '' }}>
                                                                                            Mme
                                                                                        </option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                                <div class="uk-input-group">
                                                                                    <span class="uk-input-group-addon">
                                                                                        <i class=" uk-icon-justify uk-icon-venus-mars"></i>
                                                                                    </span>
                                                                                    <label for="conjoint_sexe">Sexe</label>
                                                                                    <select data-md-selectize name="conjoint_sexe">
                                                                                        <option value="H" {{ ($fiche->conjoint->sexe == 'H') ? 'selected' : '' }}>
                                                                                            Homme
                                                                                        </option>
                                                                                        <option value="F" {{ ($fiche->conjoint->sexe == 'F') ? 'selected' : '' }}>
                                                                                            Femme
                                                                                        </option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="uk-grid">
                                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                                <div class="uk-input-group">
                                                                                    <span class="uk-input-group-addon">
                                                                                        <i class=" uk-icon-justify uk-icon-group"></i>
                                                                                    </span>
                                                                                    <label for="conjoint_sit_familiale">Situation familiale</label>
                                                                                    <select data-md-selectize name="conjoint_sit_familiale">
                                                                                        <option value="C" {{ ($fiche->conjoint->sit_familiale == 'C') ? 'selected' : '' }}>
                                                                                            Célibataire
                                                                                        </option>
                                                                                        <option value="D" {{ ($fiche->conjoint->sit_familiale == 'D') ? 'selected' : '' }}>
                                                                                            Divorcé (e)
                                                                                        </option>
                                                                                        <option value="M" {{ ($fiche->conjoint->sit_familiale == 'M') ? 'selected' : '' }}>
                                                                                            Marié (e)
                                                                                        </option>
                                                                                        <option value="V" {{ ($fiche->conjoint->sit_familiale == 'V') ? 'selected' : '' }}>
                                                                                            Veuf (ve)
                                                                                        </option>
                                                                                        <option value="N" {{ ($fiche->conjoint->sit_familiale == 'N') ? 'selected' : '' }}>
                                                                                            Concubin (e)
                                                                                        </option>
                                                                                        <option value="P" {{ ($fiche->conjoint->sit_familiale == 'P') ? 'selected' : '' }}>
                                                                                            Partenaire lié par PAC'S
                                                                                        </option>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                                <div class="uk-input-group">
                                                                                    <span class="uk-input-group-addon">
                                                                                        <i class=" uk-icon-justify uk-icon-calendar"></i>
                                                                                    </span>
                                                                                    <label for="conjoint_date_naissance">Date naissance</label>
                                                                                    <input type="text" name="conjoint_date_naissance" id="conjoint_date_naissance"  class="resetTarif md-input"  data-uk-datepicker="{format:'DD/MM/YYYY',maxDate:0,minDate:'01/01/1900', i18n: { months:['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre']}}" value="@if($fiche->conjoint){{\Carbon\Carbon::parse($fiche->conjoint->date_naissance)->format('d/m/Y')}}@endif" readonly="true"/>
                                                                                    <span class="uk-form-danger"></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="uk-grid">
                                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                                <div class="uk-input-group">
                                                                                    <span class="uk-input-group-addon">
                                                                                        <i class=" uk-icon-justify uk-icon-registered"></i>
                                                                                    </span>
                                                                                    <label for="conjoint_saregime_id">Régime</label>
                                                                                    <select data-md-selectize class='resetTarif' id="conjoint_saregime_id" name="conjoint_saregime_id">
                                                                                        <option value=""></option>
                                                                                        @foreach($regimes as $regime)
                                                                                            <option value="{{$regime->id}}" @if($fiche->conjoint) {{ ($fiche->conjoint->saregime_id == $regime->id) ? 'selected' : '' }} @endif>
                                                                                                {{$regime->libelle}}
                                                                                            </option>
                                                                                        @endforeach
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <input type="hidden" value="@if($fiche->conjoint) {{ $fiche->conjoint->id }} @else 0 @endif" name="conjoint_id" id="conjoint_id">
                                                                
                                                                </form>
                                                                @endif
                                                                
                                                                </span>
                                                                                                            
                                                            </div>

                                                        </div>

                                                    </div>
                                                    </div>

                                                    <div class="uk-width-1-1 uk-margin-top">

                                                        <div class="md-card md-card-primary" style="background-color:#E7F1F4;">
                                                                <div class="md-card-toolbar">
                                                                    @if($access)
                                                                    <div class="md-card-toolbar-actions">
                                                                       <i class="md-icon material-icons md-card-toggle">&#xE316;</i>
                                                                        <a data-id="{{ $fiche->enfants->count() }}" class="resetTarif" id="addChild" onclick="addChild()" >
                                                                            <i class="md-icon material-icons md-color-green-500">&#xE145;</i>
                                                                        </a>

                                                                    </div>
                                                                    @endif
                                                                    <h3 class="md-card-toolbar-heading-text">
                                                                        Les enfants 
                                                                        <span class="sub-heading">
                                                                            <span id="nbrChild" class="uk-badge uk-badge-notification uk-badge-primary">
                                                                                {{ $fiche->enfants->count() }}
                                                                            </span> 
                                                                        </span>
                                                                    </h3>
                                                                </div>
                                                                <div class="md-card-content">
                                                                <form id="formChildren">
                                                                    <ul id="childen" >
                                                                    
                                                                        @forelse ($fiche->enfants as $index => $enfant)
                                                                            <li class=" uk-margin-top " id="child{{$index+1}}">
                                                                                <div class="uk-grid">
                                                                                    <div class="uk-width-medium-1-10 uk-width-small-1-1 uk-margin-small-bottom uk-input-group">
                                                                                        <label for="enfant[{{$index+1}}][sexe]">Sexe</label>
                                                                                        <select data-md-selectize id="sexe{{$index+1}}" name="enfant[{{$index+1}}][sexe]" class="md-input" >
                                                                                            <option value="H" {{ ($enfant->sexe == 'M') ? 'selected' : '' }}>
                                                                                                M
                                                                                            </option>
                                                                                            <option value="F" {{ ($enfant->sexe == 'F') ? 'selected' : '' }}>
                                                                                                F
                                                                                            </option>
                                                                                        </select>
                                                                                    </div>
                                                                                    <div class="uk-width-medium-2-10 uk-width-small-1-1 uk-margin-small-bottom uk-input-group">
                                                                                        <label for="enfant[{{$index+1}}][nom]">Nom</label>
                                                                                        <input id="nom{{$index+1}}" type="text" class="md-input" name="enfant[{{$index+1}}][nom]" value="{{$enfant->nom}}" />
                                                                                    </div>
                                                                                    <div class="uk-width-medium-2-10 uk-width-small-1-1 uk-margin-small-bottom uk-input-group">
                                                                                        <label for="enfant[{{$index+1}}][prenom]">Prenom</label>
                                                                                        <input id="prenom{{$index+1}}" type="text" class="md-input" name="enfant[{{$index+1}}][prenom]" value="{{$enfant->prenom}}" />
                                                                                    </div>
                                                                                    <div class="uk-width-medium-2-10 uk-width-small-1-1 uk-margin-small-bottom uk-input-group">
                                                                                        <label for="enfant[{{$index+1}}][date_naissance]">Date naissance</label>
                                                                                        <input id="dn{{$index+1}}" type="text" name="enfant[{{$index+1}}][date_naissance]" data-id="{{$index+1}}" class="resetTarif child_DN md-input" data-uk-datepicker="{format:'DD/MM/YYYY',maxDate:0,minDate:'01/01/1900'}" value="{{\Carbon\Carbon::parse($enfant->date_naissance)->format('d/m/Y')}}" readonly="true"/>
                                                                                        <span class="uk-form-danger"></span>
                                                                                    </div>
                                                                                    <div class="uk-width-medium-2-10 uk-width-small-1-1 uk-margin-small-bottom uk-input-group">
                                                                                        <label for="enfant[{{$index+1}}][ayant_droit]">Ayant Droit</label>
                                                                                        <select data-md-selectize id="ad{{$index+1}}" class="resetTarif child_conjoint md-input"  name="enfant[{{$index+1}}][ayant_droit]">
                                                                                            <option value="P" {{ ($enfant->ayant_droit == 'P') ? 'selected' : '' }}>
                                                                                                Prospect
                                                                                            </option>
                                                                                            <option value="C" {{ ($enfant->ayant_droit == 'C') ? 'selected' : '' }}>
                                                                                                Conjoint
                                                                                            </option>
                                                                                        </select>
                                                                                    </div>
                                                                                    <div class="uk-width-medium-1-10 uk-width-small-1-1 uk-margin-small-bottom uk-input-group">
                                                                                        <input id="ide{{$index+1}}" type="hidden" value="{{ $enfant->id }}" name="enfant[{{$index+1}}][id]">
                                                                                        @if($access) 
                                                                                            <i data-id="{{$index+1}}" data-origin="1" id="delete{{$index+1}}" class="deleteChild childrenList resetTarif md-icon material-icons md-color-red-500" onclick="deleteChild({{$index+1}})" >
                                                                                                delete 
                                                                                            </i>
                                                                                        @endif
                                                                                    </div>
                                                                                </div>
                                                                                <hr class="uk-hidden-medium uk-hidden-large uk-margin">
                                                                            </li>
                                                                        @empty
                                                                            
                                                                        @endforelse
                                                                    </ul>
                                                                    </form>
                                                         
                                                                </div>

                                                            </div>

                                                        </div> 
                                                        <div class="uk-width-1-1 uk-margin-top">
                                                            <div class="md-card md-card-primary" style="background-color:#E7F1F4;">
                                                                <div class="md-card-toolbar">                                                                   
                                                                    <h3 class="md-card-toolbar-heading-text">
                                                                        Questionnaire: 
                                                                    </h3>
                                                                </div>
                                                                <div class="md-card-content">
                                                                <form id="formGrpQst" class="uk-form">
                                                                <ul class="uk-list">
                                                                @foreach ($groupeQsts as $indexGrp => $groupeQst)
                                                                  <li class="uk-margin-top">
                                                                    <div class="uk-grid">
                                                                    <input type="text" hidden value="{{$groupeQst->id}}" name="groupeQst" id="groupeQst">
                                                                        <div class="uk-width-medium-1-2">
                                                                            <h3>{{$groupeQst->libelle}}</h3>
                                                                        </div>
                                                                        <div class="uk-width-medium-1-2">
                                                                            <span class="">
                                                                                <input type="radio" name="radioGrpQst" onclick="showDivQstOui({{$indexGrp+1}})" id="radioGrpQstOui{{$indexGrp+1}}" value="1" {{ ($fiche->choixGrpQst === 1) ? 'checked' : '' }}/>
                                                                                <label for="radioGrpQstOui{{$indexGrp+1}}" class="inline-label">Oui</label>
                                                                            </span>
                                                                            <span class="">
                                                                                <input type="radio" name="radioGrpQst" onclick="showDivQstNon({{$indexGrp+1}})" id="radioGrpQstNon{{$indexGrp+1}}" value="0" {{ ($fiche->choixGrpQst === 0) ? 'checked' : '' }}/>
                                                                                <label for="radioGrpQstNon{{$indexGrp+1}}" class="inline-label">Non</label>
                                                                            </span>                                                                            
                                                                        </div>
                                                                    </div>
                                                                    
                                                                    <div class="uk-grid uk-margin-top" id="divQstOui{{$indexGrp+1}}"  @if(isset($fiche->choixGrpQst)) @if($fiche->choixGrpQst == 1)  style="display:block" @else style="display:none" @endif @else style="display:none" @endif >    
                                                                        <div class="uk-width-1-1 uk-container-center">
                                                                        @forelse ($groupeQst->questionnairesOui as $indexQst => $questionnaireOui)
                                                                        <div class="uk-grid">
                                                                            <div class="uk-width-medium-1-2 ">
                                                                                {{ $questionnaireOui->libelle }}
                                                                            </div>
                                                                            <div class="uk-width-medium-1-2 ">
                                                                              
                                                                                      <select data-md-selectize id="reponseQuestionOui[{{$questionnaireOui->id}}][reponse]" name="reponseQuestionOui[{{$questionnaireOui->id}}][reponse]" class="md-input" >
                                                                                      <option value="">Selectionner une réponse !</option>
                                                                                      @foreach ($questionnaireOui->reponseQuestionnaires as $indexRepQst => $reponseQuestionnaire)
                                                                                        <option value="{{$reponseQuestionnaire->id}}"  @if($fiche->questionnaireExist($questionnaireOui->id)) @if($fiche->ficheQuestionnaire($questionnaireOui->id)->reponsequestionnaire_id == $reponseQuestionnaire->id)  selected @else '' @endif @endif>
                                                                                            {{$reponseQuestionnaire->libelle}}
                                                                                        </option>
                                                                                       
                                                                                            
                                                                                        @endforeach
                                                                                    </select>
                                                                             
                                                                            </div> 
                                                                        </div>    
                                                                            
                                                                        @empty
                                                                            <p>Pas de question !</p>
                                                                        @endforelse                                                                            
                                                                        </div>
                                                                    </div>
                                                                    <div class="uk-grid uk-margin-top" id="divQstNon{{$indexGrp+1}}" @if(isset($fiche->choixGrpQst)) @if($fiche->choixGrpQst == 0)  style="display:block" @else style="display:none" @endif @else style="display:none" @endif>    
                                                                        <div class="uk-width-1-1 uk-container-center">
                                                                        <ul class="uk-list">
                                                                           @forelse ($groupeQst->questionnairesNon as $indexQst => $questionnaireNon)
                                                                              <li class="uk-margin-top">

                                                                                <div class="uk-grid">
                                                                                    <div class="uk-width-medium-1-2  ">
                                                                                        {{ $questionnaireNon->libelle }}
                                                                                    </div>
                                                                                    <div class="uk-width-medium-1-2  ">
                                                                                        
                                                                                        <select data-md-selectize id="reponseQuestionNon[{{$questionnaireNon->id}}][reponse]" name="reponseQuestionNon[{{$questionnaireNon->id}}][reponse]" class="md-input" >
                                                                                          <option value="">Selectionner une réponse !</option>
                                                                                          @foreach ($questionnaireNon->reponseQuestionnaires as $indexRepQst => $reponseQuestionnaire)
                                                                                            <option value="{{$reponseQuestionnaire->id}}" @if($fiche->questionnaireExist($questionnaireNon->id))  @if($fiche->ficheQuestionnaire($questionnaireNon->id)->reponsequestionnaire_id == $reponseQuestionnaire->id)  selected @else '' @endif @endif>
                                                                                                {{$reponseQuestionnaire->libelle}}
                                                                                            </option>
                                                                                           
                                                                                            @endforeach
                                                                                        </select>

                                                                                      
                                                                                    </div>
                                                                                </div>
                                                                            
                                                                              </li>
                                                                            @empty
                                                                                <p>Pas de question !</p>
                                                                            @endforelse 
                                                                        </ul>

                                                                        </div>
                                                                    </div>
                                                                  </li>
                                                                @endforeach
                                                                </ul>
                                                                </form>
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
                                                                 
                                            </section>
                                        </li>

                                     @if($access and $displayTab)
                                      <li>
                                           <section>
                                            <div class='uk-grid' id="rateDiv" >
                                                <div class='uk-width-8-10'>
<!--                                                     <div class='uk-grid'>
                                                        <div class='uk-width-1-4'>
                                                            <span data-uk-tooltip title='Soins' >
                                                                <img style='width:50px; margin-top: 1px;margin-right:4px;' class='uk-float-left' src={{asset('assets/img/soins.gif')}}> 
                                                                <span class='txtFilterTarif uk-badge'><span id='soinVal'>100</span>%</span>
                                                            </span>
                                                            <div  id="star-soins">
                                                                <input type="radio" name="rateSoins" class="rating" value="100" checked />
                                                                <input type="radio" name="rateSoins" class="rating" value="200" />
                                                                <input type="radio" name="rateSoins" class="rating" value="300" />
                                                                <input type="radio" name="rateSoins" class="rating" value="400" />
                                                                <input type="radio" name="rateSoins" class="rating" value="500" />
                                                            </div>
                                                        </div>
                                                        
                                                        <div class='uk-width-1-4'>
                                                            <span data-uk-tooltip title='Hospitalisation' >
                                                                <img style='width:50px; margin-top: 1px;margin-right:4px;' class='uk-float-left' src={{asset('assets/img/hospitalisation.gif')}}> 
                                                                <span class='txtFilterTarif uk-badge'><span id='hospitaVal'>100</span>%</span>
                                                            </span> 
                                                            <div id="star-hospita">
                                                                <input type="radio" name="rateHospiat" class="rating" value="100" checked />
                                                                <input type="radio" name="rateHospiat" class="rating" value="200" />
                                                                <input type="radio" name="rateHospiat" class="rating" value="300" />
                                                                <input type="radio" name="rateHospiat" class="rating" value="400" />
                                                                <input type="radio" name="rateHospiat" class="rating" value="500" />
                                                            </div>
                                                        </div>
                                                        <div class='uk-width-1-4'>
                                                            <span data-uk-tooltip title='Optique' >
                                                                <img style='width:50px; margin-top: 1px;margin-right:4px;' class='uk-float-left' src={{asset('assets/img/optique.gif')}}> 
                                                                <span class='txtFilterTarif uk-badge'><span id='optiqueVal'>100</span>&euro;</span>
                                                            </span>
                                                            <div id="star-optique">
                                                                <input type="radio" name="rateOptique" class="rating" value="100" checked />
                                                                <input type="radio" name="rateOptique" class="rating" value="200" />
                                                                <input type="radio" name="rateOptique" class="rating" value="300" />
                                                                <input type="radio" name="rateOptique" class="rating" value="400" />
                                                                <input type="radio" name="rateOptique" class="rating" value="500" />
                                                            </div>
                                                        </div>
                                                        <div class='uk-width-1-4'>
                                                            <span data-uk-tooltip title='Dentaire' >
                                                                <img style='width:50px; margin-top: 1px;margin-right:4px;' class='uk-float-left' src={{asset('assets/img/dentaire.gif')}}> 
                                                                <span class='txtFilterTarif uk-badge'><span id='dentaireVal'>100</span>%</span>
                                                            </span>
                                                            <div id="star-dentaire">
                                                                <input type="radio" name="rateDentaire" class="rating" value="100" checked />
                                                                <input type="radio" name="rateDentaire" class="rating" value="200" />
                                                                <input type="radio" name="rateDentaire" class="rating" value="300" />
                                                                <input type="radio" name="rateDentaire" class="rating" value="400" />
                                                                <input type="radio" name="rateDentaire" class="rating" value="500" />
                                                            </div>
                                                        </div>
                                                    </div> -->
                                                </div>
                                                <div class=' uk-width-2-10 uk-text-right'>

                                                    <input id='sans-prestation' name='sans-prestation' type='checkbox'  > Toutes Prestations

                                                    <i data-uk-tooltip title="Générer Tarif" class="md-icon material-icons loadTarif" id="simpleTarif">&#xE028;</i>

                                                </div>
                                            </div>
                                            <br>
                                            <div class='uk-width-1-1 not-found uk-container-center uk-margin-top' id="preloadCompagnies"></div>

                                                <div class="uk-grid" id="new_tarif"   >

                                                    <div id='newTarifList' class="uk-width-1-1">

                                                        

                                                    </div>

                                                </div>
                                                    
                                            
                                            
                                            </section>
                                        </li>
                                    @endif

                                    <li>
                                        <section>
                                            
                                            <div class="md-card md-card-primary">
                                                <div class="md-card-toolbar">
                                                    <h3 class="md-card-toolbar-heading-text">
                                                        Info Contrat
                                                    </h3>
                                                </div>
                                                <div class="md-card-content">
                                                    
                                                    <form id="form_info_contrat" name"form_info_contrat">

                                                    <input type="text" hidden value="{{ $fiche->num_fiche }}" name="ficheNum" id="ficheNum">
                                                    <input type="text" hidden value="{{ $fiche->client_id }}" name="clientId" id="clientId">
                                                    <input type="text" hidden value="{{$fiche->client->civilite}}" name="civilitee" id="civilitee">
                                                    <input type="text" hidden value="" name="logo" id="logo">
                                                    <input type="text" hidden value="TEST" name="compagnie" id="compagnie">
                                                    <input type="text" hidden value="" name="gamme" id="gamme">
                                                    <input type="text" hidden value="" name="garantie" id="garantie">
                                                    <input type="text" hidden value="SANTE" name="produit" id="produit">
                                                    <input type="text" hidden value="{{ $fiche->cotisation }}" name="tarif" id="tarif">
                                                        <div class="uk-grid">
                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                <div class="uk-input-group">
                                                                    <span class="uk-input-group-addon">
                                                                        <i class="material-icons">&#xE8E7;</i>
                                                                    </span>
                                                                    <label for="info_num_contrat">Numéro Contrat</label>
                                                                    <input readonly type="text" class="md-input" name="info_num_contrat" value="{{ $fiche->num_fiche }}" />
                                                                </div>
                                                            </div>
                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                <div class="uk-input-group">
                                                                    <span class="uk-input-group-addon">
                                                                        <i class=" uk-icon-justify uk-icon-user"></i>
                                                                    </span>
                                                                    <label for="info_num_client">Numéro Client</label>
                                                                    <input readonly type="text" class="md-input" name="info_num_client" value="{{ $fiche->client_id }}" />
                                                                    <span class="uk-form-danger"></span>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="uk-grid uk-hidden">
                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                <input type="hidden" name="soins_val" id="soins_val" value="{{ $fiche->soins_val }}" />
                                                                <input type="hidden" name="optique_val" id="optique_val" value="{{ $fiche->optique_val }}" />
                                                                <input type="hidden" name="dentaire_val" id="dentaire_val" value="{{ $fiche->dentaire_val }}" />
                                                                <input type="hidden" name="hospitalisation_val" id="hospitalisation_val" value="{{ $fiche->hospitalisation_val }}" />
                                                            </div>
                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                <input type="hidden" name="gamme_id" id="gamme_id" value="{{ $fiche->sagamme_id }}" />
                                                                <input type="hidden" name="garantie_id" id="garantie_id" value="{{ $fiche->sagarantie_id }}" />      
                                                                <input type="hidden" name="garantie_code" id="garantie_code" value="@if($fiche->garantie){{ $fiche->garantie->code }}@endif" />      
                                                            </div>
                                                        </div>

                                                        <div class="uk-grid">
                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                <div class="uk-input-group">
                                                                    <span class="uk-input-group-addon">
                                                                        <i class="material-icons">&#xE8BE;</i>
                                                                    </span>
                                                                    <label for="info_formule">Formule</label>
                                                                    <input readonly type="text" class="md-input" name="info_formule" id="info_formule" value="{{ $fiche->num_formule }}" />
                                                                    <ul id="optionsList" class="uk-width-2-3 md-list md-list-addon md-list-right" >
                                                                        @if( is_array(json_decode($fiche->options)) )
                                                                            @foreach(json_decode($fiche->options) as $option)
                                                                                <li class="renfort">
                                                                                    <div class="md-list-addon-element">
                                                                                        @if(isset($option->tarif))
                                                                                            <span class='uk-text-right uk-text-bold uk-badge uk-badge-primary'>
                                                                                                {{$option->tarif}} 
                                                                                                <i class='uk-icon-euro' style='color:#FFF'></i>
                                                                                            </span>
                                                                                        @endif
                                                                                    </div>
                                                                                    <div class="md-list-content">
                                                                                        <span class="uk-text-small uk-text-muted">{{$option->libelle}}</span>
                                                                                    </div>
                                                                                </li>
                                                                            @endforeach
                                                                        @endif
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <div class="uk-grid uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                
                                                                <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-input-group">
                                                                    <span class="uk-input-group-addon">
                                                                        <i class=" uk-icon-justify uk-icon-euro"></i>
                                                                    </span>
                                                                    <label for="info_montant">Montant Cotisation</label>
                                                                    <input readonly type="text" class="md-input" name="info_montant" id="info_montant" value="{{$fiche->cotisation}}" />
                                                                    <span class="uk-form-danger"></span>
                                                                </div>

                                                                <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-input-group">
                                                                    <span class="uk-input-group-addon">
                                                                        <i class=" uk-icon-justify uk-icon-euro"></i>
                                                                    </span>
                                                                    <label for="frais_dossier">Frais Dossier</label>
                                                                    <input type="text" class="md-input" id="frais_dossier" name="frais_dossier" value="{{$fiche->frais_dossier}}" readonly>
                                                                </div>

                                                            </div>
                                                        </div>

                                                        <div class="uk-grid">
                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                <div class="uk-input-group">
                                                                    <span class="uk-input-group-addon">
                                                                        <i class="material-icons">&#xE32A;</i>
                                                                    </span>
                                                                    <label for="info_num_ss">N° Sécurité Sociale</label>
                                                                    <input type="text" size="15" maxlength="15" data-slug="{{$fiche->produit->slug}}" class="md-input VerifySecuSociel" name="info_num_ss" value="{{ $fiche->num_security_social }}" />
                                                                </div>
                                                            </div>
                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                <div class="uk-input-group">
                                                                    <span class="uk-input-group-addon">
                                                                        <i class=" uk-icon-justify uk-icon-adn"></i>
                                                                    </span>
                                                                    <label for="info_num_aff">N° d'affiliation</label>
                                                                    <input type="text" class="md-input" name="info_num_aff" value="{{ $fiche->num_affiliate }}" />
                                                                    <span class="uk-form-danger"></span>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="uk-grid">
                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                <div class="uk-input-group">
                                                                    <span class="uk-input-group-addon">
                                                                        <i class="material-icons">&#xE32A;</i>
                                                                    </span>
                                                                    <label for="info_num_ss_conj">N° SS Conjoint</label>
                                                                    <input type="text" size="15" maxlength="15" data-slug="{{$fiche->produit->slug}}" class="md-input VerifySecuSocialConjoint" name="info_num_ss_conj" value="@if($fiche->conjoint){{$fiche->conjoint->num_security_social}}@endif" />
                                                                </div>
                                                            </div>
                                                            <div class="uk-width-medium-1-2 uk-width-small-1-1 uk-margin-small-bottom">
                                                                <div class="uk-input-group">
                                                                    <span class="uk-input-group-addon">
                                                                        <i class=" uk-icon-justify uk-icon-adn"></i>
                                                                    </span>
                                                                    <label for="info_num_aff_conj">N° d'affil conjoint</label>
                                                                    <input type="text" class="md-input" name="info_num_aff_conj" value="@if($fiche->conjoint){{$fiche->conjoint->num_affiliate}}@endif" />
                                                                    <span class="uk-form-danger"></span>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </form>

                                                </div>
                                            </div>
                                            

                                            <div class="md-card md-card-primary">

                                                <div class="md-card-toolbar">
                                                    <h3 class="md-card-toolbar-heading-text">
                                                        Info Bancaire (IBAN)
                                                    </h3>
                                                </div>

                                                <div class="md-card-content">
                                                    
                                                    <form id="form_info_bancaire" name"form_info_bancaire">
                                                        
                                                        <div class="md-card md-card-success">
                                                            <div class="md-card-toolbar">
                                                                <h3 class="md-card-toolbar-heading-text">
                                                                    Info Bancaire Prélèvement
                                                                </h3>
                                                            </div>
                                                            <div class="md-card-content">
                                                               <div class="uk-grid">
                                                                    <div class="uk-width-medium-1-3 uk-width-small-1-1 uk-margin-small-bottom">
                                                                        <div class="uk-input-group">
                                                                            <span class="uk-input-group-addon">
                                                                                <i class="material-icons">&#xE84F;</i>
                                                                            </span>
                                                                            <label for="nom_banque_pre">Nom Banque</label>
                                                                            <input type="text" class=" md-input" data-id="nom_banque" id="nom_banque_pre" name="nom_banque_pre" value="@if($infoBanque){{$infoBanque->nom_banque_pre}}@endif" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="uk-width-medium-1-3 uk-width-small-1-1 uk-margin-small-bottom">
                                                                        <div class="uk-input-group">
                                                                            <span class="uk-input-group-addon">
                                                                                <i class="material-icons">&#xE84F;</i>
                                                                            </span>
                                                                            <label for="adresse_banque_pre">Adresse</label>
                                                                            <input type="text" class=" md-input" data-id="adresse_banque" id="adresse_banque_pre" name="adresse_banque_pre" value="@if($infoBanque){{$infoBanque->adresse_banque_pre}}@endif" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="uk-width-medium-1-3 uk-width-small-1-1 uk-margin-small-bottom">
                                                                        <div class="uk-input-group">
                                                                            <span class="uk-input-group-addon">
                                                                                <i class="material-icons">&#xE84F;</i>
                                                                            </span>
                                                                            <label for="ville_banque_pre">Ville</label>
                                                                            <input type="text" class=" md-input" data-id="ville_banque" id="ville_banque_pre" name="ville_banque_pre" value="@if($infoBanque){{$infoBanque->ville_banque_pre}}@endif" />
                                                                        </div>
                                                                    </div>
                                                                </div>


                                                                <div class='uk-grid'>

                                                                    <div class='uk-width-small-1-1 uk-width-medium-2-5 uk-width-large-2-5'>
                                                                        
                                                                        <div class="uk-input-group">
                                                                            
                                                                            <div class="uk-input-group-addon uk-width-small-1-1 uk-width-medium-1-10">
                                                                                <i class="material-icons">&#xE84F;</i> IBAN
                                                                            </div>

                                                                            <div class='uk-grid'>
                                                                                <div class="uk-width-small-1-1 uk-width-medium-1-1">
                                                                                    <label for="iban"></label>
                                                                                    <input type="text" class="copyDataIBAN VerifyIBANPre md-input" maxlength="33" data-id="iban" id="iban_pre" name="iban_pre" value="@if($infoBanque){{Crypt::decrypt($infoBanque->iban_pre)}}@endif" />
                                                                                </div >
                                                                            </div>


                                                                        </div>

                                                                    </div>

                                                                    <div class='uk-width-small-1-1 uk-width-medium-2-5 uk-width-large-2-5'>
                                                                        
                                                                        <div class="uk-input-group">
                                                                            <span class="uk-input-group-addon">
                                                                                <i class="material-icons">&#xE84F;</i>
                                                                            </span>
                                                                            <label for="code_bic_pre">Code BIC</label>
                                                                            <input type="text" size="11" maxlength="11" class=" md-input" name="code_bic_pre" data-id="code_bic" id="code_bic_pre" value="@if($infoBanque){{Crypt::decrypt($infoBanque->code_bic_pre)}}@endif" />
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                            </div>

                                                        </div>

                                                        <div class="md-card md-card-success">
                                                            <div class="md-card-toolbar">
                                                                    <div class="md-card-toolbar-actions">
                                                                    <i id="copyBankDataPre" data-uk-tooltip title="Coller Info Bancaire" class="md-icon material-icons">&#xE14D;</i>
                                                                </div>
                                                                <h3 class="md-card-toolbar-heading-text">
                                                                    Info Bancaire Remboursement
                                                                </h3>
                                                            </div>
                                                            <div class="md-card-content">
                                                               <div class="uk-grid">
                                                                    <div class="uk-width-medium-1-3 uk-width-small-1-1 uk-margin-small-bottom">
                                                                        <div class="uk-input-group">
                                                                            <span class="uk-input-group-addon">
                                                                                <i class="material-icons">&#xE84F;</i>
                                                                            </span>
                                                                            <label for="nom_banque_rem">Nom Banque</label>
                                                                            <input type="text" class="md-input" id="nom_banque_rem" name="nom_banque_rem" value="@if($infoBanque) {{ $infoBanque->nom_banque_rem }} @endif" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="uk-width-medium-1-3 uk-width-small-1-1 uk-margin-small-bottom">
                                                                        <div class="uk-input-group">
                                                                            <span class="uk-input-group-addon">
                                                                                <i class="material-icons">&#xE84F;</i>
                                                                            </span>
                                                                            <label for="adresse_banque_rem">Adresse</label>
                                                                            <input type="text" class=" md-input" id="adresse_banque_rem" name="adresse_banque_rem" value="@if($infoBanque){{$infoBanque->adresse_banque_rem}}@endif" />
                                                                        </div>
                                                                    </div>
                                                                    <div class="uk-width-medium-1-3 uk-width-small-1-1 uk-margin-small-bottom">
                                                                        <div class="uk-input-group">
                                                                            <span class="uk-input-group-addon">
                                                                                <i class="material-icons">&#xE84F;</i>
                                                                            </span>
                                                                            <label for="ville_banque_rem">Ville</label>
                                                                            <input type="text" class="md-input" id="ville_banque_rem" name="ville_banque_rem" value="@if($infoBanque) {{ $infoBanque->ville_banque_rem }} @endif" />
                                                                        </div>
                                                                    </div>
                                                                </div>


                                                                <div class='uk-grid'>

                                                                    <div class='uk-width-small-1-1 uk-width-medium-2-5 uk-width-large-2-5'>
                                                                        
                                                                        <div class="uk-input-group">
                                                                            
                                                                            <div class="uk-input-group-addon uk-width-small-1-1 uk-width-medium-1-10">
                                                                                <i class="material-icons">&#xE84F;</i> IBAN
                                                                            </div>

                                                                            <div class='uk-grid'>
                                                                                <div class="uk-width-small-1-1 uk-width-medium-1-1">
                                                                                    <label for="iban"></label>
                                                                                    <input type="text" class="copyDataIBAN VerifyIBANRem md-input" maxlength="33" data-id="iban" id="iban_rem" name="iban_rem" value="@if($infoBanque){{Crypt::decrypt($infoBanque->iban_rem)}}@endif" />
                                                                                </div >
                                                                            </div>


                                                                        </div>

                                                                    </div>

                                                                    <div class='uk-width-small-1-1 uk-width-medium-2-5 uk-width-large-2-5'>
                                                                        
                                                                        <div class="uk-input-group">
                                                                            <span class="uk-input-group-addon">
                                                                                <i class="material-icons">&#xE84F;</i>
                                                                            </span>
                                                                            <label for="code_bic_pre">Code BIC</label>
                                                                            <input type="text" size="11" maxlength="11" class="md-input" name="code_bic_rem" data-id="code_bic" id="code_bic_rem" value="@if($infoBanque){{Crypt::decrypt($infoBanque->code_bic_rem)}}@endif" />
                                                                        </div>

                                                                    </div>

                                                                </div>

                                                            </div>

                                                        </div>

                                                    

                                                    <div class="md-card md-card-success">
                                                        <div class="md-card-toolbar">
                                                            <h3 class="md-card-toolbar-heading-text">
                                                                Paiement
                                                            </h3>
                                                        </div>
                                                        <div class="md-card-content">
                                                            <div class="uk-grid">
                                                            
                                                                
                                                                <div class="uk-width-small-1-1 uk-width-medium-3-10 uk-input-group">
                                                                    <label for="mode_paiement">Mode de paiement</label>
                                                                    <select data-md-selectize  id="mode_paiement" name="mode_paiement" >
                                                                        <option value="">---</option>
                                                                        @foreach($modePaiements as $modePaiement)
                                                                            <option @if($fiche->modepaiement_id == $modePaiement->id ) selected @endif value="{{ $modePaiement->id }}">{{ $modePaiement->libelle }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>

                                                                <div class="uk-width-small-1-1 uk-width-medium-3-10 uk-input-group ">
                                                                    <label  for="type_paiement">Type de paiement</label>
                                                                    <select data-md-selectize name="type_paiement">
                                                                        <option value="">---</option>
                                                                        @foreach($typePaiements as $typePaiement)
                                                                            <option @if($fiche->typepaiement_id == $typePaiement->id ) selected @endif value="{{ $typePaiement->id }}">{{ $typePaiement->libelle }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>

                                                                <div class="uk-width-small-1-1 uk-width-medium-3-10 uk-input-group  ">
                                                                    <label for="prelevement">Prélévement le</label>
                                                                    <select data-md-selectize id="prelevement" name="prelevement" >
                                                                        <option value="">---</option>
                                                                        @if($fiche->gamme)
                                                                            @foreach($fiche->gamme->compagnie->prelevements($fiche->produit_id) as $prelevement)
                                                                                <option @if($fiche->prelevement_id == $prelevement->jour ) selected @endif value="{{ $prelevement->jour }}">{{ $prelevement->jour }}</option>
                                                                            @endforeach
                                                                        @endif
                                                                    </select>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="md-card md-card-success">
                                                        
                                                        <div class="md-card-toolbar">
                                                            <h3 class="md-card-toolbar-heading-text"> Plus </h3>
                                                        </div>

                                                        <div class="md-card-content">

                                                            <div class="uk-grid uk-width-1-1">
                                                                
                                                                <div class="uk-grid-small-1-1 uk-width-medium-1-3 uk-input-group ">
                                                                    <label for="nbr_mois_gratuit">Mois gratuit</label>
                                                                    <select data-md-selectize name="nbr_mois_gratuit"  >
                                                                        <option @if($fiche->nbr_mois_gratuit == 0 ) selected @endif value="0">0</option>
                                                                        <option @if($fiche->nbr_mois_gratuit == 1 ) selected @endif value="1">1</option>
                                                                        <option @if($fiche->nbr_mois_gratuit == 2 ) selected @endif value="2">2</option>
                                                                        <option @if($fiche->nbr_mois_gratuit == 3 ) selected @endif value="3">3</option>
                                                                    </select>
                                                                </div>

                                                                <div class="uk-grid-small-1-1 uk-width-medium-1-3 uk-input-group ">
                                                                    <label for="paiement_cb">Paiement CB 1er mois</label>
                                                                    <select data-md-selectize name="paiement_cb">
                                                                        <option @if($fiche->paiement_cb == 0 ) selected @endif value="0">Non</option>
                                                                        <option @if($fiche->paiement_cb == 1 ) selected @endif value="1">Oui</option>
                                                                    </select>
                                                                </div>

                                                                <div class="uk-grid-small-1-1 uk-width-medium-1-3 uk-input-group ">
                                                                    <label for="remise">Remise</label>
                                                                    <select data-md-selectize name="remise" >
                                                                        <option @if($fiche->remise == 0 ) selected @endif value="0">Non</option>
                                                                        <option @if($fiche->remise == 5 ) selected @endif value="5">5%</option>
                                                                        <option @if($fiche->remise == 10 ) selected @endif value="10">10%</option>
                                                                    </select>
                                                                </div>

                                                                <!-- 
                                                                    <div class="uk-grid-small-1-1 uk-width-medium-2-10 uk-input-group ">
                                                                        <label for="frais_dossier_offert">Frais de dossier offert</label>
                                                                        <select data-md-selectize id="frais_dossier_offert" name="frais_dossier_offert">
                                                                            <option {{ (!$fiche->frais_dossier_offert) ? 'selected' : ''}} value="0">Non</option>
                                                                            <option {{ ($fiche->frais_dossier_offert) ? 'selected' : ''}} value="1">Oui</option>
                                                                        </select>
                                                                    </div> 
                                                                -->

                                                                

                                                            </div>

                                                        </div>

                                                    </div>

                                                <!--                                         
                                                    <div class="md-card md-card-success">
                                                        <div class="md-card-toolbar">
                                                            <h3 class="md-card-toolbar-heading-text">
                                                                Ancienne assurance
                                                            </h3>
                                                        </div>
                                                        <div class="md-card-content">
                                                            <div class="uk-grid uk-width-1-1">
                                                            
                                                                <div class="uk-grid-small-1-1 uk-width-medium-3-10 uk-input-group ">
                                                                    
                                                                    <select data-md-selectize class="md-input" name="TT">
                                                                        <option value="">---</option>
                                                                        <option value="Résiliation à faire par onAssur">Résiliation à faire par onAssur</option>
                                                                        <option value="Résiliation à faire par Client">Résiliation à faire par Client</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                -->
                        
                                                    </form>
                                                </div>

                                            </div>

                                           

                                            @if($access and $displayTab)
                                                <div class="uk-grid">
                                                    
                                                    <div class="uk-width-1-1 uk-margin-small-bottom">
                                                        <input type="checkbox" class="signature" name="signature" id="signature" checked="true"> Envoyer email pour la signature
                                                    </div>
                                                
                                                    <div class="uk-width-1-1 uk-margin-small-bottom">
                                                        <div id="save" >
                                                                        

                                                        </div>
                                                        <a id='saveInfoBanque' class='md-btn md-btn-block md-btn-primary md-btn-small md-btn-wave-light waves-effect waves-button waves-light' data-prd="{{ $fiche->produit->slug }}" data-slug="{{ $fiche->slug }}" data-client="{{ $fiche->client_id }}" data-fiche="{{ $fiche->num_fiche }}">
                                                            <i style="color:white;" class="material-icons" >&#xE161;</i>
                                                            Enregistrer
                                                        </a>
                                                    </div>
                                                    
                                                </div>
                                            @endif
                                             <div class="uk-grid">
                                                <div class="uk-width-1-1 uk-margin-small-bottom" id="pdf">
                                                    
                                                </div>
                                            </div>


                                        </section>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>

                                        
                                                    </div>
                                                </div>
                                                
                                            </div>
                                            
                                        </div>
                                    </div>       
                                        
                                            </div>
                                
                       
                                    </div>
                                    <div class="md-card md-card-primary">
                                        <div class="md-card-toolbar">
                                            <div class="md-card-toolbar-actions">
                                                <i class="md-icon material-icons md-card-toggle">&#xE316;</i>
                                            </div>
                                            <h3 class="md-card-toolbar-heading-text">
                                                Commentaire
                                            </h3>
                                        </div>
                                        <div class="md-card-content">
                                            <div class="uk-grid">
                                            
                                            <div class=" uk-width-1-1">
                                                <form id="formComment">
                                                    <input type="hidden" value="{{ $fiche->id }}" name="ficheId">
                                                    <input type="hidden" value="{{ $fiche->produit->slug }}" name="slugPrd">
                                                    <textarea placeholder="tapez le commentaire" name="commentaire" id="commentaire" rows="3" class="md-input"></textarea>
                                                    <button id="addComment" name="addComment" type="button"  class="md-btn md-btn-flat md-btn-flat-primary">Envoyer Commentaire</button>
                                                </form>
                                                
                                            </div>
                                        </div> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                    
                </div>
       

            @if($access)

                <div class="md-fab-wrapper md-fab-speed-dial">
                    
                    <a class="md-fab md-fab-danger " href="#" class="md-fab md-fab-danger md-fab-wave-light waves-effect waves-button waves-light" >
                        <i class="material-icons">&#xE0CF;</i>
                    </a>

                    <div class="md-fab-wrapper-small">

                        <a href="#" id="listTels" data-fiche="{{ $fiche->id }}" data-slug="{{ $fiche->produit->slug }}" data-uk-tooltip="{pos:'left'}" title="Passez un appel" class="md-fab md-fab-small md-fab-warning">
                            <i class="material-icons">&#xE0B0;</i>
                        </a>
                        <a href="#" id="listTelsSms" data-fiche="{{ $fiche->id }}" data-slug="{{ $fiche->produit->slug }}" data-uk-tooltip="{pos:'top'}" title="Envoyer un SMS"  class="md-fab md-fab-small md-fab-danger">
                            <i class="material-icons">&#xE625;</i>
                        </a>
                        <a  href="#" data-fiche="{{ $fiche->id }}" data-produit="{{ $fiche->produit->id }}" data-uk-modal data-uk-tooltip="{pos:'left'}" title="Envoyez un email"  class="loadEnvoiMail md-fab md-fab-small md-fab-success">
                            <i class="material-icons">&#xE0E1;</i>
                        </a>

                    </div>

                </div>

            @endif

            <div id="loadConjoint" style="display:none">
                
                    <div class="uk-grid">
                        <div class="uk-width-medium-1-2 uk-width-small-1-1">
                            <div class="uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class=" uk-icon-justify uk-icon-user"></i>
                                </span>
                                <label for="conjoint_nom">Nom</label>
                                <input type="text" class="md-input" name="conjoint_nom" value="" />
                            </div>
                        </div>
                        <div class="uk-width-medium-1-2 uk-width-small-1-1">
                            <div class="uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class=" uk-icon-justify uk-icon-user"></i>
                                </span>
                                <label for="conjoint_prenom">Prenom</label>
                                <input type="text" class="md-input" name="conjoint_prenom" value="" />
                                <span class="uk-form-danger"></span>
                            </div>
                        </div>
                    </div>
                    <div class="uk-grid">
                        <div class="uk-width-medium-1-2 uk-width-small-1-1">
                            <div class="uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class=" uk-icon-justify uk-icon-genderless"></i>
                                </span>
                                <label for="conjoint_civilite">Civilité</label>
                                <select  class='selectConjoint' name="conjoint_civilite">
                                    <option value="M">
                                        M.
                                    </option>
                                    <option value="Mlle">
                                        Mlle
                                    </option>
                                    <option value="Mme">
                                        Mme
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="uk-width-medium-1-2 uk-width-small-1-1">
                            <div class="uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class=" uk-icon-justify uk-icon-venus-mars"></i>
                                </span>
                                <label for="conjoint_sexe">Sexe</label>
                                <select  class='selectConjoint' name="conjoint_sexe">
                                    <option value="H">
                                        Homme
                                    </option>
                                    <option value="F">
                                        Femme
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="uk-grid">
                        <div class="uk-width-medium-1-2 uk-width-small-1-1">
                            <div class="uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class=" uk-icon-justify uk-icon-group"></i>
                                </span>
                                <label for="conjoint_sit_familiale">Situation familiale</label>
                                <select  class='selectConjoint' name="conjoint_sit_familiale">
                                    <option value="C" >
                                        Célibataire
                                    </option>
                                    <option value="D" >
                                        Divorcé (e)
                                    </option>
                                    <option value="M" >
                                        Marié (e)
                                    </option>
                                    <option value="V" >
                                        Veuf (ve)
                                    </option>
                                    <option value="N" >
                                        Concubin (e)
                                    </option>
                                    <option value="P" >
                                        Partenaire lié par PAC'S
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="uk-width-medium-1-2 uk-width-small-1-1">
                            <div class="uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class=" uk-icon-justify uk-icon-calendar"></i>
                                </span>
                                <label for="conjoint_date_naissance">Date naissance</label>
                                <input type="text" name="conjoint_date_naissance" id="conjoint_date_naissance"  class="md-input"  data-uk-datepicker="{format:'DD/MM/YYYY',maxDate:0,minDate:'01/01/1900', i18n: { months:['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre']}}" value="" readonly="true"/>
                                <span class="uk-form-danger"></span>
                            </div>
                        </div>
                    </div>
                    <div class="uk-grid">
                        <div class="uk-width-medium-1-2 uk-width-small-1-1">
                            <div class="uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class=" uk-icon-justify uk-icon-registered"></i>
                                </span>
                                <label for="conjoint_saregime_id">Régime</label>
                                <select class='selectConjoint' id="conjoint_saregime_id" name="conjoint_saregime_id">
                                    <option value=""></option>
                                    @foreach($regimes as $regime)
                                        <option value="{{$regime->id}}">
                                            {{$regime->libelle}}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    
            </div>
 


     </div>

@stop
@section('modals')

<div id="actionModal" class="uk-modal" style="z-index:2010">
    <div class="uk-modal-dialog uk-modal-dialog-large">
        <div class="uk-modal-header">
            <h3 class="uk-modal-title"><span id="actionTitle"></span><span id="rappelTitle" class="uk-text-danger"></span></h3>
        </div>
        <div class="uk-modal-content">
            
            {{ Form::open(['id' => 'formActions', 'name' => 'formActions']) }}
                
                <input type="hidden" value="{{ $fiche->produit_id }}" name="prdId" id="prdId">
                <input type="hidden" value="" name="modalFicheId" id="modalFicheId">
                <input type="hidden" value="" name="modalStatutId" id="modalStatutId">
                <input type="hidden" value="" name="statutLib" id="statutLib">
                <input type="hidden" value="" name="statutCol" id="statutCol">
                <div id="actionRappel" >
                    <div class="md-card md-card-primary">
                        <div class="md-card-content uk-grid uk-width-1-1">
                            <div style="z-index: 2000;" class="uk-width-medium-2-3 uk-width-small-2-3 uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class=" uk-icon-justify uk-icon-calendar"></i>
                                </span>
                                <label for="rappel_date">Date Rappel</label>
                                <input type="text" name="rappel_date" id="rappel_date" class="md-input" data-uk-datepicker="{format:'DD/MM/YYYY', i18n: { months:['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre']}}" value="" />
                            </div>
                            <div class="uk-width-medium-1-3 uk-width-small-1-3 uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class="uk-input-group-icon uk-icon-clock-o"></i>
                                </span>
                                <label for="rappel_heure">Heure Rappel</label>
                                <input class="md-input" type="text" id="rappel_heure" name="rappel_heure" data-uk-timepicker>
                            </div> 
                        </div>
                    </div>
                </div>
                <div class="uk-grid"></div>
                <div id="actionMotif">
                    <div class="md-card uk-margin md-card-primary">
                        <div class="md-card-content uk-grid uk-width-1-1">
                            <div class="uk-width-medium-2-3 uk-width-small-2-3 uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class=" uk-icon-justify uk-icon-list"></i>
                                </span>
                                <label for="modalMotifId">Motifs: </label>
                                <select class="md-input" id="modalMotifId" name="modalMotifId">
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="uk-grid"></div>
                <div class="md-card md-card-primary">
                    <div class="md-card-content">
                        <div class="uk-grid uk-width-1-1">
                            <div class="uk-input-group">
                                <span class="uk-input-group-addon">
                                    <i class=" uk-icon-justify uk-icon-comment"></i>
                                </span>
                                <label>Complement</label>
                                <textarea name="action_complement" id="action_complement" rows="3" class="md-input"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            {{ Form::close() }}
        </div>
        <div class="uk-modal-footer uk-text-right">
            <button type="button" class="md-btn md-btn-flat uk-modal-close">Annuler</button>
            <button id="btnActionModal" type="button" onclick="" class="md-btn md-btn-flat md-btn-flat-primary">Valider</button>
        </div>
    </div>
</div>
<div id="newContratModal" class="uk-modal">
    <div class="uk-modal-dialog uk-modal-dialog-large">
        <div class="uk-modal-header">
            <h3 class="uk-modal-title"><span class="uk-text-right"><button class="uk-modal-close uk-close " type="button"></button></span> Liste des produits  </h3>
        </div>
        <p>     
            
            @foreach ($groupeProduitsList->chunk(4) as $groupeProduits)
                <div class="uk-grid uk-grid-width-small-1-1 uk-grid-width-medium-1-2 uk-grid-width-large-1-4" data-uk-grid-margin>
                @foreach ($groupeProduits as $groupeProduit)
                    <div class="uk-margin-bottom">
                        <div class="md-card md-card-hover md-card-overlay">
                            <div class="md-card-content truncate-text uk-text-center">
                                <i class="uk-icon-large material-icons" style="font-size:100px">{{ $groupeProduit->icon }}</i>
                            </div>
                            <div class="md-card-overlay-content">
                                <div class="uk-clearfix md-card-overlay-header">
                                    <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                    <h3>
                                        {{ $groupeProduit->libelle }}
                                    </h3>
                                </div>
                                <p class="truncate-text" >
                                    <ul class="uk-list" style="overflow-y:scroll; height: 120px;">
                                        @forelse ($groupeProduit->produits as $produit)
                                            <li><a href="{{ url('conseiller/leads/duplicate/'.$fiche->client->id.'/'.$produit->slug.'/'.$fiche->id.'/'.$fiche->produit_id) }}">{{ $produit->libelle }}</a></li>
                                        @empty
                                            Pas de produits
                                        @endforelse
                                    </ul>
                                </p>
                            </div>
                        </div>
                    </div>
                @endforeach
                </div>
            @endforeach
        </p>
    </div>
</div>
<div id="confirmModal" class="uk-modal">
    <div class="uk-modal-dialog" style="text-align: center;">
        <div class="uk-modal-header">
            <p id="titleConfirmModal"><i class='material-icons'>&#xE858;</i> Patientez  SVP ... </p>
        </div>
        <p>
            
            <div id="beforeLoadDiv" class="md-preloader uk-container-center" >
                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="48"  width="48" viewbox="0 0 75 75">
                    <circle cx="37.5" cy="37.5" r="33.5" stroke-width="4" />
                </svg>
            </div>
            <div id="afterLoadDiv" >
                
            </div>
            <div id="msgConfirmModal" class="uk-text-left"></div>
        </p>
    </div>
</div>

<div id="uploadModal"  style="z-index: 200;" class="uk-modal">
    <div class="uk-modal-dialog" style="text-align: center;">
        <div class="uk-modal-header">
            <p id="titleConfirmModal">
                <i class="material-icons">&#xE226;</i>
                Document(s) attaché(s) (Type: document)
            </p>
        </div>
        <p>            
            <div class="uk-width-1-1">
                <div class="md-card">
                    <div class="md-card-content">
                            @foreach($documents as $document)
                                <div class="uk-margin-left uk-grid uk-width-1-1 uk-input-group">
                                    
                                    <div class="uk-width-1-6 uk-input-group-addon">
                                        <span id="iconDoc{{ $document->id }}">
                                            <?php $docFile = $document->uploadedSanteFile($fiche->id) ?>
                                            @if($docFile)
                                                <?php
                                                    $lien = pathinfo(url($docFile->pivot->path));
                                                    $ext  = $lien['extension'];
                                                    if($ext =='pdf'){
                                                        $icon = 'pdf';
                                                    }elseif($ext =='doc' or $ext =='docx'){
                                                        $icon = 'word';
                                                    }else{
                                                        $icon = 'image';
                                                    }
                                                ?>
                                                
                                                <i class="iconSize material-icons" style="color: green;">&#xE5CA;</i>
                                                <a href="{{ url($docFile->pivot->path) }}" style="position: relative;z-index: 10;" target="_blank"><i class="iconSize uk-icon-file-{{$icon}}-o"></i></a>
                                            @else 
                                                <i class="iconSize material-icons" style="color: red;">&#xE14C;</i>
                                            @endif
                                        </span>
                                        
                                    </div>
                                    <div class="uk-width-2-6">
                                        {{ $document->nom }} 
                                    </div>
                                    <div class="uk-width-1-6">
                                        <div class="uk-form-file md-btn md-btn-primary">
                                            Upload
                                            @if($access)
                                                <input class="documentFiche" data-produit="{{ $fiche->produit->id }}" data-fiche="{{ $fiche->id }}" data-id="{{ $document->id }}" type="file" id="doc_file{{ $document->id }}" >
                                            @endif
                                        </div>
                                    </div>
                                    <div id="infoDoc{{ $document->id }}" class="uk-width-2-6" align="center">
                                        @if($docFile)
                                        <i data-uk-tooltip title="{{ \Carbon\Carbon::parse($docFile->pivot->created_at)->format('d/m/Y H:i:s') }}" class="iconSize material-icons">&#xE192;</i>
                                        <i data-uk-tooltip title="{{ $document->getUser($docFile->pivot->user_id) }}" class="iconSize material-icons">&#xE853;</i>
                                        
                                        @else
                                        @endif
                                    </div>
                                    
                                </div>
                                <div id="errorDoc{{ $document->id }}" style="color:red;" class="errorDoc uk-text-left uk-margin" ></div>
                            <hr>
                            @endforeach
                    </div>
                </div>
            </div>
        </p>
        <div class="uk-modal-footer uk-text-right">
            <button type="button" class="md-btn md-btn-flat uk-modal-close">Fermer</button>
        </div>
    </div>
</div>

<div id="deleteFicheModal" class="uk-modal">
    <div class="uk-modal-dialog" style="text-align: center;">
        <p>
            <div class="uk-width-1-1">
                <div  class="uk-container-center" >
                    <i class="material-icons">&#xE872;</i>
                    Voulez vous supprimer cette fiche ?
                </div>
                <input type="hidden" value="{{ $fiche->id }}" id="deleteFicheId"> 
                <br>
                <div id="beforeDeleteFiche" style="display:none;" class="md-preloader uk-container-center" >
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="48"  width="48" viewbox="0 0 75 75">
                        <circle cx="37.5" cy="37.5" r="33.5" stroke-width="4" />
                    </svg>
                </div>
                <div id="afterDeleteFiche" style="display:none;" class="uk-container-center" >
                    
                </div>
            </div>
        </p>
         <div class="uk-modal-footer uk-text-right">
            <button type="button" class="md-btn md-btn-flat uk-modal-close">Annuler</button>
            <button id="btnDeleteFiche" type="button" onclick="" class="md-btn md-btn-flat md-btn-flat-primary">Supprimer</button>
        </div>
    </div>
</div>
<div id="commentsModal" class="uk-modal">
    <div class="uk-modal-dialog" style="text-align: center;">
        <div class="uk-modal-header">
            <p>
                <i class="material-icons">&#xE889;</i>
                Les commentaires sur la fiche
            </p>
        </div>
        <p>            
            <div class="uk-width-1-1">
                <div id="beforeLoadComment" class="md-preloader uk-container-center" >
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="48"  width="48" viewbox="0 0 75 75">
                        <circle cx="37.5" cy="37.5" r="33.5" stroke-width="4" />
                    </svg>
                </div>
                <div id="afterLoadComment" class="uk-container-center" >
                </div>
            </div>
        </p>
        <div class="uk-modal-footer uk-text-right">
            <button type="button" class="md-btn md-btn-flat uk-modal-close">Fermer</button>
        </div>
    </div>
</div>
<div id="compareTarifModal" style="z-index:10000px;" class="uk-modal">
    <div class="uk-modal-dialog  uk-modal-dialog-large" style="text-align: center;">
        <div class="uk-modal-header">
            <h3>
                Les tarifs à comparer
            </h3>
        </div>
        <div class="uk-modal-content" align="center">           
            <div id='comparedTarifs' class=" uk-text-center uk-grid uk-grid-width-large-1-4 uk-grid-width-medium-1-2 uk-grid-width-small-1-2">
            </div>
        </div>
        <div class="uk-modal-footer uk-text-right">
            <button type="button" class="md-btn md-btn-flat uk-modal-close">Fermer</button>
        </div>
    </div>
</div>

<div id="detailMailModal" style="z-index:10000px;" class="uk-modal">
    <div class="uk-modal-dialog  uk-modal-dialog" style="text-align: center;">
        <div class="uk-modal-header">
        </div>
        <div class="uk-modal-content" align="left">           
            <div id='detailMail' >
            </div>
        </div>
        <div class="uk-modal-footer uk-text-right">
            <button type="button" class="md-btn md-btn-flat uk-modal-close">Fermer</button>
        </div>
    </div>
</div>

<div id="modal_overflow" class="uk-modal">
        <div id="loader-wrapper">
            <div id="loader"></div>

            <div class="loader-section section-left"></div>
            <div class="loader-section section-right"></div>

        </div>
    <div class="uk-modal-dialog uk-modal-dialog-large">
        <button type="button" class="uk-modal-close uk-close"></button>
        <div class="uk-overflow-container" >
        <iframe src="" height="700" width="100%" id="retourTableauGarantie"></iframe>

        </div>
    </div>
</div>


@include('shared.produits.origine_sante')

@include('partage.traces')

@include('partage.mailing')

@include('partage.listTels')

@include('partage.listTelsSms')

@include('partage.multidetention')


@stop



@section('javascripts')
  
    {{ Html::script("assets/js/kendoui_custom.min.js") }}
    {{ Html::script("assets/js/pages/kendoui.min.js") }}
    {{ Html::script("assets/js/iCheck.js") }}
    {{ Html::script("assets/js/maskedinput/src/jquery.maskedinput.js") }}

    <script src="{{ asset('components/parsleyjs/dist/parsley.min.js') }}"></script>
    
    <!-- jquery steps -->
    <script src="{{ asset('assets/js/custom/wizard_steps.js') }}"></script>
    <!--  forms wizard functions -->
    <script src="{{ asset('assets/js/pages/forms_wizard.min.js') }}"></script>
    <!-- kendo UI -->
    <script src="{{ asset('assets/js/kendoui_custom.min.js') }}"></script>
    <!--  kendoui functions -->
    <script src="{{ asset('assets/js/pages/kendoui.min.js') }}"></script>
    <script src="{{ asset('components/datatables/media/js/jquery.dataTables.min.js') }}"></script>
    <!-- datatables colVis-->
    <script src="{{ asset('components/datatables-colvis/js/dataTables.colVis.js') }}"></script>
    <!-- datatables tableTools-->
    <script src="{{ asset('components/datatables-tabletools/js/dataTables.tableTools.js') }}"></script>
    <!-- datatables custom integration -->
    <script src="{{ asset('assets/js/custom/datatables_uikit.min.js') }}"></script>
    <!--  datatables functions -->
    <script src="{{ asset('assets/js/pages/plugins_datatables.min.js') }}"></script>
    <script src="{{ asset('assets/js/pages/datatables-alt-string.js') }}"></script>
    <!-- <script src="{{ asset('assets/js/sweetalert.min.js') }}"></script> -->
    <script src="{{ asset('assets/js/sweetalert2.min.js') }}"></script>
    <script src="{{ asset('assets/js/rating.js') }}"></script>
    <script src="{{ asset('assets/js/maskedinput.min.js') }}"></script>

    <script src="{{ asset('assets/js/vue.js') }}"></script>
    <script src="{{ asset('assets/js/vue-resource.min.js') }}"></script>

    <script src="{{ asset('assets/js/pages/page_mailbox.min.js') }}"></script> 

    
    
    <script>

        $(".validerImpression").click(function(){

                prdSlug   = $(this).attr('data-slug');
                ficheNum  = $(this).attr('data-fiche');
                ficheId   = $(this).attr('data-id');

                swal({
                      title: "Confirmer la validation d'impression !",
                      text: "Voulez-vous vraiment valider la demande d'impression !",
                      type: 'warning',
                      showCancelButton: true,
                      confirmButtonColor: '#3085d6',
                      cancelButtonColor: '#d33',
                      confirmButtonText: 'Oui, valider !',
                      showLoaderOnConfirm: true,

                    preConfirm: function() {

                    
                    return new Promise(function(resolve, reject) {

                        setTimeout(function() {

                            $.ajax({

                                url  : "{!! URL::to('equipe/validerImpression') !!}",

                                type : 'POST',
                                
                                data : "ficheNum="+ficheNum+"&prdSlug="+prdSlug,

                                beforeSend: function(xhr){
                                    xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));
                                },
                        
                            }).success(function(data){

                                //console.log(data);
                                if(data.success){

                                    resolve();

                                }else{

                                    reject(data.message);

                                }
                                
                            }).error(function(data){

                                var errors = data.responseJSON;

                                err = "<ul>";

                                $.each(errors, function(key, value){
                                    err += "<li style='color:red;'>"+value+"</li>";
                                });

                                err += "</ul>";

                                reject(err);

                            });
                        
                      }, 1000)

                    })

                  },
                  allowOutsideClick: false
                }).then(function(data) {
                    swal({
                        type  : 'success',
                        title : 'demande impression validée',
                    });
                });
            });

        $(".demandeFax").click(function(){


            var editModal = UIkit.modal('#faxModal', {bgclose: false});
            editModal.show();
                
            var idFiche  = $(this).attr('data-id');
            var prdSlug  = $(this).attr('data-slug');
            var rootLink = $('#rootLink').val();
            var lien     = rootLink+"/equipe/traceFaxDocs/"+idFiche;
                   
           $.ajax({

                url  : lien,
                
                type : 'GET',

                data : "&prdSlug="+prdSlug, 
                
             }).success(function(data){

                console.log(data);

            }).error(function(data){

                //var errors = data.responseJSON;

            });

            
        });
    
        $(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        });

        let vueProc = new Vue({
            el: "#vueProc",
            data: {
                processes   : {},
            },
            methods:{

            },
            ready:function() {

                //this.processes = {!! $processes !!};

            }
        });

        let vueLead = new Vue({

            el : "#sante",
            data : {
                nom         : '',
                prenom      : '',
                code        : '',
                cp          : '',
                ville       : '',
                adresse     : '',
                cities      : [],
                fiche       : {},
                statut      : {},
                processes   : {},
                steps       : {'appel':0, 'email':0, 'sms':0},
            },
            methods : {

                getCities: function(ville){

                    this.$http.jsonp('https://vicopo.selfbuild.fr/cherche/'+ville).then((response) => {

                        this.cities = response.body.cities;
                        
                    }, (response) => {

                    });

                },

                chooseCity: function(city){

                    this.code  = city.code;
                    this.ville = city.city;
                    this.cp    = parseInt(this.code / 1000);

                    this.cities = [];
                },

                updateProc: function(processesList){

                    if(processesList){
                        this.processes = processesList;
                        vueProc.$data.processes = this.processes;
                    }

                },
               

            },
            computed: {

                mapLink: function() {

                    return "https://www.google.com/maps/embed/v1/place?key=AIzaSyDJVdqe-aHN5PK08ZADuOBAtpONhp_T_6k&q="+this.adresse+", "+this.code+", "+this.ville;
                     
                },

                pjLink: function(){

                    return "http://www.pagesjaunes.fr/recherche/"+this.cp+"/"+this.nom+" "+this.prenom;

                },

                annuaireLink: function(){

                    return "http://annuaire.118712.fr/?s="+this.nom+" "+this.prenom;

                },

                siretLink: function(){

                    return "https://www.societe.com/cgi-bin/search?champs="+this.nom+" "+this.prenom;

                },
                
                verifyProc0: function(){

                    //alert(aa);

                    // self = this;

                    // event = self.el.getAttribute('data-fiche');
                   

                    dispalyProc = false;

                    processes = this.processes;

                    //console.log(processes);

                    //console.log(_.find(processes, ['slug', slug]));

                    okTrue = _.find(processes, ['slug', slug]);
                    
                    if(okTrue){
                        alert('ok');
                    }else{
                        alert('no');
                    }

                    // console.log("processes");
                    // console.log(processes);

                    return (dispalyProc) ? 1 : 0 ;

                },
                
                
            },
            ready:function() {

                this.cp        = parseInt(this.code / 1000);

                this.fiche     = {!! $fiche !!};
                this.statut    = {!! $fiche->statut !!};
                this.processes = {!! $processes !!};

                vueProc.$data.processes = this.processes;

                //  steps = [];

                // _.forEach(this.processes, function(value, key) {
                //    //this.steps[key] = value.slug;
                //     step[value.slug] = value.done;
                //     steps.push(step);
                //     console.log('step by step ',step);
                //     steps.push(step);
                // });

                // console.log('this.steps');
                // this.steps = steps;
                // console.log(this.steps);
                // console.log("steps",steps);


                // step = [];

                // _.forEach(this.processes, function(value, key) {
                //    //this.steps[key] = value.slug;
                //     step["'"+value.slug+"'"] = value.done;
                // });

                // // steps["A"] = {'slug' : 'appel', 'done' : 1};
                // // steps["B"] = {'slug' : 'sms'  , 'done' : 0};

                

                // console.log('step', step["sms"]);

                
                // this.steps.appel = Math.round(Math.random());
                // this.steps.email = Math.round(Math.random());
                // this.steps.sms   = Math.round(Math.random());


                // setInterval(function () {

                //     this.steps.appel = Math.round(Math.random());
                //     this.steps.email = Math.round(Math.random());
                //     this.steps.sms   = Math.round(Math.random());

                //     console.log('again ', this.steps);

                // }.bind(this), 5000);

                // console.log('first ', this.steps);



            },

        });
        
        $(document).ready(function(){

        


        $(".affichage").click(function(){

            if($('.infoFiche').hasClass('uk-width-medium-4-5')){
                $('.infoPersonnel').css('display','none');
                $('.infoFiche').removeClass('uk-width-medium-4-5');  
                $('.infoFiche').addClass('uk-width-medium-5-5');
            }else{
                $('.infoPersonnel').css('display','initial');
                $('.infoFiche').removeClass('uk-width-medium-5-5');  
                $('.infoFiche').addClass('uk-width-medium-4-5');

            }     

                        });

            
            listFraisDossier = [];

            getFraisDossiers();

            function getFraisDossiers(){

                prdSlug = $("#prdSlug").val();
                
                $.ajax({

                    url  : "{{ URL::to('fraisdossiers') }}",
                    
                    type : 'POST',

                    data :  {
                                prdSlug : prdSlug, 
                            },

                    beforeSend: function(xhr){
                        xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name ="csrf-token"]').attr('content'));
                    },
                    
                }).success(function(data){

                    listFraisDossier = data;

                 }).error(function(data){
                    console.log('NO!!!');
                });

            }

            setTimeout(function(){
                $('.uk-modal').addClass('loaded');
                $('h1').css('color','#222222');
            }, 1000);

            $('#comparateur').click(function(){
                makeTarif();
            });

            var divActions = $('.actions').get();
                      
            //$("#sans-prestation").iCheck('check');

            $("#tel_mobile").mask("99.99.99.99.99");

            $("#tel_mobile1").mask("99.99.99.99.99");
            $("#tel_mobile21").mask("99.99.99.99.99");
            $("#tel_bureau1").mask("99.99.99.99.99");
            $("#tel_domicile1").mask("99.99.99.99.99");
            $("#date_effet").mask("99/99/9999");

            var cotisation = Math.round($('#tarif').val());
            var dateEffet  = $('#date_effet').val();
            var civilitee  = $('#civilitee').val();
            var produit    = $('#produit').val();


            $('#callClient').click(function(){

                swal({
                  title: "Voulez-vous l'appeler ?",
                  text: "Cliquer sur confirmer pour passer l'appel.",
                  type: 'info',
                  showCancelButton: true,
                  confirmButtonColor: '#2cba00',
                  cancelButtonColor: '#DD6B55',
                  confirmButtonText: 'Appeler',
                  cancelButtonText: 'Annuler',
                }).then(function () {
                  swal(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                  )
                }, function (dismiss) {
                  // dismiss can be 'cancel', 'overlay',
                  // 'close', and 'timer'
                  if (dismiss === 'cancel') {
                    swal(
                      'Cancelled',
                      'Your imaginary file is safe :)',
                      'error'
                    )
                  }
                });

            });


            $('#saveInfoBanque').click(function(){

                profileSlug = $("#profile_slug").val();

                $('#saveInfoBanque').hide();

                formules  = [];
                prdSlug   = $(this).attr('data-prd');
                ficheSlug = $(this).attr('data-slug');
                ficheNum  = $(this).attr('data-fiche');
                clientId  = $(this).attr('data-client');
                var urlPdf   = "" ;

                optionsHidden = $('#optionsHidden').val();

                $.ajax({

                    url  : "{!! URL::to('"+profileSlug+"/client/saveInfoClientSante') !!}",
                    
                    type : 'POST',

                    data :  $('#form_info_contrat, #form_info_bancaire').serialize()+"&options="+optionsHidden,

                    beforeSend: function(xhr){
                        xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name ="csrf-token"]').attr('content'));

                        $("#save").html("<tr><td align='center' colspan='11'><div id='beforeLoadDiv' class='md-preloader uk-container-center' ><svg xmlns='http://www.w3.org/2000/svg' version='1.1' height='48'  width='48' viewbox='0 0 75 75'><circle cx='37.5' cy='37.5' r='33.5' stroke-width='4' /></svg></div></td></tr>");
                    },
                }).success(function(data){

                    // urlPdf+="<a id='saveInfoBanque' class='md-btn md-btn-block md-btn-primary md-btn-small md-btn-wave-light waves-effect waves-button waves-light' href='#' >"
                    //                             +"<i style='color:white;' class='material-icons' >&#xE161;</i>PDF</a>";
                                                
                    // $('#pdf').html(urlPdf);
                    
                    //window.open(data.url);
                    // $.get(data.url, function (donnee){
                    var fileName         = data.fileName; 
                    var nomClient        = data.nomClient;
                    var emailClient      = data.emailClient;
                    var prenomClient     = data.prenomClient;
                    var dossierCompagnie = data.dossierCompagnie;
                    var lienPdf          = data.lienPdf;
                    var garantie         = data.garantie;
                    //var civiliteClient =data.civiliteClient;
                    var tarif            = data.tarif;
                    var propositionId    = data.PropositionId;

                    if($("#signature").prop('checked')){

                        $.ajax({

                            url  : "{{ URL::to('envoi/emailBA') }}",
                            
                            type : 'POST',

                            data :  {
                                        prdSlug          : prdSlug,
                                        ficheSlug        : ficheSlug,
                                        fileName         : fileName, 
                                        nomClient        : nomClient, 
                                        emailClient      : emailClient,
                                        prenomClient     : prenomClient, 
                                        garantie         : garantie, 
                                        cotisation       : tarif, 
                                        dateEffet        : dateEffet, 
                                        civilitee        : civilitee, 
                                        produit          : produit, 
                                        dossierCompagnie : dossierCompagnie, 
                                        lienPdf          : lienPdf,
                                        propositionId    : propositionId
                                    },

                            beforeSend: function(xhr){
                                xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name ="csrf-token"]').attr('content'));
                            },
                            
                        }).success(function(data){
                            console.log('OK.');
                         }).error(function(data){
                            console.log('NO!!!');
                        });

                    }

                    //  });


                    // ajax nom fichier


                    // fin ajax


                    console.log(data.url);

                    vueLead.updateProc(data.processes);

                    swal({ title: "Validé", text: data.message, timer: 2000,  type: "success", confirmButtonText: "Fermer" });
                    $('#saveInfoBanque').show();
                    $('#save').hide();
                    
                    
                }).error(function(data){

                    swal({ title: "Erreur!", text: "Erreur d'enregistrement !!!", type: "error", confirmButtonText: "Fermer" });
                    $('#save').hide();
                    $('#saveInfoBanque').show();

                });

            });

            
            $('#copyBankDataPre').click(function() {

                $('#nom_banque_rem').val($('#nom_banque_pre').val());

                $('#nom_banque_rem').parent().addClass("md-input-wrapper md-input-filled");

                $('#adresse_banque_rem').val($('#adresse_banque_pre').val());

                $('#adresse_banque_rem').parent().addClass("md-input-wrapper md-input-filled");

                $('#ville_banque_rem').val($('#ville_banque_pre').val());

                $('#ville_banque_rem').parent().addClass("md-input-wrapper md-input-filled");

                $('#iban_rem').val($('#iban_pre').val());

                $('#iban_rem').parent().addClass("md-input-wrapper md-input-filled");

                $('#code_bic_rem').val($('#code_bic_pre').val());

                $('#code_bic_rem').parent().addClass("md-input-wrapper md-input-filled");

                verifyIBANRem();

            });

            $('.VerifyIBANRem').blur(function(){

                verifyIBANRem();

            });

            

            $('#star-soins').rating(function(rate, event){ $('#soinVal').html(rate); });
            $('#star-optique').rating(function(rate, event){ $('#optiqueVal').html(rate); });
            $('#star-dentaire').rating(function(rate, event){ $('#dentaireVal').html(rate); });
            $('#star-hospita').rating(function(rate, event){ $('#hospitaVal').html(rate); });


            $("#iban_pre").mask("**99-****-****-****-****-****-***", { "placeholder": "" });
            $("#iban_rem").mask("**99-****-****-****-****-****-***", { "placeholder": "" });

            $("#code_bic_pre").mask("***********", { "placeholder": "" });
            $("#code_bic_rem").mask("***********", { "placeholder": "" });


            $('#iconeProposition').click(function(){

                profileSlug = $("#profile_slug").val();
                
                formules = [];
                ficheNum = $(this).attr('data-fiche');
                clientId = $(this).attr('data-client');
                produit  = $('#produit').val(); 
                
                $(".comparedCheck").each(function(){
                    documents = []; 

                        $(".docGarantie"+$(this).attr('data-num')).each(function(){         
                            documents.push({            
                               'code':  $(this).attr('data-code'),          
                               'libelle':  $(this).attr('data-libelle'),          
                               'lien'    : $(this).attr('href')         
                            });         
                        });

                        formules.push(
                                        {
                                            'id'            : $(this).attr('data-num'),
                                            'logo'          : $(this).attr('data-logo'),
                                            'compagnie'     : $(this).attr('data-compagnie'),
                                            'gamme'         : $(this).attr('data-gamme'),
                                            'code_garantie' : $(this).attr('data-garantie-code'),
                                            'garantie'      : $(this).attr('data-garantie'),
                                            'tarif'         : Decimal.convert($(this).attr('data-tarif'), 2),
                                            'documents'     : documents,            
                                            'lienPdf'       : ''
                                        }
                                    );
             

                });
                lien = $('#tarif_link').val();

                sansPrestation = 0;
                
                if($("#sans-prestation").prop('checked')){
                    sansPrestation = 1;
                }else{
                    sansPrestation = 0;
                }

                codepostale = $('#code_postal').val();
                dateA       = moment($('#date_naissance').val(), 'DD/MM/YYYY').format('YYYY-MM-DD');
                dateC       = (moment($('#formConjoint').find('input[name="conjoint_date_naissance"]').val(), 'DD/MM/YYYY').isValid()) ? moment($('#formConjoint').find('input[name="conjoint_date_naissance"]').val(), 'DD/MM/YYYY').format('YYYY-MM-DD') : '';
                regimeA     = $('#saregime_id').find(":selected").val();
                regimeC     = $('#conjoint_saregime_id').find(":selected").val();
                prestation  = [$('#soinVal').text(), $('#optiqueVal').text(), $('#dentaireVal').text(), $('#hospitaVal').text() ];
                dateE = [];
                var dateEffet = moment($('#date_effet').val().trim(), 'DD/MM/YYYY').format('YYYY-MM-DD');
                
                $('.child_DN').each(function(){
                    
                    //date_E  = $(this).val();
                    date_E  = moment($(this).val(), 'DD/MM/YYYY').format('YYYY-MM-DD');
                    index   = $(this).attr('data-id');
                    ayant_E = $('#ad'+index).val();
                    if(date_E != '' && ayant_E != ''){
                        dateE.push(date_E+'#'+ayant_E);
                    }
                });
                swal({
                    title: "Envoi de proposition",
                    text: "Cliquer sur confirmer pour envoyer la proposition",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: "Confirmer",
                    cancelButtonText: "Annuler",
                    showLoaderOnConfirm: true,

                    preConfirm: function (email) {
                    return new Promise(function (resolve, reject) {
                        setTimeout(function(){
                            $.ajax({
                                url  : "{!! URL::to('"+profileSlug+"/client/proposeSanteFormules') !!}",
                                type : 'POST',
                                data : {
                                        codepostale : codepostale,
                                        dateA   : dateA,
                                        dateC   : dateC,
                                        regimeA : regimeA,
                                        regimeC : regimeC,
                                        dateE   : dateE,
                                        dateEffet : dateEffet,
                                        prestation : prestation,
                                        sansPrestation : sansPrestation,
                                        ficheNum:ficheNum,
                                        clientId:clientId,
                                        options:tabOptions,
                                        formules:formules,
                                        produit:produit,
                                        prestations:[$('#soinVal').text(), $('#optiqueVal').text(), $('#dentaireVal').text(), $('#hospitaVal').text()],
                                    },
                                beforeSend: function(xhr){
                                    xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));
                                },
                        
                            }).success(function(data){
                                if(data.success){
                                    resolve();
                                }else{
                                    reject("Erreur d'ajout de proposition!!");
                                }
                                
                            }).error(function(data){
                                reject("Erreur d'ajout de proposition!!");
                            });
                        }, 2000);
                    })

                },
                allowOutsideClick: false
                }).then(function () {
                   swal({ title: "success", text: "Proposition Envoyée", type: "success", confirmButtonText: "Fermer" });
                });
            });

// traitement detail prestation 

            $('#detailPrestations').click(function(){
                
                    formules = [];
                    
                    $(".comparedCheck").each(function(){
                        documents = []; 
    
                            $(".docGarantie"+$(this).attr('data-num')).each(function(){         
                                documents.push({            
                                   'code':  $(this).attr('data-code'),          
                                   'libelle':  $(this).attr('data-libelle'),          
                                   'lien'    : $(this).attr('href')         
                                });         
                            });

                            formules.push(
                                            {
                                                'id'            : $(this).attr('data-num'),
                                                'logo'          : $(this).attr('data-logo'),
                                                'compagnie'     : $(this).attr('data-compagnie'),
                                                'gamme'         : $(this).attr('data-gamme'),
                                                'code_garantie' : $(this).attr('data-garantie-code'),
                                                'garantie'      : $(this).attr('data-garantie'),
                                                'tarif'         : $(this).attr('data-tarif'),
                                                'documents'     : documents,            
                                                'lienPdf'       : ''
                                            }
                                        );
                 

                    });
                                                    $.ajax({
                                    url  : "{{ URL::to('modalDetail') }}",
                                    
                                    type : 'POST',
                                    data : {formules:formules},
                                    beforeSend: function(xhr){
                                        xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));
                                    },
                            
                                }).success(function(data){
                                    $('#retourTableauGarantie').attr('src', data);
                                   console.log(data);
                                    
                                }).error(function(data){

                                });

            });


// fin traitement 

            $(".resetTarif").change(function(){
                $("#newTarifList").html("");
            });

            $(".loadTarif").click(function(){

                makeTarif();
                    
            });

        });

        function makeTarif() {
            
            $("#etatSave").val(0);

            profileSlug = $("#profile_slug").val();

            dataForm = $('#clientForm, #formAssure, #formConjoint, #formChildren ,#formGrpQst').serializeObject();
            
            dataForm.date_effet     = moment(dataForm.date_effet, 'DD/MM/YYYY').format('YYYY-MM-DD');
            dataForm.date_naissance = moment(dataForm.date_naissance, 'DD/MM/YYYY').format('YYYY-MM-DD');
            
            if(moment(dataForm.conjoint_date_naissance, 'DD/MM/YYYY').isValid()){
                dataForm.conjoint_date_naissance = moment(dataForm.conjoint_date_naissance, 'DD/MM/YYYY').format('YYYY-MM-DD');
            }

            $.ajax({

                url  : "{!! URL::to('"+profileSlug+"/client/sante/update') !!}",
                
                type : 'POST',

                data : dataForm,//$('#clientForm, #formAssure, #formConjoint, #formChildren').serialize(), 

                beforeSend: function(xhr){
                                            xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));
                                        },
                
            }).success(function(data){

                var fichePoint = data.fichePoints;
                $('.childrenList').attr("data-origin", "1");
                $('#conjoint_id').val(data.conjointId);
                
                $.each(data.enfants, function(key, value){
                            
                    i = key + 1;

                    $("#ide"+i).val(value.id);
                    $("#ide"+i).attr("name", "enfant["+i+"][id]");
                    $("#ide"+i).attr("id", "ide"+i);
                    
                    $("#sexe"+i).attr("name", "enfant["+i+"][sexe]");
                    $("#sexe"+i).attr("id", "sexe"+i);
                    var selectize = $("#sexe"+i)[0].selectize;
                    selectize.clearOptions();
                    selectize.addOption({text: "F", value: "F"});
                    selectize.addOption({text: "M", value: "M"});
                    selectize.setValue(value.sexe); 
                    
                    $("#nom"+i).attr("name", "enfant["+i+"][nom]");
                    $("#nom"+i).attr("id", "nom"+i);
                    $("#nom"+i).val(value.nom);
                    
                    $("#prenom"+i).attr("name", "enfant["+i+"][prenom]");
                    $("#prenom"+i).attr("id", "prenom"+i);
                    $("#prenom"+i).val(value.prenom);
                    
                    $("#dn"+i).attr("name", "enfant["+i+"][date_naissance]");
                    $("#dn"+i).attr("id", "dn"+i);
                    $("#dn"+i).val(moment(value.date_naissance, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                    
                    $("#ad"+i).attr("name", "enfant["+i+"][ayant_droit]");
                    $("#ad"+i).attr("id", "ad"+i);
                    $("#ad"+i).val("id", "ad"+i);
                    $("#ad"+i).attr('value', value.ayant_droit).attr('selected', 'selected');
                    var selectize = $("#ad"+i)[0].selectize;
                    selectize.clearOptions();
                    selectize.addOption({text: "Conjoint", value: "C"});
                    selectize.addOption({text: "Prospect", value: "P"});
                    selectize.setValue(value.ayant_droit); 
                    
                    
                    $("#delete"+i).attr("onclick", "deleteChild("+i+")");
                    $("#delete"+i).attr("id", "delete"+i);
                    
                    $("#child"+i).attr("id", "child"+i);

                });

                lien = $('#tarif_link').val();

                sansPrestation = 0;
                
                if($("#sans-prestation").prop('checked')){
                    sansPrestation = 1;
                }else{
                    sansPrestation = 0;
                }

                codepostale = $('#code_postal').val();
                dateA       = moment($('#date_naissance').val(), 'DD/MM/YYYY').format('YYYY-MM-DD');
                dateC       = (moment($('#formConjoint').find('input[name="conjoint_date_naissance"]').val(), 'DD/MM/YYYY').isValid()) ? moment($('#formConjoint').find('input[name="conjoint_date_naissance"]').val(), 'DD/MM/YYYY').format('YYYY-MM-DD') : '';
                regimeA     = $('#saregime_id').find(":selected").val();
                regimeC     = $('#conjoint_saregime_id').find(":selected").val();
                prestation  = [$('#soinVal').text(), $('#optiqueVal').text(), $('#dentaireVal').text(), $('#hospitaVal').text() ];
                dateE = [];
                var dateEffet = moment($('#date_effet').val().trim(), 'DD/MM/YYYY').format('YYYY-MM-DD');
                
                $('.child_DN').each(function(){
                    
                    //date_E  = $(this).val();
                    date_E  = moment($(this).val(), 'DD/MM/YYYY').format('YYYY-MM-DD');
                    index   = $(this).attr('data-id');
                    ayant_E = $('#ad'+index).val();
                    if(date_E != '' && ayant_E != ''){
                        dateE.push(date_E+'#'+ayant_E);
                    }
                });

                $.ajax({
                    url  : "{{ URL::to('tarif/sante') }}",
                    type : 'POST',
                    data : {
                                codepostale:codepostale, 
                                dateA:dateA, 
                                dateC:dateC, 
                                regimeA:regimeA, 
                                regimeC:regimeC, 
                                prestation:prestation,
                                dateE:dateE,
                                dateEffet:dateEffet,
                                sansPrestation:sansPrestation,
                                fichePoint:fichePoint
                            },
                    datatype : "jsonp",
                    'Content-Type' : "application/json",
                    beforeSend: function(xhr){
                            xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));
                            // $("#preloadCompagnies").html("<div align='center'><div class='md-preloader uk-container-center' ><svg xmlns='http://www.w3.org/2000/svg' version='1.1' height='48'  width='48' viewbox='0 0 75 75'><circle cx='37.5' cy='37.5' r='33.5' stroke-width='4' /></svg></div></div>");
                            altair_helpers.content_preloader_show();
                            },
                            
                }).success(function(res){

                    tabOptions = [];

                    $("#preloadCompagnies").html("");
                    
                    result = res[0].compagnie;

                    if(result!=null){

                        var simpleTarif   = "" ;
                        activeTab  = 0;
                        indexTarif = 1;
                        newTarif ="";

                        newTarif +="<table  id='TarifTable' class='uk-table uk-table-nowrap'>"

                                    +"<thead>"
                                        +"<tr>"
                                            +"<td class='uk-text-center'></td>"
                                            +"<td class='uk-text-center'>Compagnie</td>"
                                            +"<td class='uk-text-center'>Garantie</td>"
                                            +"<td class='uk-text-center'>Tarif</td>"
                                            +"<td class='uk-text-center'>Documents</td>"
                                            +"<td class='uk-text-center'>"
                                                +"<img style='width:30px; margin-top: 1px;margin-right:4px;' class='uk-float-left' src={{asset('assets/img/soins.gif')}}> "
                                            +"</td>"
                                            +"<td class='uk-text-center'>"
                                                +"<img style='width:30px; margin-top: 1px;margin-right:4px;' class='uk-float-left' src={{asset('assets/img/hospitalisation.gif')}}> "
                                            +"</td>"
                                            +"<td class='uk-text-center'>"
                                                +"<img style='width:30px; margin-top: 1px;margin-right:4px;' class='uk-float-left' src={{asset('assets/img/optique.gif')}}>"
                                            +"</td>"
                                            +"<td class='uk-text-center'>"
                                                +"<img style='width:30px; margin-top: 1px;margin-right:4px;' class='uk-float-left' src={{asset('assets/img/dentaire.gif')}}> "
                                            +"</td>"
                                        +"</tr>"
                                    +"</thead>"
                                +"<tbody id=''>";

                                    

                        $.each(result, function(j, gamme){

                                active = '';
                                if(activeTab==0){
                                    active ='uk-active';
                                }
                                
                                compteur = 0;
                                if(gamme.gammes!=null){
                                
                                //simpleTarif += "<li class='"+active+"' data-uk-grid={controls: '#tab"+index+"sort'}>";
                                $.each(gamme.gammes, function(k, garantie){
                                   
                                    
                                    $.each(garantie.garanties, function(index, value){

                                        if(value.tarif){

                                            imgGarantie = "<img  class='img-tarif md-card-head-avatar md-user-image' src='"+lien+value.logo+"' alt=''/>";

                                            docs = (garantie.documents) ?  garantie.documents : null;

                                            docBA       = '-';
                                            if(docs!=null && docs[3]){
                                                docBA = "<a data-code='"+docs[3].code+"' data-libelle='"+docs[3].libelle+"' class='uk-icon-button uk-icon-clone uk-text-primary  docGarantie"+value.id+"' data-uk-tooltip title='BULLETIN ADHESION' href='"+lien+""+docs[3].lien+"' target='_blank'></a>";
                                            }

                                            docGarantie = '-';
                                            if(docs!=null && docs[2]){
                                                docGarantie = "<a data-code='"+docs[2].code+"' data-libelle='"+docs[2].libelle+"'  class='uk-icon-button uk-icon-check uk-text-success docGarantie"+value.id+"' data-uk-tooltip title='GARANTIES' href='"+lien+""+docs[2].lien+"' target='_blank'></a>";
                                            }

                                            docCG       = '-';
                                            if(docs!=null && docs[4]){
                                                docCG = "<a data-code='"+docs[4].code+"' data-libelle='"+docs[4].libelle+"' class='uk-icon-button uk-icon-plus uk-text-warning  docGarantie"+value.id+"' data-uk-tooltip title='CONDITION GENERALE' href='"+lien+""+docs[4].lien+"' target='_blank'></a>";
                                            }

                                            newTarif += "<tr id='tr"+indexTarif+"' class='classTr hideTR' data-sort='0' >"

                                                newTarif += "<td class='uk-text-middle uk-text-center'><input id='check"+indexTarif+"' type='checkbox' data-compagnie='"+j+"' data-id='compareTarif"+indexTarif+"' data-num='"+value.id+"' data-logo='"+lien+value.logo+"' data-compagnie='"+j+"' data-gamme='"+k+"' data-garantie-code='"+value.codeGarantie+"' data-garantie='"+value.libelle+"' data-tarif='"+value.tarif+"' class='icheckTD checkboxTarif' name='tarifs' data-md-icheck  data-tr='"+indexTarif+"' ></td>";

                                                newTarif += "<td class='uk-text-middle uk-text-center uk-text-small' alt='"+j+"' ><img alt='"+j+"' class='img-tarif md-card-head-avatar md-user-image' src='"+lien+value.logo+"' alt=''/></td>";
                                                
                                                newTarif += "<td class='uk-text-left uk-text-middle tdGarantie uk-text-small uk-text-break'>"
                                                                +k+" <br> <span class='uk-text-bold'>"+value.libelle+"</span><br> ";
                                                                
                                                                if(typeof value.options != 'undefined') {

                                                                    newTarif += "<br><ul id='listRenfort"+value.id+"' class='md-list md-list-addon md-list-right'>";

                                                                    if(!Array.isArray(value.options)) {
                                                                     console.log('is not array');

                                                                     //var codeOptionValeur = value.options.CodeGarantie;

                                                                     if(value.options != "")
                                                                     {
                                                                        newTarif +=  "<li class='renfort'>"
                                                                                    +"<a href='#' class='md-list-addon-element uk-width-1-1'><span class='uk-badge'>"+ value.options.Tarif +" &euro;</span></a>"
                                                                                    +"<div class='md-list-content'>"
                                                                                        +"<span class='md-list-heading'><input data-garantie-code='"+value.codeGarantie+"' data-class='"+value.options.CodeGarantie +"-"+value.id+"' class='aprilOptions "+ value.id +"' type='checkbox' data-garantie='"+value.id+"' data-libelle='"+value.options.CodeGarantie+"' data-tarif='"+value.options.Tarif+"' name='options' id='Option-"+value.codeGarantie+"-"+compteur+"'><label for='Option-"+value.codeGarantie+"-"+compteur+"'> "+value.options.CodeGarantie+" </label></span>"
                                                                                    +"</div>"
                                                                                +"</li>";
                                                                                compteur++;
                                                                     } 

                                                                     
                                                                    }else {

                                                                        console.log('is array');

                                                                        var lib_option = '';

                                                                        if(k == 'SanteEssentiellePlus')
                                                                        {
                                                                            lib_option = 'Option Eco Essentielle +';
                                                                        }
                                                                        else
                                                                        {
                                                                            lib_option = '2 &euro; Malin';
                                                                        }    

                                                                        var EUROMALIN = "E"+compteur;

                                                                        newTarif +=  "<li class='renfort'>"
                                                                                    +"<a href='#' class='md-list-addon-element uk-width-1-1'></a>"
                                                                                    +"<div class='md-list-content'>"
                                                                                        +"<span class='md-list-heading'><input data-euro-malin='"+EUROMALIN+"' data-class='' class='malin' data-lib-gamme='"+k+"' data-garantie-code='"+value.codeGarantie+"' data-lib-garantie='"+value.libelle+"' type='checkbox' data-garantie='"+value.id+"' data-libelle='2 euro malin' name='options' id='E-"+value.codeGarantie+"-"+compteur+"'><label for='E-"+value.codeGarantie+"-"+compteur+"'> "+lib_option+" </label></span>"
                                                                                    +"</div>"
                                                                                +"</li>";

                                                                        compteur++;

                                                                        $.each(value.options, function(i, v){
                                                                           
                                                                          
                                                                           var libelleRenfort = (v.CodeNiveau) ? v.CodeGarantie + ' ' + v.CodeNiveau : v.CodeGarantie;
                                                                           
                                                                           
                                                                           newTarif +=  "<li class='optionsRenfort"+value.id+" renfort'>";
                                                                                           newTarif += "<a href='#' class='md-list-addon-element uk-width-1-1'><span class='uk-badge "+value.id+"-cotisation' data-tarif='"+v.Tarif+"'>"+ v.Tarif +" &euro;</span></a>";
                                                                                            newTarif += "<div class='md-list-content'>";
                                                                                             newTarif += "<span class='md-list-heading'>";
                                                                                             newTarif += "<input data-garantie-code='"+value.codeGarantie+"' data-class='"+v.CodeGarantie +"-"+value.id+"' data-garantie='"+value.id+"' data-libelle='"+v.CodeGarantie+"' data-tarif='"+v.Tarif+"' class='"+EUROMALIN+" "+ value.id +" aprilOptions "+ v.CodeGarantie +"-"+value.id+"' name='"+ v.CodeGarantie +"' type='checkbox' id='R-"+value.codeGarantie+"-"+compteur+"'>";
                                                                                              newTarif += "<label for='R-"+value.codeGarantie+"-"+compteur+"'> "+libelleRenfort+" </label></span>"
                                                                                            +"</div>"
                                                                                        +"</li>";

                                                                            compteur++;
                                                                        
                                                                        });


                                                                    }
                                                                   
                                                                    
                                                                    newTarif += "</ul>";
                                                                      
                                                                }
                                                                
                                                            newTarif += "</td>";
                                                
                                                newTarif += "<td id='td-tarif-"+value.id+"' style='cursor:pointer;' data-soins='"+((value.groupeprestation[1]) ? value.groupeprestation[1].valeur : 0 )+"' data-optique='"+( (value.groupeprestation[2]) ? value.groupeprestation[2].valeur : 0 )+"' data-dentaire='"+( (value.groupeprestation[3]) ? value.groupeprestation[3].valeur : 0 )+"' data-hospital='"+ ( (value.groupeprestation[4]) ? value.groupeprestation[4].valeur : 0 )+"' data-gamme-id='"+value.gid+"' data-garantie-id='"+value.id+"' data-garantie-code='"+value.codeGarantie+"' data-garantie='"+value.libelle+"' data-tarif='"+value.tarif+"' data-id='compareTarif"+indexTarif+"' data-num='"+value.id+"' data-logo='"+lien+value.logo+"' data-compagnie='"+j+"' data-compagnie-code='"+gamme.code+"' data-gamme='"+k+"' data-garantie='"+value.libelle+"' data-tarif='"+value.tarif+"' data-uk-switcher-item='next' class='souscrireTarif backgroundTarifColor uk-text-small uk-text-right uk-text-middle' data-sort='"+value.tarif+"'>"
                                                                +"<span style='font-size:16px;' class=' uk-badge uk-badge-warning uk-text-bold'><span id='tarif-"+value.id+"' data-tr='check"+indexTarif+"' data-tarif='"+value.tarif+"'>"+Decimal.convert(value.tarif, 2)
                                                                    +"</span> <i class='md-color-grey-50 uk-icon-euro'></i>"
                                                                +"</span><br>"
                                                                +"<span class='marginTarif'>"
                                                                    // +"<span id='tarif12-"+value.id+"'>"+Decimal.convert(value.tarif*12, 2)+"</span>"
                                                                    +"<span data-uk-tooltip={pos:'bottom'} title='Frais Dossier'>"+listFraisDossier[value.cie_code]+"</span>"
                                                                    +"<i class='uk-icon-euro'></i>"
                                                                +"</span>"
                                                            +"</td>";

                                                newTarif += "<td class='uk-text-middle uk-text-center uk-text-small'>"+docBA+docGarantie+docCG+"</td>";
                                                
                                                if(typeof value.groupeprestation == 'object'){

                                                    varOptique  = (value.groupeprestation[2]) ? value.groupeprestation[2].affichage : 0;
                                                    valOptique  = (value.groupeprestation[2]) ? value.groupeprestation[2].valeur : 0;

                                                    varDentaire = (value.groupeprestation[3]) ? value.groupeprestation[3].affichage : 0;
                                                    valDentaire = (value.groupeprestation[3]) ? value.groupeprestation[3].valeur : 0;

                                                    varHospit   = (value.groupeprestation[4]) ? value.groupeprestation[4].affichage : 0;
                                                    valHospit   = (value.groupeprestation[4]) ? value.groupeprestation[4].valeur : 0;

                                                    varMalad    = (value.groupeprestation[1]) ? value.groupeprestation[1].affichage : 0;
                                                    valMalad    = (value.groupeprestation[1]) ? value.groupeprestation[1].valeur : 0;

                                                    
                                                    newTarif += "<td data-sort='"+valMalad+"' class='filterTarifColor uk-text-middle uk-text-center uk-text-small'><span class='uk-badge uk-badge-notification'>"+varMalad+"</span></td>"
                                                    newTarif += "<td data-sort='"+valHospit+"' class='filterTarifColor uk-text-middle uk-text-center uk-text-small'><span class='uk-badge uk-badge-notification'>"+varHospit+"</span></td>"
                                                    newTarif += "<td data-sort='"+valOptique+"' class='filterTarifColor uk-text-middle uk-text-center uk-text-small'><span class='uk-badge uk-badge-notification'>"+varOptique+"</span></td>"
                                                    newTarif += "<td data-sort='"+valDentaire+"' class='filterTarifColor uk-text-middle uk-text-center uk-text-small'><span class='uk-badge uk-badge-notification'>"+varDentaire+"</span></td>";

                                                }else{

                                                    newTarif += "<td class='filterTarifColor uk-text-middle uk-text-center uk-text-small'>-</td>"
                                                    newTarif += "<td class='filterTarifColor uk-text-middle uk-text-center uk-text-small'>-</td>"
                                                    newTarif += "<td class='filterTarifColor uk-text-middle uk-text-center uk-text-small'>-</td>"
                                                    newTarif += "<td class='filterTarifColor uk-text-middle uk-text-center uk-text-small'>-</td>";

                                                }

                                            newTarif += "</tr>";

                                            
                                            indexTarif++;

                                        }
        
                                    });
                                
                                });

                                }
                                activeTab++;
                                
                            });
                        
                        newTarif +="</tbody>"

                                +"</table>";

                        altair_helpers.content_preloader_hide();

                        $("#comparedClear").trigger('click');
                        $('.icheckTD').iCheck('destroy');
                        
                        $("#newTarifList").html(newTarif);


                        //Traitement des renforts April
                        $('.aprilOptions').change(function(){
                            
                            var id          = $(this).attr('id');
                            var libelle     = $(this).attr('data-libelle');
                            var garantie_id = $(this).attr('data-garantie');
                            var tarif       = $(this).attr('data-tarif');
                            var tarifDec    = Math.round(parseFloat(tarif));
                            var classe      = $(this).attr('data-class');
                            var code        = $(this).attr('data-garantie-code');
                            // console.log('id : ',id);
                            // console.log('libelle : ',libelle);
                            // console.log('garantie_id : ',garantie_id);
                            // console.log('tarif : ',tarifDec);
                            // console.log('classe : ',classe);
                            // console.log('code : ',code);


                            if($(this).prop( "checked" )) {
                                var option = {

                                    id: id,
                                    garantie_id: garantie_id,
                                    libelle: libelle,
                                    tarif: tarif,
                                    code: code

                                };

                                if(classe.search("PackConfort") || classe.search("PackBienEtre")) {
                                    $('.'+classe).attr('disabled', true);
                                    $('#'+id).attr('disabled', false);
                                }
                              
                                tabOptions.push(option);
                                var tempTarif = ($('#tarif-'+garantie_id).attr('data-tarif') * 1);
                                tempTarifDec  = Math.round(parseFloat(tempTarif));
                                console.log('tarifPrincipal : ',tempTarifDec);
                                $('#tarif-'+garantie_id).text(Decimal.convert(tempTarifDec + tarifDec, 2));
                                $('#tarif-'+garantie_id).attr('data-tarif', tempTarifDec + tarifDec);
                                $('#td-tarif-'+garantie_id).attr('data-tarif', tempTarifDec + tarifDec);
                                //$('#tarif12-'+garantie_id).text(Decimal.convert((tempTarifDec + tarifDec) * 12, 2));
                                //console.log(garantie_id);

                            }else {

                               if(classe.search("PackConfort") || classe.search("PackBienEtre")) {
                                    $('.'+classe).attr('disabled', false);
                                }
                              
                                tabOptions = removeOption(tabOptions,'id',id);
                                var tempTarif = Math.round(($('#tarif-'+garantie_id).attr('data-tarif') * 1));
                                $('#tarif-'+garantie_id).text(Decimal.convert(tempTarif - tarif, 2));
                                $('#tarif-'+garantie_id).attr('data-tarif', tempTarif - tarif);
                                $('#td-tarif-'+garantie_id).attr('data-tarif', tempTarif - tarif);
                                //$('#tarif12-'+garantie_id).text(Decimal.convert((tempTarif - tarif) * 12, 2));
                                console.log('remove => ', tabOptions);
                                console.log('remove 1');
                                
                            }

                            ligneCheck = $('#tarif-'+garantie_id).attr("data-tr");
                            $("#"+ligneCheck).attr("data-tarif", Decimal.convert($('#tarif-'+garantie_id).attr("data-tarif"), 2));

                            
                        });

                        $('.malin').change(function(){

                            EUROMALIN = $(this).attr("data-euro-malin");

                            var id          = $(this).attr('id');
                            var libelle     = $(this).attr('data-libelle');
                            var garantie_id = $(this).attr('data-garantie');
                            var code        = $(this).attr('data-garantie-code');
                            var checked     = $(this).prop("checked");

                            removeOption(tabOptions,'id',id);


                            if($(this).prop("checked")) {

                                var option = {

                                    id: id,
                                    garantie_id: garantie_id,
                                    libelle: libelle,
                                    code: code,
                                    checked: checked

                                };

                                tabOptions.push(option);
                                
                            }else {
                            
                                tabOptions = removeOption(tabOptions,'id',id);
                                console.log('remove => ', tabOptions);
                                console.log('remove 2');

                                
                            }

                            $('.'+EUROMALIN).each(function() {

                                if($(this).prop("checked")) {
                                    option_id = $(this).attr('id');
                                    console.log(option_id);
                                    tabOptions = removeOption(tabOptions,'id', option_id);
                                }

                            });

                            //tabOptions = [];

                            lib_gamme = $(this).attr('data-lib-gamme');

                            //lib_gamme = ( getNewAprilGammeName(lib_gamme) ) ? getNewAprilGammeName(lib_gamme) : lib_gamme;

                            code_garantie = $(this).attr('data-garantie-code');
                            data_garantie = $(this).attr('data-garantie');
                            lib_garantie  = $(this).attr('data-lib-garantie');

                            euro_malin    = ($(this).prop("checked")) ? 1 : 0;
                            
                            $.post( "{!! url('aprilRenfort') !!}", {
                                                                        
                                                                        // date effet
                                                                        dateEffet:dateEffet,
                                                                        
                                                                        // assuré
                                                                        dateC:dateC, 
                                                                        dateA:dateA, 
                                                                        codepostale:codepostale,

                                                                        // conjoint
                                                                        regimeA:regimeA, 
                                                                        regimeC:regimeC, 

                                                                        // children
                                                                        dateE:dateE, 

                                                                        // gamme
                                                                        lib_gamme:lib_gamme,
                                                                        
                                                                        // garanttie
                                                                        lib_garantie:lib_garantie,

                                                                        euro_malin:euro_malin // True or False
                                                                        
                                                                    }
                            ).done(function( data ) {

                                result = jQuery.parseJSON(data);

                                $(".optionsRenfort"+data_garantie).remove();

                                newOption = '';

                                $.each(result.options, function(io, vo){

                                    //var codeOptionValeur = vo.CodeOptionValeur.split('_');

                                    var libelleRenfort = (vo.CodeNiveau) ? vo.CodeGarantie + ' ' + vo.CodeNiveau : vo.CodeGarantie;

                                    newOption='';

                                    newOption +=  "<li class='optionsRenfort"+data_garantie+" renfort'>";
                                                    newOption += "<a href='#' class='md-list-addon-element uk-width-1-1'><span class='uk-badge "+data_garantie+"-cotisation' data-tarif='"+vo.Tarif+"'>"+ vo.Tarif+" &euro;</span></a>";
                                                      newOption += "<div class='md-list-content'>";
                                                      newOption += "<span class='md-list-heading'>";
                                                      newOption += "<input data-garantie-code='"+code_garantie+"' data-class='"+vo.CodeGarantie +"-"+data_garantie+"' data-garantie='"+data_garantie+"' data-libelle='"+vo.CodeGarantie+"' data-tarif='"+vo.Tarif+"' class='"+EUROMALIN+" "+ data_garantie +" aprilOptionsMalin "+ vo.CodeGarantie +"-"+data_garantie+"' name='"+ vo.CodeGarantie +"' type='checkbox' id='R-"+code_garantie+"-"+compteur+"'>";
                                                       newOption += "<label for='R-"+code_garantie+"-"+compteur+"'> "+libelleRenfort+" </label></span>"
                                                     +"</div>"
                                                 +"</li>";

                                     compteur++;

                                     $('#listRenfort'+data_garantie).append(newOption);
                                     
                                });

                                $('#tarif-'+data_garantie).html(result.cotisation);
                                $('#tarif-'+data_garantie).attr('data-tarif', result.cotisation);
                                //$('#tarif12-'+data_garantie).html(result.cotisation);

                                $('.aprilOptionsMalin').change(function(){
                            
                                    var id          = $(this).attr('id');
                                    var libelle     = $(this).attr('data-libelle');
                                    var garantie_id = $(this).attr('data-garantie');
                                    var tarif       = $(this).attr('data-tarif') ;
                                    var tarifDec    = Math.round(parseFloat(tarif));
                                    var classe      = $(this).attr('data-class');
                                    var code        = $(this).attr('data-garantie-code');

                                    if($(this).prop( "checked" )) {
                                        var option = {

                                                id: id,
                                                garantie_id: garantie_id,
                                                libelle: libelle,
                                                tarif: tarif,
                                                code: code
                                            };

                                                if(classe.search("PackConfort") || classe.search("PackBienEtre")) {
                                                    $('.'+classe).attr('disabled', true);
                                                    $('#'+id).attr('disabled', false);
                                                }
                                              
                                                tabOptions.push(option);
                                                var tempTarif = ($('#tarif-'+garantie_id).attr('data-tarif') * 1);
                                                var tempTarifDec    = parseFloat(tempTarif);
                                                $('#tarif-'+garantie_id).text(Decimal.convert(tempTarifDec + tarifDec, 2));
                                                $('#tarif-'+garantie_id).attr('data-tarif', tempTarifDec + tarifDec);
                                                $('#td-tarif-'+garantie_id).attr('data-tarif', tempTarifDec + tarifDec);
                                                //$('#tarif12-'+garantie_id).text(Decimal.convert((tempTarifDec + tarifDec) * 12, 2));


                                    }else {

                                               if(classe.search("PackConfort") || classe.search("PackBienEtre")) {
                                                    $('.'+classe).attr('disabled', false);
                                                }
                                      
                                        tabOptions = removeOption(tabOptions,'id',id);
                                        var tempTarif = ($('#tarif-'+garantie_id).attr('data-tarif') * 1);
                                        $('#tarif-'+garantie_id).text(Decimal.convert(tempTarif - tarif, 2));
                                        $('#tarif-'+garantie_id).attr('data-tarif', tempTarif - tarif);
                                        $('#td-tarif-'+garantie_id).attr('data-tarif', tempTarif - tarif);
                                        // $('#tarif12-'+garantie_id).text(Decimal.convert((tempTarif - tarif) * 12, 2));
                                        console.log('remove => ', tabOptions);
                                        console.log('remove 3');

                                        
                                    }

                                    ligneCheck = $('#tarif-'+garantie_id).attr("data-tr");
                                    $("#"+ligneCheck).attr("data-tarif", Decimal.convert($('#tarif-'+garantie_id).attr("data-tarif"), 2));
    
                                });

                                ligneCheck = $('#tarif-'+garantie_id).attr("data-tr");
                                $("#"+ligneCheck).attr("data-tarif", Decimal.convert($('#tarif-'+garantie_id).attr("data-tarif"), 2));

                            }, 'json');

                            // var garantie = $(this).attr('data-garantie');

                            // if($(this).prop("checked")){

                            //         $('.'+garantie).each(function( index ) {
                            //            cotisation = ($( this ).attr('data-tarif') * 1);
                            //            $( this ).attr('data-tarif', cotisation * 0.92)
                            //         });

                            //         $('.'+garantie+'-cotisation').each(function( index ) {
                            //            cotisation = ($( this ).attr('data-tarif') * 1);
                            //            $( this ).attr('data-tarif', (cotisation * 0.92))
                            //            $( this ).html(Decimal.convert(((cotisation / 100) * 0.92), 2) + ' &euro;')
                            //         });
                               
                            // }else{

                            //         $('.'+garantie).each(function( index ) {
                            //            cotisation = ($( this ).attr('data-tarif') * 1);
                            //            $( this ).attr('data-tarif', cotisation / 0.92)
                            //         });

                            //         $('.'+garantie+'-cotisation').each(function( index ) {
                            //            cotis = ($( this ).attr('data-tarif') * 1);
                            //            $( this ).attr('data-tarif', (cotis / 0.92))
                            //           $( this ).html(Decimal.convert(((cotis / 100) / 0.92), 2) + ' &euro;')
                            //         });
                            // }

                        });

                        $('#TarifTable').addClass('animated fadeInDown');

                        // $("#TarifTable").show();

                        $("#TarifTable").DataTable( {
                            "searching": true,
                            "bDestroy": false,
                            "scrollCollapse": true,
                            "paging": false,
                            "bLengthChange": false,
                            "bInfo": false,
                            //"scrollY": "500px",
                            "order": [[ 3, "asc" ]],
                            columnDefs: [
                               { type: 'alt-string', targets: 1 }
                            ]
                        });

                        $('div.dataTables_filter input').attr('placeholder', 'Recherche');

                        $(".dt-uikit-header .uk-grid .uk-width-medium-2-3:first-child").html("<span class='md-bg-teal-A700 md-color-yellow-50 uk-badge  uk-text-bold uk-text-primary'  data-uk-tooltip title='Nombre des garanties'>"+(indexTarif-1)+" Garantie(s) trouvée</span>");

                        $(".icheckTD").iCheck({
                            checkboxClass: 'icheckbox_md',
                            radioClass: 'iradio_md',
                            increaseArea: '20%'
                        });


                        $(".souscrireTarif").click(function(){

                            $.ajax({
                                url  : "{!! URL::to('getPrelevementsByCompagnie') !!}",
                                type : 'POST',
                                data : {compagnie_code:$(this).attr('data-compagnie-code'), produit_id:$("#produit_id").val()},
                                beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));},                 
                            }).success(function(data){
                                $select = $('#prelevement').selectize({
                                    valueField: 'value',
                                    labelField: 'text',
                                });
                                var control = $select[0].selectize;
                                var options = [];
                                $.each(data.prelevements, function(index, value){
                                    options.push({value : value.jour, text : value.jour});
                                });
                                $('#frais_dossier').val(data.dossier.montant);
                                control.clearOptions();
                                control.addOption(options);
                            }).error(function(data){
                                
                            });

                            $('#num').val($(this).attr('data-num'));
                            $('#logo').val($(this).attr('data-logo'));
                            $('#compagnie').val($(this).attr('data-compagnie'));
                            $('#gamme').val($(this).attr('data-gamme'));

                            $('#garantie').val($(this).attr('data-garantie'));
                            $('#tarif').val($(this).attr('data-tarif'));

                            $('#soins_val').val($(this).attr('data-soins'));
                            $('#optique_val').val($(this).attr('data-optique'));
                            $('#dentaire_val').val($(this).attr('data-dentaire'));
                            $('#hospitalisation_val').val($(this).attr('data-hospital'));

                            $('#gamme_id').val($(this).attr('data-gamme-id'));
                            $('#garantie_id').val($(this).attr('data-garantie-id'));
                            $('#garantie_code').val($(this).attr('data-garantie-code'));

                            $('#info_formule').val($(this).attr('data-garantie'));
                            $('#info_formule').parent().addClass("md-input-wrapper md-input-filled");

                            // price = Decimal.convert( $(this).attr('data-tarif'), 2).toString();
                            // $('#info_montant').val( parseFloat(price.slice(0, (price.indexOf("."))+3)) );
                            $('#info_montant').val( Decimal.convert( $(this).attr('data-tarif'), 2) );
                            $('#info_montant').parent().addClass("md-input-wrapper md-input-filled");

                            garantie_id = $(this).attr('data-garantie-id');

                            $('#optionsList').html('');
                            arrayOption = [];

                            for(var i = 0; i < tabOptions.length; i++){

                                if(tabOptions[i].garantie_id == garantie_id ){

                                    j = arrayOption.length;
                                    arrayOption[j] = tabOptions[i];

                                    element = "<li class='renfort'>"
                                                +"<div class='md-list-addon-element'>";

                                    if(tabOptions[i].tarif){
                                        element +="<span class='uk-text-right uk-text-bold uk-badge uk-badge-primary'>"
                                                    +tabOptions[i].tarif
                                                    +" <i class='uk-icon-euro' style='color:#FFF'></i>"
                                        +"</span>";
                                    }
                                    
                                    element +="</div>"
                                                +"<div class='md-list-content'>"
                                                    +"<span class='uk-text-small uk-text-muted'>"+tabOptions[i].libelle+"</span>"
                                                +"</div>"
                                            +"</li>";

                                    $('#optionsList').append(element);

                                }

                            }

                            tabOptions = arrayOption;

                            $('#optionsHidden').val(JSON.stringify(tabOptions));

                        });

                    $("#tarif_list_filter2").html("<i data-uk-tooltip title='Comparer' id='checkTr' style='display:none;' class='md-icon material-icons filterCompare'>&#xE86D;</i><i data-uk-tooltip title='Vider' style='display:none;' data-check='1' id='comparedClear'  class='md-icon material-icons filterCompare'>&#xE14C;</i>");
                       
                        setTimeout(function(){
                            $('.removeStyle').removeAttr("style");
                        }, 1000);


                        $(".checkboxTarif").on('ifChanged', function(event){

                            tr_id    = $(this).attr('data-tr');
                            tarifId  = $(this).attr('data-id');
                            cpiName  = $(this).attr('data-compagnie');
                            nbrCheck = $("#comparedClear").attr('data-check');

                            var isChecked = event.currentTarget.checked;

                            if (isChecked == true) {

                                nbrCheck++;
                                $("#tr"+tr_id).addClass('comparedTR');
                                $("#tr"+tr_id).removeClass('hideTR');
                                $('#'+tarifId).attr('data-uk-filter', cpiName+', check');
                                $(this).addClass('comparedCheck');
                                $("#comparedClear").attr('data-check', nbrCheck);

                            }else{

                                nbrCheck--;
                                $("#tr"+tr_id).removeClass('comparedTR');
                                $("#tr"+tr_id).addClass('hideTR');
                                $('#'+tarifId).attr('data-uk-filter', cpiName);
                                $(this).removeClass('comparedCheck');
                                $("#comparedClear").attr('data-check', nbrCheck);

                            }
                            

                            if(nbrCheck<=1){
                                $('.filterCompare').hide();
                            }

                            if(nbrCheck>1){
                                $('.filterCompare').show();
                                $('#iconeProposition').show();
                                $('#detailPrestations').show();
                            }
                            
                            if(nbrCheck==0){
                                $('#iconeProposition').hide();
                                $('#detailPrestations').hide();
                                $("#comparedClear").trigger("click");
                            }

                            if(nbrCheck==1){
                                $('#iconeProposition').show();
                                $('#detailPrestations').show();
                            }

                        });
                        
                        
                        $("#checkTr").click(function(){

                            $('.hideTR').each(function() {

                                //console.log($(this).attr('id'));
                                trId = $(this).attr('id');
                                $("#"+trId).hide();

                            });

                        });

                        $("#comparedClear").click(function(){

                            $('.icheckTD').iCheck('uncheck');

                            $('.hideTR').each(function() {

                                //console.log($(this).attr('id'));
                                trId = $(this).attr('id');
                                $("#"+trId).show();

                            });

                            $('.comparedTR').each(function() {

                                //console.log($(this).attr('id'));
                                trId = $(this).attr('id');
                                $("#"+trId).show();
                                $(this).removeClass('comparedTR');
                                $(this).addClass('hideTR');

                            });

                            $('.comparedCheck').each(function() {
                                tarifId  = $(this).attr('data-id');
                                cpiName  = $(this).attr('data-compagnie');
                                $('#'+tarifId).attr('data-uk-filter', cpiName);
                                $(this).removeClass('comparedCheck');
                            });
                            
                            $('.checkboxTarif').removeAttr('checked');
                            $("#comparedClear").attr('data-check', 0);
                            $('.filterCompare').hide();
                            $('#iconeProposition').hide();
                        });

                        $("#comparedClear").trigger('click');


                    }else{
                        $("#preloadCompagnies").html("Aucune Garantie Trouvée !!!");
                        $("#newTarifList").html("");
                        altair_helpers.content_preloader_hide();
                    }

                }).error(function(res){
                   
                   $("#preloadCompagnies").html("Aucune Garantie Trouvée !!!");
                   $("#newTarifList").html("");
                        altair_helpers.content_preloader_hide();

                });


                
            }).error(function(data){

                var errors = data.responseJSON;

                err = "";

                $.each(errors, function(key, value){
                    err += "<li style='color:red;'>- "+value+"</li>";
                });

                swal({
                  title: 'Erreur !!!',
                  type: 'error',
                  html: "<ul>"+err+"</ul>",
                  showCloseButton: true,
                  cancelButtonText: 'Fermer'
                });

            });
        }

        // Get New Gamme April Name
        function getNewAprilGammeName(value) {

            gammes = [];
            //gammes['Sante a la carte'] = 'NewFamily';
            gammes['SanteALaCarte'] = 'NewFamily';

            return gammes[value];
            
        }


         // Récupérer les objets filtrés
         function removeOption(myObjects,prop,valu)
         {
            return myObjects.filter(function (val) {
              return val[prop] !== valu;
            });
         }
        
        function deleteConjoint() {

            profileSlug = $("#profile_slug").val();

            swal({
                title: "Suppression",
                text: "Voulez-vous supprimer le conjoint ?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: "Confirmer",
                cancelButtonText: "Annuler",
                showLoaderOnConfirm: true,
                preConfirm: function () {
                    return new Promise(function (resolve, reject) {
                        setTimeout(function(){

                            var id = $("#conjoint_id").val();

                            if(id>0){

                                $.ajax({
                                    url  : "{!! URL::to('"+profileSlug+"/client/deleteConjoint') !!}",
                                    type : 'POST',
                                    data : "id="+id,
                                    beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));},                 
                                }).success(function(data){
                                    resolve();
                                }).error(function(data){
                                    reject('Problème en suppression du conjoint!!!');
                                });
                            }

                            resolve();

                            deleteIconConjoint();

                        }, 1000);
                    })
                },
                allowOutsideClick: false
            }).then(function () {
                swal({ title: "Success!", text: "Suppression Effectuée", type: "success", confirmButtonText: "Fermer" });
            });

        }
        
        function deleteChild(id) {

            profileSlug = $("#profile_slug").val();

            swal({
                title: "Suppression",
                text: "Voulez-vous supprimer cet enfant ?",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: "Confirmer",
                cancelButtonText: "Annuler",
                showLoaderOnConfirm: true,
                preConfirm: function () {
                return new Promise(function (resolve, reject) {
                    setTimeout(function(){

                        $("#newTarifList").html("");
                        
                        var dataOrigin = parseInt($("#delete"+id).attr("data-origin"));
                        if(dataOrigin){
                            var enfantId = $("#ide"+id).val();
                            $.ajax({
                                url  : "{!! URL::to('"+profileSlug+"/client/deleteChild') !!}",
                                type : 'POST',
                                data : {id:enfantId},
                                beforeSend: function(xhr){
                                    xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));
                                },
                            }).success(function(data){
                                if(data.success){
                                    resolve();
                                }
                            }).error(function(data){
                                reject("Erreur de suppression d'enfant!!");
                            });
                        }
                        var nbrEnfants = parseInt($("#addChild").attr("data-id"));
                        $("#child"+id).remove();
                        if(nbrEnfants>1){
                            for(var i=(id+1); i<=nbrEnfants; i++) {
                                $("#ide"+i).attr("name", "enfant["+(i-1)+"][id]");
                                $("#ide"+i).attr("id", "ide"+(i-1));
                                $("#sexe"+i).attr("name", "enfant["+(i-1)+"][sexe]");
                                $("#sexe"+i).attr("id", "sexe"+(i-1));
                                $("#nom"+i).attr("name", "enfant["+(i-1)+"][nom]");
                                $("#nom"+i).attr("id", "nom"+(i-1));
                                $("#prenom"+i).attr("name", "enfant["+(i-1)+"][prenom]");
                                $("#prenom"+i).attr("id", "prenom"+(i-1));
                                $("#dn"+i).attr("name", "enfant["+(i-1)+"][date_naissance]");
                                $("#dn"+i).attr("id", "dn"+(i-1));
                                $("#ad"+i).attr("name", "enfant["+(i-1)+"][ayant_droit]");
                                $("#ad"+i).attr("id", "ad"+(i-1));
                                $("#delete"+i).attr("onclick", "deleteChild("+(i-1)+")");
                                $("#delete"+i).attr("id", "delete"+(i-1));
                                $("#child"+i).attr("id", "child"+(i-1));
                            }
                        }
                        if(nbrEnfants>0){
                            var nbr = parseInt($("#addChild").attr("data-id")) - 1;
                            $("#addChild").attr("data-id", nbr);
                            $("#nbrChild").html(nbr);
                        }
                        
                        resolve();

                        
                    }, 1000);
                })
            },
            allowOutsideClick: false
            }).then(function () {
                swal({ title: "Succés", text: "Suppression Effectuée", type: "success", confirmButtonText: "Fermer" });
            });

                    
        }
        
        function addChild() {
            var nbrEnfants = parseInt($("#addChild").attr("data-id")) + 1;
            if(nbrEnfants<11){
                var ligne = "<li class='uk-margin-top' id='child"+nbrEnfants+"' >"+
                                "<div class='uk-grid'>"+
                                    "<div class='uk-width-medium-1-10 uk-width-small-1-1 uk-margin-small-bottom  uk-input-group'>"+
                                        "<label for='enfant_sexe'>Sexe</label>"+
                                        "<select data-md-selectize id='sexe"+nbrEnfants+"' name='enfant["+nbrEnfants+"][sexe]' class='md-input' >"+
                                            "<option value='M'>"+
                                                "M"+
                                            "</option>"+
                                            "<option value='F'>"+
                                                "F"+
                                            "</option>"+
                                        "</select>"+
                                    "</div>"+
                                    "<div class='uk-width-medium-2-10 uk-width-small-1-1 uk-margin-small-bottom uk-input-group'>"+
                                        "<label for='enfant["+nbrEnfants+"][nom]'>Nom</label>"+
                                        "<input type='text' class='md-input' id='nom"+nbrEnfants+"' name='enfant["+nbrEnfants+"][nom]' value='' />"+
                                    "</div>"+
                                    "<div class='uk-width-medium-2-10 uk-width-small-1-1 uk-margin-small-bottom  uk-input-group'>"+
                                        "<label for='enfant["+nbrEnfants+"][prenom]'>Prenom</label>"+
                                        "<input  type='text' class='md-input' id='prenom"+nbrEnfants+"' name='enfant["+nbrEnfants+"][prenom]' value='' />"+
                                    "</div>"+
                                    "<div class='uk-width-medium-2-10 uk-width-small-1-1 uk-margin-small-bottom  uk-input-group'>"+
                                        "<label for='enfant["+nbrEnfants+"][date_naissance]'>Date naissance</label>"+
                                        "<input type='text' id='dn"+nbrEnfants+"' data-id='"+nbrEnfants+"' name='enfant["+nbrEnfants+"][date_naissance]' class='resetTarif child_DN md-input' data-uk-datepicker={format:'DD/MM/YYYY',maxDate:0,minDate:'01/01/1900'}  value='' />"+
                                        "<span class='uk-form-danger'></span>"+
                                    "</div>"+
                                    "<div class='uk-width-medium-2-10 uk-width-small-1-1 uk-margin-small-bottom  uk-input-group'>"+
                                        "<label for='enfant["+nbrEnfants+"][ayant_droit]'>Ayant Droit</label>"+
                                        "<select data-md-selectize class='resetTarif child_conjoint md-input' id='ad"+nbrEnfants+"' name='enfant["+nbrEnfants+"][ayant_droit]'>"+
                                            "<option value='P'>"+
                                                "Prospect"+
                                            "</option>"+
                                            "<option value='C'>"+
                                                "Conjoint"+
                                            "</option>"+
                                        "</select>"+
                                    "</div>"+
                                    "<div class='uk-width-medium-1-10 uk-width-small-1-1 uk-margin-small-bottom  uk-input-group'>"+
                                        "<input type='hidden' id='ide"+nbrEnfants+"' data-val='0' value='0' name='enfant["+nbrEnfants+"][id]'>"+
                                        "<i data-uk-modal  data-id='"+nbrEnfants+"' data-origin='0' class='deleteChild childrenList resetTarif md-icon material-icons md-color-red-500' id='delete"+nbrEnfants+"' onclick='deleteChild("+nbrEnfants+")' > delete </i>"+
                                    "</div>"+
                                "</div>"+
                                "<hr class='uk-hidden-medium uk-hidden-large uk-margin'>"
                            "</li>";
                $("#addChild").attr("data-id", nbrEnfants);
                $("#nbrChild").html(nbrEnfants);
                $("#childen").prepend(ligne);
                $("#ad"+nbrEnfants).selectize();
                $("#sexe"+nbrEnfants).selectize();

                $("#newTarifList").html("");
            
            }
        }

        function addIconConjoint(){
            //$("#formConjoint").show();
            //$("#formConjoint").reset();
            var ligne = "<form id='formConjoint'><input id='has_conjoint' name='has_conjoint' type='hidden' value='1'>";
            ligne += $("#loadConjoint").html();
            
            ligne += "<input type='hidden' value='0' name='conjoint_id' id='conjoint_id'></form>";
            $("#form_conjoint").html(ligne);
            $("#addIconConjoint").hide();
            $("#deleteIconConjoint").show();  

            $('.selectConjoint').selectize();

            $("#newTarifList").html("");

        }
        function deleteIconConjoint(){

            $('.selectConjoint').each(function(){

                $select = $(this).selectize();

                 $select[0].selectize.destroy();

            });
            
            $("#formConjoint").remove();
            $("#addIconConjoint").show();
            $("#deleteIconConjoint").hide();

            $("#newTarifList").html("");
                   
        }
        $('#TarifTable').dataTable( {
        "destroy": true,
        "language": {
                    "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/French.json"
                }
        });
        $('#statutAction').click(function() {
            alert('ok');
        });
        
     

        $('#saveLead').click(function() {

            profileSlug = $("#profile_slug").val();

            $("#newTarifList").html("");

            $("#etatSave").val(1);

            swal({
                title: "Sauvegarde des modifications",
                text: "Cliquer sur confirmer pour sauvegarder les infos.",
                type: "info",
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: "Confirmer",
                cancelButtonText: "Annuler",
                showLoaderOnConfirm: true,

                preConfirm: function () {
                    return new Promise(function (resolve, reject) {
                        setTimeout(function(){

                            dataForm = $('#clientForm, #formAssure, #formConjoint, #formChildren ,#formGrpQst').serializeObject();

                            dataForm.date_effet     = moment(dataForm.date_effet, 'DD/MM/YYYY').format('YYYY-MM-DD');
                            dataForm.date_naissance = moment(dataForm.date_naissance, 'DD/MM/YYYY').format('YYYY-MM-DD');
                            
                            if(moment(dataForm.conjoint_date_naissance, 'DD/MM/YYYY').isValid()){
                                dataForm.conjoint_date_naissance = moment(dataForm.conjoint_date_naissance, 'DD/MM/YYYY').format('YYYY-MM-DD');
                            }

                            $.ajax({

                                url  : "{!! URL::to('"+profileSlug+"/client/sante/update') !!}",
                                
                                type : 'POST',

                                data : dataForm, //$('#clientForm, #formAssure, #formConjoint, #formChildren').serialize(),

                                beforeSend: function(xhr){
                                                            xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));
                                                        },
                                
                            }).success(function(data){

                                console.log(data);
                                
                                $('.childrenList').attr("data-origin", "1");
                                $('#conjoint_id').val(data.conjointId);
                                
                                $.each(data.enfants, function(key, value){
                                    
                                    i = key + 1;

                                    $("#ide"+i).val(value.id);
                                    $("#ide"+i).attr("name", "enfant["+i+"][id]");
                                    $("#ide"+i).attr("id", "ide"+i);
                                    
                                    $("#sexe"+i).attr("name", "enfant["+i+"][sexe]");
                                    $("#sexe"+i).attr("id", "sexe"+i);
                                    var selectize = $("#sexe"+i)[0].selectize;
                                    selectize.clearOptions();
                                    selectize.addOption({text: "F", value: "F"});
                                    selectize.addOption({text: "M", value: "M"});
                                    selectize.setValue(value.sexe); 
                                    
                                    $("#nom"+i).attr("name", "enfant["+i+"][nom]");
                                    $("#nom"+i).attr("id", "nom"+i);
                                    $("#nom"+i).val(value.nom);
                                    
                                    $("#prenom"+i).attr("name", "enfant["+i+"][prenom]");
                                    $("#prenom"+i).attr("id", "prenom"+i);
                                    $("#prenom"+i).val(value.prenom);
                                    
                                    $("#dn"+i).attr("name", "enfant["+i+"][date_naissance]");
                                    $("#dn"+i).attr("id", "dn"+i);
                                    $("#dn"+i).val(moment(value.date_naissance, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                                    
                                    $("#ad"+i).attr("name", "enfant["+i+"][ayant_droit]");
                                    $("#ad"+i).attr("id", "ad"+i);
                                    $("#ad"+i).val("id", "ad"+i);
                                    $("#ad"+i).attr('value', value.ayant_droit).attr('selected', 'selected');
                                    var selectize = $("#ad"+i)[0].selectize;
                                    selectize.clearOptions();
                                    selectize.addOption({text: "Conjoint", value: "C"});
                                    selectize.addOption({text: "Prospect", value: "P"});
                                    selectize.setValue(value.ayant_droit); 
                                    
                                    
                                    $("#delete"+i).attr("onclick", "deleteChild("+i+")");
                                    $("#delete"+i).attr("id", "delete"+i);
                                    
                                    $("#child"+i).attr("id", "child"+i);

                                });
                                
                                resolve();

                                //swal({ title: "Validé", text: data.message, timer: 2000,  type: "success", confirmButtonText: "Fermer" });

                                
                            }).error(function(data){

                                var errors = data.responseJSON;

                                err = "";

                                $.each(errors, function(key, value){
                                    err += "<li style='color:red;'>- "+key +" : "+value+"</li>";
                                });

                                reject(err);

                                //swal({ title: "Erreur!", text: "<ul>"+err+"</ul>", html: true, type: "error", confirmButtonText: "Fermer" });

                            });

                    }, 2000);
                })

            },
            allowOutsideClick: false
            }).then(function () {
                swal({ title: "Success!", text: "Informations Sauvegardées", type: "success", confirmButtonText: "Fermer" });
            });

        });

        $(".loadModal").click(function(){

            profileSlug   = $("#profile_slug").val();

            var ficheId   = $(this).attr('data-fiche');
            var statutId  = $(this).attr('data-statut');
            var prdId     = $(this).attr('data-produit');
            var statutCol = $(this).attr('data-color');
            $("#modalFicheId").val(ficheId);
            $("#modalStatutId").val(statutId);
            $('#rappelTitle').html("");
            $.ajax({
                url  : "{!! URL::to('"+profileSlug+"/client/getStatut') !!}",
                type : 'POST',
                data : {ficheId:ficheId, statutId:statutId, prdId:prdId},
                beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));},
            }).success(function(data){
                $("#statutLib").val(data.statutLib);
                $("#statutCol").val(statutCol);
                $("#actionTitle").html("Action "+data.statutLib);
                $("#modalMotifId").html('');
                if(data.motifs.length>0){
                    $("#actionMotif").show();
                    $("#modalMotifId").attr('disabled', false);
                    
                    $.each(data.motifs, function(key, value){
                        $("#modalMotifId").append("<option value='"+value['id']+"'>"+value['libelle']+"</option>");
                    });
                }else{
                    $("#actionMotif").hide();
                    $("#modalMotifId").attr('disabled', true);
                }
                
                if(data.rappelActive==1){
                    $("#actionRappel").show();
                    $("#rappel_date").attr('disabled', false);
                    $("#rappel_heure").attr('disabled', false);
                    $('#rappelTitle').html(
                        (moment(data.rappel['date_rappel']+" "+data.rappel['heure_rappel'],'YYYY-MM-DD HH:mm').isValid()) ?
                         "dernier rappel : "+moment(data.rappel['date_rappel']+" "+data.rappel['heure_rappel'],'YYYY-MM-DD HH:mm').format('DD/MM/YYYY HH:mm') : '') ;
                }else{
                    $("#actionRappel").hide();
                    $("#rappel_date").attr('disabled', true);
                    $("#rappel_heure").attr('disabled', true);
                }
                
            }).error(function(data){
            });
            var modal = UIkit.modal("#actionModal");
            modal.show();
        });
        $(".loadTabAction").click(function(){

            profileSlug = $("#profile_slug").val();

            var ficheId   = $(this).attr('data-fiche');
            var statutId  = $(this).attr('data-statut');
            var prdId     = $(this).attr('data-produit');
            var statutCol = $(this).attr('data-color');
            $("#tabFicheId").val(ficheId);
            $("#tabStatutId").val(statutId);
            $('#rappelTitle').html("");
            $.ajax({
                url  : "{!! URL::to('"+profileSlug+"/client/getStatut') !!}",
                type : 'POST',
                data : {ficheId:ficheId, statutId:statutId, prdId:prdId},
                beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));},
            }).success(function(data){
                $("#statutLib").val(data.statutLib);
                $("#statutCol").val(statutCol);
                $("#actionTitle").html("Action "+data.statutLib);
                $("#modalMotifId").html('');
                if(data.motifs.length>0){
                    $("#actionMotif").show();
                    $("#modalMotifId").attr('disabled', false);
                    
                    $.each(data.motifs, function(key, value){
                        $("#modalMotifId").append("<option value='"+value['id']+"'>"+value['libelle']+"</option>");
                    });
                }else{
                    $("#actionMotif").hide();
                    $("#modalMotifId").attr('disabled', true);
                }
                
                
                if(data.rappelActive==1){
                    $("#actionRappel").show();
                    $("#rappel_date").attr('disabled', false);
                    $("#rappel_heure").attr('disabled', false);
                    $('#rappelTitle').html("dernier rappel : "+data.rappel['date_rappel']+" "+data.rappel['heure_rappel']);
                }else{
                    $("#actionRappel").hide();
                    $("#rappel_date").attr('disabled', true);
                    $("#rappel_heure").attr('disabled', true);
                }
                
            }).error(function(data){
            });
            var modal = UIkit.modal("#actionModal");
            modal.show();
        });
        $("#btnActionModal").click(function(){

            profileSlug = $("#profile_slug").val();

            dataForm = $('#formActions').serializeObject();
            
            dataForm.rappel_date = moment(dataForm.rappel_date, 'DD/MM/YYYY').format('YYYY-MM-DD');

            $.ajax({
                url  : "{!! URL::to('"+profileSlug+"/client/changeStatut') !!}",
                type : 'POST',
                data : dataForm,
                beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));},
            }).success(function(data){

                vueLead.updateProc(data.processes);

                $("#btnStatut").html(data.statutLib);

                $("#btnStatut").css("background-color", $("#statutCol").val());

                vueLead.$data.statut = data.statut;

            }).error(function(data){
            });
            var modal = UIkit.modal("#actionModal");
            modal.hide();
            
        });
        $('.showTr').click(function() {
            var id = $(this).attr('id');
            console.log(id);
            $("#"+id+"-show").toggle('slow');
        });
        $('#showInfoGeneral').click(function() {
            $("#infoGeneral").toggle();
            //$("#infoGeneral").addClass('animated fadeInDown');
        });
        $('#showFilterRate').click(function() {
            $("#rateDiv").toggle();
        });
        
        function showTR(id){
            //var id = $(this).attr('id');
            console.log(id);
            $("#"+id+"-show").toggle();
        }
        function showComment(id){
            //var id = $(this).attr('id');
            console.log(id);
            $("#"+id+"-show").toggle();
        }
        $('.documentFiche').change(function() {
            profileSlug = $("#profile_slug").val();
            $(".errorDoc").html("");
            var docId   = $(this).attr('data-id');
            var ficheId = $(this).attr('data-fiche');
            var prdId     = $(this).attr('data-produit');
            var form_data = new FormData();                  
            form_data.append('document', $("#doc_file"+docId).prop("files")[0]);
            form_data.append('docId', docId);
            form_data.append('ficheId', ficheId);
            form_data.append('prdId', prdId);
            console.log(form_data);
            $.ajax({
                url         : "{!! URL::to('"+profileSlug+"/client/addDoc') !!}",
                cache       : false,
                dataType    : 'json',
                contentType : false,
                processData : false,
                type        : 'POST',
                data        : form_data,
                beforeSend: function(xhr){
                                            xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));
                                            $("#iconDoc"+docId).html("<div class='md-preloader uk-container-center' ><svg xmlns='http://www.w3.org/2000/svg' version='1.1' height='24'  width='24' viewbox='0 0 75 75'><circle cx='37.5' cy='37.5' r='33.5' stroke-width='4' /></svg></div>");
                                        },
            
            }).success(function(data){
                var ligne = "<i class='iconSize  material-icons' style='color: green;'>&#xE5CA;</i>"
                            +"<a href='"+data.path+"' style='position: relative;z-index: 10;' target='_blank'><i class='iconSize  uk-icon-file-"+data.icon+"-o'></i></a>";
                $("#iconDoc"+docId).html(ligne);
                var info = "<i data-uk-tooltip title='"+data.date+"' class='iconSize material-icons'>&#xE192;</i><i data-uk-tooltip title='"+data.user+"' class='iconSize material-icons'>&#xE853;</i>";
                $("#infoDoc"+docId).html(info);
                
            }).error(function(data){
                var ligne = "<i class='material-icons' style='color: red;'>&#xE14C;</i>";
                $("#iconDoc"+docId).html(ligne);
                var errors = data.responseJSON;
                $.each(errors, function(key, value){
                    $("#errorDoc"+docId).append(value);
                    console.log(value);
                });
            });
        });
        $('#btnDeleteFiche').click(function(){

            profileSlug = $("#profile_slug").val();

            var ficheId = $("#deleteFicheId").val();
            $.ajax({
                url  : "{!! URL::to('"+profileSlug+"/client/sante/delete') !!}",
                
                type : 'POST',
                data : "id="+ficheId,
                beforeSend: function(xhr){
                    
                    xhr.setRequestHeader( 'X-CSRF-TOKEN' , $('meta[name="csrf-token"]').attr('content') );
                    
                    $("#afterDeleteFiche").hide();
                    
                    $("#beforeDeleteFiche").show();
                    
                },
                
            }).success(function(data){
                if(data.success){
                    setTimeout(function(){
                        $("#beforeDeleteFiche").hide();
                        $('#afterDeleteFiche').html("<i class='material-icons uk-icon-large uk-icon-success' style='color:#2d7091;font-size:50px'>&#xE5CA;</i><br>"+data.message);
                        $('#afterDeleteFiche').show();
                    }, 2000);
                    setTimeout(function(){
                        window.location.href = data.url;
                    }, 2000);
                
                }
            }).error(function(data){
                setTimeout(function(){
                    $('#beforeDeleteFiche').hide();
                    $('#afterDeleteFiche').show();
                    $('#afterDeleteFiche').html("<i class='material-icons uk-icon-large uk-icon-danger' style='color:#d85030;font-size:50px'>&#xE14C;</i><br>probleme en suppression de la fiche.");
                    $("#afterDeleteFiche").hide();
                    $("#beforeDeleteFiche").hide();
                }, 2000);
            });
        });
        $('#btnClient').click(function() {

            profileSlug = $("#profile_slug").val();
            
            $.ajax({
                url  : "{!! URL::to('"+profileSlug+"/client/update') !!}",
                
                type : 'POST',
                data : $('#clientForm').serialize(), 
                
            }).success(function(data){
                $("#msgClient").html("");
                $("#msgClient").addClass("uk-form-success");
                $('#msgClient').html(data);
            }).error(function(data){
                var errors = data.responseJSON;
                $("#msgClient").html("");
                $("#msgClient").removeClass("uk-form-success");
                $("#msgClient").append("<ul>");
                $.each(errors, function(key, value){
                    $("#msgClient").append("<li style='color:red;'>- "+value+"</li>");
                });
                $("#msgClient").append("</ul>");
            });
            
        });
    $('#addComment').click(function() {

        profileSlug = $("#profile_slug").val();
            
        $.ajax({
            url  : "{!! URL::to('"+profileSlug+"/client/addComment') !!}",
            type : 'POST',
            data : $('#formComment').serialize(), 
            beforeSend: function(xhr){
                
                xhr.setRequestHeader( 'X-CSRF-TOKEN' , $('meta[name="csrf-token"]').attr('content') );
                
                altair_helpers.content_preloader_show();
                
            },
            
        }).success(function(data){
            
            altair_helpers.content_preloader_hide();
            $("#commentaire").val('');
            swal({   title: "validé",   text: data.message, timer: 2000,  type: "success",   confirmButtonText: "Fermer" });
        }).error(function(data){
            altair_helpers.content_preloader_hide();
        });
    });
    $('#loadComments').click(function() {

        profileSlug = $("#profile_slug").val();
        var ficheId = $(this).attr('data-fiche');
        var slugPrd = $(this).attr('data-slug');
        var modal   = UIkit.modal("#commentsModal");
        $.ajax({
            url  : "{!! URL::to('"+profileSlug+"/client/getComments') !!}",
            type : 'POST',
            data : 'ficheId='+ficheId+'&slugPrd='+slugPrd,
            beforeSend: function(xhr){
                                        xhr.setRequestHeader( 'X-CSRF-TOKEN' , $('meta[name="csrf-token"]').attr('content') );
                                        modal.show();
                                        $('#afterLoadComment').hide();
                                        $('#afterLoadComment').html("");
                                        $('#beforeLoadComment').show();
                                    },
            
        }).success(function(data){
            $('#beforeLoadComment').hide();
            
            
            if(data.length>0){
                var contentComm   = "";
                contentComm       = "<ul align='left' class='md-list md-list-addon'>";
                
                $.each(data, function(key, value){

                    imgUser = "{!! asset('upload/avatars/"+value.user.photo+"') !!}";

                    contentComm   += "<li>"
                                            +"<div class='md-list-addon-element'>"
                                                +"<img class='md-user-image md-list-addon-avatar' src='"+imgUser+"' alt=''/>"
                                            +"</div>"
                                            +"<div class='md-list-content'>"
                                                +"<span class='uk-text-left md-list-heading'>"+value.user.nom+" "+value.user.prenom+"</span>"
                                                +"<span class='uk-text-left uk-text-muted md-list-heading'>"+moment(value.created_at, 'YYYY-MM-DD HH:mm:ss').format('DD/MM/YYYY HH:mm:ss')+"</span>"
                                                +"<span class='uk-text-left uk-text-small uk-text-muted uk-text-italic'>"+value.message+"</span>"
                                            +"</div>"
                                        +"</li>";

                });

                contentComm += "</ul>";

                $('#afterLoadComment').html(contentComm);


            }
            else{
                $('#afterLoadComment').html("Pas De Commentaires.");
            }
            $('#afterLoadComment').show();

        }).error(function(data){


        });

    });


        var Decimal = {
              convert: function(number, decimal_places) {
                if (typeof number === 'number' && typeof decimal_places === 'number') {
                  var denominator    = Math.pow(10, decimal_places),
                      rounded_number = Math.round(number * denominator) / denominator;

                  return rounded_number;
                } else {
                  return number;
                }
              }
            };


//Verification de l'IBAN et du num sécurité sociale      

$(document).ready(function(){

    $('.VerifySecuSociel').blur(function(){
        //alert('toooot');
        var numSecuSocial = $(this).val();
        //var idClient      = $('#clientId').val();
        var numFiche      = $('#ficheNum').val();
        var slugProduit   = $(this).attr('data-slug');

        //console.log(numSecuSocial);
        if(numSecuSocial != '')
        {
           $.ajax({
                url  : "{{ URL::to('lead/verifySecuSocial') }}",
                
                type : 'POST',
                data : "numSecuSocial="+numSecuSocial+"&numFiche="+numFiche+"&person=A&slugProduit="+slugProduit,
                beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));},
                
            }).success(function(data){
                //console.log('ok :' + data);
                if(data == 1)
                {
                    //console.log('success');
                    $('.VerifySecuSociel').removeClass('md-input-danger');
                    $('.VerifySecuSociel').parent().removeClass('md-input-wrapper-danger');
                    $('.VerifySecuSociel').parent().parent().removeClass('uk-input-group-danger');
                    $('.VerifySecuSociel').addClass('md-input-success');
                    $('.VerifySecuSociel').parent().addClass('md-input-filled md-input-wrapper-success');
                    $('.VerifySecuSociel').parent().parent().addClass('uk-input-group-success');
                    disableSubmitButton();

                }               
                else
                {
                    //console.log('failure');
                    $('.VerifySecuSociel').removeClass('md-input-success');
                    $('.VerifySecuSociel').parent().removeClass('md-input-wrapper-success');
                    $('.VerifySecuSociel').parent().parent().removeClass('uk-input-group-success');
                    $('.VerifySecuSociel').addClass('md-input-danger');
                    $('.VerifySecuSociel').parent().addClass('md-input-filled md-input-wrapper-danger'); 
                    $('.VerifySecuSociel').parent().parent().addClass('uk-input-group-danger');
                    //$('#saveInfoBanque').addClass('disabled');
                    if(iban_rem.length>0){
                        $('#saveInfoBanque').addClass('disabled');
                    }
                }
                
            }).error(function(data){
                
            }); 
        }
        else
        {
            $('.VerifySecuSociel').removeClass('md-input-success md-input-danger');
            $('.VerifySecuSociel').parent().removeClass('md-input-wrapper-success md-input-wrapper-danger');
            $('.VerifySecuSociel').parent().parent().removeClass('uk-input-group-success uk-input-group-danger');
            //$('#saveInfoBanque').removeClass('disabled');
            disableSubmitButton();
        }    
        
    });


    $('.VerifySecuSocialConjoint').blur(function(){
        //alert('toooot');
        var numSecuSocial = $(this).val();
        //var idClient      = $('#clientId').val();
        var numFiche      = $('#ficheNum').val();
        var slugProduit   = $(this).attr('data-slug');
        //console.log(numSecuSocial);
        if(numSecuSocial != '')
        {
           $.ajax({
                url  : "{{ URL::to('lead/verifySecuSocial') }}",
                
                type : 'POST',
                data : "numSecuSocial="+numSecuSocial+"&numFiche="+numFiche+"&person=C&slugProduit="+slugProduit,
                beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));},
                
            }).success(function(data){
                //console.log('ok :' + data);
                if(data == 1)
                {
                    //console.log('success');
                    $('.VerifySecuSocialConjoint').removeClass('md-input-danger');
                    $('.VerifySecuSocialConjoint').parent().removeClass('md-input-wrapper-danger');
                    $('.VerifySecuSocialConjoint').parent().parent().removeClass('uk-input-group-danger');
                    $('.VerifySecuSocialConjoint').addClass('md-input-success');
                    $('.VerifySecuSocialConjoint').parent().addClass('md-input-filled md-input-wrapper-success');
                    $('.VerifySecuSocialConjoint').parent().parent().addClass('uk-input-group-success');
                    disableSubmitButton();

                }               
                else
                {
                    //console.log('failure');
                    $('.VerifySecuSocialConjoint').removeClass('md-input-success');
                    $('.VerifySecuSocialConjoint').parent().removeClass('md-input-wrapper-success');
                    $('.VerifySecuSocialConjoint').parent().parent().removeClass('uk-input-group-success');
                    $('.VerifySecuSocialConjoint').addClass('md-input-danger');
                    $('.VerifySecuSocialConjoint').parent().addClass('md-input-filled md-input-wrapper-danger'); 
                    $('.VerifySecuSocialConjoint').parent().parent().addClass('uk-input-group-danger');
                    if(numSecuSocial.length>0){
                        $('#saveInfoBanque').addClass('disabled');
                    }
                }
                
            }).error(function(data){
                
            }); 
        }
        else
        {
            $('.VerifySecuSocialConjoint').removeClass('md-input-success md-input-danger');
            $('.VerifySecuSocialConjoint').parent().removeClass('md-input-wrapper-success md-input-wrapper-danger');
            $('.VerifySecuSocialConjoint').parent().parent().removeClass('uk-input-group-success uk-input-group-danger');
            //$('#saveInfoBanque').removeClass('disabled');
            disableSubmitButton();
        }    
            
    });


    $('.VerifyIBANPre').blur(function(){
           
        var iban_pre = $('#iban_pre').val();

        if(iban_pre != '')
        {
           $.ajax({
                url  : "{{ URL::to('lead/verifyIBAN') }}",
                
                type : 'POST',
                data : "iban="+iban_pre,
                beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));},
                
            }).success(function(data){
                //console.log('ok :' + data);
                if(data == 1)
                {
                    //console.log('success');
                    $('.VerifyIBANPre').removeClass('md-input-danger');
                    $('.VerifyIBANPre').parent().removeClass('md-input-wrapper-danger');
                    $('.VerifyIBANPre').parent().parent().parent().parent().removeClass('uk-input-group-danger');
                    $('.VerifyIBANPre').addClass('md-input-success');
                    $('.VerifyIBANPre').parent().addClass('md-input-filled md-input-wrapper-success');
                    $('.VerifyIBANPre').parent().parent().parent().parent().addClass('uk-input-group-success');
                    disableSubmitButton();
                    //getInfosBanquesFromIban(iban_pre);
                    getInfosBanquesFromIbanPre(iban_pre);

                }               
                else
                {
                    //console.log('failure');
                    $('.VerifyIBANPre').removeClass('md-input-success');
                    $('.VerifyIBANPre').parent().removeClass('md-input-wrapper-success');
                    $('.VerifyIBANPre').parent().parent().parent().parent().removeClass('uk-input-group-success');
                    $('.VerifyIBANPre').addClass('md-input-danger');
                    $('.VerifyIBANPre').parent().addClass('md-input-filled md-input-wrapper-danger'); 
                    $('.VerifyIBANPre').parent().parent().parent().parent().addClass('uk-input-group-danger');
                    if(iban_pre.length>0){
                        $('#saveInfoBanque').addClass('disabled');
                    }
                }
                
            }).error(function(data){
                
            }); 
        }
        else
        {
            $('.VerifyIBANPre').removeClass('md-input-danger md-input-success');
            $('.VerifyIBANPre').parent().removeClass('md-input-wrapper-danger md-input-wrapper-success');
            $('.VerifyIBANPre').parent().parent().parent().parent().removeClass('uk-input-group-danger uk-input-group-success');
            //$('#saveInfoBanque').removeClass('disabled');
            disableSubmitButton();
        }    
          

    });

});

    function verifyIBANRem()
    {
        //***********************************************************************************
        var iban_rem = $('#iban_rem').val();

        if(iban_rem != '')
        {
           $.ajax({
                url  : "{{ URL::to('lead/verifyIBAN') }}",
                type : 'POST',
                data : "iban="+iban_rem,
                beforeSend: function(xhr){xhr.setRequestHeader('X-CSRF-TOKEN', $('meta[name="csrf-token"]').attr('content'));},
                
            }).success(function(data){
                //console.log('ok rem:' + data);
                if(data == 1)
                {
                    //console.log('success');
                    $('.VerifyIBANRem').removeClass('md-input-danger');
                    $('.VerifyIBANRem').parent().removeClass('md-input-wrapper-danger');
                    $('.VerifyIBANRem').parent().parent().parent().parent().removeClass('uk-input-group-danger');
                    $('.VerifyIBANRem').addClass('md-input-success');
                    $('.VerifyIBANRem').parent().addClass('md-input-filled md-input-wrapper-success');
                    $('.VerifyIBANRem').parent().parent().parent().parent().addClass('uk-input-group-success');
                    disableSubmitButton();
                    getInfosBanquesFromIbanRem(iban_rem);

                }               
                else
                {
                    //console.log('failure');
                    $('.VerifyIBANRem').removeClass('md-input-success');
                    $('.VerifyIBANRem').parent().removeClass('md-input-wrapper-success');
                    $('.VerifyIBANRem').parent().parent().parent().parent().removeClass('uk-input-group-success');
                    $('.VerifyIBANRem').addClass('md-input-danger');
                    $('.VerifyIBANRem').parent().addClass('md-input-filled md-input-wrapper-danger'); 
                    $('.VerifyIBANRem').parent().parent().parent().parent().addClass('uk-input-group-danger');
                    //$('#saveInfoBanque').addClass('disabled');
                    
                    if(iban_rem.length>0){
                        $('#saveInfoBanque').addClass('disabled');
                    }
                }
                
            }).error(function(data){
                
            }); 
        }
        else
        {
            $('.VerifyIBANRem').removeClass('md-input-danger md-input-success');
            $('.VerifyIBANRem').parent().removeClass('md-input-wrapper-danger md-input-wrapper-success');
            $('.VerifyIBANRem').parent().parent().parent().parent().removeClass('uk-input-group-danger uk-input-group-success');
            //$('#saveInfoBanque').removeClass('disabled');
            disableSubmitButton();
        }   

    } 

    function disableSubmitButton()
    {
        if($('.VerifyIBANRem').parent().parent().parent().parent().hasClass('uk-input-group-danger') || $('.VerifyIBANPre').parent().parent().parent().parent().hasClass('uk-input-group-danger') || $('.VerifySecuSocialConjoint').parent().parent().hasClass('uk-input-group-danger') || $('.VerifySecuSociel').parent().parent().hasClass('uk-input-group-danger'))
        {
            //console.log('il ya erreur !!');
            // iban_pre = $('#iban_pre').val();
            // iban_rem = $('#iban_rem').val();
            // alert("pre: "+iban_pre+" rem: "+iban_rem);
            // if(iban_pre!=null && iban_rem!=null){
            //     $('#saveInfoBanque').addClass('disabled');
            // }
        }
        else
        {
            //console.log('tout est nickel !!');
            $('#saveInfoBanque').removeClass('disabled');
        }

    }

    // function getInfosBanquesFromIban(iban)
    // {
    //     cleanIban = iban.replace(/\-/g, '');
    //     // $.get("https://api.iban.com/clients/api/iban-api.php?api_key=c5c40869571a7fed5f746a97dbe4c813&iban="+cleanIban,function(data){

    //     //     console.log('response :', data);
    //     // });

    //     $.ajax({
    //             url  : "https://api.iban.com/clients/api/iban-api.php?api_key=c5c40869571a7fed5f746a97dbe4c813&iban="+cleanIban,                
    //             type : 'GET',
    //             crossDomain: true,
    //             dataType: 'jsonp'
                
    //         }).success(function(data){
    //            //console.log('response :', data);
    //             // xmlDoc = $.parseXML( data ),
    //             // xml    = $( xmlDoc ),
    //             // title  = xml.find( "city" );
    //             //console.log('response :' ,title);

    //             $(data).find('result').each(function(){
    //                 $(this).find("city").each(function(){
    //                     var name = $(this).text();
    //                     console.log(name);
    //                 });
    //             });
                
    //         }).error(function(data){
                
    //         });

    // } 

    // Accepts a url and a callback function to run.
    function requestCrossDomain(iban,callback) {

        cleanIban     = iban.replace(/\-/g, '');
        iban_api_key  = $('#iban_api_key').val();
        iban_api_link = $('#iban_api_link').val();

        site          = iban_api_link+iban_api_key+"&iban="+cleanIban;
        //console.log(site);
        //return;
        // Take the provided url, and add it to a YQL query. Make sure you encode it!
        var yql = 'http://query.yahooapis.com/v1/public/yql?q=' + encodeURIComponent('select * from xml where url="' + site + '"') + '&format=xml&callback=?';
     
        // Request that YSQL string, and run a callback function.
        // Pass a defined function to prevent cache-busting.
        $.getJSON(yql, cbFunc);
        //console.log('request send !!');
     
        function cbFunc(data) {
            //console.log('tiiiiit');
            // If we have something to work with...
            if (data.results[0]) {
                if (typeof callback === 'function') {
                    callback(data);
                }
            }
            // Else, Maybe we requested a site that doesn't exist, and nothing returned.
            else throw new Error('Nothing returned from getJSON.');
        }
    }

    function getInfosBanquesFromIbanPre(iban) {
        requestCrossDomain(iban, function(result) {
            //var num = 1;
            //console.log('inside callback !!');
            var doc = (new DOMParser()).parseFromString(result.results, 'text/xml');           
            var xml = doc;
     
            $(xml).find('result').each(function () {
                
                var validIBAN = $(this).find('valid').text();
                if(validIBAN=='TRUE')
                {
                    var iban          = $(this).find('iban').text();
                    var ville         = $(this).find('city').text();
                    var nomBank       = $(this).find('bank_name').text();
                    var adresseBank   = $(this).find('address').text();
                    var bic           = $(this).find('swift').text();

                    $('#nom_banque_pre').val(nomBank);
                    $('#nom_banque_pre').parent().addClass("md-input-wrapper md-input-filled");
                    $('#adresse_banque_pre').val(adresseBank);
                    $('#adresse_banque_pre').parent().addClass("md-input-wrapper md-input-filled");
                    $('#ville_banque_pre').val(ville);
                    $('#ville_banque_pre').parent().addClass("md-input-wrapper md-input-filled");
                    $('#code_bic_pre').val(bic);
                    $('#code_bic_pre').parent().addClass("md-input-wrapper md-input-filled");
                    //console.log(link);
                    //console.log(headlines);
                }
                    
            });

        });
    }

    function getInfosBanquesFromIbanRem(iban) {
        requestCrossDomain(iban, function(result) {
            //var num = 1;
            //console.log('inside callback !!');
            var doc = (new DOMParser()).parseFromString(result.results, 'text/xml');           
            var xml = doc;
     
            $(xml).find('result').each(function () {
                
                var validIBAN = $(this).find('valid').text();
                if(validIBAN=='TRUE')
                {
                    var iban          = $(this).find('iban').text();
                    var ville         = $(this).find('city').text();
                    var nomBank       = $(this).find('bank_name').text();
                    var adresseBank   = $(this).find('address').text();
                    var bic           = $(this).find('swift').text();

                    $('#nom_banque_rem').val(nomBank);
                    $('#nom_banque_rem').parent().addClass("md-input-wrapper md-input-filled");
                    $('#adresse_banque_rem').val(adresseBank);
                    $('#adresse_banque_rem').parent().addClass("md-input-wrapper md-input-filled");
                    $('#ville_banque_rem').val(ville);
                    $('#ville_banque_rem').parent().addClass("md-input-wrapper md-input-filled");
                    $('#code_bic_rem').val(bic);
                    $('#code_bic_rem').parent().addClass("md-input-wrapper md-input-filled");
                    //console.log(link);
                    //console.log(headlines);
                }
                    
     
            });
        });
    }

// Fonctions du questionnaire
    function showDivQstOui(id)
    {
        //alert('tooot');
        $('#divQstOui'+id).show();
        $('#divQstNon'+id).hide();
    }

    function showDivQstNon(id)
    {
        //alert('tiiit');
        $('#divQstNon'+id).show();
        $('#divQstOui'+id).hide();
    }
            



    </script>
    
    @yield('scripts')
    @yield('gestionLead')
    @yield('productsBarJS')

@stop