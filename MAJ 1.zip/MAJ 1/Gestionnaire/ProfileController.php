<?php

namespace App\Http\Controllers\Gestionnaire;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth;
use App\Messagerie;
use App\Tracessante;


class ProfileController extends Controller
{

    public function index() {

    	//return "Profile Page";
       
		$user               = Auth::user();
		
		$agence             = $user->agence;
		
		$nombreMessageNonLu = Messagerie::where('vu', 0)->whereActive(1)->where('to_id', $user->id)->orderBy('created_at', 'desc')->get();
		
		$traces             = Tracessante::where('user_id', $user->id)->orderBy('created_at', 'desc')->take(10)->get();

  		return view('gestion.profile', compact('agence', 'traces', 'user', 'nombreMessageNonLu'));
    }

}
