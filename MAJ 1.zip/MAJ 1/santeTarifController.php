<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use SoapClient;

use App\Sacompagnie;

use App\Groupeprestationgarantie; 

use App\Prestationgarantie;

use App\Sadocument;

use App\Documentgamme;

use App\Sagroupeprestation;

use App\Sadepartement;

use App\Saprestation;

use App\Sagamme;

use App\Sagarantie;

use App\Saregime;

use App\Compositionfamiliale;

use App\Satarif;

use App\User;

use App\CompagnieProduit;

use DB;

use File;

use Crypt;

class santeTarifController extends Controller
{
        
    // declaration des atributs
  public $tabGaranties;
  public $compagnies;
    public $nombreAdultes = 1;
    public $nombreEnfants = 0;
    
    // constructeur
    public function __construct(){

        $this->compagnies = [];
        $this->tabGaranties = [];
    }

    public function index()
    {   
        $compagnies   = Sacompagnie::where('active', 1)->orderby('libelle', 'asc')->get();
        $regimes      = Saregime::where('active', 1)->orderby('libelle', 'asc')->get(); 
        $year           = date("Y");
        $yearplus1          = date("Y") + 1;
    

        return view('webservice.index', array('compagnies'  => $compagnies, 
                                                'regimes'   => $regimes,
                                                'year'      => $year,
                                                'yearplus1' => $yearplus1,
                                               
                                                ));
    }

    public function compagnies(Request $request) {
      
        $user             = User::where('key', $request->get('key'))->where('active', 1)->first();
        $compagnieStopper = $user->compagnieProduitCourtier->lists('sacompagnieproduit_id');
        $compagni         = CompagnieProduit::whereIn('id', $compagnieStopper)->where('active', 1)->lists('sacompagnie_id');
        $flattened        = collect($compagni)->flatten();

        $dateConjoint         = $request->get('dateC');


            if ( $dateConjoint ) {
              $ageConjoint          = \Carbon\Carbon::parse($dateConjoint)->age;
              if($ageConjoint >= 55){

            if($flattened->contains(8)){

                $this->cegema($request);
                
            }
            }
          }else{

            if($flattened->contains(8)){

                $this->cegema($request);
                
            }

          }

            // if($flattened->contains(50)){

            //     $this->april($request);
                
            // }
                
          

            if($flattened->contains(9)){

                $this->alptis($request);
                
            }
          $ageAssure         = \Carbon\Carbon::parse($request->get('dateA'))->age;

            if ($ageAssure < 85) {

              if($flattened->contains(14)){

                $this->pereireDirectAdonis($request);
                $this->pereireDirectSocrate($request);
                  
              }

            }



             if($flattened->contains(5)){

                $this->afps($request);
                
            }

            if($flattened->contains(11)){

                $this->smam($request);
                
            }

            // if($flattened->contains(54)){

            //     $this->neoliane($request);
                
            // }

            // if($flattened->contains(10)){

            //     $this->fmaSante($request);
                
            // }
      
      // $this->april($request);
      // $this->smam($request);
      // $this->alptis($request);
      // $this->pereireDirectAdonis($request);
      // $this->pereireDirectSocrate($request);
      // $this->cegema($request);
      // //$this->neoliane($request); 
      // $this->fmaSante($request);
      // $this->afps($request); 
      return [collect($this->compagnies)->last()];
       
    }

    public function dataTableauGaranties(Request $request) {
      
                $this->compagnies($request);

                $data = [];
      
      $tarifs =  [collect($this->compagnies)->last()];

        foreach($tarifs as $key => $compagnie){


            foreach($compagnie as $ke => $gamme){

                foreach($gamme as $libelleGamme => $gammes){
                    //$data['gamme'] = $libelleGamme;
                    foreach($gammes as $t => $garanties){

                      if (is_array($garanties)){

                        foreach($garanties as $libelleGamme => $garantie){

                            foreach($garantie as $d => $gar){


                                foreach($gar as $libelleGarantie => $dd){

                                    foreach($dd as $x => $ww){

                                        if($x == 'codeGarantie'){

                                          $index = $ww;
                                      $tarifGarantie[$libelleGamme][$index] = $tarif.' €';
                                            array_push($data, $tarifGarantie);
                                        }
                                        if($x == 'tarif'){
                                          
                                          $tarif = $ww;                                         
                                        }

                                    }
                                }
                            }
                        }
                    }
                    }
                }
            }   
        }

        return [collect($data)->last()];
       
    }


    public function april(Request $request)
    {
        //dd($request);
        $urlxml            = "https://wspartenaires.april.fr/Sante/Tarification.svc?wsdl";
        $xml               = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:obs="http://www.april.fr/APR/Exposition/Distribution/Sante"> ... </soapenv:Envelope>';
        $action            = 'http://www.april.fr/APR/Exposition/Distribution/Sante/ITarification/ObtenirTarifMultiple';
        $client            = new SoapClient($urlxml);
        $result            = $client->__doRequest($xml , $urlxml, $action, SOAP_1_2);

          //data générale
        $dateEffet         = $request->get('dateEffet');
        //var_dump($dateEffet);
        $codePostal        = $request->get('codepostale');

        //data assuré
        $dateAssure        = $request->get('dateA');
        //dd($dateAssure);
        $regimeAssure      = $this->regimeApril($request->get('regimeA'));

        //data conjoint
        $dateConjoint      = $request->get('dateC');
        $regimeConjoint    = $this->regimeApril($request->get('regimeC'));
    
        //data enfants
        $enfantsData       = [];
        $enfantsData       = $request->get('dateE');
        //dd($enfantsData);
        //data groupe prestations
        $prestations       = $request->get('prestation');


        $gammes            = Sacompagnie::where('libelle', 'april')->first()->gamme()->where('active',1)->get();
        //dd($gammes);

        //Initialiser le tableau de garanties
            $sansPrestation = $request->get('sansPrestation');
            $fichePoint     = $request->get('fichePoint');
            $this->initGarantie($gammes, $prestations, $sansPrestation, $fichePoint);

        if(count($gammes)>0){
          $this->tabGaranties['compagnie'][$gammes[0]->compagnie->libelle]['code'] = $gammes[0]->compagnie->code;
        }


        foreach($gammes as $gamme)
        {

          $wsApril                                            = new \stdClass();
          $wsApril->Licence                                   = "{3263DD2A-543A-45B7-9920-72F402EAA893}";
          $wsApril->Identite                                  = "CO:81116";
          $wsApril->IdentifiantTracabilite                    = "test";
          $wsApril->Projet                                    = new \stdClass();
          //$wsApril->Projet->CodeProduit                       = $this->remplaceGamme($gamme->libelle);
          $wsApril->Projet->CodeProduit                       = $gamme->libelle;
          $wsApril->Projet->Assures                           = new \stdClass();

          //Assuré
          $wsApril->Projet->Assures->Assure[0]                    = new \stdClass();
          $wsApril->Projet->Assures->Assure[0]->Nom               = "premier";
          $wsApril->Projet->Assures->Assure[0]->Prenom            = "assure";
          $wsApril->Projet->Assures->Assure[0]->DateDeNaissance   = $dateAssure;
          $wsApril->Projet->Assures->Assure[0]->Type              = "AssurePrincipal";
          $wsApril->Projet->Assures->Assure[0]->RegimeObligatoire = $regimeAssure;

          //Conjoint
          if($dateConjoint){

          $wsApril->Projet->Assures->Assure[1]                    = new \stdClass();
          $wsApril->Projet->Assures->Assure[1]->Nom               = "second";
          $wsApril->Projet->Assures->Assure[1]->Prenom            = "assure";
          $wsApril->Projet->Assures->Assure[1]->DateDeNaissance   = $dateConjoint;
          $wsApril->Projet->Assures->Assure[1]->Type              = "Conjoint";
          $wsApril->Projet->Assures->Assure[1]->RegimeObligatoire = $regimeConjoint;

          }

          //Instances enfants
          if(count($enfantsData) > 0){
            
                  
              $indice = ($dateConjoint) ? 2 : 1;

              $count  = 2;
              foreach($enfantsData as $enfantData){ 

                if($enfantData){
                  //dd($enfantData);
                         
                    $enfant         = explode('#', $enfantData);
                    $regimeEnfant   = $enfant[1];
                    $dateEnfant     = $enfant[0];
                          
                          //régime enfant (Ayant droit P == Prospect, C == Conjoint)
                    $regimeEnfant = ($regimeEnfant == 'P') ? $regimeAssure : $regimeConjoint;
                    
                    //Instance enfant
                    $wsApril->Projet->Assures->Assure[$indice]                          = new \stdClass();
                    $wsApril->Projet->Assures->Assure[$indice]->Nom                     = "troisieme";
                    $wsApril->Projet->Assures->Assure[$indice]->Prenom                  = "assure";
                    $wsApril->Projet->Assures->Assure[$indice]->Type                    = "Enfant";
                    $wsApril->Projet->Assures->Assure[$indice]->DateDeNaissance         = $dateEnfant;
                    $wsApril->Projet->Assures->Assure[$indice]->RegimeObligatoire       = $regimeEnfant;
                          
                    $indice++;
                    $count++;
                }
              }
          }

          $wsApril->Projet->Client                                      = new \stdClass();
          $wsApril->Projet->Client->ActiviteProfessionnelle             = "Employe";
          $wsApril->Projet->Client->Adresse                             = new \stdClass();
          $wsApril->Projet->Client->Adresse->CodePostal                 = $codePostal;
          // $wsApril->Projet->Couvertures                   = new \stdClass();
          // $wsApril->Projet->Couvertures->Couverture             = new \stdClass();
          // $wsApril->Projet->Couvertures->Couverture->CodeGarantie       = "MaladieChirurgie";
          // $wsApril->Projet->Couvertures->Couverture->CodeNiveau         = "ECO";
          $wsApril->Projet->DateEffet                                   = $dateEffet;



          $params                                                       = new \stdClass();

          $params->Demande = $wsApril;
          //dd($params);

          try
          {

              $response = $client->ObtenirTarifMultiple($params);
              dd($response);

              if($response->ObtenirTarifMultipleResult->StatutMetier == 'SUCCES')
              {
                if(isset($response->ObtenirTarifMultipleResult->NiveauxCouverturePrincipale))
                {
                  foreach($response->ObtenirTarifMultipleResult->NiveauxCouverturePrincipale->NiveauCouverturePrincipale as $cle => $donne) 
                  {

                    list($libelleGamme, $libelleGarantie) = explode(" - ", $donne->LibelleCommercial);
                    //dd($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][(string)$libelleGarantie]);
                    // var_dump($donne->LibelleCommercial);

                    // var_dump($donne->TarifsCouvertures->TarifCouverture[0]->Tarif); 

                    // var_dump($libelleGarantie);

                    //var_dump($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][(string)$libelleGarantie]);
                    

                    if(isset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][(string)$libelleGarantie])) 
                    {
                      //var_dump($donne->LibelleCommercial);
                      
                        //********************************************
                        if(is_array($donne->TarifsCouvertures->TarifCouverture) or ($donne->TarifsCouvertures->TarifCouverture instanceof Traversable))
                        {
                           $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][(string)$libelleGarantie]['tarif'] = $donne->TarifsCouvertures->TarifCouverture[0]->Tarif;

                           //$renforts                  = collect($donne->TarifsCouvertures->TarifCouverture)->slice(1)->toArray();

                           $renforts                     = $donne->TarifsCouvertures->TarifCouverture;

                           $firstElm                     = array_shift($renforts);
                           //dd($renforts);

                           $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][(string)$libelleGarantie]['options'] = $renforts;

                        }
                        else
                        {
                          $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][(string)$libelleGarantie]['tarif'] = $donne->TarifsCouvertures->TarifCouverture->Tarif;
                        }

                        
                        //$temp = $donne->TarifsCouvertures->TarifCouverture;
                       //var_dump($temp); 

                      //dd($donne);
                                                

                       //$this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$this->remplaceGamme($gamme->libelle)] = $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle];

                       //var_dump($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$this->remplaceGamme($gamme->libelle)]);
                       
                      
                        //$this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$this->remplaceGamme($gamme->libelle)]['garanties'][(string)$donne->Garantie->GarantieOutput->Libelle]['options'] = $donne->OptionProduit;
                    


                       // if($gamme->libelle != $this->remplaceGamme($gamme->libelle)){
                       // unset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]);
                       // }

                    }else{
                      continue;
                    }
                  }//enf foreach
                }
                

             }//end if Business

          }
          catch(Exception $e){
            return $e;
          }
      
      } // end for gammes

      // echo "<pre>";
      //     print_r($this->tabGaranties);
      //     echo "</pre>";
      //var_dump($this->compagnies);

      array_push($this->compagnies, $this->tabGaranties);

    }

    public function aprilOld(Request $request) {

        /*--=====================================
        =            Tarif april web service    =
        ======================================--*/
        
        //Initialiser le web service soap april
      $urlxml = "http://wspar51.april.fr/WSSante/WsSante.asmx?WSDL";
    $xml    = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:obs="http://www.april.fr/APR/Exposition/Distribution/Sante"> ... </soapenv:Envelope>';
    $action = 'http://www.april.fr/APR/Exposition/Distribution/Sante/ITarification/ObtenirTarif';
    $client = new SoapClient($urlxml);
        $result = $client->__doRequest($xml , $urlxml, $action, SOAP_1_2);
        
        //data générale
        $dateEffet         = str_replace("-", "", $request->get('dateEffet'));
        $codePostal        = $request->get('codepostale');

        //data assuré
        $dateAssure        = str_replace("-", "", $request->get('dateA'));
        $regimeAssure      = $this->regimeApril($request->get('regimeA'));

        //data conjoint
        $dateConjoint      = str_replace("-", "", $request->get('dateC'));
        $regimeConjoint    = $this->regimeApril($request->get('regimeC'));
    
    //data enfants
    $enfantsData       = $request->get('dateE');

    //data groupe prestations
    $prestations       = $request->get('prestation');


    $gammes = Sacompagnie::where('libelle', 'april')->first()->gamme;

    //Initialiser le tableau de garanties
        $sansPrestation = $request->get('sansPrestation');
        $fichePoint     = $request->get('fichePoint');
        $this->initGarantie($gammes, $prestations, $sansPrestation, $fichePoint);

    if(count($gammes)>0){
      $this->tabGaranties['compagnie'][$gammes[0]->compagnie->libelle]['code'] = $gammes[0]->compagnie->code;
    }

    foreach($gammes as $gamme){

        //Instance web service april
      $wsApril                         = new \stdClass();
      $wsApril->astr_Clef              = "{3263DD2A-543A-45B7-9920-72F402EAA893}";
      $wsApril->TarifParams            = new \stdClass();
      $wsApril->TarifParams->IdCo      = "81116";
      $wsApril->TarifParams->Devis     = new \stdClass();

          
          //Instance assuré
      $wsApril->TarifParams->Devis->Assure[0]                              = new \stdClass();
      $wsApril->TarifParams->Devis->Assure[0]->Nom                         = "premier";
      $wsApril->TarifParams->Devis->Assure[0]->Prenom                      = "assure";
      $wsApril->TarifParams->Devis->Assure[0]->NumeroAssure                = 1;
      $wsApril->TarifParams->Devis->Assure[0]->Type                        = "Adherent";
      $wsApril->TarifParams->Devis->Assure[0]->DateNaissance               = $dateAssure;
      $wsApril->TarifParams->Devis->Assure[0]->RegimeObligatoire           = $regimeAssure;

      //Instance conjoint
      if($dateConjoint){

        $wsApril->TarifParams->Devis->Assure[1]                          = new \stdClass();
        $wsApril->TarifParams->Devis->Assure[1]->Nom                     = "second";
        $wsApril->TarifParams->Devis->Assure[1]->Prenom                  = "assure";
        $wsApril->TarifParams->Devis->Assure[1]->NumeroAssure            = 2;
        $wsApril->TarifParams->Devis->Assure[1]->Type                    = "Conjoint";
        $wsApril->TarifParams->Devis->Assure[1]->DateNaissance           = $dateConjoint;
        $wsApril->TarifParams->Devis->Assure[1]->RegimeObligatoire       = $regimeConjoint;
          
      } 

          //Instances enfants
      if(count($enfantsData) > 0){
              
          $indice = ($dateConjoint) ? 2 : 1;
          $count  = 2;
          foreach($enfantsData as $enfantData){ 

            if($enfantData){ 
                     
                $enfant         = explode('#', $enfantData);
                $regimeEnfant   = $enfant[1];
                $dateEnfant     = str_replace("-", "", $enfant[0]);
                      
                      //régime enfant (Ayant droit P == Prospect, C == Conjoint)
                $regimeEnfant = ($regimeEnfant == 'P') ? $regimeAssure : $regimeConjoint;
                
                //Instance enfant
                $wsApril->TarifParams->Devis->Assure[$indice]                          = new \stdClass();
                $wsApril->TarifParams->Devis->Assure[$indice]->Nom                     = "troisieme";
                $wsApril->TarifParams->Devis->Assure[$indice]->Prenom                  = "assure";
                $wsApril->TarifParams->Devis->Assure[$indice]->NumeroAssure            = $count + 1;
                $wsApril->TarifParams->Devis->Assure[$indice]->Type                    = "Enfant";
                $wsApril->TarifParams->Devis->Assure[$indice]->DateNaissance           = $dateEnfant;
                $wsApril->TarifParams->Devis->Assure[$indice]->RegimeObligatoire       = $regimeEnfant;
                      
                $indice++;
                $count++;
            }
          }
      }


      $wsApril->TarifParams->Devis->Parametres                        = new \stdClass();
      $wsApril->TarifParams->Devis->Parametres->DateEffet             = $dateEffet;
      $wsApril->TarifParams->Devis->Parametres->CodePostal            = $codePostal;
      $wsApril->TarifParams->Devis->Parametres->BesoinHospitalisation = $prestations[3].'%';
      $wsApril->TarifParams->Devis->Parametres->BesoinFraisMedicaux   = $prestations[0].'%';
      $wsApril->TarifParams->Devis->Parametres->BesoinDentaire        = $prestations[2].'%';
      $wsApril->TarifParams->Devis->Parametres->BesoinOptique         = $prestations[1].'%';
      $wsApril->TarifParams->Devis->Parametres->Produit               = $gamme->libelle;
      $wsApril->TarifParams->Devis->Parametres->DeuxEurosMalins       = false;
      $wsApril->TarifParams->Devis->Parametres->CreateurEntreprise    = true;
    

    try{

        $response = $client->Tarif($wsApril);
        //dd($response);
         
      if(isset($response->TarifResult->BusinessData)){
        foreach($response->TarifResult->BusinessData->Proposition->PropositionOutput as $cle => $donne) {
                
                if(isset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$donne->Produit]['garanties'][(string)$donne->Garantie->GarantieOutput->Libelle])) {

           $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$donne->Produit]['garanties'][(string)$donne->Garantie->GarantieOutput->Libelle]['tarif'] = (float)$donne->Garantie->GarantieOutput->CotisationMensuelle / 100;

           $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$this->remplaceGamme($donne->Produit)] = $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$donne->Produit];
           
          
            $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$this->remplaceGamme($donne->Produit)]['garanties'][(string)$donne->Garantie->GarantieOutput->Libelle]['options'] = $donne->OptionProduit;
        


           if($donne->Produit != $this->remplaceGamme($donne->Produit)){
           unset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$donne->Produit]);
           }

                }else{
                  continue;
                }
        }//enf foreach

       }//end if Business

    }
    catch(Exception $e){
      return $e;
    }



      
      } // end for gammes

      
      array_push($this->compagnies, $this->tabGaranties);


    }//--====  End of Tarif april web service  ====-->
   

    public function smam(Request $request){
       /*--=====================================
        =            Tarif smam web service    =
        ======================================--*/
          //data générale
          $dateEffet          = \Carbon\Carbon::parse($request->get('dateEffet'))->format('d-m-Y');
          $dateEffet          = str_replace("-", "", $dateEffet);
          $codePostal         = $request->get('codepostale');


          //data assuré
          $dateAssure         = \Carbon\Carbon::parse($request->get('dateA'))->format('d-m-Y');
          $dateAssure       = str_replace("-", "", $dateAssure);
          $regimeAssure       = $this->regimeSmam($request->get('regimeA'));

          //data conjoint

          

          //data enfants
          $enfantsData      = $request->get('dateE');

          
          $nombreEnfants    =  count($enfantsData);

            //data groupe prestations
          $prestations      = $request->get('prestation');

          $url              = 'http://extranet.apivia-courtage.fr/tarifs/';
        
            //Initialiser le web service soap smam

          $data = [
                "regime"       => $regimeAssure,
                "cle"          => "4d7b07d772d871dc44ec327fdf41ae1d",
                "compagnie"    => "SMAM",
                "gamme"        => "*",
                "formule"      => "*",
                "codepostal"   => $codePostal,
                "datenaissance"=> $dateAssure,
                "date_effet"   => $dateEffet,
                "format"       => "xml",
                "enfants"      => $nombreEnfants
                    ];
            if(!empty($request->get('dateC'))){
              $dateConjoint       = \Carbon\Carbon::parse($request->get('dateC'))->format('d-m-Y');
              $dateConjoint       = str_replace("-", "", $dateConjoint);
              $regimeConjoint     = $this->regimeSmam($request->get('regimeC'));

              $data['regime_co'] = $regimeConjoint;
              $data["datenaissance_co"] = $dateConjoint;

            }

            //return $url;

            

               $params = http_build_query($data);
                //return $url.'?'.$params;
                $urlReponse = $url.'?'.$params;

            $ch               = curl_init();
            $timeout          = 0;
            curl_setopt($ch, CURLOPT_URL,$urlReponse);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,$timeout);
            $rawdata          =curl_exec($ch);
            curl_close($ch);
            $reponseSmam      = new \SimpleXMLElement($rawdata);
            $compagnie = $gammes = Sacompagnie::where('libelle', 'SMAM')
                              ->with(['gamme' => function($q) use ($regimeAssure){
                                  if($regimeAssure == 'tns'){
                                    $q->where('libelle','<>', 'tnsante');
                                  }
                                }])
                            ->first();

          $gammes = $compagnie->gamme;
            

            //Initialiser le tableau de garanties
           $sansPrestation = $request->get('sansPrestation');
           $fichePoint     = $request->get('fichePoint');
        $this->initGarantie($gammes, $prestations, $sansPrestation, $fichePoint);
          
          $this->tabGaranties['compagnie'][$compagnie->libelle]['code'] = $compagnie->code;
          
          foreach($reponseSmam as $cle => $gamme) {

              foreach($gamme as $key => $tarifGarantie) {

                if(isset($this->tabGaranties['compagnie'][$compagnie->libelle]['gammes'][(string)$gamme['reference']]['garanties'][(string)$tarifGarantie['formule']])) {

                  $this->tabGaranties['compagnie'][$compagnie->libelle]['gammes'][(string)$gamme['reference']]['garanties'][(string)$tarifGarantie['formule']]['tarif'] = (float)$tarifGarantie;

                }

              } 
               
          }

          array_push($this->compagnies, $this->tabGaranties);


    }

    public function alptis(Request $request){
      
       /*--=====================================
        =            Tarif alptis web service    =
        ======================================--*/
            //data générale
            $dateEffet          = $request->get('dateEffet');
            $dateEffet          = str_replace("-", "", $dateEffet);
            $codePostal         = $request->get('codepostale');


            //data assuré
            $dateAssure         = $request->get('dateA');
            $dateAssure         = str_replace("-", "", $dateAssure);
            $regimeAssure       = $this->regimeAlptis($request->get('regimeA'));

            //data conjoint
            $dateConjoint       = $request->get('dateC');
            $dateConjoint       = str_replace("-", "", $dateConjoint);
            $regimeConjoint     = $this->regimeAlptis($request->get('regimeC'));

            //data enfants
            $enfantsData        = $request->get('dateE');

            //data groupe prestations
            $prestations        = $request->get('prestation');
        
            $collection         = collect([['somme' => 0],['somme' => 4],['somme' => 8],['somme' => 12],['somme' => 16],['somme' => 20]]);
            $somme = 0;
            foreach($prestations as $valeur){

            $somme += $valeur/100;

            }

            $results = $collection->where('somme',$somme);
            //dd($results);
            if($results->count() > 0){
                $niveau = $somme/4;

                  }else{

                       return ;

                       }

            $enfant = '';

            if(!empty($enfantsData)){
              foreach($enfantsData as $Enfantregime){ 
                 if(!empty($Enfantregime)){ 
                       $enfantregime         = explode('#', $Enfantregime);
                       $regimeEnfant         = $enfantregime[1];
                       $dateEnfant                = str_replace("-", "", $enfantregime[0]);
                 if($regimeEnfant == 'P'){
                       $EnfantR = $regimeAssure;
                       $enfant =$enfant.'<enfant civilite="M." datenaissance="'.$dateEnfant.'" regime="'.$EnfantR.'" />';
                        }else{
                    $EnfantR  = $regimeConjoint;
                    $enfant   = $enfant.'<enfant civilite="M." datenaissance="'.$dateEnfant.'" regime="'.$EnfantR.'" />';
                             }
                 }
               }
            }
          //echo $enfant;

       $urlxml = "http://webservices.alptis.org/index.php/wsserver/TarifSante/wsdl?version=1.1";

       $xml    = '<definitions xmlns="http://schemas.xmlsoap.org/wsdl/" xmlns:tns="http://webservices.alptis.org/index.php/wsserver/default/wsdl/TarifSante" xmlns:impl="http://webservices.alptis.org/index.php/wsserver/default/wsdl/TarifSante" xmlns:xsd1="http://webservices.alptis.org/index.php/wsserver/default/wsdl/TarifSante" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" name="TarifSante" targetNamespace="http://webservices.alptis.org/index.php/wsserver/default/wsdl/TarifSante">...</definitions>';
       $action = 'http://webservices.alptis.org/index.php/wsserver/TarifSante';

      $gammes  = Sagamme::where('libelle','SANTEPLURIELLE')->get();

      $sansPrestation = $request->get('sansPrestation');
      $fichePoint     = $request->get('fichePoint');
      $this->initGarantie($gammes, $prestations, $sansPrestation, $fichePoint);

              if(count($gammes)>0){
                $this->tabGaranties['compagnie'][$gammes[0]->compagnie->libelle]['code'] = $gammes[0]->compagnie->code;
              }

             foreach($gammes as $gamme){

                
                 if(empty($dateConjoint)){
                    $alptisRequest ='<?xml version="1.0"?>
                    <!DOCTYPE dossierSante SYSTEM "http://www.alptis.org/espacepro/dtd/dossierSanteV5.dtd">
                    <dossierSante login="65017" pass="WS46405">
                        <garantie nomgarantie="SANTEPLURIELLE" niveau="'.$niveau.'" typecom="EM"/>
                        <assure>
                            <adherent civilite="M." datenaissance="'.$dateAssure.'" regime="'.$regimeAssure.'" csp="410" datedebutassurance="'.$dateEffet.'"
                            departement="'.$codePostal.'"/>'.$enfant.'
                        </assure>
                    </dossierSante>';
                }else{
                    $alptisRequest ='<?xml version="1.0"?>
                    <!DOCTYPE dossierSante SYSTEM "http://www.alptis.org/espacepro/dtd/dossierSanteV5.dtd">
                    <dossierSante login="65017" pass="WS46405">
                        <garantie nomgarantie="SANTEPLURIELLE" niveau="'.$niveau.'" typecom="EM"/>
                        <assure>
                            <adherent civilite="M." datenaissance="'.$dateAssure.'" regime="'.$regimeAssure.'" csp="410" datedebutassurance="'.$dateEffet.'" departement="'.$codePostal.'"/>
                            <conjoint civilite="M." datenaissance="'.$dateConjoint.'" regime="'.$regimeConjoint.'" csp="410" />'.$enfant.'
                        </assure>
                    </dossierSante>';
                }

                  $client             = new SoapClient($urlxml);

                  $response           = $client->calculerTarifSante($alptisRequest);
                    //dd($response);
                  $cotisations        = new \SimpleXMLElement($response);

            if($cotisations->cotisation->cotisationGarantie['cotisationtotale'] == null){
                return;
                    }

                    if(isset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes']['SANTEPLURIELLE']['garanties']['SANTEPLURIELLE'.$niveau])) {

               
       

         $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes']['SANTEPLURIELLE']['garanties']['SANTEPLURIELLE'.$niveau]['tarif'] = (float)$cotisations->cotisation->cotisationGarantie['cotisationtotale'];
       }
         
         }  

         array_push($this->compagnies, $this->tabGaranties);

     
    
    }


    public function neoliane(Request $request){
      
       /*--=====================================
        =            Tarif alptis web service    =
        ======================================--*/
        $profil1 = '<?xml version="1.0" encoding="utf-8"?>

<projetSante Username="CONSEILAVIE" Password="av=9Qg75Hy@">

               <gamme>NEOLIANE SANTEPRO</gamme>

               <dateEffet>12/06/2017</dateEffet>

               <cp>06</cp>

               <Principal>

                              <sexe>M</sexe>

                              <dtn>21/01/1972</dtn>

                              <regime>SS</regime>

               </Principal>

               <Conjoint>

                              <sexe>F</sexe>

                              <dtn>22/01/1976</dtn>

                              <regime>SS</regime>

                       <ayantdroit>affilieensonnom</ayantdroit>

               </Conjoint>

               <Enfants>

                              <enfant>

                                             <ayantdroit>Principal</ayantdroit>

                                            <sexe>M</sexe>

                                             <dtn>19/03/2005</dtn>

                                            <regime>SS</regime>

                              </enfant>

                              <enfant>

                                             <ayantdroit>Principal</ayantdroit>

                                            <sexe>F</sexe>

                                             <dtn>06/09/2009</dtn>

                                            <regime>SS</regime>

                              </enfant>

               </Enfants>

</projetSante>';

$client=new SoapClient('http://wstarifs.neoliane.fr/webservices/service.php', array('trace' =>true));

try {

               $retour = $client->__soapCall('Tarifer', array('XMLEntree'=>$profil1));
               $cotisations        = new \SimpleXMLElement($retour);
               dd($cotisations);

               var_dump($retour) ;

}

catch(Exception $e) {

               echo 'LastRequest : <br/>';

               echo $client->__getLastRequest().'<br>';

               echo 'LastResponse : <br/>';

               echo $client->__getLastResponse().'<br>';

               die();

}
            //data générale
            $dateEffet          = $request->get('dateEffet');
            $dateEffet          = str_replace("-", "", $dateEffet);
            $codePostal         = $request->get('codepostale');


            //data assuré
            $dateAssure         = $request->get('dateA');
            $dateAssure         = str_replace("-", "", $dateAssure);
            $regimeAssure       = $this->regimeApril($request->get('regimeA'));

            //data conjoint
            $dateConjoint       = $request->get('dateC');
            $dateConjoint       = str_replace("-", "", $dateConjoint);
            $regimeConjoint     = $this->regimeApril($request->get('regimeC'));

            //data enfants
            $enfantsData        = $request->get('dateE');

            //data groupe prestations
            $prestations        = $request->get('prestation');

            $collection         = collect([['somme' => 0],['somme' => 4],['somme' => 8],['somme' => 12],['somme' => 16],['somme' => 20]]);
            $somme = 0;

            $enfant = '';

            if(!empty($enfantsData)){
              foreach($enfantsData as $Enfantregime){ 
                 if(!empty($Enfantregime)){ 
                       $enfantregime         = explode('#', $Enfantregime);
                       $regimeEnfant         = $enfantregime[1];
                       $dateEnfant                = str_replace("-", "", $enfantregime[0]);
                 if($regimeEnfant == 'P'){
                       $EnfantR = $regimeAssure;
                       $enfant =$enfant.'<enfant civilite="M." datenaissance="'.$dateEnfant.'" regime="'.$EnfantR.'" />';
                        }else{
                    $EnfantR  = $regimeConjoint;
                    $enfant   = $enfant.'<enfant civilite="M." datenaissance="'.$dateEnfant.'" regime="'.$EnfantR.'" />';
                             }
                 }
               }
            }
          //echo $enfant;

       $urlxml = "http://wstarifs.neoliane.fr/webservices/service.php";

       $xml    = '<definitions xmlns="http://schemas.xmlsoap.org/wsdl/" xmlns:tns="http://wstarifs.neoliane.fr/webservices/server.php" xmlns:impl="http://wstarifs.neoliane.fr/webservices/server.php" xmlns:xsd1="http://wstarifs.neoliane.fr/webservices/server.php" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" name="tarifier" targetNamespace="http://wstarifs.neoliane.fr/webservices/server.php">...</definitions>';
       $action = 'http://wstarifs.neoliane.fr/webservices/server.php';

      $gammes  = Obgamme::where('libelle','DECES')->get();

      //$sansPrestation = $request->get('sansPrestation');
      //$this->initGarantie($gammes, $prestations, $sansPrestation);

              if(count($gammes)>0){
                $this->tabGaranties['compagnie'][$gammes[0]->compagnie->libelle]['code'] = $gammes[0]->compagnie->code;
              }

              foreach($gammes as $gamme){
    
                 if(empty($dateConjoint)){
                    $neolianeRequest ='<?xml version="1.0" encoding="utf-8"?>
                    <projetSante Username="USERNAME" Password="PASSWORD">
                        <gamme>NEOLIANE INITIAL</gamme>
                        <dateEffet>01/02/2015</dateEffet>
                        <cp>06</cp>
                        <Principal>
                        <sexe>M</sexe>
                        <dtn>21/01/1972</dtn>
                        <regime>SS</regime>
                        </Principal>
                   </projetSante>';
                }else{
                    $neolianeRequest ='<?xml version="1.0" encoding="utf-8"?>
                    <projetSante Username="CONSEILAVIE" Password="av=9Qg75Hy@">
                        <gamme>NEOLIANE INITIAL</gamme>
                        <dateEffet>01/02/2015</dateEffet>
                        <cp>06</cp>
                        <Principal>
                        <sexe>M</sexe>
                        <dtn>21/01/1972</dtn>
                        <regime>SS</regime>
                        </Principal>
                        <Conjoint>
                        <sexe>F</sexe>
                        <dtn>22/01/1976</dtn>
                        <regime>SS</regime>
                        <ayantdroit>affilieensonnom</ayantdroit>
                        </Conjoint>
                     </projetSante>';
                }

                  $client             = new SoapClient($urlxml);
                  //dd($client);

                  $response           = $client->Tarifer($neolianeRequest);
                  dd($response);
                  $cotisations        = new \SimpleXMLElement($response);

            if($cotisations->cotisation->cotisationGarantie['cotisationtotale'] == null){
                return;
                    }

                    if(isset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes']['SANTEPLURIELLE']['garanties']['SANTEPLURIELLE'.$niveau])) {

               
       

         $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes']['SANTEPLURIELLE']['garanties']['SANTEPLURIELLE'.$niveau]['tarif'] = (float)$cotisations->cotisation->cotisationGarantie['cotisationtotale'];
       }
         
         }  

         array_push($this->compagnies, $this->tabGaranties);

     
    
    }

    public function pereireDirectAdonis(Request $request){

         /*--=====================================
        =            Tarif pereireDirect web service    =
        ======================================--*/
            //data générale
            $dateEffet          = $request->get('dateEffet');
            $exercice           = str_replace("-", "", $dateEffet);
            $exercice           = substr($exercice, 0, 4);
            $exercice           = $exercice - date('Y');
            if(substr($request->get('codepostale'), 0, 2) == '20'){

            $departement        =  20;
            }else{
             $departement        =  Sadepartement::where('code', substr($request->get('codepostale'), 0, 2))->first()->code;             
            }



            //data assuré
            $dateAssure         = $request->get('dateA');
            $regimeAssure       = $this->regimePereire($request->get('regimeA'));

            //data conjoint
            $dateConjoint       = $request->get('dateC');
            $regimeConjoint     = $this->regimePereire($request->get('regimeC'));

            //data enfants
            $nombreEnfants      = 0;
            $nombreEnfants      = count($request->get('dateE'));

            //data groupe prestations
            $prestations        = $request->get('prestation');

         
            //cle pereire
            $key = '$2y$10$mlrxsS8uM.85a5dfyCOYfuXhFXW5pC8yjGKXnpQb5LO5K.No9pj5K';
            $url = 'http://assistcall.net/tarificateur/public/api/direct';

            if(!empty($dateConjoint)){

              $fields = array(
                "cle=$key",
                "exercice=$exercice",
                "regimeA=$regimeAssure",
                "dateA=$dateAssure",
                "deptA=$departement",
                "gamme_id=1",
                "regimeC=$regimeConjoint",
                "dateC=$dateConjoint",
                "nb_enfant=$nombreEnfants"

            );

            }else{

            $fields = array(
                "cle=$key",
                "exercice=$exercice",
                "regimeA=$regimeAssure",
                "dateA=$dateAssure",
                "deptA=$departement",
                "gamme_id=1",
                "nb_enfant=$nombreEnfants"
            );

            }

            //open connection
            // $ch = curl_init();

            // //set the url, number of POST vars, POST data
            // curl_setopt($ch, CURLOPT_URL, $url);
            // curl_setopt($ch, CURLOPT_POST, count($fields));
            // curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));

            // //execute post
            // $result = curl_exec($ch);

            // //close connection
            // curl_close($ch);
            // //dd($result);
            //dd($url.'?'.implode('&', $fields));
            $content     = @file_get_contents($url.'?'.implode('&', $fields)).'';
            $tarif       = json_decode($content, true);
                       // dd($tarif);
            //echo '<pre>', print_r($tarif) ,exit('</pre>');


              if(isset($tarif['ADONIS']) && array_key_exists('ADONIS', $tarif)){
                $gammes  = Sagamme::where('libelle','ADONIS')->get();
                $garanties = Sagarantie::where('sagamme_id', $gammes->first()->id)->get();


                $sansPrestation = $request->get('sansPrestation');
                $fichePoint     = $request->get('fichePoint');
                $this->initGarantie($gammes, $prestations, $sansPrestation, $fichePoint);

                if(count($gammes)>0){
                  $this->tabGaranties['compagnie'][$gammes[0]->compagnie->libelle]['code'] = $gammes[0]->compagnie->code;
                }

                foreach($gammes as $gamme){

                    foreach($garanties as $garantie){

                      if(isset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle])) {

                        $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['tarif'] = (float)$tarif['ADONIS'][$garantie->libelle];

                      }

                    }
                }
                array_push($this->compagnies, $this->tabGaranties);
              }
            
     
  } 


   public function pereireDirectSocrate(Request $request){

         /*--=====================================
        =            Tarif pereireDirect web service    =
        ======================================--*/
            //data générale
            $dateEffet          = $request->get('dateEffet');
            $exercice           = str_replace("-", "", $dateEffet);
            $exercice           = substr($exercice, 0, 4);
            $exercice           = $exercice - date('Y');
            if(substr($request->get('codepostale'), 0, 2) == '20'){

            $departement        =  20;
            }else{
             $departement        =  Sadepartement::where('code', substr($request->get('codepostale'), 0, 2))->first()->code;             
            }


            //data assuré
            $dateAssure         = $request->get('dateA');
            $regimeAssure       = $this->regimePereire($request->get('regimeA'));

            //data conjoint
            $dateConjoint       = $request->get('dateC');
            $regimeConjoint     = $this->regimePereire($request->get('regimeC'));

            //data enfants
            $nombreEnfants        = 0;
            $nombreEnfants        = count($request->get('dateE'));

            //data groupe prestations
            $prestations        = $request->get('prestation');

            //cle pereire
            $key = '$2y$10$mlrxsS8uM.85a5dfyCOYfuXhFXW5pC8yjGKXnpQb5LO5K.No9pj5K';
            $url = 'http://assistcall.net/tarificateur/public/api/direct';

            if(!empty($dateConjoint)){

              $fields = array(
                "cle=$key",
                "exercice=$exercice",
                "regimeA=$regimeAssure",
                "dateA=$dateAssure",
                "deptA=$departement",
                "gamme_id=2",
                "regimeC=$regimeConjoint",
                "dateC=$dateConjoint",
                "nb_enfant=$nombreEnfants"

            );

            }else{

            $fields = array(
                "cle=$key",
                "exercice=$exercice",
                "regimeA=$regimeAssure",
                "dateA=$dateAssure",
                "deptA=$departement",
                "gamme_id=2",
                "nb_enfant=$nombreEnfants"
            );

            }

          
            $content = file_get_contents($url.'?'.implode('&', $fields)).'';
            
            $tarif   = json_decode($content, true);



              

            if(isset($tarif['SOCRATE']) && array_key_exists('SOCRATE', $tarif)){

              $gammes    = Sagamme::where('libelle','SOCRATE')->get();
              $garanties = Sagarantie::where('sagamme_id', $gammes->first()->id)->get();


              $sansPrestation = $request->get('sansPrestation');
              $fichePoint     = $request->get('fichePoint');
              $this->initGarantie($gammes, $prestations, $sansPrestation, $fichePoint);

              if(count($gammes)>0){
                $this->tabGaranties['compagnie'][$gammes[0]->compagnie->libelle]['code'] = $gammes[0]->compagnie->code;
              }

              foreach($gammes as $gamme){

                  foreach($garanties as $garantie){

                    if(isset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle])) {

                        $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['tarif'] = (float)$tarif['SOCRATE'][$garantie->libelle];

                    }

                  }

              }

              array_push($this->compagnies, $this->tabGaranties);

            }

          
  } 

  public function cegema(Request $request){

         /*--=====================================
        =            Tarif cegema web service    =
        ======================================--*/
            //data générale
            $dateEffet          = $request->get('dateEffet');
            $exercice           = str_replace("-", "", $dateEffet);
            $exercice           = substr($exercice, 0, 4);
            $ageA               = $this->calculAge($exercice, $request->get('dateA'));
            $exercice           = $exercice - date('Y');
            if(substr($request->get('codepostale'), 0, 2) == '20'){

            $departement        =  20;
            }else{
             $departement        =  Sadepartement::where('code', substr($request->get('codepostale'), 0, 2))->first()->code;             
            }


            //data assuré
            $dateAssure         = $request->get('dateA');
            $regimeAssure       = $this->regimePereire($request->get('regimeA'));

            //data conjoint
            $dateConjoint       = $request->get('dateC');
            $regimeConjoint     = $this->regimePereire($request->get('regimeC'));

            //data enfants
            $nombreEnfants        = count($request->get('dateE'));

            //data groupe prestations
            $prestations        = $request->get('prestation');

            //cle
            $key = '$2y$10$mlrxsS8uM.85a5dfyCOYfuXhFXW5pC8yjGKXnpQb5LO5K.No9pj5K';
            $url = 'http://assistcall.net/tarificateur/public/api/cegema';

            if(!empty($dateConjoint)){

              $fields = array(
                "cle=$key",
                "exercice=$exercice",
                "regimeA=$regimeAssure",
                "dateA=$dateAssure",
                "deptA=$departement",
                "gamme_id=5",
                "regimeC=$regimeConjoint",
                "dateC=$dateConjoint",
                "nb_enfant=$nombreEnfants"

            );

            }else{

            $fields = array(
                "cle=$key",
                "exercice=$exercice",
                "regimeA=$regimeAssure",
                "dateA=$dateAssure",
                "deptA=$departement",
                "gamme_id=5",
                "nb_enfant=$nombreEnfants"
            );

            }


  
            $content     = file_get_contents($url.'?'.implode('&', $fields));
            $tarif       = json_decode($content, true);
              //dd($tarif);

            
            $gammes  = Sagamme::where('libelle','VITANEO RESP')->get();
            $garanties = Sagarantie::where('sagamme_id', $gammes->first()->id)->get();

            if(count($tarif) > 1){
            $sansPrestation = $request->get('sansPrestation');
            $fichePoint     = $request->get('fichePoint');
            $this->initGarantie($gammes, $prestations, $sansPrestation, $fichePoint);


            if(count($gammes)>0){
              $this->tabGaranties['compagnie'][$gammes[0]->compagnie->libelle]['code'] = $gammes[0]->compagnie->code;
            }
            
            foreach($gammes as $gamme){

                foreach($garanties as $garantie){


                  if(isset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]) && isset($tarif['VITANEO RESP'][$garantie->libelle])) {

                $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['tarif'] = (float)$tarif['VITANEO RESP'][$garantie->libelle];

                }

              }

            }
            array_push($this->compagnies, $this->tabGaranties);
            }

  } 

  public function afps(Request $request){
          
         /*--=====================================
        =            Tarif cegema web service    =
        ======================================--*/
            
            //data générale
            $dateEffet          = $request->get('dateEffet');
            $exercice           = str_replace("-", "", $dateEffet);
            $exercice           = substr($exercice, 0, 4);
            $exercice           = $exercice - date('Y');
            if(substr($request->get('codepostale'), 0, 2) == '20'){

            $departement        =  20;
            }else{
             $departement        =  Sadepartement::where('code', substr($request->get('codepostale'), 0, 2))->first()->code;             
            }

            //data assuré
            $dateAssure         = $request->get('dateA');
            $regimeAssure       = $this->regimePereire($request->get('regimeA'));

            //data conjoint
            $dateConjoint       = $request->get('dateC');
            $regimeConjoint     = $this->regimePereire($request->get('regimeC'));

            //data enfants
            $nombreEnfants      = count($request->get('dateE'));

            //data groupe prestations
            $prestations        = $request->get('prestation');

            //cle
            $key = '$2y$10$mlrxsS8uM.85a5dfyCOYfuXhFXW5pC8yjGKXnpQb5LO5K.No9pj5K';
            $url = 'http://assistcall.net/tarificateur/public/api/azaf';

            if(!empty($dateConjoint)){

                $fields = array(
                  "cle=$key",
                  "exercice=$exercice",
                  "regimeA=$regimeAssure",
                  "dateA=$dateAssure",
                  "deptA=$departement",
                  "gamme_id=6",
                  "regimeC=$regimeConjoint",
                  "dateC=$dateConjoint",
                  "nb_enfant=$nombreEnfants"

              );

              }else{

              $fields = array(
                  "cle=$key",
                  "exercice=$exercice",
                  "regimeA=$regimeAssure",
                  "dateA=$dateAssure",
                  "deptA=$departement",
                  "gamme_id=6",
                  "nb_enfant=$nombreEnfants"
              );

              }

            $content     = file_get_contents($url.'?'.implode('&', $fields));
            $tarif      = json_decode($content, true);

             $gammes  = Sagamme::where('code','OSS')->get();

             if(count($tarif) > 1){
            $sansPrestation = $request->get('sansPrestation');
            $fichePoint     = $request->get('fichePoint');
            $this->initGarantie($gammes, $prestations, $sansPrestation, $fichePoint);

            if(count($gammes)>0){
              $this->tabGaranties['compagnie'][$gammes[0]->compagnie->libelle]['code'] = $gammes[0]->compagnie->code;
            }

            foreach($gammes as $gamme){

                foreach($gamme->garanties as $garantie){

                  if(isset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle])) {
                  
                   if(isset($tarif['OSALYS SENIORS 2'][$garantie->libelle])) {
                    $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['tarif'] = (float)$tarif['OSALYS SENIORS 2'][$garantie->libelle];
                   }else{
                     unset($this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]);
                   }
                

                }
              }

             
            }
            
            array_push($this->compagnies, $this->tabGaranties);
            }

  } 






  // traitement base de donnee

  public function fmaSante(Request $request) {
        
        $Enfantsregimes         = $request->input('dateE');

        //data groupe prestations
        $prestations        = $request->get('prestation');

        if(count($Enfantsregimes) > 0) {
          foreach($Enfantsregimes as $Enfantregime){

              $this->nombreEnfants++;
          }
        }

        $compagnie              = Sacompagnie::where('libelle','FMA SANTE')->first();
        $gammes                 = Sacompagnie::where('libelle','FMA SANTE')->first()->gamme;
        $sansPrestation = $request->get('sansPrestation');
        $fichePoint     = $request->get('fichePoint');
        $this->initGarantie($gammes, $prestations, $sansPrestation, $fichePoint);

        $this->tabGaranties['compagnie'][$compagnie->libelle]['code'] = $compagnie->code;

        foreach($gammes as $gamme){

          $gratuite               = $gamme->gratuiteEnfant;
          $exercice               = $request->input('exercice');
          $tabAge                 = [];
          $zone                   = $this->recupeZone($request->input('codepostale'), $gamme->id);
          $dateLimiteEnfant       = $gamme->ageEnfantLimite;
          

           $garanties = $this->recupererGaranties($gamme->id, $request->get('prestation') );
           //print_r($garanties);

          
          $tabTarif               = [];
          $dateC                  = $request->input('dateC');
          $nbrenfant              = $this->nombreEnfants;
          //age assure
          $dateA                  = $request->input('dateA');
          $ageA                   = $this->calculAge($exercice, $dateA);
          $regimeA                = $request->input('regimeA');
          $tabAge[]               = $ageA;
          $tarifs                 =   $this->calculTarifV($compagnie, $request, $exercice, $regimeA, $zone, $garanties, $dateLimiteEnfant, $nbrenfant, $gamme, $compagnie->libelle, $garanties);

      }

      array_push($this->compagnies, $this->tabGaranties);
}








    

     //correspondence régime april
     private function regimeApril($regime) {
      
      $regimes = [ 
                    1 => 'AlsaceMoselle', 
                    2 => 'Agricole', 
                    6 => 'Agricole', 
                    3 => 'TNS', 
                    4 => 'SS'
                 ];

      return array_has($regimes, $regime) ? array_get($regimes, $regime) : 0;
    }

     private function remplaceGamme($nom) {

      // if($nom == "NewFamily"){
      //   $nom = "Sante a la carte";
      // }
      // if($nom == "SantePro"){
      //   $nom = "Sante Globale";
      // }

      $fields = [
              "NewFamily"          => "Sante a la carte",
              "SantePro"           => "Sante Globale",
              "SanteProV2"         => "SanteProV2",
              "SanteEssentielPlus" => "SanteEssentielPlus",
              "SeniorPlusV2"       => "SeniorPlusV2"



      ];
     

      return array_has($fields, $nom) ? array_get($fields, $nom) : 0;
    }

  //correspondence régime smam
    private function regimeSmam($regime) {
      
      $regimes = [ 
                    1 => 'am', 
                    2 => 'agri', 
                    6 => 'agri', 
                    3 => 'tns', 
                    4 => 'ts'
                 ];

      return array_has($regimes, $regime) ? array_get($regimes, $regime) : 0;
    }

   

 //correspondence régime alptis
 private function regimeAlptis($regime) {
        
        $regimes = [ 
                      1 => 'AM', 
                      2 => 'SA', 
                      6 => 'SA', 
                      3 => 'TNS', 
                      4 => 'SS'
                   ];

        return array_has($regimes, $regime) ? array_get($regimes, $regime) : 0;
    }

    //correspondence régime alptis
 private function regimePereire($regime) {
        
        $regimes = [ 
                      1 => 4, 
                      2 => 3, 
                      6 => 3, 
                      3 => 2, 
                      4 => 1
                   ];

        return array_has($regimes, $regime) ? array_get($regimes, $regime) : 0;
    }



    // les fonctions
     public function initGarantieAlptis($garanties, $prestations) {

        $groupePrestations = Sagroupeprestation::where('visible', 1)->get();

        foreach ($garanties as $garantieAlptis) {

            foreach($garantieAlptis->gamme->garanties()->whereIn('id', $this->groupePrestationListGarantie($prestations))->get() as $garantie) {

                $this->tabGaranties['compagnie'][$garantie->gamme->compagnie->libelle]['gammes'][$garantie->gamme->libelle]['garanties'][$garantie->libelle]['tarif'] = 0;

                $this->tabGaranties['compagnie'][$garantie->gamme->compagnie->libelle]['gammes'][$garantie->gamme->libelle]['garanties'][$garantie->libelle]['description'] = '--';

                $this->tabGaranties['compagnie'][$garantie->gamme->compagnie->libelle]['gammes'][$garantie->gamme->libelle]['garanties'][$garantie->libelle]['logo']  = '/uploads/logo/APRIL.jpg';

                $this->tabGaranties['compagnie'][$garantie->gamme->compagnie->libelle]['gammes'][$garantie->gamme->libelle]['garanties'][$garantie->libelle]['id']    = $garantie->id;

                $this->tabGaranties['compagnie'][$garantie->gamme->compagnie->libelle]['gammes'][$garantie->gamme->libelle]['garanties'][$garantie->libelle]['codeGarantie'] = $garantie->code;

                $this->tabGaranties['compagnie'][$garantie->gamme->compagnie->libelle]['gammes'][$garantie->gamme->libelle]['garanties'][$garantie->libelle]['gid']   = $garantie->gamme->id;
                // ajouter par ayoub : groupeprestations

                $this->recupererGroupePrestationsParGarantie($garantie);

            // fin ajout



            } 
            // ajouter par ayoub : document

            $this->recupererDocuments($garantieAlptis->gamme);


        }
             // fin ajout

        return $this->tabGaranties;
    }

    




    public function initGarantie($gammes, $prestations, $sansOuAvecPrestation, $fichePoint) {

      $groupePrestations = Sagroupeprestation::where('visible', 1)->get();

      foreach ($gammes as $gamme) {

        if($sansOuAvecPrestation){
          $garantiesvoulu = $gamme->garanties;

        }else{
          $garantiesvoulu = $gamme->garanties()->whereIn('id', $this->groupePrestationListGarantie($prestations, $fichePoint))->get();
        }


        $i = 0;
        foreach($garantiesvoulu as $garantie) {

          $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['tarif'] = 0;

          $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['description'] = '--';

          $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['libelle'] = $garantie->libelle;

          $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['logo'] = $gamme->compagnie->logo;

          $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['id'] = $garantie->id;

          $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['codeGarantie'] = $garantie->code;

          $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['cie_code'] = $gamme->compagnie->code;

          $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['gid'] = $gamme->id;

          $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][$garantie->libelle]['options'] = '';
          // ajouter par ayoub : groupeprestations

          $this->recupererGroupePrestationsParGarantie($garantie);

          // fin ajout

          $i = 1;


        } 
      // ajouter par ayoub : document

        if($i){
          $this->recupererDocuments($gamme);
        }


      }
             // fin ajout

      return $this->tabGaranties;
    }



    public function groupePrestationListGarantie($prestations, $fichePoint) {

      // $garanties = Sagarantie::whereHas('groupePrestationGarantie' , function($p) use ($prestations){
      //                               $p->where('sagroupeprestation_id', 10);
      //                               $p->whereBetween('valeur', [$prestations[0] - 99, $prestations[0]]);
      //                             })
      //                         ->whereHas('groupePrestationGarantie' , function($p) use ($prestations){
      //                               $p->where('sagroupeprestation_id', 2);
      //                               $p->whereBetween('valeur', [$prestations[1] - 99, $prestations[1]]);
      //                             })
      //                         ->whereHas('groupePrestationGarantie' , function($p) use ($prestations){
      //                               $p->where('sagroupeprestation_id', 3);
      //                               $p->whereBetween('valeur', [$prestations[2] - 99, $prestations[2]]);
      //                             })
      //                         ->whereHas('groupePrestationGarantie' , function($p) use ($prestations){
      //                               $p->where('sagroupeprestation_id', 4);
      //                               $p->whereBetween('valeur', [$prestations[3] - 99, $prestations[3]]);
      //                             })
      //                         //->with('groupePrestationGarantie')
      //                         ->distinct()
      //                         ->lists('id');

      $garanties  = Sagarantie::where('min_point', '<=', $fichePoint)->where('max_point', '>=', $fichePoint)->with('groupePrestationGarantie')->distinct()->lists('id');
      
      // $garanties = Groupeprestationgarantie::where(function($s) use ($prestations){
      //           $s->where('sagroupeprestation_id', 1);
      //           $s->whereBetween('valeur', [$prestations[0] - 99, $prestations[0]]);
      //         })->orWhere(function($o) use ($prestations){
      //           $o->where('sagroupeprestation_id', 2);
      //           $o->whereBetween('valeur', [$prestations[1] - 99, $prestations[1]]);
      //         })->orWhere(function($d) use ($prestations){
      //           $d->where('sagroupeprestation_id', 3);
      //           $d->whereBetween('valeur', [$prestations[2] - 99, $prestations[2]]);
      //         })->orWhere(function($h) use ($prestations){
      //           $h->where('sagroupeprestation_id', 4);
      //           $h->whereBetween('valeur', [$prestations[3] - 99, $prestations[3]]);
      //         })->distinct()->lists('sagarantie_id');
              
      return $garanties;
    }

    public function recupererDocuments($gamme) {
      
      $documents = documentgamme::where('sagamme_id',$gamme->id)->where('active',1)->get();
        if(empty($documents)){
             $docs = Sadocument::all();
             foreach($docs as $doc){
              $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['documents'][$doc->id] = ['libelle' => '', 'lien' => '', 'code' => ''];
              }
        }else{
      foreach($documents as $document){ 
            
              $doc = Sadocument::where('id', $document->sadocument_id)->first();
              $this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['documents'][$doc->id] = ['libelle' => $doc->libelle, 'lien' => $document->lien, 'code' => $doc->code];
           

            }
            }
              
    }

    public function recupererGroupePrestationsParGarantie($garantie) {
      
      $groupePrestations = Sagroupeprestation::where('visible', 1)->get();

       

      foreach($groupePrestations as $groupeprestation) {
        try{

              if(Groupeprestationgarantie::where('sagroupeprestation_id', $groupeprestation->id)->where('sagarantie_id', $garantie->id)->first()){

          $this->tabGaranties['compagnie'][$garantie->gamme->compagnie->libelle]['gammes'][$garantie->gamme->libelle]['garanties'][$garantie->libelle]['groupeprestation'][$groupeprestation->id]['valeur'] = Groupeprestationgarantie::where('sagroupeprestation_id', $groupeprestation->id)->where('sagarantie_id', $garantie->id)->first()->valeur;


            $this->tabGaranties['compagnie'][$garantie->gamme->compagnie->libelle]['gammes'][$garantie->gamme->libelle]['garanties'][$garantie->libelle]['groupeprestation'][$groupeprestation->id]['libelle'] = Sagroupeprestation::where('id', $groupeprestation->id)->first()->libelle;

            $this->tabGaranties['compagnie'][$garantie->gamme->compagnie->libelle]['gammes'][$garantie->gamme->libelle]['garanties'][$garantie->libelle]['groupeprestation'][$groupeprestation->id]['affichage'] = Groupeprestationgarantie::where('sagroupeprestation_id', $groupeprestation->id)->where('sagarantie_id', $garantie->id)->first()->libelle;
            }
          }catch(Exception $e){
            dd($e);
        }
         
      
    }
              
      
    }


    // ancien tarif fonction

    public function recupererGaranties($gamme, $valeur){
        return Sagarantie::where('sagamme_id', $gamme)
                    ->join('sagarantie_sagroupeprestation', 'sagarantie_id', '=', 'sagaranties.id')
                    ->join('sagroupeprestations', 'sagroupeprestations.id', '=', 'sagarantie_sagroupeprestation.sagroupeprestation_id')
                    ->where('sagroupeprestation_id', 10)->whereBetween('valeur', [($valeur[0] - 99),$valeur[0]])
                    ->where('sagroupeprestation_id', 2)->whereBetween('valeur', [($valeur[1] - 99),$valeur[1]])
                    ->where('sagroupeprestation_id', 3)->whereBetween('valeur', [($valeur[2] - 99),$valeur[2]])
                    ->where('sagroupeprestation_id', 4)->whereBetween('valeur', [($valeur[3] - 99),$valeur[3]])
                    ->select('sagaranties.libelle as libelleGarantie', 'sagaranties.id', 'sagaranties.code as code', 'sagamme_id', 'sagroupeprestation_id', 'sagarantie_id', 'valeur', 'sagroupeprestations.libelle', 'sagroupeprestations.description')
                    ->distinct()
                    ->get();
      // return Sagarantie::where('sagamme_id', $gamme)->get();
                    
    }


    public function calculAge($exercice, $dateN){
        $anneeassure             = explode('-', $dateN);
        $age                     = $exercice - $anneeassure[0];
        return $age;
    }

    public function calculTarifV($compagnie, $request, $exercice, $regime, $zone, $garanties, $dateLimiteEnfant, $nbrEnfant, $gamme, $compagnieLibelle, $garantiesObjet){

          

                if(empty($zone)){
                    return ;
                }
            $nbrEnfants             = $request->get('dateE');
            $conjoint               = $request->get('dateC');
            $codepostale             = $request->get('codepostale');

            //data groupe prestations
            $prestations          = $request->get('prestation');

            $garantiesPrestations = $this->groupePrestationListGarantie($prestations);
            //echo $garantiesPrestations;

            $garantiesGamme       = $gamme->garanties->lists('id');

            $compositionFamiliale   = $this->nombrePresonne($conjoint, $nbrEnfants, $gamme);
            $ageAssure              = $this->calculAge($request->get('exercice'), $request->get('dateA'));
            $zonee                 = DB::table('cie_zonier')->where('NUMCOM','like', $compagnie->code)->where('CODEDEPARTEMENT', substr($codepostale, 0, 2))->first();
            //echo $gamme->garanties->lists('id');


              $collection = collect($garantiesObjet->lists('id'));
              //echo $collection;
              $unique     = $collection->unique();
              //echo 'sazone_id : ' . $unique->values() . '<br />';
              $tarifs     =  Satarif::where('exercice', $exercice)
                                    ->whereIn('sagarantie_id', $gamme->garanties->lists('id'))
                                    ->where('zone','like', $zonee->ZONE)
                                    ->where('active', 1)
                                    ->where(function ($q) use ($request){
                                     $q->where(function($queryAssure) use ($request){
                                    if($request->has('dateA')){
                                        
                                        $ageAssure = $this->calculAge($request->get('exercice'), $request->get('dateA'));
                                            
                                            $queryAssure->orWhere('age', $ageAssure)->where('saregime_id', $request->get('regimeA'));
                                            }
                                        });
                                     $q->orWhere(function($queryConjoint) use ($request){
                                    if($request->has('dateC')){
                                        
                                        $ageC = $this->calculAge($request->get('exercice'), $request->get('dateC'));

                                       $queryConjoint->orWhere('age', $ageC)->where('saregime_id', $request->get('regimeC'));
                                    }
                                    });
                                        $q->orWhere(function($queryEnfant) use ($request){
                                    $enfants = $request->get('dateE');
                                    $nbr     = 0;
                                    if(count($enfants)> 0){ 
                                      foreach($enfants as $enfant){
                                          $count = 0;
                                          if(!empty($enfant)){
                                              $enfantregime         = explode('#', $enfant);
                                              $regimeEnfant   = $enfantregime[1];
                                              $dateE          = $enfantregime[0];
                                            
                                              if($regimeEnfant == 'P'){
                                                  $regimeEnfant = $request->get('regimeA');
                                              }elseif ( $regimeEnfant == 'C'){
                                                  $regimeEnfant = $request->get('regimeC');
                                              }
                                              $dateenfant         = $this->calculAge($request->get('exercice'), $dateE);
                                              if($dateenfant <= 19){
                                                  $queryEnfant->orWhere('age', 19)->where('saregime_id', $regimeEnfant);
                                                  
                                              }else{
                                                  $queryEnfant->orWhere('age', $dateenfant)->where('saregime_id', $regimeEnfant);
                                              }

                                              
                                          }
                                           $count++;
                                         
                                      }
                                    }
                                 

                                 });
                                    })->get();
                                     //print_r($tarifs);



                                    $total = 0;
                                     // echo '<pre>', $tarifs ,'</pre>';

                                    foreach($tarifs as $tarif){

                                        $total += $tarif->cotisation; 
                                    }

                                    //echo '<pre>', $total ,'</pre>';
                                    if($total == 0){
                                        
                                        return $total;
                                    }else{

                                // $this->initGarantie($garantiesObjet, $compagnieLibelle, $compagnie);

                                 $compteur = 0;
                                 
                                 foreach($tarifs as $tarif){
                                    if(!empty($compositionFamiliale)){
                                         $this->tabGaranties['compagnie'][$compagnieLibelle]['gammes'][$tarif->garantie->gamme->libelle]['garanties'][$tarif->garantie->libelle]['tarif'] += ($tarif->cotisation * $tarif->taux * $compositionFamiliale->taux);
                                        $compteur++;

                                    }else{
                                        $this->tabGaranties['compagnie'][$compagnieLibelle]['gammes'][$tarif->garantie->gamme->libelle]['garanties'][$tarif->garantie->libelle]['tarif'] += ($tarif->cotisation * $tarif->taux);

                                        $compteur++;
                                    }

                                    
                                 }

                        
        }
    }

    public function recupeZone($codepostale , $gammeId){
        
       
        $departement             =  Sadepartement::where('code', substr($codepostale, 0, 2))->first();
        $sagamme                   = Sagamme::find($gammeId);
        $zone                      = $departement->zones->where('sagamme_id', $gammeId)->first();
        return $zone;
        }

        public function nombrePresonne($dateConjoint, $dateEnfants, $gamme){
        $this->nombreAdultes     = 1; 
        $this->nombreEnfants     = 0; 
        if(!empty($dateConjoint)){
            $this->nombreAdultes++;
        }
        if(count($dateEnfants) > 0){
               foreach($dateEnfants as $dateEnfant){
                                if(!empty($dateEnfant)){
                                      $this->nombreEnfants++;

                                                       }
                                                   }
                                    }
        if($this->nombreEnfants > $gamme->gratuiteEnfant){
            $this->nombreEnfants = $gamme->gratuiteEnfant;
        }

        $composition = Compositionfamiliale::where('sagamme_id', $gamme->id)
                                            ->where('adulte', $this->nombreAdultes)
                                            ->where('nombre_enfant', $this->nombreEnfants)
                                            ->first();

        return $composition;

    }


        public function recupererGroupePrestationTarif(Request $request){  

        //$garantyIds = collect($request->get("garanties"))->pluck('id');


        $garantyIds  = $request->get('garantie');

        $garantyCodes= $request->get('codeGarantie');

        $tarifs      = $request->get('tarif');

        $objetProposition = $request->get('objetProposition');

        $Border           = $request->get('border');
        
        $garanties   = Sagarantie::whereIn('code', $garantyCodes)->with('gp')->get();

        $gps         = Sagroupeprestation::all();

        $prestations = Saprestation::all();



        $gar = [];
        $obj = [];
        $pre = [];

        $indice = 0;
        $src    = 0;
        
        foreach ($gps as $i => $gp) {

            $src = $indice;

            $obj[$src] = ['id' => $gp->id, 'tarifs' => $tarifs, 'libelle' => $gp->libelle, 'garanties' => [], 'backgroundColor' => '#D1D1D1', 'marginLeft' => '0px','idLigne'    => 'groupePrestation', 'type' => 0, 'button' => '<button  data-toggle="modal" data-uk-modal={target:"#modal_creation_prestation"} data-id="'.$gp->id.'" data-target="#myModal" v-on:click=editGamme(gamme)>+</button>', 'Border' => $Border];



            foreach ($garanties as $j => $garantie) {

                                $documents = documentgamme::where('sagamme_id',$garantie->gamme->id)->where('active',1)->get();
        if(empty($documents)){
             $docs = Sadocument::all();
             foreach($docs as $doc){
              $gar[$j]['documents']  = [
              'libelle' => '', 
              'lien' => '', 
              'code' => '',
              'codeGamme' => ''
              ];
              }
        }else{
          $count = 0;
      foreach($documents as $document){ 
            
              $doc = Sadocument::where('id', $document->sadocument_id)->first();
              $gar[$j]['documents'][$count]  = [
              'libelle' => $doc->libelle, 
              'lien' => url('/').'/'.$document->lien,  
              'code' => $doc->code,
              'codeGamme' => 'upload/proposition/TG/'.$garantie->gamme->code.'_'
              ];
           
              $count++;
            }
            }

                $gar[$j]['id']                  = $garantie->id;
                $gar[$j]['codeGarantie']        = $garantie->code;
                $gar[$j]['objetProposition']    = $objetProposition;
                $gar[$j]['garantie']            = $garantie->libelle;
                $gar[$j]['tarif']               = $tarifs[$garantie->code];
        
                foreach ($garantie->gp as $k => $value) {

                    if($value->pivot->sagroupeprestation_id == $gp->id){

                        $valeur  = $value->pivot->valeur;
                        
                    }

                }
                
                $gar[$j]['valeur']  = $valeur;

            }

            foreach ($prestations as $prestation) {

                if($prestation->sagroupeprestation_id == $gp->id){

                    foreach ($garanties as $j => $garantie){

                        $preGarantie     = Prestationgarantie::where('saprestation_id', $prestation->id)->where('sagarantie_id', $garantie->id)->first();

                        if($preGarantie && $prestation->sagroupeprestation_id == $gp->id){
                            
                            $gg[$j]['valeur'] = $preGarantie->libelle;

                        }else{

                            $gg[$j]['valeur'] = '-';
                            
                        }

                        $gg[$j]['id']                   = $garantie->id;
                        $gg[$j]['codeGarantie']        = $garantie->code;
                        $gg[$j]['garantie']             = $garantie->libelle;
                        $gg[$j]['tarif']                = $tarifs[$garantie->code];
                        
                        

                        foreach ($garantie->gp as $k => $value) {

                            if($value->pivot->sagroupeprestation_id == $gp->id){

                                $valeur = $value->pivot->valeur;
                                
                            }

                        }

                        $gar[$j]['valeur'] = '--';

                    }

                    $indice++;

                        $obj[$indice]       =  [   
                                                    'id'                => $prestation->id,
                                                    'libelle'           => $prestation->libelle,
                                                    'backgroundColor'   => '#FFFFFF',
                                                    'marginLeft'        => '80px',
                                                    'idLigne'           => 'prestation',
                                                    'type'              => 1,
                                                    'garanties'         => $gg,
                                                    'button'            => '',
                                                    'Border' => $Border
                                                ];

                }
                    
            }

            $obj[$src]['garanties'] = $gar;
            $indice++;

        }
        return $obj;
        //return view('sagroupeprestations.proposition',compact('obj', 'garanties')) ;

    }

public function aprilRenfort(Request $request) {


        $urlxml            = "https://wspartenaires.april.fr/Sante/Tarification.svc?wsdl";
        $xml               = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:obs="http://www.april.fr/APR/Exposition/Distribution/Sante"> ... </soapenv:Envelope>';
        $action            = 'http://www.april.fr/APR/Exposition/Distribution/Sante/ITarification/ObtenirTarifMultiple';
        $client            = new SoapClient($urlxml);
        $result            = $client->__doRequest($xml , $urlxml, $action, SOAP_1_2);

        //data générale
        $dateEffet         = $request->get('dateEffet');
        //dd($dateEffet);
        $codePostal        = $request->get('codepostale');

        //data assuré
        $dateAssure        = $request->get('dateA');
        //dd($dateAssure);
        $regimeAssure      = $this->regimeApril($request->get('regimeA'));

        //data conjoint
        $dateConjoint      = $request->get('dateC');
        //dd($dateConjoint);
        $regimeConjoint    = $this->regimeApril($request->get('regimeC'));

        //data enfants
        $enfantsData       = $request->get('dateE');

        //data groupe prestations
        $prestations       = $request->get('prestation');


       // $gammes            = Sacompagnie::where('libelle', 'april')->first()->gamme()->where('active',1)->get();

        $lib_gamme         = $request->get('lib_gamme');
        //dd($lib_gamme);
        $lib_garantie      = $request->get('lib_garantie');
        //dd($lib_garantie);
        $euro_malin        = $request->get('euro_malin');

        $wsApril                                            = new \stdClass();
        $wsApril->Licence                                   = "{3263DD2A-543A-45B7-9920-72F402EAA893}";
        $wsApril->Identite                                  = "CO:81116";
        $wsApril->IdentifiantTracabilite                    = "ecg";
        $wsApril->Projet                                    = new \stdClass();
        //$wsApril->Projet->CodeProduit                       = $this->remplaceGamme($gamme->libelle);
        $wsApril->Projet->CodeProduit                       = $lib_gamme;
        $wsApril->Projet->Assures                           = new \stdClass();

        //Assuré
        $wsApril->Projet->Assures->Assure[0]                    = new \stdClass();
        $wsApril->Projet->Assures->Assure[0]->Nom               = "premier";
        $wsApril->Projet->Assures->Assure[0]->Prenom            = "assure";
        $wsApril->Projet->Assures->Assure[0]->DateDeNaissance   = $dateAssure;
        $wsApril->Projet->Assures->Assure[0]->Type              = "AssurePrincipal";
        $wsApril->Projet->Assures->Assure[0]->RegimeObligatoire = $regimeAssure;

        //Conjoint
        if($dateConjoint){

        $wsApril->Projet->Assures->Assure[1]                    = new \stdClass();
        $wsApril->Projet->Assures->Assure[1]->Nom               = "second";
        $wsApril->Projet->Assures->Assure[1]->Prenom            = "assure";
        $wsApril->Projet->Assures->Assure[1]->DateDeNaissance   = $dateConjoint;
        $wsApril->Projet->Assures->Assure[1]->Type              = "Conjoint";
        $wsApril->Projet->Assures->Assure[1]->RegimeObligatoire = $regimeConjoint;

        }

        //Instances enfants
        if(count($enfantsData) > 0){
          
                
            $indice = ($dateConjoint) ? 2 : 1;

            $count  = 2;
            foreach($enfantsData as $enfantData){ 

              if($enfantData){
                //dd($enfantData);
                       
                  $enfant         = explode('#', $enfantData);
                  $regimeEnfant   = $enfant[1];
                  $dateEnfant     = $enfant[0];
                        
                        //régime enfant (Ayant droit P == Prospect, C == Conjoint)
                  $regimeEnfant = ($regimeEnfant == 'P') ? $regimeAssure : $regimeConjoint;
                  
                  //Instance enfant
                  $wsApril->Projet->Assures->Assure[$indice]                          = new \stdClass();
                  $wsApril->Projet->Assures->Assure[$indice]->Nom                     = "troisieme";
                  $wsApril->Projet->Assures->Assure[$indice]->Prenom                  = "assure";
                  $wsApril->Projet->Assures->Assure[$indice]->Type                    = "Enfant";
                  $wsApril->Projet->Assures->Assure[$indice]->DateDeNaissance         = $dateEnfant;
                  $wsApril->Projet->Assures->Assure[$indice]->RegimeObligatoire       = $regimeEnfant;
                        
                  $indice++;
                  $count++;
              }
            }
        }

        $wsApril->Projet->Client                                        = new \stdClass();
        $wsApril->Projet->Client->ActiviteProfessionnelle               = "Employe";
        $wsApril->Projet->Client->Adresse                               = new \stdClass();
        $wsApril->Projet->Client->Adresse->CodePostal                   = $codePostal;

        if($euro_malin)
        {
          $wsApril->Projet->Couvertures                                 = new \stdClass();
          $wsApril->Projet->Couvertures->Couverture                     = new \stdClass();

          if($lib_gamme == 'SanteEssentiellePlus')//tester si 2 euro malin ou eco essentiel plus
          $wsApril->Projet->Couvertures->Couverture->CodeGarantie       = "OptionEco";
          else
          $wsApril->Projet->Couvertures->Couverture->CodeGarantie       = "2eurosMalin";
        }
        
        $wsApril->Projet->DateEffet                                     = $dateEffet;



        $params                                                         = new \stdClass();

        $params->Demande = $wsApril;
        //dd($params);

        $response = $client->ObtenirTarifMultiple($params);
        //dd($response);

        if($response->ObtenirTarifMultipleResult->StatutMetier == 'SUCCES')
        {
            if(isset($response->ObtenirTarifMultipleResult->NiveauxCouverturePrincipale))
            {
              //$propositions = collect($response->ObtenirTarifMultipleResult->NiveauxCouverturePrincipale->NiveauCouverturePrincipale)->where('LibelleCommercial', $lib_garantie)->all();
              //dd($propositions);

              foreach($response->ObtenirTarifMultipleResult->NiveauxCouverturePrincipale->NiveauCouverturePrincipale as $cle => $donne) 
              {

                list($libelleGamme, $libelleGarantie) = explode(" - ", $donne->LibelleCommercial); 

                //var_dump($libelleGarantie);
                //dd($lib_garantie);

                  if($libelleGarantie == $lib_garantie)
                  {
                      //var_dump($libelleGarantie);
                      //dd($lib_garantie);
                    $euroMalin    = [
                            'libelle'    => '',
                            'cotisation' => '',
                            'options'    => []
                          ];

                          //var_dump($donne->LibelleCommercial);
                    if(is_array($donne->TarifsCouvertures->TarifCouverture) or ($donne->TarifsCouvertures->TarifCouverture instanceof Traversable))
                    {
                       //$this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][(string)$libelleGarantie]['tarif'] = $donne->TarifsCouvertures->TarifCouverture[0]->Tarif;

                       //$renforts                  = collect($donne->TarifsCouvertures->TarifCouverture)->slice(1)->toArray();
                      $renforts                     = $donne->TarifsCouvertures->TarifCouverture;

                      $firstElm                     = array_shift($renforts);
                       //dd($renforts);
                       $euroMalin['libelle']      = $libelleGarantie;
                       $euroMalin['cotisation']   = $donne->TarifsCouvertures->TarifCouverture[0]->Tarif;
                       $euroMalin['options']      = $renforts;

                    }
                    else
                    {
                      //$this->tabGaranties['compagnie'][$gamme->compagnie->libelle]['gammes'][$gamme->libelle]['garanties'][(string)$libelleGarantie]['tarif'] = $donne->TarifsCouvertures->TarifCouverture->Tarif;

                       $euroMalin['libelle']      = $libelleGarantie;
                       $euroMalin['cotisation']   = $donne->TarifsCouvertures->TarifCouverture->Tarif;
                       //$euroMalin['options']      = $renforts;

                    }

                    return collect($euroMalin);

                  }
                  
                    //********************************************
                    

                
              }//enf foreach
            }
            

         }//end if Business



  }//--====  End of Tarif april web service  ====-->


public function aprilRenfortOld(Request $request) {


     /*--=====================================
      =            Tarif april web service    =
      ======================================--*/

      //Initialiser le web service soap april
      $urlxml = "http://wspar51.april.fr/WSSante/WsSante.asmx?WSDL";
      $xml    = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:obs="http://www.april.fr/APR/Exposition/Distribution/Sante"> ... </soapenv:Envelope>';
      $action = 'http://www.april.fr/APR/Exposition/Distribution/Sante/ITarification/ObtenirTarif';
      $client = new SoapClient($urlxml);
      $result = $client->__doRequest($xml , $urlxml, $action, SOAP_1_2);
        
      //data générale
      $dateEffet         = str_replace("-", "", $request->get('dateEffet'));
      $codePostal        = $request->get('codepostale');

      //data assuré
      $dateAssure        = str_replace("-", "", $request->get('dateA'));
      $regimeAssure      = $this->regimeApril($request->get('regimeA'));

      //data conjoint
      $dateConjoint      = str_replace("-", "", $request->get('dateC'));
      $regimeConjoint    = $this->regimeApril($request->get('regimeC'));

      //data enfants
      $enfantsData       = $request->get('dateE');

      //data groupe prestations
      $prestations       = $request->get('prestation');


      $gammes = Sacompagnie::where('libelle', 'april')->first()->gamme;

      $lib_gamme    = $request->get('lib_gamme');
      $lib_garantie = $request->get('lib_garantie');
      $euro_malin   = $request->get('euro_malin');
      
         
      //Instance web service april
      $wsApril                         = new \stdClass();
      $wsApril->astr_Clef              = "{3263DD2A-543A-45B7-9920-72F402EAA893}";
      $wsApril->TarifParams            = new \stdClass();
      $wsApril->TarifParams->IdCo      = "81116";
      $wsApril->TarifParams->Devis     = new \stdClass();

        
      //Instance assuré
      $wsApril->TarifParams->Devis->Assure[0]                              = new \stdClass();
      $wsApril->TarifParams->Devis->Assure[0]->Nom                         = "premier";
      $wsApril->TarifParams->Devis->Assure[0]->Prenom                      = "assure";
      $wsApril->TarifParams->Devis->Assure[0]->NumeroAssure                = 1;
      $wsApril->TarifParams->Devis->Assure[0]->Type                        = "Adherent";
      $wsApril->TarifParams->Devis->Assure[0]->DateNaissance               = $dateAssure;
      $wsApril->TarifParams->Devis->Assure[0]->RegimeObligatoire           = $regimeAssure;

      //Instance conjoint
      if($dateConjoint){

          $wsApril->TarifParams->Devis->Assure[1]                          = new \stdClass();
          $wsApril->TarifParams->Devis->Assure[1]->Nom                     = "second";
          $wsApril->TarifParams->Devis->Assure[1]->Prenom                  = "assure";
          $wsApril->TarifParams->Devis->Assure[1]->NumeroAssure            = 2;
          $wsApril->TarifParams->Devis->Assure[1]->Type                    = "Conjoint";
          $wsApril->TarifParams->Devis->Assure[1]->DateNaissance           = $dateConjoint;
          $wsApril->TarifParams->Devis->Assure[1]->RegimeObligatoire       = $regimeConjoint;
          
      } 

      //Instances enfants
      if(count($enfantsData) > 0){

        $indice = ($dateConjoint) ? 2 : 1;
            
        $count = 2;
        
        foreach($enfantsData as $enfantData){

          if($enfantData){ 
                   
              $enfant         = explode('#', $enfantData);
              $regimeEnfant   = $enfant[1];
              $dateEnfant     = str_replace("-", "", $enfant[0]);
                    
              //régime enfant (Ayant droit P == Prospect, C == Conjoint)
              $regimeEnfant = ($regimeEnfant == 'P') ? $regimeAssure : $regimeConjoint;
              
              //Instance enfant
              $wsApril->TarifParams->Devis->Assure[$indice]                          = new \stdClass();
              $wsApril->TarifParams->Devis->Assure[$indice]->Nom                     = "troisieme";
              $wsApril->TarifParams->Devis->Assure[$indice]->Prenom                  = "assure";
              $wsApril->TarifParams->Devis->Assure[$indice]->NumeroAssure            = $count + 1;
              $wsApril->TarifParams->Devis->Assure[$indice]->Type                    = "Enfant";
              $wsApril->TarifParams->Devis->Assure[$indice]->DateNaissance           = $dateEnfant;
              $wsApril->TarifParams->Devis->Assure[$indice]->RegimeObligatoire       = $regimeEnfant;
                    
              $indice++;
              $count++;

          }

        }

      }


      $wsApril->TarifParams->Devis->Parametres                        = new \stdClass();
      $wsApril->TarifParams->Devis->Parametres->DateEffet             = $dateEffet;
      $wsApril->TarifParams->Devis->Parametres->CodePostal            = $codePostal;
      $wsApril->TarifParams->Devis->Parametres->BesoinHospitalisation = '';
      $wsApril->TarifParams->Devis->Parametres->BesoinFraisMedicaux   = '';
      $wsApril->TarifParams->Devis->Parametres->BesoinDentaire        = '';
      $wsApril->TarifParams->Devis->Parametres->BesoinOptique         = '';
      $wsApril->TarifParams->Devis->Parametres->Produit               = $lib_gamme;
      $wsApril->TarifParams->Devis->Parametres->DeuxEurosMalins       = $euro_malin;
      $wsApril->TarifParams->Devis->Parametres->CreateurEntreprise    = true;
    
      try{

          $response     = $client->Tarif($wsApril);
          $propositions = collect($response->TarifResult->BusinessData->Proposition->PropositionOutput)->where('Garantie.GarantieOutput.Libelle', $lib_garantie)->all();
          
          $euroMalin    = [
                            'libelle'    => '',
                            'cotisation' => '',
                            'options'    => []
                          ];

          foreach ($propositions as $proposition) {
              $euroMalin['libelle']    = $proposition->Garantie->GarantieOutput->Libelle;
              $euroMalin['cotisation'] = $proposition->Garantie->GarantieOutput->CotisationMensuelle;
              $euroMalin['options']    = $proposition->OptionProduit->OptionProduitOutput;
          }

          return collect($euroMalin);
          //return json_encode($euroMalin);
          
      }
      catch(Exception $e){

        return $e;

      }



  }//--====  End of Tarif april web service  ====-->

}
